import 'dart:async';
import 'dart:io';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:share_plus/share_plus.dart';

class VeritabaniYardimcisi {
  static final VeritabaniYardimcisi _instance = VeritabaniYardimcisi._internal();
  static Database? _database;

  factory VeritabaniYardimcisi() => _instance;

  VeritabaniYardimcisi._internal();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    String path = join(await getDatabasesPath(), 'seray_saglik_asistanim.db');
    return await openDatabase(path, version: 1, onCreate: _onCreate);
  }

  Future _onCreate(Database db, int version) async {
    await db.execute('CREATE TABLE seker_olcumleri (id INTEGER PRIMARY KEY AUTOINCREMENT, deger INTEGER, durum TEXT, tarih TEXT)');
    await db.execute('CREATE TABLE tansiyon_olcumleri (id INTEGER PRIMARY KEY AUTOINCREMENT, buyuk INTEGER, kucuk INTEGER, nabiz INTEGER, tarih TEXT)');
    await db.execute('CREATE TABLE ilaclar (id INTEGER PRIMARY KEY AUTOINCREMENT, ad TEXT, dozaj TEXT, saat TEXT)');
    await db.execute('CREATE TABLE enabiz_tahlilleri (id INTEGER PRIMARY KEY AUTOINCREMENT, tarih TEXT, tahlil_adi TEXT, sonuc TEXT, referans_degeri TEXT)');
  }

  // --- WHATSAPP / BULUT YEDEKLEME SİHİRLİ FONKSİYONU ---
  Future<void> veritabaniYedekleHafizaya() async {
    String dbYolu = join(await getDatabasesPath(), 'seray_saglik_asistanim.db');
    File dbDosyasi = File(dbYolu);

    if (await dbDosyasi.exists()) {
      // Telefonda kayıtlı olan canlı .db dosyasını WhatsApp veya Google Drive ile paylaşım penceresine gönderir
      await Share.shareXFiles(
        [XFile(dbDosyasi.path, filename: 'seray_saglik_yedek.db')],
        text: 'Seray Sağlık Asistanım Güvenli Bulut Yedek Dosyası',
      );
    }
  }

  // --- "YEDEK BULUNDU" GERİ YÜKLEME SİHİRLİ FONKSİYONU ---
  Future<bool> yedegiGeriYukle(String secilenYedekYolu) async {
    try {
      if (_database != null) {
        await _database!.close();
        _database = null;
      }

      String asilDbYolu = join(await getDatabasesPath(), 'seray_saglik_asistanim.db');
      File yeniYedekDosyasi = File(secilenYedekYolu);
      
      // Gelen yedek dosyasını mevcut boş veritabanının üzerine yazar (WhatsApp mantığı)
      await yeniYedekDosyasi.copy(asilDbYolu);
      
      _database = await _initDatabase(); // Veritabanını yeniden canlandır
      return true;
    } catch (e) {
      return false;
    }
  }

  // Ölçüm Sorguları
  Future<int> sekerEkle(Map<String, dynamic> veri) async { Database db = await database; return await db.insert('seker_olcumleri', veri); }
  Future<List<Map<String, dynamic>>> sekerleriGetir() async { Database db = await database; return await db.query('seker_olcumleri', orderBy: 'tarih DESC'); }
  Future<int> tansiyonEkle(Map<String, dynamic> veri) async { Database db = await database; return await db.insert('tansiyon_olcumleri', veri); }
  Future<List<Map<String, dynamic>>> tansiyonlariGetir() async { Database db = await database; return await db.query('tansiyon_olcumleri', orderBy: 'tarih DESC'); }
  Future<int> ilacEkle(Map<String, dynamic> veri) async { Database db = await database; return await db.insert('ilaclar', veri); }
  Future<List<Map<String, dynamic>>> ilaclariGetir() async { Database db = await database; return await db.query('ilaclar', orderBy: 'id DESC'); }
  Future<int> ilacSil(int id) async { Database db = await database; return await db.delete('ilaclar', where: 'id = ?', whereArgs: [id]); }
  Future<int> tahlilEkle(Map<String, dynamic> veri) async { Database db = await database; return await db.insert('enabiz_tahlilleri', veri); }
  Future<List<Map<String, dynamic>>> tumTahlilleriGetir() async { Database db = await database; return await db.query('enabiz_tahlilleri', orderBy: 'tarih DESC'); }

  Future<void> veritabaniSifirla() async {
    Database db = await database;
    await db.delete('seker_olcumleri');
    await db.delete('tansiyon_olcumleri');
    await db.delete('ilaclar');
    await db.delete('enabiz_tahlilleri');
  }
}
