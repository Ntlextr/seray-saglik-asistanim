import 'package:flutter/material.dart';
import '../theme/renkler.dart';
import '../services/dil_servisi.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/veritabani_yardimcisi.dart';
import '../services/profil_yoneticisi.dart';
import '../services/profil_sabitleri.dart';
import '../services/pdf_rapor_servisi.dart';
import '../screens/ayarlar_ekrani.dart';
import '../screens/kullanim_kilavuzu_ekrani.dart';
import '../screens/profil_sayfasi.dart';
import '../screens/kutuphane_ekrani.dart';
import '../screens/gida_degisim_listesi_ekrani.dart';
import '../screens/rapor_ekrani.dart';
import '../screens/yardim_asistan_ekrani.dart';

class UstMenu extends StatelessWidget {
  const UstMenu({Key? key}) : super(key: key);

  // Ek Profil (Ana/varsayılan olmayan) kullanıcısı Yedekle'ye basınca hiç
  // sormadan SADECE KENDİ verisini yedekler. Ana Profil (admin) ise, birden
  // fazla profil varsa hangi profillerin dahil edileceğini seçmeli
  // kutucuklarla sorar.
  Future<void> _yedekle(BuildContext context) async {
    final py = ProfilYoneticisi();
    final aktifId = await py.aktifProfilId();
    if (aktifId != ProfilSabitleri.varsayilanProfilId) {
      await VeritabaniYardimcisi().veritabaniYedekleHafizaya(sadeceProfilIdleri: [aktifId]);
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(DilServisi.metin('buProfilinYedegiAlindi'))),
        );
      }
      return;
    }

    final tumProfiller = await py.profilleriGetir();
    if (tumProfiller.length <= 1) {
      await VeritabaniYardimcisi().veritabaniYedekleHafizaya();
      return;
    }
    if (!context.mounted) return;
    final secilenIdler = await showDialog<List<String>>(
      context: context,
      builder: (d) => _ProfilSecmeDialogu(
        baslik: DilServisi.metin('yedeklenecekProfiller'),
        profiller: [for (final p in tumProfiller) {'id': p.id, 'ad': p.ad}],
      ),
    );
    if (secilenIdler == null || secilenIdler.isEmpty) return;
    await VeritabaniYardimcisi().veritabaniYedekleHafizaya(sadeceProfilIdleri: secilenIdler);
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(DilServisi.metin('secilenProfillerinYedegiAlindi'))),
      );
    }
  }  // --- _yedekle() sonu ---

  // SADECE Ana Profil (admin) bu fonksiyona erişebilir (Ek Profillerin
  // menüsünde bu seçenek hiç görünmez). Seçilen zip'in İÇİNDE hangi
  // profillerin bulunduğu önce gösterilir, kullanıcı hangilerini geri
  // yüklemek istediğini seçmeli kutucuklarla belirler.
  Future<void> _yedekGeriYukle(BuildContext context) async {
    FilePickerResult? r = await FilePicker.platform.pickFiles();
    if (r == null || r.files.single.path == null) return;
    final yol = r.files.single.path!;

    List<Map<String, String>> icindekiler;
    try {
      icindekiler = await VeritabaniYardimcisi().yedekIcerigindekiProfilleriListele(yol);
    } catch (_) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(DilServisi.metin('dosyaOkunamadi'))),
        );
      }
      return;
    }
    if (icindekiler.isEmpty) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(DilServisi.metin('zipteProfilBulunamadi'))),
        );
      }
      return;
    }

    List<String> secilecekIdler;
    if (icindekiler.length == 1) {
      secilecekIdler = [icindekiler.first['id']!];
    } else {
      if (!context.mounted) return;
      final secim = await showDialog<List<String>>(
        context: context,
        builder: (d) => _ProfilSecmeDialogu(
          baslik: DilServisi.metin('geriYuklenecekProfiller'),
          profiller: icindekiler,
        ),
      );
      if (secim == null || secim.isEmpty) return;
      secilecekIdler = secim;
    }

    final basarili = await VeritabaniYardimcisi().yedegiGeriYukle(yol, sadeceProfilIdleri: secilecekIdler);
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(basarili ? DilServisi.metin('secilenProfillerGeriYuklendi') : DilServisi.metin('yedekYuklenemedi')),
      ));
    }
  }  // --- _yedekGeriYukle() sonu ---

  Future<void> _gunlukSonuclar(BuildContext context) async {
    final ad = (await ProfilYoneticisi().aktifProfil()).ad;
    await PdfRaporServisi.gunlukRaporuOlusturVePaylas(kullaniciAdi: ad);
  }  // --- _gunlukSonuclar() sonu ---

  Future<void> _cikisYap(BuildContext context) async {
    final onay = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(DilServisi.metin('cikisYap')),
        content: Text(DilServisi.metin('cikisOnay')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: Text(DilServisi.metin('vazgec'))),
          TextButton(onPressed: () => Navigator.pop(context, true), child: Text(DilServisi.metin('cikisYapBuyuk'))),
        ],
      ),
    );
    if (onay != true) return;
    SystemNavigator.pop();
  }  // --- _cikisYap() sonu ---

  // Özet ekranındaki ölçüm kartlarıyla AYNI stil: CircleAvatar + dolgun
  // (opak) pastel arka plan. Önceden renk.withOpacity(...) kullanıyordu —
  // bu, beyaz zeminle karışınca soluk/"cansız" duruyordu. Artık gerçek
  // pastel bir zemin (shade50) + tam doygun ikon rengi (shade700) kullanıyor,
  // Özet'teki kadar canlı.
  Widget _satir(IconData ikon, MaterialColor renk, String baslik) {
    return Row(
      children: [
        CircleAvatar(
          radius: 19,
          backgroundColor: renk.shade50,
          child: Icon(ikon, color: renk.shade700, size: 20),
        ),
        const SizedBox(width: 12),
        Text(baslik, style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 14)),
      ],
    );
  }  // --- _satir() sonu ---

  Future<void> _menuyuAc(BuildContext context) async {
    final RenderBox buton = context.findRenderObject() as RenderBox;
    final RenderBox overlay = Overlay.of(context).context.findRenderObject() as RenderBox;
    final konum = RelativeRect.fromRect(
      Rect.fromPoints(
        buton.localToGlobal(Offset(0, buton.size.height), ancestor: overlay),
        buton.localToGlobal(buton.size.bottomRight(Offset.zero), ancestor: overlay),
      ),
      Offset.zero & overlay.size,
    );

    // AİLE TAKİBİ: "Yedek Bul ve Geri Yükle" SADECE Ana Profil'de (admin)
    // görünür — Ek Profillerde bu seçenek TAMAMEN GİZLENİR (kullanıcı
    // kararı: bir Ek Profil başka birinin yedeğini yanlışlıkla geri
    // yükleyemesin diye, o yetki sadece admin/Ana Profil'de). "Verileri
    // Yedekle" ise HERKESTE var ama Ek Profilde sadece kendini yedekler.
    final anaProfilMi = (await ProfilYoneticisi().aktifProfilId()) == ProfilSabitleri.varsayilanProfilId;

    // ÖNEMLİ DÜZELTME: Kullanıcı, 10 maddelik bu menünün açılınca telefon
    // ekranının çoğunu kaplayıp alt gezinme çubuğunu (Anasayfa/Analizler/
    // Seray AI/İlaçlarım/Beslenme) örttüğünü bildirdi. Menü yüksekliğine
    // ekran yüksekliğinin ~%55'i ile bir ÜST SINIR (constraints) kondu —
    // bu sınırı aşarsa Flutter otomatik olarak menünün İÇİNDE kaydırma
    // ekler, alt gezinme çubuğu her zaman görünür/tıklanabilir kalır.
    final ekranYuksekligi = MediaQuery.of(context).size.height;

    // DÜZELTME (22 Ağustos): "Yardım Asistanına Sor" eklenince liste 10
    // öğeye çıktı ve eski %55 sınırı artık ZAR ZOR yetiyordu — Flutter
    // içeride otomatik kaydırma ekliyordu ama görünür bir ipucu olmadığı
    // için son öğe "kayıp" görünüyordu. %72'ye çıkarıldı (bu cihazda
    // hâlâ ~250dp alt menüye yer bırakıyor) — artık normalde hiç
    // kaydırma gerekmeden hepsi sığıyor.
    final secim = await showMenu<String>(
      context: context,
      position: konum,
      color: Colors.white,
      constraints: BoxConstraints(maxHeight: ekranYuksekligi * 0.72),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      items: [
        PopupMenuItem(value: 'profil', height: 44, child: _satir(Icons.person, AppRenkleri.aktif, DilServisi.metin('profil'))),
        const PopupMenuDivider(height: 8),
        PopupMenuItem(value: 'gunluk_sonuc', height: 44, child: _satir(Icons.picture_as_pdf, Colors.orange, DilServisi.metin('gunlukSonuclariPaylas'))),
        PopupMenuItem(value: 'yedekle', height: 44, child: _satir(Icons.backup, Colors.indigo, anaProfilMi ? DilServisi.metin('verileriYedekle') : DilServisi.metin('buProfiliYedekle'))),
        if (anaProfilMi)
          PopupMenuItem(value: 'geri_yukle', height: 44, child: _satir(Icons.restore, Colors.indigo, DilServisi.metin('yedekBulGeriYukle'))),
        const PopupMenuDivider(height: 8),
        PopupMenuItem(value: 'kutuphane', height: 44, child: _satir(Icons.menu_book, Colors.teal, DilServisi.metin('bilgiKutuphanesi'))),
        PopupMenuItem(value: 'gida_degisim', height: 44, child: _satir(Icons.restaurant_menu, Colors.brown, DilServisi.metin('gidaDegisimListesi'))),
        PopupMenuItem(value: 'rapor_analizi', height: 44, child: _satir(Icons.description, Colors.blueGrey, DilServisi.metin('raporAnaliziBaslik'))),
        PopupMenuItem(value: 'ayarlar', height: 44, child: _satir(Icons.settings, Colors.grey, DilServisi.metin('ayarlarBaslik'))),
        PopupMenuItem(value: 'kilavuz', height: 44, child: _satir(Icons.help_outline, Colors.grey, DilServisi.metin('kullanmaKilavuzu'))),
        PopupMenuItem(value: 'yardim_asistan', height: 44, child: _satir(Icons.support_agent, Colors.deepPurple, DilServisi.metin('yardimAsistaninaSor'))),
      ],
    );

    if (secim == null || !context.mounted) return;
    switch (secim) {
      case 'profil':
        Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfilSayfasi()));
        break;
      case 'gunluk_sonuc':
        _gunlukSonuclar(context);
        break;
      case 'yedekle':
        _yedekle(context);
        break;
      case 'geri_yukle':
        _yedekGeriYukle(context);
        break;
      case 'kutuphane':
        Navigator.push(context, MaterialPageRoute(builder: (_) => const KutuphaneEkrani()));
        break;
      case 'gida_degisim':
        Navigator.push(context, MaterialPageRoute(builder: (_) => const GidaDegisimListesiEkrani()));
        break;
      case 'rapor_analizi':
        Navigator.push(context, MaterialPageRoute(builder: (_) => const RaporEkrani()));
        break;
      case 'ayarlar':
        Navigator.push(context, MaterialPageRoute(builder: (_) => const AyarlarEkrani()));
        break;
      case 'kilavuz':
        Navigator.push(context, MaterialPageRoute(builder: (_) => const KullanimKilavuzuEkrani()));
        break;
      case 'yardim_asistan':
        Navigator.push(context, MaterialPageRoute(builder: (_) => const YardimAsistanEkrani()));
        break;
    }
  }  // --- _menuyuAc() sonu ---

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Her ekranda çalışan, tek dokunuşluk çıkış butonu
        IconButton(
          icon: const Icon(Icons.logout),
          tooltip: DilServisi.metin('cikisYap'),
          onPressed: () => _cikisYap(context),
        ),
        // Builder: bu ikonun tam konumunu alıp menüyü TAM ORADA açmak için
        Builder(
          builder: (menuContext) => IconButton(
            icon: const Icon(Icons.more_vert),
            tooltip: DilServisi.metin('menu'),
            onPressed: () => _menuyuAc(menuContext),
          ),
        ),
      ],
    );
  }  // --- build() sonu ---
}

// Hem "Yedeklenecek Profiller" (admin, çoklu profil varsa) hem "Geri
// Yüklenecek Profiller" (zip içeriği birden fazla profil içeriyorsa) için
// ortak, tekrar kullanılabilir seçmeli kutucuk penceresi. Başlangıçta
// TÜMÜ seçili gelir — kullanıcı istemediğini işaretinden kaldırır.
class _ProfilSecmeDialogu extends StatefulWidget {
  final String baslik;
  final List<Map<String, String>> profiller; // her biri {'id':..., 'ad':...}
  const _ProfilSecmeDialogu({required this.baslik, required this.profiller});

  @override
  State<_ProfilSecmeDialogu> createState() => _ProfilSecmeDialoguState();
}  // --- _ProfilSecmeDialogu sonu ---

class _ProfilSecmeDialoguState extends State<_ProfilSecmeDialogu> {
  late Set<String> _secili;

  @override
  void initState() {
    super.initState();
    _secili = widget.profiller.map((p) => p['id']!).toSet();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: Text(widget.baslik),
      content: SizedBox(
        width: double.maxFinite,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            for (final p in widget.profiller)
              CheckboxListTile(
                value: _secili.contains(p['id']),
                title: Text(p['ad'] ?? p['id']!),
                controlAffinity: ListTileControlAffinity.leading,
                onChanged: (deger) => setState(() {
                  if (deger == true) {
                    _secili.add(p['id']!);
                  } else {
                    _secili.remove(p['id']!);
                  }
                }),
              ),
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, <String>[]), child: Text(DilServisi.metin('vazgec'))),
        ElevatedButton(
          onPressed: _secili.isEmpty ? null : () => Navigator.pop(context, _secili.toList()),
          child: Text(DilServisi.metin('onayla')),
        ),
      ],
    );
  }  // --- build() sonu ---
}  // --- _ProfilSecmeDialoguState sonu ---
