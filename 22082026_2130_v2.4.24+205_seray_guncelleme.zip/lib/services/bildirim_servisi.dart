import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest_all.dart' as tz_data;
import 'dil_servisi.dart';
import 'package:android_intent_plus/android_intent.dart';
import '../navigasyon_anahtari.dart';
import '../screens/alarm_ekrani.dart';

// Uygulama tamamen kapalıyken "Ertele" butonuna basıldığında da çalışması
// için bu fonksiyon ayrı (top-level) ve @pragma ile işaretli olmak zorunda.
@pragma('vm:entry-point')
void bildirimArkaPlanYanitlandi(NotificationResponse yanit) {
  BildirimServisi._bildirimYanitlandi(yanit);
}

class BildirimServisi {
  static final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  static bool _hazir = false;

  static Future<void> baslat() async {
    if (_hazir) return;
    tz_data.initializeTimeZones();
    // Uygulama şu an için Türkiye saatine göre çalışıyor.
    tz.setLocalLocation(tz.getLocation('Europe/Istanbul'));

    const androidAyarlari = AndroidInitializationSettings('@mipmap/launcher_icon');
    const ayarlar = InitializationSettings(android: androidAyarlari);
    await _plugin.initialize(
      ayarlar,
      onDidReceiveNotificationResponse: _bildirimYanitlandi,
      onDidReceiveBackgroundNotificationResponse: bildirimArkaPlanYanitlandi,
    );

    final androidUygulama = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await androidUygulama?.requestNotificationsPermission();
    // Android 12+ cihazlarda hatırlatma alarmının tam zamanında çalması için
    // kullanıcıdan "Kesin Alarmlar" iznini iste (ayarlar ekranını açar).
    await androidUygulama?.requestExactAlarmsPermission();
    await androidUygulama?.createNotificationChannel(const AndroidNotificationChannel(
      'ilac_hatirlatma_kanali_v3',
      'İlaç Hatırlatmaları',
      description: 'Günlük ilaç saatlerinde çalan hatırlatmalar',
      importance: Importance.max,
      playSound: true,
      sound: UriAndroidNotificationSound('content://settings/system/notification_sound'),
      enableVibration: true,
    ));
    // Su hatırlatması İLAÇ alarmıyla AYNI kanalı/tam-ekran davranışını
    // KULLANMAMALI — ayrı, sıradan (kapatılabilir) bir bildirim kanalı.
    await androidUygulama?.createNotificationChannel(const AndroidNotificationChannel(
      'su_hatirlatma_kanali_v1',
      'Su İçme Hatırlatmaları',
      description: 'Günde birkaç kez su içmeyi hatırlatan nazik bildirimler',
      importance: Importance.defaultImportance,
      playSound: true,
    ));
    _hazir = true;
  }

  // "Ayarlar ekranındaki Kesin Alarm butonu kaldırıldı; izin zaten baslat()
  // içinde otomatik isteniyor. Bu fonksiyon yine de dışarıdan çağrılabilsin
  // diye duruyor (örn. ileride tekrar gerekirse).
  static Future<void> kesinAlarmIzniniIste() async {
    await baslat();
    final androidUygulama = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await androidUygulama?.requestExactAlarmsPermission();
  }

  // MIUI/HyperOS (Xiaomi/Redmi/POCO) cihazlarda "Otomatik Başlatma" izni
  // kapalıysa, telefon yeniden başladığında veya arka planda uygulama
  // öldürüldüğünde ilaç alarmları hiç çalmaz. Bu, MIUI'ye özel bir ekran
  // açar; desteklenmeyen cihazlarda genel uygulama ayarlarına yönlendirir.
  // MIUI/HyperOS sürümüne göre bu ekranın adresi DEĞİŞİYOR — tek bir kesin
  // intent yok. Bilinen birkaç adresi sırayla deniyoruz; hiçbiri
  // TUTMAZSA (istisna fırlatırsa VEYA fırlatmadan yanlış bir ekrana
  // düşerse) en azından Güvenlik uygulamasının KENDİSİNİ (spesifik bir
  // alt sayfa değil) açıyoruz — kullanıcı en azından doğru uygulamada
  // olur, karttaki elle yönlendirme metnini oradan takip edebilir.
  static Future<void> otomatikBaslatmaAyariniAc() async {
    final denenecekAdresler = [
      'com.miui.securitycenter/com.miui.permcenter.autostart.AutoStartManagementActivity',
      'com.miui.securitycenter/com.miui.autostart.AutoStartManagementActivity',
    ];
    for (final adres in denenecekAdresler) {
      try {
        final intent = AndroidIntent(
          action: 'android.intent.action.MAIN',
          componentName: adres,
        );
        await intent.launch();
        return;
      } catch (_) {
        // Bu adres tutmadı, sıradakini dene.
      }
    }
    // Hiçbiri tutmadıysa: doğrudan Güvenlik uygulamasının kendisini aç
    // (belirli bir alt ekranı hedeflemeden — bu, iç aktivite isimlerinin
    // sürümden sürüme değişmesine karşı en güvenilir yöntem).
    try {
      const guvenlikUygulamasi = AndroidIntent(
        action: 'android.intent.action.MAIN',
        package: 'com.miui.securitycenter',
      );
      await guvenlikUygulamasi.launch();
    } catch (_) {
      // Hiçbiri tutmadı — telefonun GENEL Ayarlar ana sayfasını aç.
      // Kullanıcı oradaki arama kutusuna "arka planda otomatik başlatma"
      // yazıp kendi telefonundaki doğru sayfayı bulabilir (marka/sürüme
      // göre bu sayfanın tam yeri değişebildiği için tek bir kesin intent
      // her cihazda güvenilir çalışmıyor — kartın üstündeki yazılı tarif
      // de bu adımı anlatıyor).
      try {
        const genelAyarlar = AndroidIntent(action: 'android.settings.SETTINGS');
        await genelAyarlar.launch();
      } catch (_) {
        await uygulamaAyarlariniAc();
      }
    }
  }  // --- otomatikBaslatmaAyariniAc() sonu ---

  // Kilit ekranında gösterme ve arka planda açılır pencere gibi izinler
  // MIUI'de "Diğer izinler" altında, üreticiye göre değişen bir ekranda
  // olduğu için tek bir kesin intent yerine genel Uygulama Bilgisi
  // sayfasına yönlendirip kullanıcıyı orada yönlendiriyoruz.
  static Future<void> uygulamaAyarlariniAc() async {
    try {
      const intent = AndroidIntent(
        action: 'android.settings.APPLICATION_DETAILS_SETTINGS',
        data: 'package:com.serayteknoloji.saglik_asistanim',
      );
      await intent.launch();
    } catch (_) {
      // Sessizce geç.
    }
  }

  // MIUI/HyperOS ve benzeri Android arayüzlerinde uygulama arka planda
  // öldürülmesin diye pil optimizasyonundan muaf tutulması için sistem
  // izin ekranını açar. Zaten izin verilmişse sistem hiçbir şey göstermez.
  static Future<void> pilOptimizasyonuGorMezdenGel() async {
    try {
      const intent = AndroidIntent(
        action: 'android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS',
        data: 'package:com.serayteknoloji.saglik_asistanim',
      );
      await intent.launch();
    } catch (_) {
      // Bazı cihazlarda bu ekran desteklenmeyebilir; sessizce geç.
    }
  }

  // ÖNEMLİ DÜZELTME: MIUI'de bildirim İÇİNDEKİ Ertele/Kapat yazı butonları
  // güvenilir şekilde tetiklenmiyor (kullanıcı doğruladı — dokununca hiçbir
  // tepki yok). Bu yüzden action butonları TAMAMEN kaldırıldı; artık TEK
  // yol var: bildirimin gövdesine dokununca tam ekran İçtim/Atladım
  // penceresi açılıyor (bu yol MIUI'de de güvenilir çalışıyor).
  static void _bildirimYanitlandi(NotificationResponse yanit) async {
    // Su hatırlatması sıradan bir bildirimdir — İlaç alarmının tam ekran
    // açma mantığına HİÇ girmemeli, sadece kendiliğinden kapanır.
    if (yanit.payload == 'su_hatirlatma') return;
    _alarmEkraniniAcPayload(yanit.id ?? 0, yanit.payload);
  }

  // ÖNEMLİ: payload normalde "İlaçAdı|Tip" biçiminde taşınıyor (ör.
  // "NovoRapid|İnsülin") — böylece bildirim/TTS metni türe göre doğru
  // kelimeyi ("ilacınızı"/"insülininizi") üretebiliyor. ERTELE'den gelen
  // bildirimlerde ÜÇÜNCÜ bir parça daha var: "İlaçAdı|Tip|OrijinalId" —
  // çünkü ertelenen bildirimin SİSTEM id'si (erteleId = id+500000) artık
  // ilacın gerçek veritabanı id'sinden FARKLI (çakışmasın diye) — bu yüzden
  // hangi ilaca ait olduğunu payload'daki orijinal id'den okumak gerekiyor,
  // yoksa İçtim/Atladım yanlış (var olmayan) bir id'ye kaydedilir. Eski/eksik
  // payload'larda (örn. "|" yoksa) güvenli şekilde Hap davranışına düşer.
  static (String, String, int?) _payloadAyristir(String? payload) {
    final ham = payload ?? 'İlaç';
    final parcalar = ham.split('|');
    final ad = parcalar.isNotEmpty ? parcalar[0] : 'İlaç';
    final tur = parcalar.length > 1 ? parcalar[1] : 'Hap';
    final orijinalId = parcalar.length > 2 ? int.tryParse(parcalar[2]) : null;
    return (ad, tur, orijinalId);
  }  // --- _payloadAyristir() sonu ---

  static void _alarmEkraniniAcPayload(int sistemId, String? payload) {
    final ayrisik = _payloadAyristir(payload);
    // Ertelenmiş bir bildirimse payload'daki orijinal ilaç id'sini kullan
    // (DB/geçmiş/yeniden-kurma için), ama İPTAL ETMEK için hâlâ bildirimin
    // KENDİ sistem id'si (sistemId — ertelenmişse erteleId) lazım, çünkü
    // ekranda o an ÇALAN bildirim odur, orijinal id değil.
    _alarmEkraniniAc(ayrisik.$3 ?? sistemId, ayrisik.$1, tur: ayrisik.$2, sistemId: sistemId);
  }  // --- _alarmEkraniniAcPayload() sonu ---

  static void _alarmEkraniniAc(int id, String ilacAdi, {String tur = 'Hap', int? sistemId}) {
    final baglam = navigasyonAnahtari.currentState;
    if (baglam == null) return;
    baglam.push(MaterialPageRoute(
      builder: (_) => AlarmEkrani(bildirimId: id, sistemBildirimId: sistemId ?? id, ilacAdi: ilacAdi, ilacTuru: tur),
      fullscreenDialog: true,
    ));
  }

  // Uygulama bir bildirime dokunularak (tamamen kapalıyken) açıldıysa bunu
  // yakalar. main.dart, ilk kare çizildikten sonra bunu çağırır.
  static Future<void> baslangicBildirimineBak() async {
    final detaylar = await _plugin.getNotificationAppLaunchDetails();
    if (detaylar != null && detaylar.didNotificationLaunchApp) {
      final yanit = detaylar.notificationResponse;
      if (yanit != null && yanit.payload != 'su_hatirlatma') {
        _alarmEkraniniAcPayload(yanit.id ?? 0, yanit.payload);
      }
    }
  }

  // ÖNEMLİ DÜZELTME: Kullanıcı "bildirim penceresi şimdikinden büyük olsun"
  // dedi — Android varsayılan olarak bildirimleri KÜÇÜK/tek satır gösterir.
  // BigTextStyleInformation ile bildirim ZATEN AÇILMIŞ (genişletilmiş) hâlde
  // görünür — daha büyük, daha okunaklı, ilaç adı ve mesaj net seçilir.
  static NotificationDetails _bildirimDetaylari({String bildirimMetni = '', String baslik = '💊 İlaç Zamanı'}) {
    return NotificationDetails(
      android: AndroidNotificationDetails(
        'ilac_hatirlatma_kanali_v3',
        'İlaç Hatırlatmaları',
        channelDescription: 'Günlük ilaç saatlerinde çalan hatırlatmalar',
        importance: Importance.max,
        priority: Priority.high,
        playSound: true,
        fullScreenIntent: true,
        ongoing: true, // kaydırarak kapatılamasın — sadece dokunup tam ekrandan cevap verilince kapanır
        autoCancel: false,
        // FLAG_INSISTENT: cevap verilene kadar ses/titreşim tekrar eder (alarm mantığı)
        additionalFlags: Int32List.fromList(<int>[4]),
        styleInformation: bildirimMetni.isNotEmpty
            ? BigTextStyleInformation(
                bildirimMetni,
                htmlFormatBigText: false,
                contentTitle: baslik,
                htmlFormatContentTitle: false,
              )
            : null,
        // ÖNEMLİ DÜZELTME: MIUI'de bildirim içi Ertele/Kapat action
        // butonları güvenilir tetiklenmiyordu (kullanıcı doğruladı) —
        // butonlar TAMAMEN kaldırıldı. Tek yol: bildirimin gövdesine
        // dokununca tam ekran İçtim/Atladım açılıyor, orası güvenilir.
      ),
    );
  }

  // Her gün aynı saatte tekrar eden ilaç alarmı kurar. id olarak ilacın
  // veritabanındaki id'si kullanılır, böylece silinince/düzenlenince eşleşir.
  static Future<void> ilacHatirlaticisiKur({required int id, required String ilacAdi, required TimeOfDay saat, String tip = 'Hap'}) async {
    await baslat();
    final simdi = tz.TZDateTime.now(tz.local);
    var hedef = tz.TZDateTime(tz.local, simdi.year, simdi.month, simdi.day, saat.hour, saat.minute);
    if (hedef.isBefore(simdi)) hedef = hedef.add(const Duration(days: 1));

    // ÖNEMLİ: Kullanıcı istedi — bildirim türe göre "ilacınızı" / "insülininizi"
    // demeli. Başlık da türe göre değişiyor.
    final insulinMi = tip == 'İnsülin';
    final kelime = insulinMi ? DilServisi.metin('bildirimInsulininizi') : DilServisi.metin('bildirimIlacinizi');
    final baslikEmoji = insulinMi ? '💉' : '💊';
    final baslik = '$baslikEmoji ${insulinMi ? DilServisi.metin('insulinKelime') : DilServisi.metin('bildirimIlac')} ${DilServisi.metin('bildirimZamani')}: $ilacAdi';
    final metin = '$ilacAdi $kelime ${DilServisi.metin('bildirimAlmayiUnutmayin')}';

    await _plugin.zonedSchedule(
      id,
      baslik,
      metin,
      hedef,
      _bildirimDetaylari(bildirimMetni: metin, baslik: baslik),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      matchDateTimeComponents: DateTimeComponents.time, // her gün aynı saatte tekrar eder
      uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
      payload: '$ilacAdi|$tip',
    );
  }

  // YENİ (22 Ağustos): İlaç bildirimleri "ongoing:true" (kaydırarak
  // kapatılamaz) olduğu için, kullanıcı yanıt vermezse SİSTEM BİLDİRİM
  // ÇEKMECESİNDE birikirler — Android launcher bunu uygulama ikonunda bir
  // rakam (badge) olarak gösterir. Kullanıcı bunu fark edip "uygulamayı
  // açınca bunları listeleyip gösterelim" istedi. Sadece İLAÇ kanalındaki
  // (su/haftalık özet DEĞİL — onlar zaten autoCancel:true, kalıcı değiller)
  // aktif bildirimleri döndürür.
  static Future<void> iptalEt(int id) async {
    await baslat();
    await _plugin.cancel(id);
  }

  // YENİ (22 Ağustos): İlaç bildirimleri "ongoing:true" (kaydırarak
  // kapatılamaz) olduğu için, kullanıcı yanıt vermezse SİSTEM BİLDİRİM
  // ÇEKMECESİNDE birikirler — Android launcher bunu uygulama ikonunda bir
  // rakam (badge) olarak gösterir. Kullanıcı bunu fark edip "uygulamayı
  // açınca bunları listeleyip gösterelim" istedi. Sadece İLAÇ kanalındaki
  // (su/haftalık özet DEĞİL — onlar zaten autoCancel:true, kalıcı değiller)
  // aktif bildirimleri döndürür.
  static Future<List<ActiveNotification>> bekleyenIlacBildirimleriniGetir() async {
    await baslat();
    final androidUygulama = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    final tumAktifler = await androidUygulama?.getActiveNotifications() ?? [];
    return tumAktifler.where((b) => b.channelId == 'ilac_hatirlatma_kanali_v3').toList();
  }  // --- bekleyenIlacBildirimleriniGetir() sonu ---

  // --- ÇOKLU DOZ DESTEĞİ (22 Ağustos) ---
  // Bir ilaç günde 1-3 doz gerektirebilir. Her doz KENDİ bağımsız günlük
  // alarmına ihtiyaç duyar (aynı id'ye ikinci zonedSchedule çağrısı
  // birinciyi SİLER). Doz 0'ın kompozit id'si tam olarak ilacın veritabanı
  // id'sine EŞİT — bu, eski (tek dozlu) kayıtlarla ve zaten kurulu
  // alarmlarla GERİYE DÖNÜK TAM UYUMLULUK sağlıyor, hiçbir veri taşıma
  // gerekmiyor. Doz 1/2 için +10.000.000/+20.000.000 eklenir — bu, hem
  // ertele'nin kendi +500.000 kaymasından hem su hatırlatmalarının
  // 90001-90020 aralığından kesin olarak ayrık.
  static int dozBildirimId(int id, int dozIndex) => id + dozIndex * 10000000;

  // Kompozit bir bildirim id'sinden orijinal ilaç id'sini VE doz index'ini
  // geri çıkarır — bildirime dokunulunca (İçtim/Atladım/Ertele) hangi
  // ilacın hangi dozuna ait olduğunu bulmak için gerekli.
  static (int ilacId, int dozIndex) dozBilgisiCoz(int kompozitId) {
    final dozIndex = kompozitId ~/ 10000000;
    final ilacId = kompozitId % 10000000;
    return (ilacId, dozIndex);
  }

  // Veritabanındaki 'saat' alanı artık virgülle ayrılmış birden fazla
  // saat tutabiliyor (ör. "09:00,14:00,21:00") — TEK bir "HH:mm" de
  // (eski kayıtlar) geçerli, tek elemanlı liste olarak döner.
  static List<TimeOfDay> saatleriAyristir(String? saatMetni) {
    if (saatMetni == null || saatMetni.isEmpty) return [];
    final sonuc = <TimeOfDay>[];
    for (final parca in saatMetni.split(',')) {
      final p = parca.trim();
      if (!p.contains(':')) continue;
      final parcalar = p.split(':');
      final saat = int.tryParse(parcalar[0]);
      final dakika = int.tryParse(parcalar.length > 1 ? parcalar[1] : '0');
      if (saat != null && dakika != null) sonuc.add(TimeOfDay(hour: saat, minute: dakika));
    }
    return sonuc;
  }  // --- saatleriAyristir() sonu ---

  // Bir ilacın TÜM doz alarmlarını (en fazla 3) kurar. Önce olası eski
  // 3 doz slotunu iptal eder (dozaj sonradan azaltılmışsa fazlalık eski
  // alarm kalmasın diye), sonra SADECE verilen saatler kadar yeniden kurar.
  static Future<void> ilacTumAlarmlariKur({required int id, required String ilacAdi, required List<TimeOfDay> saatler, String tip = 'Hap'}) async {
    await baslat();
    for (int i = 0; i < 3; i++) {
      await _plugin.cancel(dozBildirimId(id, i));
    }
    for (int i = 0; i < saatler.length && i < 3; i++) {
      await ilacHatirlaticisiKur(id: dozBildirimId(id, i), ilacAdi: ilacAdi, saat: saatler[i], tip: tip);
    }
  }  // --- ilacTumAlarmlariKur() sonu ---

  // Bir ilacın (alarm kapatıldığında veya silindiğinde) TÜM doz
  // alarmlarını iptal eder.
  static Future<void> ilacTumAlarmlariIptalEt(int id) async {
    await baslat();
    for (int i = 0; i < 3; i++) {
      await _plugin.cancel(dozBildirimId(id, i));
    }
  }  // --- ilacTumAlarmlariIptalEt() sonu ---

  // DÜZELTME (22 Ağustos): İlaç alarmları eskiden SADECE ekleme/düzenleme
  // anında bir kez kuruluyordu — su hatırlatıcılarının aksine (bkz.
  // suHatirlaticilariniKur, su_kilo_ekrani her açıldığında yeniden
  // çağırıyor) hiçbir "kendi kendini onarma" mekanizması yoktu. MIUI gibi
  // agresif pil/arka plan yönetimi olan cihazlarda sistem, kesin alarmı
  // sessizce iptal edebiliyor — bu durumda kullanıcı ilacı tekrar
  // düzenlemedikçe alarm bir daha hiç çalmıyordu (kullanıcının bildirdiği
  // "ilaç var ama bildirim gelmiyor" şikayetinin en olası kök nedeni).
  // Artık İlaçlarım ekranı her açıldığında (su ekranıyla aynı desende)
  // TÜM aktif ilaçların alarmları sessizce yeniden kuruluyor — zaten doğru
  // çalışan bir alarmı yeniden kurmak zararsız (aynı id ile üzerine yazar).
  static Future<void> tumIlacHatirlaticilariniYenidenKur(List<Map<String, dynamic>> ilaclar) async {
    for (final ilac in ilaclar) {
      try {
        final id = int.tryParse(ilac['id'].toString());
        if (id == null) continue;
        // alarm_var_mi eski kayıtlarda NULL olabilir — NULL/1 = alarm açık
        // (geriye dönük uyumluluk için varsayılan davranış), sadece
        // açıkça '0' ise alarm kapalı.
        final alarmVarMiDeger = ilac['alarm_var_mi'];
        final alarmKapali = alarmVarMiDeger != null && alarmVarMiDeger.toString() == '0';
        if (alarmKapali) {
          await ilacTumAlarmlariIptalEt(id);
          continue;
        }
        final saatler = saatleriAyristir(ilac['saat']?.toString());
        if (saatler.isEmpty) continue;
        await ilacTumAlarmlariKur(
          id: id,
          ilacAdi: ilac['ad']?.toString() ?? '',
          saatler: saatler,
          tip: ilac['tip']?.toString() ?? 'Hap',
        );
      } catch (_) {
        // Tek bir ilaçta sorun olsa bile diğerlerinin kurulumunu engellemesin.
      }
    }
  }  // --- tumIlacHatirlaticilariniYenidenKur() sonu ---

  // ÖNEMLİ: Bildirimdeki Ertele butonu MIUI'de tetiklenmediği için
  // kaldırıldı — bu fonksiyon artık tam ekran İçtim/Atladım penceresindeki
  // "Ertele (10 dk)" seçeneğinden çağrılıyor. ÖNEMLİ DÜZELTME: artık AYNI
  // id yerine +500000 kaydırılmış AYRI bir id kullanıyor — eskiden aynı
  // id'yle kurulunca, az önce (alarm_ekrani.dart'ta) aynı id'ye yeniden
  // kurulan GÜNLÜK alarmın üzerine yazıp onu bozuyordu. Artık ikisi tamamen
  // bağımsız: günlük alarm kendi id'sinde dokunulmadan duruyor, erteleme
  // ayrı bir id'de tek seferlik çalışıyor.
  static Future<void> ertele({required int id, required String ilacAdi, required String tur}) async {
    await baslat();
    final erteleId = id + 500000;
    final insulinMi = tur == 'İnsülin';
    final kelime = insulinMi ? DilServisi.metin('bildirimInsulininizi') : DilServisi.metin('bildirimIlacinizi');
    final baslik = '${insulinMi ? "💉" : "💊"} ${insulinMi ? DilServisi.metin('insulinKelime') : DilServisi.metin('bildirimIlac')} ${DilServisi.metin('bildirimHatirlatmasiErtelendi')}';
    final metin = '$ilacAdi $kelime ${DilServisi.metin('bildirimAlmayiUnutmayin')}';
    await _plugin.zonedSchedule(
      erteleId,
      baslik,
      metin,
      tz.TZDateTime.now(tz.local).add(const Duration(minutes: 10)),
      _bildirimDetaylari(bildirimMetni: metin, baslik: baslik),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
      payload: '$ilacAdi|$tur|$id',
    );
  }  // --- ertele() sonu ---

  // --- SU İÇME HATIRLATMALARI ---
  // Sabit saatlerde günlük tekrarlayan bildirimler (ilaç hatırlatıcısıyla
  // AYNI mekanizma — zonedSchedule + matchDateTimeComponents.time). Gerçek
  // zamanlı "zaten içtiyse gösterme" mantığı native arka plan servisi
  // gerektirir (bkz. proje notları); bu yüzden sabit saatli + Özet
  // ekranındaki "akıllı" bant (sadece uygulama açıkken) birlikte kullanılıyor.
  // ID'ler 90001-90005 aralığında sabit — ilaç ID'leriyle (veritabanı
  // autoincrement, küçük sayılar) çakışmaz.
  static const List<int> suHatirlatmaIdleri = [90001, 90002, 90003, 90004, 90005];
  static const List<TimeOfDay> suHatirlatmaSaatleri = [
    TimeOfDay(hour: 10, minute: 0),
    TimeOfDay(hour: 13, minute: 0),
    TimeOfDay(hour: 16, minute: 0),
    TimeOfDay(hour: 19, minute: 0),
    TimeOfDay(hour: 21, minute: 0),
  ];

  // Su hatırlatması için SIRADAN bildirim: tam ekran açmaz, "ısrarcı" ses
  // tekrarı yok, kaydırarak kapatılabilir. İlaç alarmının aksine bu SADECE
  // nazik bir hatırlatma — kaçırılması hayati değil.
  static NotificationDetails _suBildirimDetaylari() {
    return const NotificationDetails(
      android: AndroidNotificationDetails(
        'su_hatirlatma_kanali_v1',
        'Su İçme Hatırlatmaları',
        channelDescription: 'Günde birkaç kez su içmeyi hatırlatan nazik bildirimler',
        importance: Importance.defaultImportance,
        priority: Priority.defaultPriority,
        playSound: true,
        autoCancel: true,
      ),
    );
  }  // --- _suBildirimDetaylari() sonu ---

  static Future<void> suHatirlaticilariniKur() async {
    await baslat();
    for (int i = 0; i < suHatirlatmaIdleri.length; i++) {
      final saat = suHatirlatmaSaatleri[i];
      final simdi = tz.TZDateTime.now(tz.local);
      var hedef = tz.TZDateTime(tz.local, simdi.year, simdi.month, simdi.day, saat.hour, saat.minute);
      if (hedef.isBefore(simdi)) hedef = hedef.add(const Duration(days: 1));
      await _plugin.zonedSchedule(
        suHatirlatmaIdleri[i],
        '💧 ${DilServisi.metin('suIcmeVakti')}',
        DilServisi.metin('suHatirlatmaMetni'),
        hedef,
        _suBildirimDetaylari(),
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        matchDateTimeComponents: DateTimeComponents.time,
        uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
        payload: 'su_hatirlatma',
      );
    }
  }  // --- suHatirlaticilariniKur() sonu ---

  static Future<void> suHatirlaticilariniIptalEt() async {
    await baslat();
    for (final id in suHatirlatmaIdleri) {
      await _plugin.cancel(id);
    }
  }  // --- suHatirlaticilariniIptalEt() sonu ---

  // --- HAFTALIK ÖZET BİLDİRİMİ ---
  // Her pazar akşamı 20:00'de tek bir hatırlatma — gerçek özet metni
  // (ortalama şeker, adım, su hedefi vb.) bildirimde DEĞİL, uygulama
  // içinde hesaplanıyor (ana_sayfa.dart / analizler_ekrani.dart), çünkü
  // bildirim arka planda tetiklendiğinde veritabanına erişmek ayrı bir
  // arka plan izolatı gerektirir — gereksiz karmaşıklık. Bildirim sadece
  // "bak" diyor, dokununca uygulama açılıyor, özet orada hazır bekliyor.
  static const int haftalikOzetBildirimId = 90020;

  static Future<void> haftalikOzetHatirlaticisiKur() async {
    await baslat();
    final simdi = tz.TZDateTime.now(tz.local);
    var hedef = tz.TZDateTime(tz.local, simdi.year, simdi.month, simdi.day, 20, 0);
    // DateTime.weekday: Pazartesi=1 ... Pazar=7
    while (hedef.weekday != DateTime.sunday || hedef.isBefore(simdi)) {
      hedef = hedef.add(const Duration(days: 1));
    }
    await _plugin.zonedSchedule(
      haftalikOzetBildirimId,
      '📊 Haftalık Özetiniz Hazır',
      'Bu hafta şeker, adım ve su takibinizin özetini görmek için dokunun.',
      hedef,
      _suBildirimDetaylari(),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      matchDateTimeComponents: DateTimeComponents.dayOfWeekAndTime,
      uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
      payload: 'haftalik_ozet',
    );
  }  // --- haftalikOzetHatirlaticisiKur() sonu ---

  static Future<void> haftalikOzetHatirlaticisiniIptalEt() async {
    await baslat();
    await _plugin.cancel(haftalikOzetBildirimId);
  }  // --- haftalikOzetHatirlaticisiniIptalEt() sonu ---
}
