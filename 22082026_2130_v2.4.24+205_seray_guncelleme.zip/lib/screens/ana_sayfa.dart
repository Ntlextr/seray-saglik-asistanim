import 'dart:async';
import '../theme/renkler.dart';
import '../theme/sablon.dart';
import '../services/dil_servisi.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'seker_ekle_ekrani.dart';
import 'tansiyon_ekle_ekrani.dart';
import 'su_kilo_ekrani.dart';
import 'beslenme_ekrani.dart';
import 'ilac_ekrani.dart';
import 'yapay_zeka_ekrani.dart';
import 'rapor_ekrani.dart';
import '../services/veritabani_yardimcisi.dart';
import '../services/adim_servisi.dart';
import '../services/widget_servisi.dart';
import '../services/bildirim_servisi.dart';
import '../widgets/ust_menu.dart';

class AnaSayfa extends StatefulWidget {
  const AnaSayfa({Key? key}) : super(key: key);

  @override
  _AnaSayfaState createState() => _AnaSayfaState();
}

class _AnaSayfaState extends State<AnaSayfa> {
  String _kullaniciAdi = "...";
  String _cinsiyet = "Bay";
  List<Map<String, dynamic>> _sonSekerler = [];
  List<Map<String, dynamic>> _sonTansiyonlar = [];
  int _bugunSuMl = 0;
  double? _sonKilo;
  int _bugunAdim = 0;
  Timer? _adimYenilemeTimer;
  static const int _gunlukSuHedefiMl = 2000;
  List<Map<String, dynamic>> _ilaclar = [];
  int _referansDisiSayisi = 0;

  // Widget ekleme bannerı — kullanıcı ekleyince veya kapatınca bir daha
  // görünmesin diye SharedPreferences'ta kalıcı olarak saklanıyor.
  bool _widgetBanneriGizli = false;

  // e-Nabız kartında dinamik "referans dışı" rozeti için — yapay_zeka_ekrani.dart
  // içindeki _refDisinda() ile AYNI mantık, o dosya değiştirilmeden burada
  // küçük bir kopyası kullanılıyor (o dosyaya dokunma riski alınmadı).
  bool _refDisindaMi(String deger, String ref) {
    if (ref.isEmpty || ref == '-') return false;
    final ilkSayiEslesme = RegExp(r'^-?[0-9]+([.,][0-9]+)?').firstMatch(deger.trim());
    if (ilkSayiEslesme == null) return false;
    final sayi = double.tryParse(ilkSayiEslesme.group(0)!.replaceAll(',', '.'));
    if (sayi == null) return false;
    final parcalar = ref.split(RegExp(r'[-–]'));
    if (parcalar.length < 2) return false;
    final min = double.tryParse(parcalar[0].trim().replaceAll(',', '.').replaceAll(RegExp(r'[^0-9.]'), ''));
    final maks = double.tryParse(parcalar[1].trim().replaceAll(',', '.').replaceAll(RegExp(r'[^0-9.]'), ''));
    if (min == null || maks == null) return false;
    return sayi < min || sayi > maks;
  }  // --- _refDisindaMi() sonu ---

  String _tarihiBicimlendir(String? isoTarih) {
    if (isoTarih == null) return '';
    final t = DateTime.tryParse(isoTarih);
    if (t == null) return isoTarih;
    String iki(int n) => n.toString().padLeft(2, '0');
    return '${iki(t.day)}.${iki(t.month)}.${t.year} ${iki(t.hour)}:${iki(t.minute)}';
  }

  // Bugün için henüz saati gelmemiş ilaçları, saate göre artan sırada
  // döndürür (en yakın olan önce) — Karşılama ekranındaki mantığın aynısı.
  // DÜZELTME (22 Ağustos, çoklu doz desteği): 'saat' artık virgülle
  // ayrılmış birden fazla saat tutabiliyor — her doz, kendi tek saatiyle
  // AYRI bir satır olarak "genişletiliyor" (ör. 3 dozlu bir ilaç burada
  // 3 ayrı satır olarak görünebilir), böylece geri kalan gösterim kodu
  // (ilac['saat']) hep TEK bir "HH:mm" beklediği gibi çalışmaya devam eder.
  List<Map<String, dynamic>> get _yaklasanIlaclar {
    final simdi = TimeOfDay.now();
    final simdiDakika = simdi.hour * 60 + simdi.minute;

    final genisletilmis = <Map<String, dynamic>>[];
    for (final ilac in _ilaclar) {
      // alarm_var_mi kapalıysa bu ilaç "Yaklaşan İlaçlarınız"da hiç görünmesin.
      final alarmVarMiDeger = ilac['alarm_var_mi'];
      if (alarmVarMiDeger != null && alarmVarMiDeger.toString() == '0') continue;
      for (final saat in BildirimServisi.saatleriAyristir(ilac['saat']?.toString())) {
        if ((saat.hour * 60 + saat.minute) > simdiDakika) {
          genisletilmis.add({...ilac, 'saat': '${saat.hour.toString().padLeft(2, '0')}:${saat.minute.toString().padLeft(2, '0')}'});
        }
      }
    }

    genisletilmis.sort((a, b) {
      final aParcalar = a['saat'].toString().split(':');
      final bParcalar = b['saat'].toString().split(':');
      final aDakika = (int.tryParse(aParcalar[0]) ?? 0) * 60 + (int.tryParse(aParcalar.length > 1 ? aParcalar[1] : '0') ?? 0);
      final bDakika = (int.tryParse(bParcalar[0]) ?? 0) * 60 + (int.tryParse(bParcalar.length > 1 ? bParcalar[1] : '0') ?? 0);
      return aDakika.compareTo(bDakika);
    });

    return genisletilmis;
  }  // --- _yaklasanIlaclar getter sonu ---

  @override
  void initState() {
    super.initState();
    _verileriTazele();
    AdimServisi.baslat();
    _adimYenilemeTimer = Timer.periodic(const Duration(seconds: 5), (_) async {
      final adim = await AdimServisi.bugunkuAdimGetir();
      if (mounted) setState(() => _bugunAdim = adim);
      WidgetServisi.guncelle(adim: adim, suMl: _bugunSuMl);
    });
  }

  @override
  void dispose() {
    _adimYenilemeTimer?.cancel();
    super.dispose();
  }

  Future<void> _verileriTazele() async {
    final prefs = await SharedPreferences.getInstance();
    final sekerler = await VeritabaniYardimcisi().sekerleriGetir();
    final tansiyonlar = await VeritabaniYardimcisi().tansiyonlariGetir();
    final bugunSu = await VeritabaniYardimcisi().bugunToplamSuGetir();
    final kiloKayitlari = await VeritabaniYardimcisi().kiloKayitlariniGetir();
    final ilaclar = await VeritabaniYardimcisi().ilaclariGetir();
    final tumTahliller = await VeritabaniYardimcisi().tumTahlilleriGetir();
    final refDisiSayisi = tumTahliller.where((t) {
      final sonuc = (t['sonuc'] ?? '').toString();
      final ref = (t['referans_degeri'] ?? '').toString();
      return _refDisindaMi(sonuc, ref);
    }).length;

    setState(() {
      // Hem profil_kayit_ekrani hem eski kayıt anahtarları kontrol ediliyor
      _kullaniciAdi = prefs.getString('kullanici_ad') ?? 
                       prefs.getString('user_ad') ?? 
                       "Kullanıcı";
      _cinsiyet = prefs.getString('kullanici_cinsiyet') ?? 
                  prefs.getString('user_cinsiyet') ?? 
                  "Bay";
                  
      _sonSekerler = sekerler;
      _sonTansiyonlar = tansiyonlar;
      _bugunSuMl = bugunSu;
      _sonKilo = kiloKayitlari.isNotEmpty ? (kiloKayitlari.first['kilo'] as num?)?.toDouble() : null;
      _ilaclar = ilaclar;
      _referansDisiSayisi = refDisiSayisi;
      _widgetBanneriGizli = prefs.getBool('widget_banneri_gizli') ?? false;
    });
    WidgetServisi.guncelle(adim: _bugunAdim, suMl: _bugunSuMl);
    // DÜZELTME (22 Ağustos): Ana Sayfa her açıldığında (kullanıcı belki
    // hiç İlaçlarım sekmesine girmiyor) tüm ilaç alarmlarını sessizce
    // yeniden kur — bkz. bildirim_servisi.dart'taki fonksiyon açıklaması.
    BildirimServisi.tumIlacHatirlaticilariniYenidenKur(ilaclar);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(
        shape: AppSablon.appBarSekli,
        clipBehavior: Clip.antiAlias,
        title: Text(DilServisi.metin('anaSayfaBaslik'), style: const TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: AppRenkleri.aktif,
        foregroundColor: Colors.white,
        elevation: 0,
        actions: const [UstMenu()],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // ESKİ MANTIK GERİ GETİRİLDİ: Kullanıcı isteği üzerine, tüm
              // verilerin Ana Sayfa'dan doğrudan büyük renkli butonlarla
              // girilebilmesi eski haline döndürüldü. Özet kartları
              // (Adım/Su/Kilo/Şeker/Tansiyon) ve "Hoşgeldin" karşılama
              // balonu artık Ana Sayfa'da DEĞİL — bunlar yeni, ayrı
              // Karşılama (hero) ekranına taşındı (bkz. karsilama_ekrani.dart).
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppRenkleri.aktif,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 18),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
                      ),
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => SekerEkleEkrani())).then((_) => _verileriTazele());
                      },
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.bloodtype, size: 26),
                          const SizedBox(height: 6),
                          Text(DilServisi.metin('sekerEkle'), textAlign: TextAlign.center, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppRenkleri.aktif.shade700,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 18),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
                      ),
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => TansiyonEkleEkrani())).then((_) => _verileriTazele());
                      },
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.favorite, size: 26),
                          const SizedBox(height: 6),
                          Text(DilServisi.metin('tansiyonEkle'), textAlign: TextAlign.center, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blue,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 18),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
                      ),
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => const SuKiloEkrani())).then((_) => _verileriTazele());
                      },
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.water_drop, size: 26),
                          const SizedBox(height: 6),
                          Text(DilServisi.metin('suKiloBaslik'), textAlign: TextAlign.center, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.orange,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 18),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
                      ),
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => const BeslenmeEkrani())).then((_) => _verileriTazele());
                      },
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.restaurant, size: 26),
                          const SizedBox(height: 6),
                          Text(DilServisi.metin('yemekEkle'), textAlign: TextAlign.center, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.redAccent,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 18),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
                      ),
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => const IlacEkrani())).then((_) => _verileriTazele());
                      },
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.medication, size: 26),
                          const SizedBox(height: 6),
                          Text(DilServisi.metin('ilacEkle'), textAlign: TextAlign.center, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),

              // e-NABIZ TAHLİLLERİM
              Material(
                color: AppRenkleri.aktif,
                borderRadius: BorderRadius.circular(14),
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const YapayZekaEkrani()),
                    ).then((_) => _verileriTazele());
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: Row(
                      children: [
                        const CircleAvatar(
                          radius: 18,
                          backgroundColor: Colors.white24,
                          child: Icon(Icons.picture_as_pdf, color: Colors.white, size: 20),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(DilServisi.metin('eNabizTahlillerim'), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
                              const SizedBox(height: 2),
                              Text(
                                _referansDisiSayisi > 0
                                    ? '⚠️ $_referansDisiSayisi ${DilServisi.metin('referansDisiSonucVar')}'
                                    : DilServisi.metin('eNabizAciklama'),
                                style: const TextStyle(color: Colors.white70, fontSize: 12),
                              ),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_right, color: Colors.white),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),

              // RAPOR ANALİZİ
              Material(
                color: AppRenkleri.aktif.shade700,
                borderRadius: BorderRadius.circular(14),
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const RaporEkrani()),
                    ).then((_) => _verileriTazele());
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: Row(
                      children: [
                        const CircleAvatar(
                          radius: 18,
                          backgroundColor: Colors.white24,
                          child: Icon(Icons.description, color: Colors.white, size: 20),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(DilServisi.metin('raporAnalizi'), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
                              const SizedBox(height: 2),
                              Text(DilServisi.metin('raporAciklama'), style: const TextStyle(color: Colors.white70, fontSize: 12)),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_right, color: Colors.white),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),

              // YAKLAŞAN İLAÇLARINIZ — Karşılama ekranındaki aynı bileşen,
              // Ana Sayfa'nın altındaki boş alanı doldurmak için buraya da
              // eklendi (kullanıcı isteği).
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.grey.shade200),
                ),
                child: _yaklasanIlaclar.isEmpty
                    ? Center(
                        child: Text(DilServisi.metin('bugunIcinIlacYok'), style: TextStyle(color: Colors.grey.shade500, fontSize: 13)),
                      )
                    : Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.medication_outlined, size: 16, color: AppRenkleri.aktif),
                              const SizedBox(width: 6),
                              Text(DilServisi.metin('yaklasanIlaclariniz'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                            ],
                          ),
                          const SizedBox(height: 8),
                          for (final ilac in _yaklasanIlaclar.take(3))
                            Padding(
                              padding: const EdgeInsets.symmetric(vertical: 4),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(ilac['saat']?.toString() ?? '', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: AppRenkleri.aktif.shade700)),
                                  Text(
                                    '${ilac['ad'] ?? ''}${(ilac['dozaj'] ?? '').toString().isNotEmpty ? ' ${ilac['dozaj']}' : ''}',
                                    style: const TextStyle(fontSize: 13),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                            ),
                        ],
                      ),
              ),
            ],
          ),
        ),
      ),
      // NOT: Alt navigasyon menüsü artık sadece main.dart'taki
      // AnaEkranYonlendirici içinde tek bir yerden yönetiliyor.
      // Burada ikinci bir bottomNavigationBar OLMAMALI, aksi halde
      // eski (Ana Sayfa/Şeker/Tansiyon/Profil) menü ile yeni
      // (Özet/Analizler/İlaçlarım/Profil) menü çakışır.
    );
  }
}
