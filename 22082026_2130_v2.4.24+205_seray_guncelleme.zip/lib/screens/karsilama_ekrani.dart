import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../theme/renkler.dart';
import '../services/dil_servisi.dart';
import '../services/veritabani_yardimcisi.dart';
import '../services/adim_servisi.dart';
import '../services/bildirim_servisi.dart';
import 'alarm_ekrani.dart';

// ============================================================================
// KARŞILAMA EKRANI — kullanıcının gönderdiği poster/mockup görseline göre
// tasarlandı. ÖNEMLİ: bu, Ana Sayfa'nın İÇİNE eklenen bir bölüm DEĞİL —
// Ana Sayfa'dan tamamen AYRI, kendi başına bir ekran. Uygulama açılışında
// (izin/PIN akışından sonra) SADECE BİR KEZ gösterilir, tek ekrana sığar
// (KAYDIRMA yok), sonra dokununca (ya da Seray AI bandına basınca) mevcut
// Ana Sayfa'ya (AnaEkranYonlendirici'ye) geçer. Ana Sayfa'nın kendisi
// eski, sade (büyük renkli butonlu) hâline döndürüldü — özet bilgilerin
// hepsi artık SADECE burada gösteriliyor.
// ============================================================================
class KarsilamaEkrani extends StatefulWidget {
  final Widget sonrakiEkran;
  const KarsilamaEkrani({Key? key, required this.sonrakiEkran}) : super(key: key);

  @override
  _KarsilamaEkraniState createState() => _KarsilamaEkraniState();
}

class _KarsilamaEkraniState extends State<KarsilamaEkrani> {
  String _kullaniciAdi = "...";
  String _cinsiyet = "Bay";
  List<Map<String, dynamic>> _sonSekerler = [];
  List<Map<String, dynamic>> _sonTansiyonlar = [];
  List<Map<String, dynamic>> _ilaclar = [];
  int _bugunAdim = 0;
  int _bugunSuMl = 0;
  double? _sonKilo;
  bool _yukleniyor = true;
  static const int _gunlukSuHedefiMl = 2000;
  // YENİ (22 Ağustos): Kullanıcı yanıt vermediği için sistem bildirim
  // çekmecesinde birikmiş (uygulama ikonundaki rakamla eşleşen) ilaç
  // bildirimleri — "Seray AI" bandı yerine burada gösterilecek.
  List<ActiveNotification> _bekleyenBildirimler = [];

  String get _hitap => DilServisi.dilKodu == 'en' ? '' : ((_cinsiyet == 'Bayan' || _cinsiyet == 'Kadın') ? 'Hanım' : 'Bey');

  String get _selamlama {
    final saat = DateTime.now().hour;
    if (saat >= 5 && saat < 12) return DilServisi.metin('selamlamaGunaydin');
    if (saat >= 12 && saat < 18) return DilServisi.metin('selamlamaIyiGunler');
    if (saat >= 18 && saat < 23) return DilServisi.metin('selamlamaIyiAksamlar');
    return DilServisi.metin('selamlamaIyiGeceler');
  }

  // DÜZELTME (22 Ağustos, çoklu doz desteği): Ana Sayfa'daki aynı mantık —
  // 'saat' artık virgülle ayrılmış birden fazla saat tutabiliyor, her doz
  // ayrı bir satır olarak genişletiliyor.
  List<Map<String, dynamic>> get _yaklasanIlaclar {
    final simdi = TimeOfDay.now();
    final simdiDakika = simdi.hour * 60 + simdi.minute;

    final genisletilmis = <Map<String, dynamic>>[];
    for (final ilac in _ilaclar) {
      final alarmVarMiDeger = ilac['alarm_var_mi'];
      if (alarmVarMiDeger != null && alarmVarMiDeger.toString() == '0') continue;
      for (final saat in BildirimServisi.saatleriAyristir(ilac['saat']?.toString())) {
        if ((saat.hour * 60 + saat.minute) > simdiDakika) {
          genisletilmis.add({...ilac, 'saat': '${saat.hour.toString().padLeft(2, '0')}:${saat.minute.toString().padLeft(2, '0')}'});
        }
      }
    }

    genisletilmis.sort((a, b) {
      final aParcalar = a['saat'].toString().split(':');
      final bParcalar = b['saat'].toString().split(':');
      final aDakika = (int.tryParse(aParcalar[0]) ?? 0) * 60 + (int.tryParse(aParcalar.length > 1 ? aParcalar[1] : '0') ?? 0);
      final bDakika = (int.tryParse(bParcalar[0]) ?? 0) * 60 + (int.tryParse(bParcalar.length > 1 ? bParcalar[1] : '0') ?? 0);
      return aDakika.compareTo(bDakika);
    });

    return genisletilmis;
  }  // --- _yaklasanIlaclar getter sonu ---

  @override
  void initState() {
    super.initState();
    _verileriYukle();
  }

  Future<void> _verileriYukle() async {
    final prefs = await SharedPreferences.getInstance();
    final sekerler = await VeritabaniYardimcisi().sekerleriGetir();
    final tansiyonlar = await VeritabaniYardimcisi().tansiyonlariGetir();
    final ilaclar = await VeritabaniYardimcisi().ilaclariGetir();
    final bugunSu = await VeritabaniYardimcisi().bugunToplamSuGetir();
    final kiloKayitlari = await VeritabaniYardimcisi().kiloKayitlariniGetir();
    await AdimServisi.baslat();
    final adim = await AdimServisi.bugunkuAdimGetir();
    final bekleyenler = await BildirimServisi.bekleyenIlacBildirimleriniGetir();
    if (!mounted) return;
    setState(() {
      _kullaniciAdi = prefs.getString('kullanici_ad') ?? prefs.getString('user_ad') ?? "Kullanıcı";
      _cinsiyet = prefs.getString('kullanici_cinsiyet') ?? prefs.getString('user_cinsiyet') ?? "Bay";
      _sonSekerler = sekerler;
      _sonTansiyonlar = tansiyonlar;
      _ilaclar = ilaclar;
      _bugunSuMl = bugunSu;
      _sonKilo = kiloKayitlari.isNotEmpty ? (kiloKayitlari.first['kilo'] as num?)?.toDouble() : null;
      _bugunAdim = adim;
      _bekleyenBildirimler = bekleyenler;
      _yukleniyor = false;
    });
  }  // --- _verileriYukle() sonu ---

  String _tarihiBicimlendir(String? isoTarih) {
    if (isoTarih == null) return '';
    final t = DateTime.tryParse(isoTarih);
    if (t == null) return isoTarih;
    String iki(int n) => n.toString().padLeft(2, '0');
    return '${iki(t.day)}.${iki(t.month)}.${t.year} ${iki(t.hour)}:${iki(t.minute)}';
  }

  // YENİ: Bekleyen bildirim kartına dokununca artık sadece ekranı kapatmıyor
  // (_devamEt), o bildirimin ait olduğu ilacın alarm/İçtim-Atladım ekranına
  // gidiyor. Sistem bildirim id'si önce normal günlük alarm (dozBilgisiCoz)
  // olarak, bulunamazsa ertelenmiş bildirim (erteleId = id+500000) olarak
  // çözülmeye çalışılır — hiçbiri eşleşmezse güvenli şekilde eski davranışa
  // (_devamEt) düşer.
  void _bekleyenBildirimeGit() {
    if (_bekleyenBildirimler.isEmpty) {
      _devamEt();
      return;
    }
    final sistemId = _bekleyenBildirimler.first.id ?? 0;

    Map<String, dynamic> ilacBul(int ilacId) => _ilaclar.firstWhere(
          (i) => int.tryParse(i['id'].toString()) == ilacId,
          orElse: () => <String, dynamic>{},
        );

    var cozulmus = BildirimServisi.dozBilgisiCoz(sistemId);
    var eslesenIlac = ilacBul(cozulmus.$1);
    if (eslesenIlac.isEmpty) {
      // Ertelenmiş bildirim olabilir — erteleId = orijinal id + 500000.
      cozulmus = BildirimServisi.dozBilgisiCoz(sistemId - 500000);
      eslesenIlac = ilacBul(cozulmus.$1);
    }
    if (eslesenIlac.isEmpty) {
      _devamEt();
      return;
    }

    Navigator.of(context)
        .push(MaterialPageRoute(
          builder: (_) => AlarmEkrani(
            bildirimId: cozulmus.$1,
            sistemBildirimId: sistemId,
            ilacAdi: eslesenIlac['ad']?.toString() ?? '',
            ilacTuru: eslesenIlac['tip']?.toString() ?? 'Hap',
          ),
          fullscreenDialog: true,
        ))
        .then((_) => _verileriYukle());
  }  // --- _bekleyenBildirimeGit() sonu ---

  void _devamEt() {
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (context) => widget.sonrakiEkran),
    );
  }  // --- _devamEt() sonu ---

  // Küçük, kompakt istatistik kartı — Adım/Su/Kilo için (poster tarzına
  // göre eklendi, kullanıcının "eski Ana Sayfa'daki özetler heroya
  // taşınsın" isteği üzerine).
  Widget _kompaktKart({required IconData ikon, required Color renk, required String etiket, required String deger}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(ikon, color: renk, size: 18),
          const SizedBox(height: 4),
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(deger, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
          ),
          Text(etiket, style: TextStyle(fontSize: 10, color: Colors.grey.shade500)),
        ],
      ),
    );
  }  // --- _kompaktKart() sonu ---

  @override
  Widget build(BuildContext context) {
    if (_yukleniyor) {
      return Scaffold(
        backgroundColor: AppRenkleri.aktif,
        body: const Center(child: CircularProgressIndicator(color: Colors.white)),
      );
    }

    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      body: SafeArea(
        // ÖNEMLİ: Bilinçli olarak SingleChildScrollView KULLANILMADI —
        // kullanıcı "mobil uygulamanın ilk ekranı kaydırılmaz" dedi,
        // bu ekran her zaman TEK ekrana sığmalı.
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 14, 20, 12),
          child: GestureDetector(
            onTap: _devamEt,
            behavior: HitTestBehavior.translucent,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Selamlama — kompakt, poster referansındaki gibi küçük
                // tek satır (önceki turda çok büyüktü, küçültüldü).
                Text(
                  '$_selamlama,',
                  style: TextStyle(fontSize: 14, color: Colors.grey.shade600),
                ),
                Text(
                  '$_kullaniciAdi${_hitap.isEmpty ? "" : " $_hitap"}',
                  style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold, color: Color(0xFF006655)),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 10),

                // Adım / Su / Kilo — kompakt, yan yana 3 küçük kart
                Expanded(
                  flex: 2,
                  child: Row(
                    children: [
                      Expanded(child: _kompaktKart(ikon: Icons.directions_walk, renk: Colors.orange, etiket: DilServisi.metin('adimBaslik'), deger: '$_bugunAdim')),
                      const SizedBox(width: 8),
                      Expanded(child: _kompaktKart(ikon: Icons.water_drop, renk: Colors.lightBlue, etiket: DilServisi.metin('suBaslik'), deger: '${(_bugunSuMl / 1000).toStringAsFixed(1)}/${(_gunlukSuHedefiMl / 1000).toStringAsFixed(0)} L')),
                      const SizedBox(width: 8),
                      Expanded(child: _kompaktKart(ikon: Icons.monitor_weight, renk: Colors.purple, etiket: DilServisi.metin('kiloBaslik'), deger: _sonKilo != null ? '${_sonKilo!.toStringAsFixed(1)} kg' : '—')),
                    ],
                  ),
                ),
                const SizedBox(height: 8),

                // Son Kan Şekeri + Son Tansiyon — yan yana, büyük punto
                Expanded(
                  flex: 3,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: Colors.grey.shade200),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(DilServisi.metin('kanSekeriBaslik'), style: TextStyle(fontSize: 11, color: Colors.grey.shade600, fontWeight: FontWeight.w600)),
                              const SizedBox(height: 4),
                              if (_sonSekerler.isNotEmpty) ...[
                                FittedBox(
                                  fit: BoxFit.scaleDown,
                                  alignment: Alignment.centerLeft,
                                  child: Text('${_sonSekerler.first['deger']}', style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: Colors.red)),
                                ),
                                Text('mg/dL', style: TextStyle(fontSize: 10, color: Colors.grey.shade500)),
                                const SizedBox(height: 2),
                                Text(_tarihiBicimlendir(_sonSekerler.first['tarih']?.toString()), style: TextStyle(fontSize: 9, color: Colors.grey.shade500), maxLines: 1, overflow: TextOverflow.ellipsis),
                              ] else
                                Text('—', style: TextStyle(fontSize: 24, color: Colors.grey.shade400)),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: Colors.grey.shade200),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(DilServisi.metin('tansiyon'), style: TextStyle(fontSize: 11, color: Colors.grey.shade600, fontWeight: FontWeight.w600)),
                              const SizedBox(height: 4),
                              if (_sonTansiyonlar.isNotEmpty) ...[
                                FittedBox(
                                  fit: BoxFit.scaleDown,
                                  alignment: Alignment.centerLeft,
                                  child: Text('${_sonTansiyonlar.first['buyuk']}/${_sonTansiyonlar.first['kucuk']}', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: AppRenkleri.aktif.shade700)),
                                ),
                                Text('mmHg', style: TextStyle(fontSize: 10, color: Colors.grey.shade500)),
                                const SizedBox(height: 2),
                                Text(_tarihiBicimlendir(_sonTansiyonlar.first['tarih']?.toString()), style: TextStyle(fontSize: 9, color: Colors.grey.shade500), maxLines: 1, overflow: TextOverflow.ellipsis),
                              ] else
                                Text('—', style: TextStyle(fontSize: 24, color: Colors.grey.shade400)),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),

                // Yaklaşan İlaçlarınız
                Expanded(
                  flex: 3,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.grey.shade200),
                    ),
                    child: _yaklasanIlaclar.isEmpty
                        ? Center(
                            child: Text(DilServisi.metin('bugunIcinIlacYok'), style: TextStyle(color: Colors.grey.shade500, fontSize: 13)),
                          )
                        : Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Row(
                                children: [
                                  Icon(Icons.medication_outlined, size: 15, color: AppRenkleri.aktif),
                                  const SizedBox(width: 6),
                                  Text(DilServisi.metin('yaklasanIlaclariniz'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                                ],
                              ),
                              const SizedBox(height: 6),
                              for (final ilac in _yaklasanIlaclar.take(2))
                                Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 2),
                                  child: Row(
                                    children: [
                                      Container(
                                        width: 44,
                                        alignment: Alignment.centerLeft,
                                        child: Text(ilac['saat']?.toString() ?? '', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11, color: AppRenkleri.aktif.shade700)),
                                      ),
                                      Expanded(
                                        child: Text(
                                          '${ilac['ad'] ?? ''}${(ilac['dozaj'] ?? '').toString().isNotEmpty ? ' ${ilac['dozaj']}' : ''}',
                                          style: const TextStyle(fontSize: 11),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                            ],
                          ),
                  ),
                ),
                const SizedBox(height: 8),

                // YENİ (22 Ağustos): "Seray AI" bandı KALDIRILDI — ekranın
                // tamamı zaten dokununca aynı yere (_devamEt) gidiyordu,
                // bu banner sadece görsel tekrardı, ayrı bir işlevi yoktu.
                // Yerine, kullanıcı yanıt vermediği için bildirim
                // çekmecesinde birikmiş (uygulama ikonundaki rakamla
                // eşleşen) ilaç bildirimlerinin özeti konuldu.
                Expanded(
                  flex: 2,
                  child: Material(
                    color: _bekleyenBildirimler.isEmpty ? AppRenkleri.aktif.shade50 : Colors.orange.shade50,
                    borderRadius: BorderRadius.circular(16),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(16),
                      onTap: _bekleyenBildirimeGit,
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Row(
                          children: [
                            CircleAvatar(
                              radius: 16,
                              backgroundColor: _bekleyenBildirimler.isEmpty ? AppRenkleri.aktif.shade100 : Colors.orange.shade100,
                              child: Icon(
                                _bekleyenBildirimler.isEmpty ? Icons.check_circle_outline : Icons.notifications_active,
                                color: _bekleyenBildirimler.isEmpty ? AppRenkleri.aktif.shade700 : Colors.orange.shade800,
                                size: 18,
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: _bekleyenBildirimler.isEmpty
                                    ? [
                                        Text(DilServisi.metin('bildirimlerGuncel'), style: TextStyle(color: AppRenkleri.aktif.shade700, fontWeight: FontWeight.bold, fontSize: 13)),
                                      ]
                                    : [
                                        Text(
                                          DilServisi.metin('bekleyenBildirimlerBaslik').replaceFirst('{n}', '${_bekleyenBildirimler.length}'),
                                          style: TextStyle(color: Colors.orange.shade900, fontWeight: FontWeight.bold, fontSize: 13),
                                        ),
                                        Text(
                                          _bekleyenBildirimler.map((b) => (b.title ?? '').split(': ').last).join(', '),
                                          style: TextStyle(color: Colors.orange.shade800, fontSize: 10),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ],
                              ),
                            ),
                            Icon(Icons.chevron_right, color: _bekleyenBildirimler.isEmpty ? AppRenkleri.aktif.shade700 : Colors.orange.shade800, size: 20),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 6),

                // Devam Et — dokunma ipucu
                Center(
                  child: Text(
                    DilServisi.metin('devamEtmekIcinDokun'),
                    style: TextStyle(fontSize: 11, color: Colors.grey.shade500),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
