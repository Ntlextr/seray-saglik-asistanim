import 'dart:async';
import '../theme/renkler.dart';
import '../theme/sablon.dart';
import '../widgets/ust_menu.dart';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:package_info_plus/package_info_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/bildirim_servisi.dart';
import '../services/saglik_baglantisi_servisi.dart';
import '../services/adim_servisi.dart';
import '../services/veritabani_yardimcisi.dart';
import '../services/profil_yoneticisi.dart';
import '../services/profil_sabitleri.dart';
import '../navigasyon_anahtari.dart';
import '../main.dart' show AnaEkranYonlendirici;
import 'profil_kayit_ekrani.dart';
import '../services/ses_servisi.dart';
import 'kritik_izinler_ekrani.dart';
import 'tanitim_turu_ekrani.dart';
import 'pin_kilit_ekrani.dart';
import 'package:local_auth/local_auth.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import '../services/crash_servisi.dart';
import '../services/dil_servisi.dart';

class AyarlarEkrani extends StatefulWidget {
  const AyarlarEkrani({Key? key}) : super(key: key);
  @override
  State<AyarlarEkrani> createState() => _AyarlarEkraniState();
}

class _AyarlarEkraniState extends State<AyarlarEkrani> {
  @override
  void dispose() {
    // DÜZELTME (22 Ağustos): Bu ekranda ses testi (SesServisi.konus) var ama
    // dispose() sesi durdurmuyordu — test sesi çalarken ekrandan çıkılırsa
    // arka planda çalmaya devam ediyordu.
    SesServisi.durdur();
    _acilKisiAdController.dispose();
    _acilKisiTelefonController.dispose();
    super.dispose();
  }  // --- dispose() sonu ---

  List<Map<String, String>> _sesler = [];
  String? _secilenSesAdi;
  double _hiz = SesServisi.varsayilanHiz;
  bool _seslerYukleniyor = true;
  String _nabizYontemi = 'fft'; // 'basit' | 'fft'

  // KVKK ve Hakkında metinleri artık Cloudflare'den çekiliyor — böylece
  // metni güncellemek için yeni bir APK yayınlamaya gerek kalmıyor.
  // İnternet yoksa uygulamanın içindeki yedek (fallback) metin gösterilir.
  String _kvkkMetni = _yerelKvkkYedek;
  // ÖNEMLİ DÜZELTME: Hakkında açıklaması KVKK'nın aksine hiç yerel yedeği
  // olmadan doğrudan null başlıyordu — sunucudan çekilemezse (zayıf
  // internet, gecikme, vb.) kart tamamen boş görünüyordu, kullanıcıya
  // hiçbir belirti/hata da gösterilmiyordu. Artık KVKK ile birebir aynı
  // desende, yerel bir yedek metinle başlıyor.
  String _hakkindaAciklama = _yerelHakkindaYedek;
  // YENİ: WhatsApp grup linki artık worker.js'den çekiliyor (link
  // sıfırlanırsa APK basmaya gerek kalmasın diye) — internet yoksa bu
  // sabit değer (en son bilinen link) yedek olarak kullanılır.
  String _whatsappGrupLinki = 'https://chat.whatsapp.com/GJpkqz6HC1c6w3kKM2QINE?s=cl&p=a&ilr=4';
  bool _pinAktif = false;
  bool _biyometriAktif = false;
  final _acilKisiAdController = TextEditingController();
  final _acilKisiTelefonController = TextEditingController();
  bool _haftalikOzetAktif = false;
  // AİLE TAKİBİ: profil listesi ve aktif profil.
  List<ProfilBilgisi> _profiller = [];
  String _aktifProfilId = ProfilSabitleri.varsayilanProfilId;

  @override
  void initState() {
    super.initState();
    _kvkkMetni = _kvkkVarsayilanMetin;
    _hakkindaAciklama = _hakkindaVarsayilanMetin;
    _sesAyarlariniYukle();
    _icerigiCloudflaredanCek();
    _pinDurumunuYukle();
    _acilKisiyiYukle();
    _haftalikOzetDurumunuYukle();
    _profilleriYukle();
  }  // --- initState() sonu ---

  Future<void> _profilleriYukle() async {
    final liste = await ProfilYoneticisi().profilleriGetir();
    final aktif = await ProfilYoneticisi().aktifProfilId();
    if (mounted) {
      setState(() {
        _profiller = liste;
        _aktifProfilId = aktif;
      });
    }
  }  // --- _profilleriYukle() sonu ---

  // Yeni profil ekleme dialogu — isim sorulur, eklenince hemen o profile
  // geçmek isteyip istemediği sorulur.
  Future<void> _yeniProfilEkleDialogu() async {
    final controller = TextEditingController();
    final ad = await showDialog<String>(
      context: context,
      builder: (d) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(DilServisi.metin('yeniProfilEkle')),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: InputDecoration(labelText: DilServisi.metin('kisininAdi')),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d), child: Text(DilServisi.metin('vazgec'))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppRenkleri.aktif),
            onPressed: () => Navigator.pop(d, controller.text.trim()),
            child: Text(DilServisi.metin('ekle'), style: const TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
    if (ad == null || ad.isEmpty) return;
    final yeni = await ProfilYoneticisi().profilEkle(ad);
    await _profilleriYukle();
    if (!mounted) return;
    final gecMi = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(DilServisi.metin('profilEklendi')),
        content: Text('"${yeni.ad}" ${DilServisi.metin('profilEklendiAciklama')}'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: Text(DilServisi.metin('sonra'))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppRenkleri.aktif),
            onPressed: () => Navigator.pop(d, true),
            child: Text(DilServisi.metin('buProfileGec'), style: const TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
    if (gecMi == true) await _profileGec(yeni.id);
  }  // --- _yeniProfilEkleDialogu() sonu ---

  // AİLE TAKİBİ: profil değiştirince veritabanı bağlantısı sıfırlanıyor —
  // ekranı en baştan tazelemek için TÜM navigasyon geçmişini temizleyip
  // yeniden başlıyoruz. Aksi hâlde eski profilin verileriyle açık kalan
  // ekranlar kafa karıştırırdı.
  //
  // ÖNEMLİ: Sadece profil YENİ OLUŞTURULDUĞUNDA değil, kullanıcı "Sonra"
  // deyip daha sonra listeden "Geç" ile geçtiğinde de aynı kontrol
  // uygulanır — geçilen profilin adı/yaşı/boyu HÂLÂ hiç girilmemişse
  // (yani ilk kez kullanılıyorsa), direkt Ana Sayfa yerine önce Profil
  // Kaydı ekranı açılır. Zaten bilgileri dolu bir profile geçerken bu
  // adım atlanır, direkt Ana Sayfa'ya gidilir.
  Future<void> _profileGec(String profilId) async {
    if (profilId == _aktifProfilId) return;
    await ProfilYoneticisi().aktifProfiliDegistir(profilId);
    if (!mounted) return;

    final prefs = await SharedPreferences.getInstance();
    final adAnahtari = await ProfilYoneticisi().profilAnahtari('kullanici_ad');
    final kimlikBosMu = (prefs.getString(adAnahtari) ?? '').trim().isEmpty;

    if (kimlikBosMu) {
      navigasyonAnahtari.currentState?.pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const ProfilKayitEkrani()),
        (route) => false,
      );
      return;
    }
    navigasyonAnahtari.currentState?.pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const AnaEkranYonlendirici()),
      (route) => false,
    );
  }  // --- _profileGec() sonu ---

  Future<void> _profilSilOnayi(ProfilBilgisi profil) async {
    final onay = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(DilServisi.metin('profiliSil')),
        content: Text(
          '"${profil.ad}" ${DilServisi.metin('profiliSilAciklama')}',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: Text(DilServisi.metin('vazgec'))),
          TextButton(
            onPressed: () => Navigator.pop(d, true),
            child: Text(DilServisi.metin('sil'), style: const TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
    if (onay != true) return;
    final oncekiAktif = _aktifProfilId;
    final basarili = await ProfilYoneticisi().profilSil(profil.id);
    if (!basarili && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(DilServisi.metin('enAzBirProfil'))),
      );
      return;
    }
    await _profilleriYukle();
    // Sadece silinen profil AKTİF olansa, ekranı en baştan tazelemek
    // gerekir (aktif veritabanı değişti demektir). Aktif olmayan bir
    // profil silindiyse sadece liste güncellenir, Ayarlar'da kalınır.
    if (oncekiAktif == profil.id && mounted) {
      navigasyonAnahtari.currentState?.pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const AnaEkranYonlendirici()),
        (route) => false,
      );
    }
  }  // --- _profilSilOnayi() sonu ---

  Future<void> _haftalikOzetDurumunuYukle() async {
    final prefs = await SharedPreferences.getInstance();
    if (mounted) setState(() => _haftalikOzetAktif = prefs.getBool('haftalik_ozet_aktif') ?? false);
  }  // --- _haftalikOzetDurumunuYukle() sonu ---

  Future<void> _haftalikOzetDegistir(bool acilsinMi) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('haftalik_ozet_aktif', acilsinMi);
    if (acilsinMi) {
      await BildirimServisi.haftalikOzetHatirlaticisiKur();
    } else {
      await BildirimServisi.haftalikOzetHatirlaticisiniIptalEt();
    }
    if (mounted) setState(() => _haftalikOzetAktif = acilsinMi);
  }  // --- _haftalikOzetDegistir() sonu ---

  // Basit, AI kullanmayan (anında, ücretsiz) istatistik özeti — bildirimin
  // yönlendirdiği yer burası. "Haftalık İçgörü" (Analizler'deki AI yorumu)
  // ile karıştırılmamalı, o ayrı ve daha derin bir analiz.
  Future<void> _haftalikOzetiGoster() async {
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(DilServisi.metin('buHaftakiOzetiniz')),
        content: FutureBuilder<String>(
          future: _haftalikOzetMetniHesapla(),
          builder: (context, snapshot) {
            if (!snapshot.hasData) {
              return const SizedBox(height: 60, child: Center(child: CircularProgressIndicator()));
            }
            return Text(snapshot.data!, style: const TextStyle(fontSize: 14, height: 1.5));
          },
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: Text(DilServisi.metin('kapat')))],
      ),
    );
  }  // --- _haftalikOzetiGoster() sonu ---

  Future<String> _haftalikOzetMetniHesapla() async {
    final yediGunOnce = DateTime.now().subtract(const Duration(days: 7));
    bool sonrasiMi(String? tarih) {
      if (tarih == null) return false;
      final t = DateTime.tryParse(tarih);
      return t != null && t.isAfter(yediGunOnce);
    }

    final sekerler = (await VeritabaniYardimcisi().sekerleriGetir())
        .where((s) => sonrasiMi(s['tarih']?.toString()))
        .toList();
    final suKayitlari = (await VeritabaniYardimcisi().suKayitlariniGetir())
        .where((s) => sonrasiMi(s['tarih']?.toString()))
        .toList();
    final kiloKayitlari = await VeritabaniYardimcisi().kiloKayitlariniGetir();
    final adimGecmisi = await AdimServisi.sonYediGunGetir();

    final sb = StringBuffer();
    if (sekerler.isNotEmpty) {
      final ortalama = sekerler.map((s) => (s['deger'] as num).toDouble()).reduce((a, b) => a + b) / sekerler.length;
      sb.writeln('🩸 Ortalama şeker: ${ortalama.toStringAsFixed(0)} mg/dL (${sekerler.length} ölçüm)');
    } else {
      sb.writeln('🩸 Bu hafta şeker ölçümü kaydedilmemiş.');
    }
    if (adimGecmisi.isNotEmpty) {
      final toplamAdim = adimGecmisi.fold<int>(0, (t, e) => t + e.value);
      sb.writeln('🚶 Toplam adım: $toplamAdim');
    }
    final suGunSayisi = suKayitlari.map((s) => (s['tarih'] ?? '').toString().split('T').first).toSet().length;
    sb.writeln('💧 Su kaydı girilen gün sayısı: $suGunSayisi / 7');
    if (kiloKayitlari.length >= 2) {
      final fark = (kiloKayitlari.first['kilo'] as num) - (kiloKayitlari.last['kilo'] as num);
      sb.writeln('⚖️ Kilo değişimi (kayıtlı ölçümler arası): ${fark.toStringAsFixed(1)} kg');
    }
    return sb.toString();
  }  // --- _haftalikOzetMetniHesapla() sonu ---

  Future<void> _acilKisiyiYukle() async {
    final prefs = await SharedPreferences.getInstance();
    final py = ProfilYoneticisi();
    _acilKisiAdController.text = prefs.getString(await py.profilAnahtari('acil_kisi_ad')) ?? '';
    _acilKisiTelefonController.text = prefs.getString(await py.profilAnahtari('acil_kisi_telefon')) ?? '';
  }  // --- _acilKisiyiYukle() sonu ---

  Future<void> _acilKisiyiKaydet() async {
    final prefs = await SharedPreferences.getInstance();
    final py = ProfilYoneticisi();
    await prefs.setString(await py.profilAnahtari('acil_kisi_ad'), _acilKisiAdController.text.trim());
    await prefs.setString(await py.profilAnahtari('acil_kisi_telefon'), _acilKisiTelefonController.text.trim());
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(DilServisi.metin('acilKisiKaydedildi'))),
      );
    }
  }  // --- _acilKisiyiKaydet() sonu ---

  Future<void> _pinDurumunuYukle() async {
    final prefs = await SharedPreferences.getInstance();
    if (mounted) {
      setState(() {
        _pinAktif = prefs.getBool('pin_kilit_aktif') ?? false;
        _biyometriAktif = prefs.getBool('biyometri_aktif') ?? false;
      });
    }
  }  // --- _pinDurumunuYukle() sonu ---

  Future<void> _biyometriDegistir(bool acilsinMi) async {
    if (acilsinMi) {
      // Açmadan önce gerçekten bir kez parmak izi doğrulatıyoruz — hem
      // cihazda parmak izi kayıtlı mı diye test etmiş oluyoruz hem de
      // kullanıcı "açtım ama çalışmıyor" şaşkınlığı yaşamıyor.
      try {
        final auth = LocalAuthentication();
        final destekleniyorMu = await auth.isDeviceSupported();
        final kayitliVarMi = await auth.canCheckBiometrics;
        if (!destekleniyorMu || !kayitliVarMi) {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(DilServisi.metin('parmakIziKayitliDegil'))),
            );
          }
          return;
        }
        final basarili = await auth.authenticate(
          localizedReason: DilServisi.metin('parmakIziKilidiAcNeden'),
          options: const AuthenticationOptions(biometricOnly: true),
        );
        if (!basarili) return;
      } catch (e) {
        if (mounted) {
          showDialog(
            context: context,
            builder: (dialogContext) => AlertDialog(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              title: Text(DilServisi.metin('parmakIziHatasi')),
              content: SelectableText(e.toString()),
              actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: Text(DilServisi.metin('kapat')))],
            ),
          );
        }
        return;
      }
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('biyometri_aktif', acilsinMi);
    if (mounted) setState(() => _biyometriAktif = acilsinMi);
  }  // --- _biyometriDegistir() sonu ---

  // Anahtar açılırken yeni PIN belirletir, kapatılırken önce mevcut PIN'i
  // doğrulatır (böylece kilidi telefonu ele geçiren biri sessizce kapatamaz).
  void _pinKilidiDegistir(bool acilsinMi) {
    if (acilsinMi) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => PinKilitEkrani(
            mod: PinKilitModu.belirle,
            onBasarili: () {
              if (mounted) setState(() => _pinAktif = true);
              Navigator.pop(context);
            },
            onVazgec: () => Navigator.pop(context),
          ),
        ),
      );
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => PinKilitEkrani(
            mod: PinKilitModu.dogrula,
            onBasarili: () async {
              final prefs = await SharedPreferences.getInstance();
              await prefs.setBool('pin_kilit_aktif', false);
              await prefs.setBool('biyometri_aktif', false);
              if (mounted) setState(() { _pinAktif = false; _biyometriAktif = false; });
              if (mounted) Navigator.pop(context);
            },
            onVazgec: () => Navigator.pop(context),
          ),
        ),
      );
    }
  }  // --- _pinKilidiDegistir() sonu ---

  Future<void> _icerigiCloudflaredanCek() async {
    try {
      final response = await http
          .get(Uri.parse('https://api.seraytekno.com/icerik'))
          .timeout(const Duration(seconds: 8));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (mounted) {
          setState(() {
            // İngilizce modda uzak sunucu (her zaman Türkçe) yerine yerel
            // çeviriyi kullan — sunucu şu an dil desteklemiyor.
            if (DilServisi.dilKodu != 'en') {
              _kvkkMetni = data['kvkk'] ?? _yerelKvkkYedek;
              _hakkindaAciklama = data['hakkinda'] ?? _yerelHakkindaYedek;
            }
            _whatsappGrupLinki = data['whatsapp_grup'] ?? _whatsappGrupLinki;
          });
        }
      }
    } catch (_) {
      // İnternet yoksa veya sunucuya ulaşılamazsa, uygulamanın içindeki
      // yedek metin zaten gösteriliyor — kullanıcı hiçbir hata görmez.
    }
  }  // --- _icerigiCloudflaredanCek() sonu ---

  Future<void> _sesAyarlariniYukle() async {
    final prefs = await SharedPreferences.getInstance();
    final sesler = await SesServisi.turkceSesleriGetir();
    if (mounted) {
      setState(() {
        _sesler = sesler;
        _secilenSesAdi = prefs.getString('tts_ses_adi');
        _hiz = prefs.getDouble('tts_hiz') ?? SesServisi.varsayilanHiz;
        _nabizYontemi = prefs.getString('nabiz_yontemi') ?? 'fft';
        _seslerYukleniyor = false;
      });
    }
  }  // --- _sesAyarlariniYukle() sonu ---

  Future<void> _nabizYontemiDegistir(String? yeniDeger) async {
    if (yeniDeger == null) return;
    setState(() => _nabizYontemi = yeniDeger);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('nabiz_yontemi', yeniDeger);
  }  // --- _nabizYontemiDegistir() sonu ---

  Future<void> _sesSec(Map<String, String> ses) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('tts_ses_adi', ses['name'] ?? '');
    await prefs.setString('tts_ses_locale', ses['locale'] ?? 'tr-TR');
    setState(() => _secilenSesAdi = ses['name']);
    SesServisi.konus(DilServisi.metin('sesSeciminizBu'));
  }  // --- _sesSec() sonu ---

  Future<void> _hiziGuncelle(double yeniHiz) async {
    setState(() => _hiz = yeniHiz);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('tts_hiz', yeniHiz);
  }  // --- _hiziGuncelle() sonu ---

  // Cihazdaki ses adları genelde uzun/teknik oluyor (örn. "tr-tr-x-abc-local");
  // burada kısa, sade "Ses 1", "Ses 2" gibi etiketler kullanıyoruz.
  Widget _sesButonu(int index, Map<String, String> ses) {
    final secili = _secilenSesAdi == ses['name'];
    return OutlinedButton(
      onPressed: () => _sesSec(ses),
      style: OutlinedButton.styleFrom(
        backgroundColor: secili ? AppRenkleri.aktif.shade50 : Colors.white,
        side: BorderSide(color: secili ? AppRenkleri.aktif : Colors.grey.shade300, width: secili ? 1.5 : 1),
        padding: const EdgeInsets.symmetric(horizontal: 4),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
      child: Text(
        'Ses ${index + 1}',
        style: TextStyle(fontSize: 12, color: secili ? AppRenkleri.aktif.shade800 : Colors.black87, fontWeight: secili ? FontWeight.bold : FontWeight.normal),
      ),
    );
  }  // --- _sesButonu() sonu ---
  Future<void> _temaSec(String temaAdi) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('tema_secimi', temaAdi);
    setState(() {
      AppRenkleri.temaAdi = temaAdi;
      AppRenkleri.cocukTemasiAktif = temaAdi == 'cocuk';
    });
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(DilServisi.metin('temaYenidenAcSnackbar'))),
      );
    }
  }  // --- _temaSec() sonu ---

  Widget _temaSecenegi(String anahtar, String etiket, MaterialColor renk) {
    final secili = AppRenkleri.temaAdi == anahtar;
    return InkWell(
      onTap: () => _temaSec(anahtar),
      borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: renk,
              shape: BoxShape.circle,
              border: Border.all(color: secili ? Colors.black87 : Colors.transparent, width: 2.5),
            ),
            child: secili ? const Icon(Icons.check, color: Colors.white) : null,
          ),
          const SizedBox(height: 4),
          Text(etiket, style: TextStyle(fontSize: 10, fontWeight: secili ? FontWeight.bold : FontWeight.normal)),
        ],
      ),
    );
  }  // --- _temaSecenegi() sonu ---

  // Renk temasından bağımsız, ayrı bir "görsel şablon" seçimi (bkz.
  // theme/sablon.dart). Şu an sadece köşe yuvarlaklığını değiştiriyor;
  // ileride yeni şablonlar eklenirse buraya sadece yeni bir seçenek
  // eklemek yeterli olacak.
  // Dil seçim fonksiyonu — şablon seçimiyle BİREBİR aynı desen.
  Future<void> _dilSec(String kod) async {
    await DilServisi.kaydet(kod);
    setState(() {});
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(DilServisi.metin('dilYenidenAcSnackbar'))),
      );
    }
  }  // --- _dilSec() sonu ---

  Future<void> _sablonSec(String sablonAdi) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('sablon_secimi', sablonAdi);
    setState(() {
      AppSablon.sablonAdi = sablonAdi;
    });
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(DilServisi.metin('sablonYenidenAcSnackbar'))),
      );
    }
  }  // --- _sablonSec() sonu ---

  Widget _sablonSecenegi(String anahtar, String etiket, String aciklama, IconData ikon) {
    final secili = AppSablon.sablonAdi == anahtar;
    return InkWell(
      onTap: () => _sablonSec(anahtar),
      borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
      child: Container(
        width: 140,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: secili ? AppRenkleri.aktif.shade50 : Colors.white,
          borderRadius: BorderRadius.circular(anahtar == 'enerjik' ? 30 : (anahtar == 'modern_yuvarlak' ? 22 : 12)),
          border: Border.all(color: secili ? AppRenkleri.aktif : Colors.grey.shade300, width: secili ? 1.5 : 1),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(ikon, color: secili ? AppRenkleri.aktif.shade700 : Colors.grey.shade600, size: 20),
                const Spacer(),
                if (secili) Icon(Icons.check_circle, color: AppRenkleri.aktif, size: 18),
              ],
            ),
            const SizedBox(height: 8),
            Text(etiket, style: TextStyle(fontSize: 13, fontWeight: secili ? FontWeight.bold : FontWeight.w500)),
            const SizedBox(height: 2),
            Text(aciklama, style: const TextStyle(fontSize: 10, color: Colors.grey)),
          ],
        ),
      ),
    );
  }  // --- _sablonSecenegi() sonu ---

  static const String _yerelHakkindaYedek = '''
Seray Sağlık Asistanım, 30 yıldır Tip 2 diyabet hastası olan İ. Serdar Çırak tarafından, kişisel diyabet tecrübesinden yola çıkılarak, ihtiyaç duyduğu bir çözümü herkesle paylaşmak amacıyla büyük emek ve özenle geliştirilmiştir.

Bu uygulama izinsiz hiçbir şekilde kopyalanamaz, çoğaltılamaz veya dağıtılamaz. Tüm hakları saklıdır.

© 2026 Seray Teknoloji
''';

  static const String _yerelHakkindaYedekEn = '''
Seray Health Assistant was developed with great care by İ. Serdar Çırak, who has lived with Type 2 diabetes for 30 years, drawing on his own personal experience to share a solution he needed with everyone else.

This app may not be copied, reproduced, or distributed without permission. All rights reserved.

© 2026 Seray Teknoloji
''';

  String get _hakkindaVarsayilanMetin =>
      DilServisi.dilKodu == 'en' ? _yerelHakkindaYedekEn : _yerelHakkindaYedek;

  static const String _yerelKvkkYedek = '''
KİŞİSEL VERİLERİN KORUNMASI AYDINLATMA METNİ

0. Veri Sorumlusunun Kimliği
6698 sayılı Kişisel Verilerin Korunması Kanunu ("KVKK") uyarınca, aşağıda açıklanan kişisel verileriniz veri sorumlusu sıfatıyla Seray Teknoloji ("Uygulama", "biz") tarafından bu metinde açıklanan amaç ve kapsamda işlenmektedir. İletişim: seraysaglikasistanim@gmail.com

1. Toplanan Veriler
Ad-soyad, yaş, diyabet durumu gibi profil bilgileriniz; girdiğiniz tansiyon, kan şekeri, nabız, kilo, su, adım, ilaç/insülin, beslenme ve e-Nabız tahlil sonuçlarınızı içeren özel nitelikli sağlık verileriniz; onayınızla girdiğiniz acil durum kişisinin adı/telefonu; Seray AI sohbet geçmişiniz; cihaz ve hata (crash) kayıtları işlenir. Ayrıca, uygulamamızı kaç kişinin kullandığını görebilmemiz ve genel kullanım istatistiklerini takip edebilmemiz amacıyla ad-soyadınız ve yaşadığınız şehir, kayıt sırasında ayrıca alınır; bu bilgi şeker/tansiyon/ilaç gibi sağlık verilerinizden TAMAMEN AYRIDIR.

2. Verilerin Saklanma Yeri
Tüm ölçüm/sağlık verileriniz öncelikli olarak kendi cihazınızda (yerel SQLite veritabanında) saklanır. Ad-soyad ve şehir bilginiz ile uygulamayı ne sıklıkla kullandığınıza dair genel istatistikler ise (madde 1'de açıklandığı gibi) merkezi bir sistemde ayrıca tutulur — bu, sağlık verilerinizin cihazınızın dışına çıkması anlamına gelmez, sadece kimlik/kullanım bilgisi için geçerlidir. Kendi isteğinizle yapacağınız veri yedekleme/geri yükleme işlemleri için Firebase ve Google Drive güvenli bulut altyapıları kullanılır; bu yedekleme verileri şifreli tutulur ve üçüncü şahıslarla paylaşılmaz.

3. Yapay Zeka Analizi
e-Nabız tahlillerinizi, ilaçlarınızı veya beslenme kayıtlarınızı analiz ettirmek ya da Seray AI'a soru sormak istediğinizde, ilgili içerik veri güvenliğini ve API gizliliğini sağlamak amacıyla aracı bir Cloudflare Worker sunucusu üzerinden şifreli bağlantıyla (HTTPS) yapay zeka servis sağlayıcısına (OpenAI GPT-4o-mini) iletilir. Gönderilen verilerde gerçek kimlik bilgileriniz yer almaz, yalnızca ölçüm rakamları/sorunuz analiz edilir; bu içerik yapay zeka modellerini eğitmek amacıyla kullanılmaz veya sunucularda saklanmaz.

4. Kritik Ölçüm Bildirimi
Çok yüksek/çok düşük bir ölçüm kaydettiğinizde, sizin onayınızla ve sizin tetiklemenizle, Ayarlar'da belirlediğiniz acil durum kişisine cihazınızın kendi SMS uygulaması üzerinden bilgilendirme mesajı gönderme seçeneği sunulur; bu mesaj Uygulama sunucularından değil, doğrudan cihazınızdan gönderilir.

5. Cihaz İzinleri
Uygulama; kamera (nabız ölçümü ve ilaç kutusu fotoğrafı için), bildirimler (ilaç/su hatırlatmaları için), adım sayar/hareket sensörü ve isteğe bağlı Health Connect izinlerini yalnızca ilgili özellik kullanıldığında talep eder.

6. Yedekleme ve Paylaşım
"Yedekle" veya "Sonuçları Paylaş" özelliklerini kullandığınızda, oluşturulan dosya yalnızca sizin seçtiğiniz uygulama, kişi veya Firebase/Google Drive bulut hesabınızla paylaşılır. Bu paylaşımın sorumluluğu kullanıcıya aittir.

7. Hukuki Sebep
Genel kullanım verileri KVKK m.5/2 (meşru menfaat, sözleşmenin ifası) kapsamında; sağlık verisi gibi özel nitelikli verileriniz ise KVKK m.6 uyarınca yalnızca açık rızanızla işlenir (bkz. Açık Rıza Metni).

8. Haklarınız (KVKK m.11)
Verilerinizin işlenip işlenmediğini öğrenme; işlenmişse bilgi talep etme; işlenme amacına uygun kullanılıp kullanılmadığını öğrenme; yurt içinde/yurt dışında aktarıldığı kişileri bilme; eksik/yanlış işlenmişse düzeltilmesini isteme; KVKK'da öngörülen şartlarda silinmesini/yok edilmesini isteme; bu işlemlerin aktarılan taraflara bildirilmesini isteme; kanuna aykırı işlenme nedeniyle zarara uğramanız halinde zararın giderilmesini talep etme haklarına sahipsiniz. Uygulama içinden "Verileri Sıfırla" butonuna basmanız veya uygulamayı cihazınızdan silmeniz, yerel veritabanındaki tüm verilerinizi kalıcı olarak temizler. Sorularınız için seraysaglikasistanim@gmail.com adresinden bize ulaşabilirsiniz.

9. Sorumluluk Reddi
Uygulamanın kullanımından doğabilecek her türlü veri kaybı, cihaz arızası veya diğer teknik sorunlardan Seray Teknoloji sorumlu tutulamaz; uygulamanın kullanımı tamamen kullanıcının kendi sorumluluğundadır. Uygulama tıbbi teşhis veya tedavi amacı taşımaz, sağlıkla ilgili kararlarınız için mutlaka doktorunuza danışın.


AÇIK RIZA METNİ

Bu metin, yukarıdaki Aydınlatma Metni'nden ayrıdır. Sağlık verileriniz yalnızca onay verdiğiniz madde ölçüsünde işlenir; onaylamadığınız bir madde varsa yalnızca o özellik çalışmaz, uygulamanın temel ölçüm/kayıt kullanımı bu onaylara bağlı değildir.

☐ Şeker, tansiyon, nabız, kilo, su, adım, ilaç ve beslenme verilerim dahil sağlık verilerimin, uygulama içinde bana hizmet sunulması amacıyla işlenmesine,
☐ e-Nabız tahlillerimin, ilaçlarımın/beslenme kayıtlarımın ve Seray AI'a sorduğum soruların; anonimleştirilerek, aracı bir Cloudflare Worker sunucusu üzerinden yapay zeka servis sağlayıcısına (OpenAI GPT-4o-mini) iletilip analiz edilmesine,
☐ Verilerimin kendi isteğimle Firebase ve Google Drive altyapısında şifreli olarak yedeklenmesine (isteğe bağlı — onay vermezsem verilerim yalnızca cihazımda kalır),
☐ Kritik bir ölçüm kaydettiğimde, belirlediğim acil durum kişisine SMS ile bilgilendirme gönderme seçeneğinin bana sunulmasına,
☐ İlaç ve su hatırlatmalarımın zamanında iletilmesi için bildirim gönderilmesine
☐ Ad-soyadımın ve şehir bilgimin, uygulama istatistiklerini takip etme amacıyla merkezi bir sistemde saklanmasına (sağlık verilerimden ayrı olarak — bu onayı vermesem bile temel ölçüm/kayıt özelliklerini kullanabileceğimi biliyorum)

açık rıza gösteriyorum. Bu veriler yalnızca o anki analiz/seslendirme ve yedekleme işlemleri için kullanılır; yapay zeka modellerini eğitmek amacıyla üçüncü taraflarca saklanmaz veya işlenmez. Uygulamanın kesinlikle bir doktor teşhisi koymadığını, tıbbi tavsiye vermediğini ve acil klinik müdahale aracı olmadığını kabul ediyorum. Bu onayları dilediğim zaman Ayarlar ekranından geri çekebilirim; geri çekmem, öncesinde gerçekleştirilmiş işlemleri geçersiz kılmaz.
''';

  static const String _yerelKvkkYedekEn = '''
PERSONAL DATA PROTECTION NOTICE

0. Data Controller's Identity
Under Turkey's Personal Data Protection Law No. 6698 ("KVKK"), the personal data described below is processed by Seray Teknoloji ("the App", "we") as data controller, for the purposes and scope described in this notice. Contact: seraysaglikasistanim@gmail.com

1. Data Collected
Your profile information such as name, age, and diabetes status; the special-category health data you enter, including blood pressure, blood sugar, pulse, weight, water, steps, medication/insulin, nutrition, and e-Nabız lab results; the name/phone number of an emergency contact you enter with your consent; your Seray AI chat history; and device and crash logs are processed. In addition, to see how many people use our app and track general usage statistics, your name and the city you live in are collected separately at registration; this information is COMPLETELY SEPARATE from your health data such as sugar/blood pressure/medication.

2. Where Data Is Stored
All of your measurement/health data is primarily stored on your own device (in a local SQLite database). Your name, city, and general statistics about how often you use the app (as described in item 1) are additionally kept in a central system — this does not mean your health data leaves your device, it applies only to identity/usage information. Firebase and Google Drive secure cloud infrastructure are used for backup/restore operations you initiate yourself; this backup data is kept encrypted and is not shared with third parties.

3. AI Analysis
When you want your e-Nabız lab results, medications, or nutrition records analyzed, or when you ask Seray AI a question, the relevant content is sent over an encrypted connection (HTTPS) through an intermediary Cloudflare Worker server to the AI service provider (OpenAI GPT-4o-mini), in order to protect data security and API privacy. The data sent does not include your real identity information — only measurement figures/your question are analyzed; this content is not used to train AI models or stored on servers.

4. Critical Measurement Notification
When you record a very high/very low measurement, with your consent and triggered by you, you are offered the option to send a notification message to the emergency contact you set in Settings via your device's own SMS app; this message is sent directly from your device, not from the App's servers.

5. Device Permissions
The App requests camera (for pulse measurement and medicine box photos), notifications (for medicine/water reminders), step counter/motion sensor, and optional Health Connect permissions only when the relevant feature is used.

6. Backup and Sharing
When you use the "Backup" or "Share Results" features, the generated file is shared only with the app, person, or Firebase/Google Drive cloud account you choose. Responsibility for this sharing belongs to the user.

7. Legal Basis
General usage data is processed under KVKK Art. 5/2 (legitimate interest, performance of a contract); your special-category data such as health data is processed only with your explicit consent under KVKK Art. 6 (see Explicit Consent Notice).

8. Your Rights (KVKK Art. 11)
You have the right to: learn whether your data is being processed; request information if it has been; learn whether it's used in accordance with its purpose; know the parties it's transferred to domestically/abroad; request correction if processed incompletely/incorrectly; request its deletion/destruction under the conditions set out in KVKK; request that these actions be notified to the parties it was transferred to; and request compensation for damages arising from unlawful processing. Pressing "Reset Data" in the app or uninstalling the app permanently clears all your data in the local database. You can reach us for questions at seraysaglikasistanim@gmail.com.

9. Disclaimer
Seray Teknoloji cannot be held responsible for any data loss, device malfunction, or other technical issues arising from use of the App; use of the App is entirely at the user's own responsibility. The App is not intended for medical diagnosis or treatment; always consult your doctor for health-related decisions.


EXPLICIT CONSENT NOTICE

This notice is separate from the Data Protection Notice above. Your health data is processed only to the extent you consent to each item; if there's an item you don't consent to, only that feature won't work — the app's core measurement/logging use is not dependent on these consents.

☐ To my health data, including sugar, blood pressure, pulse, weight, water, steps, medication, and nutrition data, being processed in order to provide me service within the app,
☐ To my e-Nabız lab results, medications/nutrition records, and questions I ask Seray AI being anonymized and sent through an intermediary Cloudflare Worker server to the AI service provider (OpenAI GPT-4o-mini) for analysis,
☐ To my data being backed up, at my own request, in encrypted form on Firebase and Google Drive infrastructure (optional — if I don't consent, my data stays only on my device),
☐ To being offered the option to send an SMS notification to my designated emergency contact when I record a critical measurement,
☐ To notifications being sent so my medicine and water reminders arrive on time
☐ To my name and city being stored in a central system for the purpose of tracking app statistics (separately from my health data — I understand I can still use the core measurement/logging features even if I don't give this consent)

I give my explicit consent. This data is used only for that analysis/read-aloud and backup operation at the time; it is not stored or processed by third parties to train AI models. I acknowledge that the App does not provide a doctor's diagnosis, does not give medical advice, and is not a tool for emergency clinical intervention. I can withdraw these consents at any time from the Settings screen; withdrawing does not invalidate actions already performed beforehand.
''';

  String get _kvkkVarsayilanMetin =>
      DilServisi.dilKodu == 'en' ? _yerelKvkkYedekEn : _yerelKvkkYedek;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        shape: AppSablon.appBarSekli,
        clipBehavior: Clip.antiAlias,
        title: Text(DilServisi.metin('ayarlarBaslik')),
        backgroundColor: AppRenkleri.aktif,
        foregroundColor: Colors.white,
        actions: const [UstMenu()],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // ======== YAPI ETİKETİ — dosya adı/tarihiyle uğraşmadan, uygulamayı
          // açar açmaz BU KUTUYU görüp doğru sürümün kurulduğunu anla.
          // ÖNEMLİ DÜZELTME: sürüm numarası artık elle yazılmıyor — GitHub
          // Actions derlerken build numarasını beklenenden 1 fazla
          // artırdığı için ("Uygulama Hakkında"daki gerçek sürümle burada
          // elle yazılan sürüm birbirini tutmuyordu, kafa karıştırıyordu).
          // Şimdi "Uygulama Hakkında" ile AYNI kaynaktan (PackageInfo,
          // telefonun kendi paket bilgisi) okunuyor — ikisi artık HİÇBİR
          // ZAMAN birbirinden ayrışamaz. Sadece açıklama metnini (ne
          // değiştiği) her paket verişimde ben elle güncelliyorum.
          FutureBuilder<PackageInfo>(
            future: PackageInfo.fromPlatform(),
            builder: (context, snapshot) => Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              margin: const EdgeInsets.only(bottom: 12),
              decoration: BoxDecoration(
                color: Colors.black87,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                '🔖 YAPI ETİKETİ: "v${snapshot.hasData ? snapshot.data!.version : "?"} — Bekleyen bildirim → ilgili ilaca yönlendirme, e-Nabız kartında referans dışı sonuç rozeti, Yaklaşan İlaçlarınız 2 satırlı düzen" — bu yazıyı görüyorsan doğru sürüm kurulu.',
                style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
            ),
          ),
          // ======== UYGULAMA KİLİDİ (PIN) ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.lock_outline, color: AppRenkleri.aktif),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(DilServisi.metin('uygulamaKilidiPin'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                      ),
                      Switch(value: _pinAktif, activeColor: AppRenkleri.aktif, onChanged: _pinKilidiDegistir),
                    ],
                  ),
                  Text(
                    DilServisi.metin('pinAciklama'),
                    style: const TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                  if (_pinAktif) ...[
                    const SizedBox(height: 4),
                    TextButton(
                      onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => PinKilitEkrani(
                            mod: PinKilitModu.belirle,
                            onBasarili: () {
                              if (mounted) Navigator.pop(context);
                            },
                            onVazgec: () => Navigator.pop(context),
                          ),
                        ),
                      ),
                      child: Text(DilServisi.metin('pinDegistir')),
                    ),
                    const Divider(height: 1),
                    Row(
                      children: [
                        Icon(Icons.fingerprint, color: AppRenkleri.aktif, size: 22),
                        const SizedBox(width: 10),
                        Expanded(child: Text(DilServisi.metin('parmakIziyleAc'), style: const TextStyle(fontSize: 14))),
                        Switch(value: _biyometriAktif, activeColor: AppRenkleri.aktif, onChanged: _biyometriDegistir),
                      ],
                    ),
                    Text(
                      DilServisi.metin('parmakIziAciklama'),
                      style: const TextStyle(fontSize: 11, color: Colors.grey),
                    ),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),

          // ======== KRİTİK İZİNLER (İlaç hatırlatmaları için) ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            color: Colors.amber.shade50,
            child: ListTile(
              leading: const Icon(Icons.notifications_active, color: Colors.orange),
              title: Text(DilServisi.metin('ilacHatirlatmaIzinKontrol'), style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(
                DilServisi.metin('ilacHatirlatmaIzinKontrolAciklama'),
                style: const TextStyle(fontSize: 12),
              ),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => KritikIzinlerEkrani(onTamamlandi: () => Navigator.pop(context))),
              ),
            ),
          ),
          const SizedBox(height: 12),

          // ======== UYGULAMA TURU (madde 5 — görsel kimlik/tanıtım) ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: ListTile(
              leading: Icon(Icons.slideshow, color: AppRenkleri.aktif),
              title: Text(DilServisi.metin('uygulamaTuru'), style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(
                DilServisi.metin('uygulamaTuruAciklama'),
                style: const TextStyle(fontSize: 12),
              ),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TanitimTuruEkrani())),
            ),
          ),
          const SizedBox(height: 12),

          // ======== PİL AYARI (tek tıkla, doğrudan) ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: ListTile(
              leading: Icon(Icons.battery_charging_full, color: AppRenkleri.aktif),
              title: Text(DilServisi.metin('pilOptimizasyonuKapat')),
              subtitle: Text(
                DilServisi.metin('pilOptimizasyonuKapatAciklama'),
                style: const TextStyle(fontSize: 12),
              ),
              onTap: () => BildirimServisi.pilOptimizasyonuGorMezdenGel(),
            ),
          ),
          const SizedBox(height: 12),

          // ======== HEALTH CONNECT (mevcut kullanıcılar için, ilk kurulum
          // ekranını bu özellik eklenmeden önce geçmiş olabilirler — o
          // ekranda hiç izin isteği tetiklenmemiş olabilir) ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: ListTile(
              leading: Icon(Icons.directions_walk, color: AppRenkleri.aktif),
              title: Text(DilServisi.metin('healthConnectBaglan')),
              subtitle: Text(
                DilServisi.metin('healthConnectBaglanAciklama'),
                style: const TextStyle(fontSize: 12),
              ),
              onTap: () async {
                final basarili = await SaglikBaglantisiServisi.izinIste();
                if (!mounted) return;
                final hata = SaglikBaglantisiServisi.sonHata;
                if (basarili) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text(DilServisi.metin('healthConnectBaglandi'))),
                  );
                } else {
                  // Teşhis amaçlı: artık hatayı GİZLEMİYORUZ, ekranda gösteriyoruz —
                  // ekran görüntüsü alıp geliştiriciye iletilebilsin diye.
                  showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      title: Text(DilServisi.metin('healthConnectBaglanamadi')),
                      content: SelectableText(hata ?? DilServisi.metin('bilinmeyenHata')),
                      actions: [
                        TextButton(onPressed: () => Navigator.pop(context), child: Text(DilServisi.metin('kapat'))),
                      ],
                    ),
                  );
                }
              },
            ),
          ),
          const SizedBox(height: 12),

          // ======== ADIM SAYARI TEŞHİS/TEST ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: ListTile(
              leading: Icon(Icons.directions_run, color: AppRenkleri.aktif),
              title: Text(DilServisi.metin('adimSayariTestEt')),
              subtitle: Text(
                DilServisi.metin('adimSayariTestEtAciklama'),
                style: const TextStyle(fontSize: 12),
              ),
              onTap: () async {
                await AdimServisi.baslat();
                final bugunku = await AdimServisi.bugunkuAdimGetir();
                if (!mounted) return;
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    title: Text(DilServisi.metin('adimSayarDurumu')),
                    content: SelectableText(
                      'İzin verildi mi: ${AdimServisi.izinVerildiMi ? "Evet" : "Hayır"}\n'
                      'Sensör dinlemesi başladı mı: ${AdimServisi.akisBasladiMi ? "Evet" : "Hayır"}\n'
                      'Bugünkü adım (şu an): $bugunku\n\n'
                      '${AdimServisi.sonHata ?? "Bir hata yok — birkaç adım yürüyüp tekrar kontrol edin, sensörün ilk veriyi göndermesi biraz zaman alabilir."}',
                    ),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(context), child: Text(DilServisi.metin('kapat'))),
                    ],
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 12),

          // ======== SES AYARLARI (Bay/Bayan + Hız) ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.record_voice_over, color: AppRenkleri.aktif),
                      const SizedBox(width: 10),
                      Text(DilServisi.metin('sesliOkumaAyarlari'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                    ],
                  ),
                  const SizedBox(height: 12),
                  if (_seslerYukleniyor)
                    const Center(child: Padding(padding: EdgeInsets.all(8), child: CircularProgressIndicator()))
                  else if (_sesler.isEmpty)
                    Text(DilServisi.metin('birdenFazlaSesYok'), style: const TextStyle(fontSize: 12, color: Colors.grey))
                  else ...[
                    Text(DilServisi.metin('ses'), style: const TextStyle(fontSize: 12, color: Colors.grey)),
                    const SizedBox(height: 6),
                    GridView.count(
                      crossAxisCount: 3,
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      crossAxisSpacing: 8,
                      mainAxisSpacing: 8,
                      childAspectRatio: 2.4,
                      children: [
                        for (int i = 0; i < _sesler.length; i++)
                          _sesButonu(i, _sesler[i]),
                      ],
                    ),
                    const SizedBox(height: 16),
                  ],
                  Text(DilServisi.metin('konusmaHizi'), style: const TextStyle(fontSize: 12, color: Colors.grey)),
                  Row(
                    children: [
                      const Icon(Icons.slow_motion_video, size: 18, color: Colors.grey),
                      Expanded(
                        child: Slider(
                          value: _hiz,
                          min: 0.3,
                          max: 0.8,
                          divisions: 10,
                          label: _hiz.toStringAsFixed(2),
                          activeColor: AppRenkleri.aktif,
                          onChanged: _hiziGuncelle,
                        ),
                      ),
                      const Icon(Icons.fast_forward, size: 18, color: Colors.grey),
                    ],
                  ),
                  Align(
                    alignment: Alignment.centerRight,
                    child: TextButton.icon(
                      onPressed: () => SesServisi.konus(DilServisi.metin('sesTestCumlesi')),
                      icon: const Icon(Icons.volume_up, size: 26),
                      label: Text(DilServisi.metin('testEt')),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),

          // ======== GÖRÜNÜM / TEMA SEÇİMİ ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.palette, color: AppRenkleri.aktif),
                      const SizedBox(width: 10),
                      Text(DilServisi.metin('gorunum'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(DilServisi.metin('renkTemasiSecin'), style: const TextStyle(fontSize: 11, color: Colors.grey)),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 12,
                    runSpacing: 12,
                    children: [
                      _temaSecenegi('turkuaz', 'Turkuaz', AppRenkleri.turkuaz),
                      _temaSecenegi('mavi', 'Mavi', AppRenkleri.mavi),
                      _temaSecenegi('yesil', 'Yeşil', AppRenkleri.yesil),
                      _temaSecenegi('turuncu', 'Turuncu', AppRenkleri.turuncu),
                      _temaSecenegi('cocuk', 'Mor', AppRenkleri.cocukRenkli),
                      _temaSecenegi('kirmizi', 'Kırmızı', AppRenkleri.kirmizi),
                      _temaSecenegi('sari', 'Sarı', AppRenkleri.sari),
                      _temaSecenegi('lacivert', 'Lacivert', AppRenkleri.lacivert),
                      _temaSecenegi('bordo', 'Bordo/Kahve', AppRenkleri.bordo),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),

          // ======== GÖRSEL ŞABLON SEÇİMİ ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.dashboard_customize_outlined, color: AppRenkleri.aktif),
                      const SizedBox(width: 10),
                      Text(DilServisi.metin('sablon'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(DilServisi.metin('sablonAciklama'), style: const TextStyle(fontSize: 11, color: Colors.grey)),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 12,
                    runSpacing: 12,
                    children: [
                      _sablonSecenegi('klasik', 'Klasik', 'Mevcut, bilinen görünüm', Icons.crop_square),
                      _sablonSecenegi('modern_yuvarlak', 'Modern Yuvarlak', 'Daha yuvarlak, ferah köşeler', Icons.rounded_corner),
                      _sablonSecenegi('enerjik', 'Enerjik', 'Farklı font, en yuvarlak, gölgeli', Icons.auto_awesome),
                    ],
                  ),
                ],
              ),
            ),
          ),

          // ======== DİL SEÇİMİ (26 ekranın başlığı çevrildi, iç metinler sırada) ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.language, size: 20),
                      const SizedBox(width: 8),
                      Text(DilServisi.metin('dil'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(DilServisi.metin('dilAciklama'), style: const TextStyle(fontSize: 11, color: Colors.grey)),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 10,
                    children: [
                      ChoiceChip(
                        label: const Text('Türkçe'),
                        selected: DilServisi.dilKodu == 'tr',
                        onSelected: (_) => _dilSec('tr'),
                      ),
                      ChoiceChip(
                        label: const Text('English'),
                        selected: DilServisi.dilKodu == 'en',
                        onSelected: (_) => _dilSec('en'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),

          // ======== NABIZ ÖLÇÜM YÖNTEMİ ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.favorite, color: AppRenkleri.aktif),
                      const SizedBox(width: 10),
                      Text(DilServisi.metin('nabizOlcumYontemi'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  RadioListTile<String>(
                    contentPadding: EdgeInsets.zero,
                    dense: true,
                    activeColor: AppRenkleri.aktif,
                    value: 'basit',
                    groupValue: _nabizYontemi,
                    title: Text(DilServisi.metin('basitHizli'), style: const TextStyle(fontSize: 14)),
                    subtitle: Text(DilServisi.metin('tepeNoktasiSayma'), style: const TextStyle(fontSize: 11)),
                    onChanged: _nabizYontemiDegistir,
                  ),
                  RadioListTile<String>(
                    contentPadding: EdgeInsets.zero,
                    dense: true,
                    activeColor: AppRenkleri.aktif,
                    value: 'fft',
                    groupValue: _nabizYontemi,
                    title: Text(DilServisi.metin('gelismisFft'), style: const TextStyle(fontSize: 14)),
                    subtitle: Text(DilServisi.metin('frekansAnalizi'), style: const TextStyle(fontSize: 11)),
                    onChanged: _nabizYontemiDegistir,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: ListTile(
              leading: Icon(Icons.info_outline, color: AppRenkleri.aktif),
              title: Text(DilServisi.metin('uygulamaHakkinda')),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  FutureBuilder<PackageInfo>(
                    future: PackageInfo.fromPlatform(),
                    builder: (context, snapshot) => Text(
                      snapshot.hasData
                          ? 'Seray Sağlık Asistanım v${snapshot.data!.version}'
                          : 'Seray Sağlık Asistanım',
                      style: const TextStyle(fontSize: 12),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(_hakkindaAciklama, style: TextStyle(fontSize: 12, color: Colors.grey.shade700, height: 1.3)),
                  const SizedBox(height: 6),
                  InkWell(
                    onTap: () => launchUrl(Uri.parse('mailto:seraysaglikasistanim@gmail.com')),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          DilServisi.metin('iletisimBaslik'),
                          style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.grey.shade800),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          DilServisi.metin('iletisimAciklama'),
                          style: TextStyle(fontSize: 12, color: Colors.grey.shade700),
                        ),
                        const SizedBox(height: 2),
                        Row(
                          children: [
                            Icon(Icons.email_outlined, size: 14, color: Colors.blue.shade600),
                            const SizedBox(width: 4),
                            Expanded(
                              child: Text(
                                'seraysaglikasistanim@gmail.com',
                                style: TextStyle(fontSize: 12, color: Colors.blue.shade600, fontWeight: FontWeight.w500),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 6),
                  // YENİ: Kullanıcı grubu — WhatsApp topluluğuna katılım linki.
                  InkWell(
                    onTap: () => launchUrl(
                      Uri.parse(_whatsappGrupLinki),
                      mode: LaunchMode.externalApplication,
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.groups_outlined, size: 14, color: Colors.green),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(
                            DilServisi.metin('kullaniciGrubunaKatil'),
                            style: TextStyle(fontSize: 12, color: Colors.green.shade700, fontWeight: FontWeight.w500),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),

          // ======== KVKK ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: ExpansionTile(
              leading: Icon(Icons.privacy_tip_outlined, color: AppRenkleri.aktif),
              title: Text(DilServisi.metin('kvkkBaslik')),
              children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(_kvkkMetni,
                      style: const TextStyle(fontSize: 13, height: 1.4, color: Colors.black87)),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),

          const SizedBox(height: 12),

          // ======== CRASHLYTICS TEST (sadece kurulumu doğrulamak için) ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: ListTile(
              leading: Icon(Icons.bug_report_outlined, color: crashlyticsAktifMi ? Colors.green : Colors.grey),
              title: Text(DilServisi.metin('cokmeTakibiTest')),
              subtitle: Text(
                crashlyticsAktifMi
                    ? DilServisi.metin('crashlyticsAktif')
                    : DilServisi.metin('crashlyticsPasif'),
                style: const TextStyle(fontSize: 12),
              ),
              onTap: !crashlyticsAktifMi
                  ? null
                  : () => showDialog(
                        context: context,
                        builder: (context) => AlertDialog(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                          title: Text(DilServisi.metin('testCokmesi')),
                          content: Text(
                            DilServisi.metin('testCokmesiAciklama'),
                          ),
                          actions: [
                            TextButton(onPressed: () => Navigator.pop(context), child: Text(DilServisi.metin('vazgec'))),
                            TextButton(
                              onPressed: () => FirebaseCrashlytics.instance.crash(),
                              child: Text(DilServisi.metin('testEt'), style: const TextStyle(color: Colors.red)),
                            ),
                          ],
                        ),
                      ),
            ),
          ),

          const SizedBox(height: 12),

          const SizedBox(height: 12),

          // ======== AİLE TAKİBİ: PROFİL YÖNETİMİ ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.people_alt, color: AppRenkleri.aktif),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(DilServisi.metin('profillerAileTakibi'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    DilServisi.metin('profillerAciklama'),
                    style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                  ),
                  const SizedBox(height: 12),
                  for (final profil in _profiller)
                    Container(
                      margin: const EdgeInsets.only(bottom: 6),
                      decoration: BoxDecoration(
                        color: profil.id == _aktifProfilId ? AppRenkleri.aktif.shade50 : Colors.grey.shade50,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: profil.id == _aktifProfilId ? AppRenkleri.aktif : Colors.grey.shade300,
                          width: profil.id == _aktifProfilId ? 1.5 : 1,
                        ),
                      ),
                      child: ListTile(
                        dense: true,
                        leading: CircleAvatar(
                          backgroundColor: profil.id == _aktifProfilId ? AppRenkleri.aktif : Colors.grey.shade400,
                          child: Icon(Icons.person, color: Colors.white, size: 20),
                        ),
                        title: Text(profil.ad, style: const TextStyle(fontWeight: FontWeight.w600)),
                        subtitle: profil.id == _aktifProfilId ? Text(DilServisi.metin('suAnAktif'), style: const TextStyle(fontSize: 11)) : null,
                        trailing: profil.id == _aktifProfilId
                            ? Icon(Icons.check_circle, color: AppRenkleri.aktif)
                            : Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  if (_profiller.length > 1)
                                    IconButton(
                                      icon: const Icon(Icons.delete_outline, color: Colors.red, size: 20),
                                      onPressed: () => _profilSilOnayi(profil),
                                    ),
                                  TextButton(
                                    onPressed: () => _profileGec(profil.id),
                                    child: Text(DilServisi.metin('gec')),
                                  ),
                                ],
                              ),
                      ),
                    ),
                  const SizedBox(height: 4),
                  OutlinedButton.icon(
                    onPressed: _yeniProfilEkleDialogu,
                    icon: const Icon(Icons.person_add_alt_1, size: 18),
                    label: Text(DilServisi.metin('yeniProfilEkle')),
                    style: OutlinedButton.styleFrom(foregroundColor: AppRenkleri.aktif, side: BorderSide(color: AppRenkleri.aktif.shade300)),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 12),

          const SizedBox(height: 12),

          // ======== HAFTALIK ÖZET BİLDİRİMİ ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.calendar_view_week, color: AppRenkleri.aktif),
                      const SizedBox(width: 10),
                      Expanded(child: Text(DilServisi.metin('haftalikOzetBildirimi'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15))),
                      Switch(value: _haftalikOzetAktif, activeColor: AppRenkleri.aktif, onChanged: _haftalikOzetDegistir),
                    ],
                  ),
                  Text(
                    DilServisi.metin('haftalikOzetBildirimiAciklama'),
                    style: const TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                  const SizedBox(height: 6),
                  TextButton(
                    onPressed: _haftalikOzetiGoster,
                    child: Text(DilServisi.metin('buHaftakiOzetiSimdiGor')),
                  ),
                ],
              ),
            ),
          ),

          // ======== ACİL DURUM KİŞİSİ ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.emergency_outlined, color: AppRenkleri.aktif),
                      const SizedBox(width: 10),
                      Expanded(child: Text(DilServisi.metin('acilDurumKisisi'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15))),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    DilServisi.metin('acilDurumKisisiAciklama'),
                    style: const TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _acilKisiAdController,
                    decoration: InputDecoration(labelText: DilServisi.metin('adIstegeBagli'), isDense: true, border: const OutlineInputBorder()),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _acilKisiTelefonController,
                    keyboardType: TextInputType.phone,
                    decoration: InputDecoration(labelText: DilServisi.metin('telefonNumarasi'), isDense: true, border: const OutlineInputBorder()),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: AppRenkleri.aktif),
                      onPressed: _acilKisiyiKaydet,
                      child: Text(DilServisi.metin('kaydet'), style: const TextStyle(color: Colors.white)),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // ======== GİZLİLİK POLİTİKASI (WEB) ========
          // Play Store, uygulama içi metnin YANI SIRA gerçek bir web
          // URL'sinde barındırılan bir gizlilik politikası ister.
          // GitHub Pages'te (Settings → Pages → main/docs) yayınlanan
          // docs/gizlilik.html'e bağlanır.
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: ListTile(
              leading: Icon(Icons.public, color: AppRenkleri.aktif),
              title: Text(DilServisi.metin('gizlilikPolitikasi')),
              subtitle: Text(DilServisi.metin('gizlilikPolitikasiAciklama'), style: const TextStyle(fontSize: 12)),
              trailing: const Icon(Icons.open_in_new, size: 18),
              onTap: () => launchUrl(
                Uri.parse(DilServisi.dilKodu == 'en'
                    ? 'https://ntlextr.github.io/seray-saglik-asistanim/gizlilik_en.html'
                    : 'https://ntlextr.github.io/seray-saglik-asistanim/gizlilik.html'),
                mode: LaunchMode.externalApplication,
              ),
            ),
          ),
        ],
      ),
    );
  }  // --- build() sonu ---
}
