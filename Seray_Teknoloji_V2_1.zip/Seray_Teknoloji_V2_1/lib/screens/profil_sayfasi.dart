// lib/screens/profil_sayfasi.dart
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ProfilSayfasi extends StatefulWidget {
  const ProfilSayfasi({super.key});

  @override
  State<ProfilSayfasi> createState() => _ProfilSayfasiState();
}

class _ProfilSayfasiState extends State<ProfilSayfasi> {
  final TextEditingController _adController = TextEditingController();
  final TextEditingController _boyController = TextEditingController();
  final TextEditingController _kiloController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _verileriYukle();
  }

  Future<void> _verileriYukle() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _adController.text = prefs.getString('ad') ?? '';
      _boyController.text = prefs.getString('boy') ?? '';
      _kiloController.text = prefs.getString('kilo') ?? '';
    });
  }

  Future<void> _kaydet() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('ad', _adController.text);
    await prefs.setString('boy', _boyController.text);
    await prefs.setString('kilo', _kiloController.text);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Profil güncellendi!")));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Profil Bilgilerim")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(controller: _adController, decoration: const InputDecoration(labelText: "Ad Soyad")),
            TextField(controller: _boyController, decoration: const InputDecoration(labelText: "Boy (cm)")),
            TextField(controller: _kiloController, decoration: const InputDecoration(labelText: "Kilo (kg)")),
            const SizedBox(height: 20),
            ElevatedButton(onPressed: _kaydet, child: const Text("Kaydet")),
          ],
        ),
      ),
    );
  }
}
