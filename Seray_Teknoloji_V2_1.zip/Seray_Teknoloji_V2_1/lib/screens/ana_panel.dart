import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../models/saglik_verisi.dart'; // Sağlık modeli
import '../services/database_servisi.dart';

class AnaSaglikPaneli extends StatefulWidget {
  const AnaSaglikPaneli({super.key});

  @override
  State<AnaSaglikPaneli> createState() => _AnaSaglikPaneliState();
}

class _AnaSaglikPaneliState extends State<AnaSaglikPaneli> {
  List<String> _ilaclar = [];
  final TextEditingController _ilacController = TextEditingController();
  SaglikVerisi? _sonVeri; // Son analizi tutacak

  @override
  void initState() {
    super.initState();
    _verileriYukle();
  }

  Future<void> _verileriYukle() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _ilaclar = prefs.getStringList('ilaclar') ?? [];
      // Son analizi çek
      List<String> kayitlar = prefs.getStringList('saglik_kayitlari') ?? [];
      if (kayitlar.isNotEmpty) {
        _sonVeri = SaglikVerisi.fromJson(jsonDecode(kayitlar.last));
      }
    });
  }

  Future<void> _ilacEkle(String ilac) async {
    if (ilac.isEmpty) return;
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _ilaclar.add(ilac);
      _ilacController.clear();
    });
    await prefs.setStringList('ilaclar', _ilaclar);
  }

  Future<void> _ilacSil(int index) async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _ilaclar.removeAt(index);
    });
    await prefs.setStringList('ilaclar', _ilaclar);
  }

  Future<void> _yeniOlcumDialogGoster() async {
    final sekerController = TextEditingController();
    final tansiyonUstController = TextEditingController();
    final tansiyonAltController = TextEditingController();
    final nabizController = TextEditingController();
    String? hataMesaji;

    await showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text("Yeni Ölçüm Ekle"),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: sekerController,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(labelText: "Şeker (mg/dL)"),
                ),
                TextField(
                  controller: tansiyonUstController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: "Tansiyon Büyük (Üst)"),
                ),
                TextField(
                  controller: tansiyonAltController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: "Tansiyon Küçük (Alt)"),
                ),
                TextField(
                  controller: nabizController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: "Nabız"),
                ),
                if (hataMesaji != null) ...[
                  const SizedBox(height: 10),
                  Text(hataMesaji!, style: const TextStyle(color: Colors.red)),
                ],
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("İptal"),
            ),
            ElevatedButton(
              onPressed: () async {
                final seker = double.tryParse(sekerController.text.replaceAll(',', '.'));
                final tansiyonUst = double.tryParse(tansiyonUstController.text.replaceAll(',', '.'));
                final tansiyonAlt = double.tryParse(tansiyonAltController.text.replaceAll(',', '.'));
                final nabiz = double.tryParse(nabizController.text.replaceAll(',', '.'));

                if (seker == null || tansiyonUst == null || tansiyonAlt == null || nabiz == null) {
                  setDialogState(() => hataMesaji = "Lütfen tüm alanları geçerli sayı ile doldurun.");
                  return;
                }

                final yeniVeri = SaglikVerisi(
                  tarih: DateTime.now(),
                  seker: seker,
                  tansiyonUst: tansiyonUst,
                  tansiyonAlt: tansiyonAlt,
                  nabiz: nabiz,
                );

                await DatabaseServisi.veriKaydet(yeniVeri);

                if (context.mounted) Navigator.pop(context);
                await _verileriYukle();
              },
              child: const Text("Kaydet"),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Seray Sağlık Yönetimi")),
      body: Column(
        children: [
          // YENİ: Son Analiz Özeti
          if (_sonVeri != null)
            Card(
              margin: const EdgeInsets.all(10),
              color: Colors.blue.shade50,
              child: ListTile(
                leading: const Icon(Icons.analytics, color: Colors.blue),
                title: Text("Son Şeker: ${_sonVeri!.seker} mg/dL"),
                subtitle: Text("Tansiyon: ${_sonVeri!.tansiyonUst}/${_sonVeri!.tansiyonAlt}"),
              ),
            ),
          
          // Yeni ölçüm ekleme hızlı eylemi
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: ElevatedButton.icon(
              onPressed: _yeniOlcumDialogGoster,
              icon: const Icon(Icons.bloodtype),
              label: const Text("Yeni Ölçüm Ekle"),
              style: ElevatedButton.styleFrom(
                minimumSize: const Size.fromHeight(50),
              ),
            ),
          ),

          // İlaç ekleme alanı
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(child: TextField(controller: _ilacController, decoration: const InputDecoration(labelText: "Yeni İlaç Adı"))),
                IconButton(icon: const Icon(Icons.add), onPressed: () => _ilacEkle(_ilacController.text)),
              ],
            ),
          ),
          
          // İlaç listesi
          Expanded(
            child: ListView.builder(
              itemCount: _ilaclar.length,
              itemBuilder: (context, index) => ListTile(
                title: Text(_ilaclar[index]),
                trailing: IconButton(icon: const Icon(Icons.delete, color: Colors.red), onPressed: () => _ilacSil(index)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
