// lib/services/api_service.dart
import 'package:googleai_dart/googleai_dart.dart';

class ApiService {
  static final GoogleAIClient _client = GoogleAIClient(
    config: GoogleAIConfig.googleAI(
      authProvider: ApiKeyProvider(
        'AQ.Ab8RN6LQTThMgNTmxqX8O5VfkGFxrSRGPG5UjUgYN0TdR2Y8Lg',
      ),
    ),
  );

  /// PDF'ten çıkarılan ham metni Gemini'ye gönderip
  /// sağlık değerlerini JSON metni olarak geri döndürür.
  static Future<String> tahlilMetniniAnalizEt(String pdfMetni) async {
    final istek =
        'Asagida bir tahlil/check-up PDF\'inden cikarilmis ham metin var.\n'
        'Bu metindeki en guncel degerleri bul ve SADECE asagidaki JSON formatinda,\n'
        'baska hicbir aciklama veya metin eklemeden cevap ver:\n\n'
        '{"tarih": "YYYY-MM-DDTHH:mm:ss", "tansiyonUst": SAYI, "tansiyonAlt": SAYI, "seker": SAYI, "nabiz": SAYI}\n\n'
        'Eger bir degeri bulamazsan 0 yaz. tarih alanina bugunun tarihini yaz.\n\n'
        'METIN:\n$pdfMetni';

    final response = await _client.models.generateContent(
      model: 'gemini-2.5-flash',
      request: GenerateContentRequest(
        contents: [Content(parts: [TextPart(istek)], role: 'user')],
      ),
    );

    String cevap = '';
    final parcalar = response.candidates?.first.content?.parts ?? [];
    for (final p in parcalar) {
      if (p is TextPart) {
        cevap = p.text;
        break;
      }
    }

    // Gemini bazen ```json ... ``` seklinde kod bloguyla donebiliyor, temizle
    cevap = cevap.replaceAll('```json', '').replaceAll('```', '').trim();
    return cevap;
  }
}
