import 'package:googleai_dart/googleai_dart.dart';

class ApiService {
  static final GoogleAIClient _client = GoogleAIClient(
    config: GoogleAIConfig.googleAI(
      authProvider: ApiKeyProvider(
        'AQ.Ab8RN6LQTThMgNTmxqX8O5VfkGFxrSRGPG5UjUgYN0TdR2Y8Lg',
      ),
    ),
  );

  /// E-Nabız PDF metnini geniş tıbbi parametrelerle analiz eder ve JSON döndürür.
  static Future<String> tahlilMetniniAnalizEt(String pdfMetni) async {
    if (pdfMetni.trim().isEmpty) {
      return '{"hata": "PDF içeriği boş."}';
    }

    final istek =
        'Sen profesyonel bir lab laboratuvar ve saglik uzmanisina yardimci olan yapay zekasin.\n'
        'Asagidaki E-Nabiz metnindeki en guncel tahlil sonuclarini ve tarihlerini bul.\n'
        'Cevabi baska hicbir metin veya aciklama eklemeden SADECE su JSON formatinda geri dondur:\n\n'
        '{\n'
        '  "tarih": "YYYY-MM-DD",\n'
        '  "seker": 0,\n'
        '  "tansiyonUst": 0,\n'
        '  "tansiyonAlt": 0,\n'
        '  "nabiz": 0,\n'
        '  "kolesterol": 0,\n'
        '  "ldl": 0,\n'
        '  "hdl": 0,\n'
        '  "trigliserid": 0,\n'
        '  "ast": 0,\n'
        '  "alt": 0,\n'
        '  "ure": 0,\n'
        '  "kreatinin": 0,\n'
        '  "hemoglobin": 0,\n'
        '  "b12": 0,\n'
        '  "d_vitamini": 0,\n'
        '  "tsh": 0\n'
        '}\n\n'
        'Eger metinde bu degerlerden biri veya birkaci bulunamazsa o alanlara 0 yaz. tarih alanina tahlilin yapildigi tarihi yaz.\n'
        'METIN:\n$pdfMetni';

    try {
      final response = await _client.models.generateContent(
        model: 'gemini-flash', 
        request: GenerateContentRequest(
          contents: [Content(parts: [TextPart(istek)], role: 'user')],
          generationConfig: GenerationConfig(responseMimeType: 'application/json'),
        ),
      );

      String cevap = '';
      final parcalar = response.candidates?.first.content?.parts ?? [];
      for (final p in parcalar) {
        if (p is TextPart) { cevap = p.text; break; }
      }
      return cevap.replaceAll('```json', '').replaceAll('```', '').trim();
    } catch (e) {
      return '{"hata": "${e.toString()}"}';
    }
  }
}
