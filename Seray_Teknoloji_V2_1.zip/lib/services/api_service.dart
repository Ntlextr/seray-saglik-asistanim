import 'package:googleai_dart/googleai_dart.dart';

class ApiService {
  static final GoogleAIClient _client = GoogleAIClient(
    config: GoogleAIConfig.googleAI(
      authProvider: ApiKeyProvider(
        'AQ.Ab8RN6LQTThMgNTmxqX8O5VfkGFxrSRGPG5UjUgYN0TdR2Y8Lg',
      ),
    ),
  );

  /// PDF'ten çıkarılan ham metni Gemini'ye gönderip
  /// sağlık değerlerini JSON metni olarak geri döndürür.
  static Future<String> tahlilMetniniAnalizEt(String pdfMetni) async {
    // PDF içeriği boş kalmışsa koruma kuralı
    if (pdfMetni.trim().isEmpty) {
      return '{"hata": "PDF içerisinden okunabilir bir metin çıkarılamadı. Lütfen PDF\'in taranmış bir resim olmadığından emin olun."}';
    }

    final istek =
        'Asagida bir tahlil/check-up PDF\'inden cikarilmis ham metin var.\n'
        'Bu metindeki en guncel degerleri bul ve SADECE asagidaki JSON formatinda,\n'
        'baska hicbir aciklama veya metin eklemeden cevap ver:\n\n'
        '{"tarih": "YYYY-MM-DDTHH:mm:ss", "tansiyonUst": SAYI, "tansiyonAlt": SAYI, "seker": SAYI, "nabiz": SAYI}\n\n'
        'Eger bir degeri bulamazsan 0 yaz. tarih alanina bugunun tarihini yaz.\n\n'
        'METIN:\n$pdfMetni';

    try {
      final response = await _client.models.generateContent(
        // 'gemini-flash' takma adı ile model her zaman en güncel sürümde kalır, eskimez.
        model: 'gemini-flash', 
        request: GenerateContentRequest(
          contents: [Content(parts: [TextPart(istek)], role: 'user')],
          // Yapay zekanın doğrudan temiz JSON döndürmesini zorunlu kılar
          generationConfig: GenerationConfig(
            responseMimeType: 'application/json',
          ),
        ),
      );

      String cevap = '';
      final parcalar = response.candidates?.first.content?.parts ?? [];
      for (final p in parcalar) {
        if (p is TextPart) {
          cevap = p.text;
          break;
        }
      }

      // Güvenlik amacıyla markdown kod bloklarını temizleme işlemi
      cevap = cevap.replaceAll('```json', '').replaceAll('```', '').trim();
      return cevap;

    } catch (e) {
      // Olası internet veya API hatalarını uygulamanın çökmesini önleyerek yakalar
      return '{"hata": "Bağlantı hatası oluştu: ${e.toString()}"}';
    }
  }
}
