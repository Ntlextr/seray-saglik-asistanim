import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/saglik_verisi.dart';

class DatabaseServisi {
  static const String _key = 'saglik_kayitlari';

  static Future<void> veriKaydet(SaglikVerisi yeniVeri) async {
    final prefs = await SharedPreferences.getInstance();
    List<String> kayitlar = prefs.getStringList(_key) ?? [];
    kayitlar.add(jsonEncode(yeniVeri.toJson()));
    await prefs.setStringList(_key, kayitlar);
  }

  static Future<List<SaglikVerisi>> verileriGetir() async {
    final prefs = await SharedPreferences.getInstance();
    List<String> kayitlar = prefs.getStringList(_key) ?? [];
    return kayitlar.map((s) => SaglikVerisi.fromJson(jsonDecode(s))).toList();
  }

  /// Dr. Raporu için veriyi metin formatında döker (Model yapısıyla tam uyumlu)
  static Future<String> raporHazirla() async {
    List<SaglikVerisi> liste = await verileriGetir();
    String rapor = "SAĞLIK TAKİP RAPORU\n------------------\n";
    for (var v in liste) {
      // Hata veren ilacBilgisi kaldırıldı, mevcut model verileriyle eşitlendi
      rapor += "${v.tarih.toString().substring(0,10)} | Şeker: ${v.seker} | Tansiyon: ${v.tansiyonUst}/${v.tansiyonAlt} | Nabız: ${v.nabiz}\n";
    }
    return rapor;
  }
}
