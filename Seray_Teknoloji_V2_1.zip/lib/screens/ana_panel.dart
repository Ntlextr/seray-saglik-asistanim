import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import '../models/saglik_verisi.dart';
import '../services/database_servisi.dart';

class AnaSaglikPaneli extends StatefulWidget {
  const AnaSaglikPaneli({super.key});

  @override
  State<AnaSaglikPaneli> createState() => _AnaSaglikPaneliState();
}

class _AnaSaglikPaneliState extends State<AnaSaglikPaneli> {
  List<String> _ilaclar = [];
  final TextEditingController _ilacController = TextEditingController();
  SaglikVerisi? _sonVeri;
  String _kullaniciAdi = "";
  String _selamlamaMetni = "";

  @override
  void initState() {
    super.initState();
    _verileriYukle();
  }

  Future<void> _verileriYukle() async {
    final prefs = await SharedPreferences.getInstance();
    int saat = DateTime.now().hour;
    String selamlama = "Merhaba";
    if (saat >= 5 && saat < 12) selamlama = "G�naydn";
    else if (saat >= 12 && saat < 17) selamlama = "yi G�nler";
    else if (saat >= 17 && saat < 22) selamlama = "yi Akamlar";
    else selamlama = "yi Geceler";

    setState(() {
      _kullaniciAdi = prefs.getString('user_ad') ?? "Kullanc";
      _selamlamaMetni = selamlama;
      _ilaclar = prefs.getStringList('ilaclar') ?? [];
      List<String> kayitlar = prefs.getStringList('saglik_kayitlari') ?? [];
      if (kayitlar.isNotEmpty) {
        _sonVeri = SaglikVerisi.fromJson(jsonDecode(kayitlar.last));
      }
    });
  }

  /// Se�meli Paylam Men�s� (WhatsApp d�z metin, E-posta resmi dosya eki �retir)
  void _doktoraRaporPaylasMenu() {
    showModalBottomSheet(
      context: context,
      builder: (context) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Padding(
            padding: EdgeInsets.all(16.0),
            child: Text("Raporu Nasl G�ndermek stersiniz?", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          ),
          ListTile(
            leading: const Icon(Icons.message, color: Colors.green),
            title: const Text("WhatsApp ile Hzl G�nder"),
            onTap: () async {
              Navigator.pop(context);
              String metinRapor = await DatabaseServisi.doktorRaporuHazirla();
              await Share.share(metinRapor, subject: 'G�nl�k Salk Takip Verilerim');
            },
          ),
          ListTile(
            leading: const Icon(Icons.picture_as_pdf, color: Colors.red),
            title: const Text("E-Posta / Yazdrlabilir Belge Olarak Payla"),
            onTap: () async {
              Navigator.pop(context);
              String metinRapor = await DatabaseServisi.doktorRaporuHazirla();
              final directory = await getTemporaryDirectory();
              final file = File('${directory.path}/doktor_saglik_takip_raporu.txt');
              await file.writeAsString(metinRapor);
              await Share.shareXFiles([XFile(file.path)], text: 'Sayn Doktorum, g�nl�k eker ve tansiyon �l��m d�k�mlerim ektedir.');
            },
          ),
          const SizedBox(height: 10),
        ],
      ),
    );
  }

  Future<void> _ilacEkle(String ilac) async {
    if (ilac.isEmpty) return;
    final prefs = await SharedPreferences.getInstance();
    setState(() { _ilaclar.add(ilac); _ilacController.clear(); });
    await prefs.setStringList('ilaclar', _ilaclar);
  }

  Future<void> _ilacSil(int index) async {
    final prefs = await SharedPreferences.getInstance();
    setState(() { _ilaclar.removeAt(index); });
    await prefs.setStringList('ilaclar', _ilaclar);
  }

  Future<void> _yeniOlcumDialogGoster() async {
    final sekerController = TextEditingController();
    final tansiyonUstController = TextEditingController();
    final tansiyonAltController = TextEditingController();
    final nabizController = TextEditingController();
    String? hataMesaji;

    await showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text("Yeni �l��m Ekle"),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: sekerController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: "eker (mg/dL)")),
                TextField(controller: tansiyonUstController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: "Tansiyon B�y�k (�st)")),
                TextField(controller: tansiyonAltController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: "Tansiyon K���k (Alt)")),
                TextField(controller: nabizController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: "Nabz")),
                if (hataMesaji != null) ...[const SizedBox(height: 10), Text(hataMesaji!, style: const TextStyle(color: Colors.red))],
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text("ptal")),
            ElevatedButton(
              onPressed: () async {
                final seker = double.tryParse(sekerController.text);
                final tUst = double.tryParse(tansiyonUstController.text);
                final tAlt = double.tryParse(tansiyonAltController.text);
                final nabiz = double.tryParse(nabizController.text);

                if (seker == null || tUst == null || tAlt == null || nabiz == null) {
                  setDialogState(() => hataMesaji = "L�tfen t�m alanlar doldurun.");
                  return;
                }

                final yeniVeri = SaglikVerisi(tarih: DateTime.now(), seker: seker, tansiyonUst: tUst, tansiyonAlt: tAlt, nabiz: nabiz);
                await DatabaseServisi.veriKaydet(yeniVeri);
                if (context.mounted) Navigator.pop(context);
                await _verileriYukle();
              },
              child: const Text("Kaydet"),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Seray Salk Y�netimi"), backgroundColor: Colors.teal, foregroundColor: Colors.white),
      body: Column(
        children: [
          Card(
            margin: const EdgeInsets.all(12),
            color: Colors.teal.shade50,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                children: [
                  const Icon(Icons.wb_sunny, color: Colors.orange, size: 32),
                  const SizedBox(width: 16),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("$_selamlamaMetni, $_kullaniciAdi! ", style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.teal)),
                      const SizedBox(height: 4),
                      const Text("Bug�nk� deerlerinizi kontrol ettiniz mi?", style: TextStyle(color: Colors.black54)),
                    ],
                  ),
                ],
              ),
            ),
          ),

          if (_sonVeri != null)
            Card(
              margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              color: Colors.blue.shade50,
              child: ListTile(
                leading: const Icon(Icons.analytics, color: Colors.blue),
                title: Text("Son eker: ${_sonVeri!.seker.toStringAsFixed(0)} mg/dL"),
                subtitle: Text("Tansiyon: ${_sonVeri!.tansiyonUst.toStringAsFixed(0)}/${_sonVeri!.tansiyonAlt.toStringAsFixed(0)}"),
              ),
            ),
          
          const SizedBox(height: 10),

          // �L��M EKLEME VE DOKTORA G�NDERME BUTONLARI
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _yeniOlcumDialogGoster,
                    icon: const Icon(Icons.add),
                    label: const Text("�l��m Ekle"),
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.teal, foregroundColor: Colors.white, minimumSize: const Size(0, 50)),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _doktoraRaporPaylasMenu,
                    icon: const Icon(Icons.share),
                    label: const Text("Doktora G�nder"),
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.blue.shade700, foregroundColor: Colors.white, minimumSize: const Size(0, 50)),
                  ),
                ),
              ],
            ),
          ),

          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Row(
              children: [
                Expanded(child: TextField(controller: _ilacController, decoration: const InputDecoration(labelText: "Yeni la� Ad", border: OutlineInputBorder()))),
                const SizedBox(width: 8),
                IconButton(icon: const Icon(Icons.add_box, size: 40, color: Colors.teal), onPressed: () => _ilacEkle(_ilacController.text)),
              ],
            ),
          ),
          
          Expanded(
            child: ListView.builder(
              itemCount: _ilaclar.length,
              itemBuilder: (context, index) => Card(
                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                child: ListTile(
                  title: Text(_ilaclar[index], style: const TextStyle(fontWeight: FontWeight.w500)),
          // la� listesi
          Expanded(
            child: ListView.builder(
              itemCount: _ilaclar.length,
              itemBuilder: (context, index) => Card(
                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                child: ListTile(
                  title: Text(_ilaclar[index], style: const TextStyle(fontWeight: FontWeight.w500)),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete, color: Colors.red), 
                    onPressed: () => _ilacSil(index),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
