import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'profil_kayit_ekrani.dart'; // Sıfırlama işleminde geri dönmek için

class ProfilSayfasi extends StatefulWidget {
  const ProfilSayfasi({Key? key}) : super(key: key);

  @override
  _ProfilSayfasiState createState() => _ProfilSayfasiState();
}

class _ProfilSayfasiState extends State<ProfilSayfasi> {
  String _ad = "...";
  String _soyad = "...";
  int _yas = 0;
  int _toplamTahlilSayisi = 0;

  @override
  void initState() {
    super.initState();
    _profilVerileriniYukle();
  }

  /// Telefon hafızasından kayıtlı profil ve tahlil geçmişi istatistiklerini yükler
  Future<void> _profilVerileriniYukle() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _ad = prefs.getString('user_ad') ?? "Bilinmiyor";
      _soyad = prefs.getString('user_soyad') ?? "Bilinmiyor";
      _yas = prefs.getInt('user_yas') ?? 0;
      
      // Kaydedilen tahlillerin sayısını çekiyoruz
      List<String> gecmis = prefs.getStringList('gecmis_analizler') ?? [];
      _toplamTahlilSayisi = gecmis.length;
    });
  }

  /// Kullanıcı profilini silip uygulamayı ilk kurulum haline getirir
  Future<void> _profiliSifirla() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear(); // Tüm SharedPreferences hafızasını temizler
    
    if (mounted) {
      // Kullanıcıyı en baştaki kayıt ekranına geri gönderir
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => const ProfilKayitEkrani()),
        (route) => false,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profil Bilgilerim'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            const SizedBox(height: 20),
            // Profil Avatarı Bölümü
            Center(
              child: Stack(
                children: [
                  CircleAvatar(
                    radius: 60,
                    backgroundColor: Colors.teal.shade100,
                    child: Text(
                      _ad[0].toUpperCase(),
                      style: const TextStyle(fontSize: 48, fontWeight: FontWeight.bold, color: Colors.teal),
                    ),
                  ),
                  Positioned(
                    bottom: 0,
                    right: 4,
                    child: CircleAvatar(
                      backgroundColor: Colors.teal.shade700,
                      radius: 18,
                      child: const Icon(Icons.edit, size: 18, color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Text(
              "$_ad $_soyad",
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const Text(
              "Seray Sağlık Kullanıcısı",
              style: TextStyle(fontSize: 14, color: Colors.grey),
            ),
            const SizedBox(height: 30),
            
            // İstatistik Kartı
            Card(
              color: Colors.teal.shade50,
              elevation: 0,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _istatistikOgesi("Yaş", "$_yas"),
                    Container(width: 1, height: 40, color: Colors.teal.shade200),
                    _istatistikOgesi("Analiz Edilen", "$_toplamTahlilSayisi Rapor"),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Menü Seçenekleri Listesi
            _menuOgesi(Icons.person_outline, "Adı Soyadı", "$_ad $_soyad"),
            _menuOgesi(Icons.cake_outlined, "Yaş Bilgisi", "$_yas Yaşında"),
            _menuOgesi(Icons.privacy_tip_outline, "Gizlilik Sözleşmesi", "Verileriniz Cihazınızda Saklanır"),
            
            const SizedBox(height: 40),
            
            // Hesabı/Profili Sıfırlama Butonu
            OutlinedButton.icon(
              onPressed: () {
                // Güvenlik için kullanıcıya onay kutusu gösteriyoruz
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: const Text("Profili Sıfırla"),
                    content: const Text("Tüm profil bilgileriniz ve geçmiş tahlil kayıtlarınız telefonunuzdan silinecektir. Emin misiniz?"),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(context), child: const Text("Vazgeç")),
                      TextButton(onPressed: _profiliSifirla, child: const Text("Evet, Sıfırla", style: TextStyle(color: Colors.red))),
                    ],
                  ),
                );
              },
              icon: const Icon(Icons.logout, color: Colors.red),
              label: const Text("PROFİLİ VE VERİLERİ SIFIRLA", style: TextStyle(color: Colors.red)),
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: Colors.red),
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _istatistikOgesi(String baslik, String deger) {
    return Column(
      children: [
        Text(baslik, style: const TextStyle(fontSize: 14, color: Colors.black54)),
        const SizedBox(height: 4),
        Text(deger, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.teal)),
      ],
    );
  }

  Widget _menuOgesi(IconData ikon, String baslik, String altBaslik) {
    return Card(
      elevation: 0.5,
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: ListTile(
        leading: Icon(ikon, color: Colors.teal.shade700),
        title: Text(baslik, style: const TextStyle(fontWeight: FontWeight.w500)),
        subtitle: Text(altBaslik, style: const TextStyle(fontSize: 13, color: Colors.grey)),
        trailing: const Icon(Icons.arrow_forward_ios, size: 14, color: Colors.grey),
      ),
    );
  }
}
