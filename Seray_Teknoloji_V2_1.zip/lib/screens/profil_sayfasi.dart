import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:share_plus/share_plus.dart';
import 'profil_kayit_ekrani.dart';

class ProfilSayfasi extends StatefulWidget {
  const ProfilSayfasi({Key? key}) : super(key: key);

  @override
  _ProfilSayfasiState createState() => _ProfilSayfasiState();
}

class _ProfilSayfasiState extends State<ProfilSayfasi> {
  String _ad = "..."; 
  String _soyad = "..."; 
  int _yas = 0;
  final TextEditingController _yedekController = TextEditingController();

  @override
  void initState() { 
    super.initState(); 
    _verileriYukle(); 
  }

  Future<void> _verileriYukle() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _ad = prefs.getString('user_ad') ?? "Bilinmiyor";
      _soyad = prefs.getString('user_soyad') ?? "Bilinmiyor";
      _yas = prefs.getInt('user_yas') ?? 0;
    });
  }

  // YEDEKLEME MOTORU: Tüm verileri tek şifreli metin kodu olarak WhatsApp/E-Postaya gönderir
  Future<void> _verileriYedekle() async {
    final prefs = await SharedPreferences.getInstance();
    Map<String, dynamic> tumVeriler = {
      'user_ad': prefs.getString('user_ad'),
      'user_soyad': prefs.getString('user_soyad'),
      'user_yas': prefs.getInt('user_yas'),
      'saglik_kayitlari': prefs.getStringList('saglik_kayitlari') ?? [],
      'ilaclar': prefs.getStringList('ilaclar') ?? [],
    };
    String yedekKodu = jsonEncode(tumVeriler);
    Share.share("SERAY_SAGLIK_YEDEK_DATA:\n$yedekKodu", subject: 'Sağlık Verisi Güvenli Yedek Kodu');
  }

  // GERİ YÜKLEME MOTORU: Kopyalanan yedek kodunu okur ve uygulamaya yükler
  Future<void> _veriyiGeriYukle(String kod) async {
    try {
      final temizKod = kod.replaceAll("SERAY_SAGLIK_YEDEK_DATA:\n", "").trim();
      Map<String, dynamic> cozulen = jsonDecode(temizKod);
      final prefs = await SharedPreferences.getInstance();
      
      if (cozulen.containsKey('user_ad')) {
        await prefs.setString('user_ad', cozulen['user_ad']);
        await prefs.setString('user_soyad', cozulen['user_soyad']);
        await prefs.setInt('user_yas', cozulen['user_yas']);
        await prefs.setStringList('saglik_kayitlari', List<String>.from(cozulen['saglik_kayitlari']));
        await prefs.setStringList('ilaclar', List<String>.from(cozulen['ilaclar']));
        
        _verileriYukle();
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Yedek başarıyla geri yüklendi!'), backgroundColor: Colors.green));
        }
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Hata: Geçersiz yedek kodu!'), backgroundColor: Colors.red));
    }
  }

  Future<void> _cikisYapVeSil() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear(); // Tüm verileri siler
    if (mounted) {
      Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context) => const ProfilKayitEkrani()), (route) => false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Profil & Yedek Yönetimi'), backgroundColor: Colors.teal, foregroundColor: Colors.white),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          Card(
            color: Colors.teal.shade50,
            child: ListTile(
              leading: const Icon(Icons.account_box, size: 40, color: Colors.teal),
              title: Text("$_ad $_soyad", style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
              subtitle: Text("Sistem Yaş Bilgisi: $_yas Yaşında"),
            ),
          ),
          const SizedBox(height: 20),
          const Text("💾 Veri Güvenliği, Yedekleme ve Geri Yükleme", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          const Divider(),
          const SizedBox(height: 10),
          ElevatedButton.icon(
            onPressed: _verileriYedekle, 
            icon: const Icon(Icons.cloud_upload), 
            label: const Text("TÜM VERİLERİ YEDEKLE (KODU PAYLAŞ)"),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.teal.shade700, foregroundColor: Colors.white, padding: const EdgeInsets.all(14)),
          ),
          const SizedBox(height: 20),
          TextField(
            controller: _yedekController, 
            maxLines: 3,
            decoration: const InputDecoration(labelText: "Paylaşılan Yedek Kodunu Buraya Yapıştırın", border: OutlineInputBorder()),
          ),
          const SizedBox(height: 8),
          ElevatedButton.icon(
            onPressed: () => _veriyiGeriYukle(_yedekController.text),
            icon: const Icon(Icons.cloud_download),
            label: const Text("KODDAN GERİ YÜKLE"),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.orange.shade800, foregroundColor: Colors.white, padding: const EdgeInsets.all(12)),
          ),
          const SizedBox(height: 40),
          const Divider(),
          ElevatedButton.icon(
            onPressed: () {
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  title: const Text("Güvenli Çıkış & Profil Silme"),
                  content: const Text("Uygulamadaki tüm profil bilgileriniz ve yüklediğiniz tahlil geçmişiniz silinecektir. Devam edilsin mi?"),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context), child: const Text("İptal")),
                    TextButton(onPressed: _cikisYapVeSil, child: const Text("Evet, Tümünü Sil ve Çık", style: TextStyle(color: Colors.red))),
                  ],
                ),
              );
            },
            icon: const Icon(Icons.power_settings_new),
            label: const Text("HESABI SİL & GÜVENLİ ÇIKIŞ"),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red.shade700, foregroundColor: Colors.white, padding: const EdgeInsets.all(14)),
          ),
        ],
      ),
    );
  }
}
