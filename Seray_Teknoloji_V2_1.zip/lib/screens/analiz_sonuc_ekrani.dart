import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:share_plus/share_plus.dart';
import 'package:flutter_tts/flutter_tts.dart';
import '../services/api_service.dart';
import '../models/saglik_verisi.dart';
import '../services/database_servisi.dart';

class AnalizSonucEkrani extends StatefulWidget {
  final String hamPdfMetni;

  const AnalizSonucEkrani({Key? key, required this.hamPdfMetni}) : super(key: key);

  @override
  _AnalizSonucEkraniState createState() => _AnalizSonucEkraniState();
}

class _AnalizSonucEkraniState extends State<AnalizSonucEkrani> {
  bool _yukleniyor = true;
  String? _hataMesaji;
  Map<String, dynamic>? _saglikVerileri;
  final FlutterTts _flutterTts = FlutterTts();

  @override
  void initState() {
    super.initState();
    _analiziBaslat();
  }

  @override
  void dispose() {
    _flutterTts.stop();
    super.dispose();
  }

  Future<void> _analiziBaslat() async {
    try {
      String jsonString = await ApiService.tahlilMetniniAnalizEt(widget.hamPdfMetni);
      final cozuldenVeri = jsonDecode(jsonString);

      if (cozuldenVeri.containsKey('hata')) {
        setState(() {
          _hataMesaji = cozuldenVeri['hata'];
          _yukleniyor = false;
        });
      } else {
        setState(() {
          _saglikVerileri = cozuldenVeri;
          _yukleniyor = false;
        });
        
        // Model nesnesi oluturup DatabaseServisi sistemine kaydediyoruz
        final yeniModelVerisi = SaglikVerisi(
          tarih: DateTime.tryParse(cozuldenVeri['tarih'] ?? '') ?? DateTime.now(),
          seker: double.tryParse(cozuldenVeri['seker']?.toString() ?? '0') ?? 0,
          tansiyonUst: double.tryParse(cozuldenVeri['tansiyonUst']?.toString() ?? '0') ?? 0,
          tansiyonAlt: double.tryParse(cozuldenVeri['tansiyonAlt']?.toString() ?? '0') ?? 0,
          nabiz: double.tryParse(cozuldenVeri['nabiz']?.toString() ?? '0') ?? 0,
        );

        await DatabaseServisi.veriKaydet(yeniModelVerisi);
        await _sesliSaglikAnaliziYap();
      }
    } catch (e) {
      setState(() {
        _hataMesaji = "Veri ilenirken bir hata oldu: $e";
        _yukleniyor = false;
      });
    }
  }

  Future<void> _sesliSaglikAnaliziYap() async {
    if (_saglikVerileri == null) return;

    int seker = _saglikVerileri!['seker'] ?? 0;
    int tansiyonUst = _saglikVerileri!['tansiyonUst'] ?? 0;
    String sesMetni = "Tahlil sonu�larnz baaryla analiz edildi. ";

    if (seker > 140) sesMetni += "Dikkat, kan ekeriniz y�ksek g�r�n�yor. ";
    if (tansiyonUst > 13) sesMetni += "B�y�k tansiyonunuz snrda veya y�ksek.";
    if (seker <= 140 && tansiyonUst <= 13) sesMetni += "Harika! Deerleriniz normal snrlar i�inde.";

    await _flutterTts.setLanguage("tr-TR");
    await _flutterTts.setSpeechRate(0.5);
    await _flutterTts.speak(sesMetni);
  }

  void _sonuclariPaylas() {
    if (_saglikVerileri == null) return;

    String paylasimMetni = 
        " Salk Raporu Analiz Sonucu\n"
        " Tarih: ${_saglikVerileri!['tarih']}\n"
        " Tansiyon: ${_saglikVerileri!['tansiyonUst']}/${_saglikVerileri!['tansiyonAlt']}\n"
        " Kan ekeri: ${_saglikVerileri!['seker']} mg/dL\n"
        " Nabz: ${_saglikVerileri!['nabiz']} bpm\n\n"
        "Seray Salk Asistan tarafndan otomatik analiz edilmitir.";

    Share.share(paylasimMetni, subject: 'Tahlil Sonu�larm');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Gelimi Analiz Paneli'),
        backgroundColor: Colors.teal,
        actions: _saglikVerileri != null ? [IconButton(icon: const Icon(Icons.share), onPressed: _sonuclariPaylas)] : null,
      ),
      body: _yukleniyor
          ? const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(color: Colors.teal),
                  SizedBox(height: 16),
                  Text('Gemini Yapay Zekas Analiz Ediyor...'),
                ],
              ),
            )
          : _hataMesaji != null
              ? Center(child: Padding(padding: const EdgeInsets.all(16.0), child: Text(_hataMesaji!, style: const TextStyle(color: Colors.red, fontSize: 16))))
              : _sonucListesiniGoster(),
    );
  }

  Widget _sonucListesiniGoster() {
    return ListView(
      padding: const EdgeInsets.all(16.0),
      children: [
        Card(
          color: Colors.teal.shade50,
          child: ListTile(
            leading: const Icon(Icons.calendar_today, color: Colors.teal),
            title: const Text('Tahlil Kayt Tarihi'),
            subtitle: Text(_saglikVerileri!['tarih'] ?? 'Bilinmiyor'),
            trailing: IconButton(icon: const Icon(Icons.volume_up, color: Colors.teal), onPressed: _sesliSaglikAnaliziYap),
          ),
        ),
        const SizedBox(height: 20),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('�l��len Deerler', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ElevatedButton.icon(
              onPressed: _sonuclariPaylas,
              icon: const Icon(Icons.share, size: 16),
              label: const Text('Raporu Payla'),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.teal.shade700, foregroundColor: Colors.white),
            )
          ],
        ),
        const Divider(),
        _degerKarti('Tansiyon (B�y�k/K���k)', '${_saglikVerileri!['tansiyonUst']} / ${_saglikVerileri!['tansiyonAlt']}', Icons.favorite, Colors.red),
        _degerKarti('Kan ekeri', '${_saglikVerileri!['seker']} mg/dL', Icons.opacity, Colors.orange),
        _degerKarti('Nabz', '${_saglikVerileri!['nabiz']} bpm', Icons.speed, Colors.blue),
      ],
    );
  }

  Widget _degerKarti(String baslik, String deger, IconData icon, Color renk) {
    return Card(
      elevation: 2,
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: ListTile(
        leading: CircleAvatar(backgroundColor: renk.withOpacity(0.1), child: Icon(icon, color: renk)),
        title: Text(baslik),
        trailing: Text(deger, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black87)),
      ),
    );
  }
}
