import 'dart:convert';
import 'package:googleai_dart/googleai_dart.dart';

class ApiService {
  static final GoogleAIClient _client = GoogleAIClient(
    config: GoogleAIConfig.googleAI(
      authProvider: ApiKeyProvider(
        'AQ.Ab8RN6LQTThMgNTmxqX8O5VfkGFxrSRGPG5UjUgYN0TdR2Y8Lg',
      ),
    ),
  );

  /// Bozuk kodlama karakterlerini yakalayıp düzgün Türkçe harflerine çeviren kurtarma motoru
  static String _bozukKarakterleriTamirEt(String metin) {
    var bozuklar = {
      'Ã½': 'ı', 'Ã ': 'à', 'Ã§': 'ç', 'Ã¶': 'ö', 'Ã¼': 'ü', 'Åÿ': 'ş', 'Ã°': 'ğ',
      'Ã ': 'Ø', 'Ã ': 'Ç', 'Ã ': 'Ö', 'Ã ': 'Ü', 'Å ': 'Ş', 'Ã ': 'Ğ', 'Ä±': 'ı',
      'Ä ': 'ğ', 'Å ': 'ş', 'Ã§': 'ç', 'Ã¶': 'ö', 'Ã¼': 'ü', 'Ä°': 'İ', '': 'ı'
    };
    bozuklar.forEach((key, value) {
      metin = metin.replaceAll(key, value);
    });
    return metin;
  }

  static Future<String> tahlilMetniniAnalizEt(String pdfMetni) async {
    // PDF'ten gelen ham metni önce tamir motorundan geçiriyoruz
    pdfMetni = _bozukKarakterleriTamirEt(pdfMetni);

    if (pdfMetni.trim().isEmpty) {
      return '{"hata": "PDF icerigi bos."}';
    }

    final istek =
        'Sen profesyonel bir lab laboratuvar ve saglik uzmanisina yardimci olan yapay zekasin.\n'
        'Asagidaki E-Nabiz metnindeki en guncel tahlil sonuclarini bul.\n'
        'Cevabi baska hicbir metin, aciklama veya ters bolu isareti eklemeden SADECE tek bir satirda su JSON formatinda dondur:\n\n'
        '{"tarih": "2026-07-15", "seker": 0, "tansiyonUst": 0, "tansiyonAlt": 0, "nabiz": 0, "kolesterol": 0, "ldl": 0, "hdl": 0, "trigliserid": 0, "ast": 0, "alt": 0, "ure": 0, "kreatinin": 0, "hemoglobin": 0, "b12": 0, "d_vitamini": 0, "tsh": 0}\n\n'
        'Metinde bulunmayan sayisal alanlara 0 yaz. tarih alanina tahlil tarihini YYYY-MM-DD formatinda yaz.\n'
        'METIN:\n$pdfMetni';

    try {
      final response = await _client.models.generateContent(
        model: 'gemini-flash-latest', 
        request: GenerateContentRequest(
          contents: [Content(parts: [TextPart(istek)], role: 'user')],
          generationConfig: GenerationConfig(responseMimeType: 'application/json'),
        ),
      );

      String cevap = '';
      final parcalar = response.candidates?.first.content?.parts ?? [];
      for (final p in parcalar) {
        if (p is TextPart) { cevap = p.text; break; }
      }

      // JSON Çökmelerini Önleyen Web Tarzı Filtreler
      cevap = cevap.replaceAll('```json', '').replaceAll('```', '').trim();
      cevap = cevap.replaceAll('\n', '').replaceAll('\r', '').replaceAll('\t', '');
      
      // Çıktıyı vermeden önce son bir kez daha temizliyoruz
      return _bozukKarakterleriTamirEt(cevap);
    } catch (e) {
      return '{"hata": "${e.toString()}"}';
    }
  }
}
