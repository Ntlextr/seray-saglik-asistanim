import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart';
import '../models/saglik_verisi.dart';
import '../services/database_servisi.dart';

/// Düz metin raporunu gerçek bir PDF dosyasına dönüştürüp geçici klasöre kaydeder
Future<File> _raporuPdfyeCevirVeKaydet(String metin, String dosyaAdi) async {
  final PdfDocument document = PdfDocument();
  final PdfPage sayfa = document.pages.add();
  final PdfLayoutResult? sonuc = PdfTextElement(
    text: metin,
    font: PdfStandardFont(PdfFontFamily.helvetica, 12),
  ).draw(
    page: sayfa,
    bounds: Rect.fromLTWH(0, 0, sayfa.getClientSize().width, sayfa.getClientSize().height),
    format: PdfLayoutFormat(layoutType: PdfLayoutType.paginate),
  );
  // ignore: unused_local_variable
  final _ = sonuc;
  final List<int> bayt = document.saveSync();
  document.dispose();
  final directory = await getTemporaryDirectory();
  final file = File('${directory.path}/$dosyaAdi.pdf');
  await file.writeAsBytes(bayt);
  return file;
}

class AnaSaglikPaneli extends StatefulWidget {
  const AnaSaglikPaneli({super.key});

  @override
  State<AnaSaglikPaneli> createState() => _AnaSaglikPaneliState();
}

class _AnaSaglikPaneliState extends State<AnaSaglikPaneli> {
  List<String> _ilaclar = [];
  final TextEditingController _ilacController = TextEditingController();
  SaglikVerisi? _sonVeri;
  String _kullaniciAdi = "";
  String _selamlamaMetni = "";

  @override
  void initState() {
    super.initState();
    _verileriYukle();
  }

  Future<void> _verileriYukle() async {
    final prefs = await SharedPreferences.getInstance();
    int saat = DateTime.now().hour;
    String selamlama = "Merhaba";
    if (saat >= 5 && saat < 12) selamlama = "Günaydın";
    else if (saat >= 12 && saat < 17) selamlama = "İyi Günler";
    else if (saat >= 17 && saat < 22) selamlama = "İyi Akşamlar";
    else selamlama = "İyi Geceler";

    setState(() {
      _kullaniciAdi = prefs.getString('user_ad') ?? "Kullanıcı";
      _selamlamaMetni = selamlama;
      _ilaclar = prefs.getStringList('ilaclar') ?? [];
      List<String> kayitlar = prefs.getStringList('saglik_kayitlari') ?? [];
      if (kayitlar.isNotEmpty) {
        _sonVeri = SaglikVerisi.fromJson(jsonDecode(kayitlar.last));
      }
    });
  }

  void _doktoraRaporPaylasMenu() {
    showModalBottomSheet(
      context: context,
      builder: (context) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Padding(
            padding: EdgeInsets.all(16.0),
            child: Text("Raporu Nasıl Göndermek İstersiniz?", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          ),
          ListTile(
            leading: const Icon(Icons.message, color: Colors.green),
            title: const Text("WhatsApp ile Hızlı Gönder"),
            onTap: () async {
              Navigator.pop(context);
              String metinRapor = await DatabaseServisi.doktorRaporuHazirla();
              await Share.share(metinRapor, subject: 'Günlük Sağlık Takip Verilerim');
            },
          ),
          ListTile(
            leading: const Icon(Icons.picture_as_pdf, color: Colors.red),
            title: const Text("E-Posta / Yazdırılabilir Belge Olarak Paylaş"),
            onTap: () async {
              Navigator.pop(context);
              String metinRapor = await DatabaseServisi.doktorRaporuHazirla();
              final file = await _raporuPdfyeCevirVeKaydet(metinRapor, 'doktor_saglik_takip_raporu');
              await Share.shareXFiles([XFile(file.path)], text: 'Sayın Doktorum, günlük şeker ve tansiyon ölçüm dökümlerim ektedir.');
            },
          ),
          const SizedBox(height: 10),
        ],
      ),
    );
  }

  Future<void> _ilacEkle(String ilac) async {
    if (ilac.isEmpty) return;
    final prefs = await SharedPreferences.getInstance();
    setState(() { _ilaclar.add(ilac); _ilacController.clear(); });
    await prefs.setStringList('ilaclar', _ilaclar);
  }

  Future<void> _ilacSil(int index) async {
    final prefs = await SharedPreferences.getInstance();
    setState(() { _ilaclar.removeAt(index); });
    await prefs.setStringList('ilaclar', _ilaclar);
  }
  Future<void> _yeniOlcumDialogGoster() async {
    final sekerController = TextEditingController();
    final tansiyonUstController = TextEditingController();
    final tansiyonAltController = TextEditingController();
    final nabizController = TextEditingController();
    String? hataMesaji;

    await showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text("Yeni Ölçüm Ekle"),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: sekerController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: "Şeker (mg/dL)")),
                TextField(controller: tansiyonUstController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: "Tansiyon Büyük (Üst)")),
                TextField(controller: tansiyonAltController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: "Tansiyon Küçük (Alt)")),
                TextField(controller: nabizController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: "Nabız")),
                if (hataMesaji != null) ...[const SizedBox(height: 10), Text(hataMesaji!, style: const TextStyle(color: Colors.red))],
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text("İptal")),
            ElevatedButton(
              onPressed: () async {
                final seker = double.tryParse(sekerController.text);
                final tUst = double.tryParse(tansiyonUstController.text);
                final tAlt = double.tryParse(tansiyonAltController.text);
                final nabiz = double.tryParse(nabizController.text);

                if (seker == null || tUst == null || tAlt == null || nabiz == null) {
                  setDialogState(() => hataMesaji = "Lütfen tüm alanları doldurun.");
                  return;
                }

                final yeniVeri = SaglikVerisi(tarih: DateTime.now(), seker: seker, tansiyonUst: tUst, tansiyonAlt: tAlt, nabiz: nabiz);
                await DatabaseServisi.veriKaydet(yeniVeri);
                if (context.mounted) Navigator.pop(context);
                await _verileriYukle();
              },
              child: const Text("Kaydet"),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Seray Sağlık Yönetimi"), backgroundColor: Colors.teal, foregroundColor: Colors.white),
      body: Column(
        children: [
          Card(
            margin: const EdgeInsets.all(12),
            color: Colors.teal.shade50,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                children: [
                  const Icon(Icons.wb_sunny, color: Colors.orange, size: 32),
                  const SizedBox(width: 16),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("$_selamlamaMetni, $_kullaniciAdi! 👋", style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.teal)),
                      const SizedBox(height: 4),
                      const Text("Bugünkü değerlerinizi kontrol ettiniz mi?", style: TextStyle(color: Colors.black54)),
                    ],
                  ),
                ],
              ),
            ),
          ),
          if (_sonVeri != null)
            Card(
              margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              color: Colors.blue.shade50,
              child: ListTile(
                leading: const Icon(Icons.analytics, color: Colors.blue),
                title: Text("Son Şeker: ${_sonVeri!.seker.toStringAsFixed(0)} mg/dL"),
                subtitle: Text("Tansiyon: ${_sonVeri!.tansiyonUst.toStringAsFixed(0)}/${_sonVeri!.tansiyonAlt.toStringAsFixed(0)}"),
              ),
            ),
          const SizedBox(height: 10),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _yeniOlcumDialogGoster,
                    icon: const Icon(Icons.add),
                    label: const Text("Ölçüm Ekle"),
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.teal, foregroundColor: Colors.white, minimumSize: const Size(0, 50)),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _doktoraRaporPaylasMenu,
                    icon: const Icon(Icons.share),
                    label: const Text("Doktora Gönder"),
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.blue.shade700, foregroundColor: Colors.white, minimumSize: const Size(0, 50)),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Row(
              children: [
                Expanded(child: TextField(controller: _ilacController, decoration: const InputDecoration(labelText: "Yeni İlaç Adı", border: OutlineInputBorder()))),
                const SizedBox(width: 8),
                IconButton(icon: const Icon(Icons.add_box, size: 40, color: Colors.teal), onPressed: () => _ilacEkle(_ilacController.text)),
              ],
            ),
          ),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: Align(
              alignment: Alignment.centerLeft, 
              child: Text("💊 Günlük İlaç Takibim", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _ilaclar.length,
              itemBuilder: (context, index) {
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  child: ListTile(
                    title: Text(_ilaclar[index], style: const TextStyle(fontWeight: FontWeight.w500)),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete, color: Colors.red), 
                      onPressed: () => _ilacSil(index),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
