import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart';
import '../services/api_service.dart';

/// Düz metin raporunu gerçek bir PDF dosyasına dönüştürüp geçici klasöre kaydeder
Future<File> _raporuPdfyeCevirVeKaydet(String metin, String dosyaAdi) async {
  final PdfDocument document = PdfDocument();
  final PdfPage sayfa = document.pages.add();
  PdfTextElement(
    text: metin,
    font: PdfStandardFont(PdfFontFamily.helvetica, 12),
  ).draw(
    page: sayfa,
    bounds: Rect.fromLTWH(0, 0, sayfa.getClientSize().width, sayfa.getClientSize().height),
    format: PdfLayoutFormat(layoutType: PdfLayoutType.paginate),
  );
  final List<int> bayt = document.saveSync();
  document.dispose();
  final directory = await getTemporaryDirectory();
  final file = File('${directory.path}/$dosyaAdi.pdf');
  await file.writeAsBytes(bayt);
  return file;
}

class AnalizSonucEkrani extends StatefulWidget {
  final String hamPdfMetni;
  const AnalizSonucEkrani({Key? key, required this.hamPdfMetni}) : super(key: key);

  @override
  _AnalizSonucEkraniState createState() => _AnalizSonucEkraniState();
}

class _AnalizSonucEkraniState extends State<AnalizSonucEkrani> {
  bool _yukleniyor = true;
  String? _hataMesaji;
  List<Map<String, dynamic>> _tumGecmisTahliller = [];

  @override
  void initState() {
    super.initState();
    _analiziBaslat();
  }

  Future<void> _analiziBaslat() async {
    try {
      String jsonString = await ApiService.tahlilMetniniAnalizEt(widget.hamPdfMetni);
      
      // Web sitelerindeki gibi bozuk baytları yok sayıp kurtaran UTF-8 emniyet kilidi
      List<int> kodUnitleri = jsonString.codeUnits;
      String guvenliJsonString = utf8.decode(kodUnitleri, allowMalformed: true);

      final yeniTahlil = jsonDecode(guvenliJsonString);

      if (yeniTahlil.containsKey('hata')) {
        setState(() { _hataMesaji = yeniTahlil['hata']; _yukleniyor = false; });
      } else {
        final prefs = await SharedPreferences.getInstance();
        List<String> kayitlar = prefs.getStringList('saglik_kayitlari') ?? [];
        
        kayitlar.add(guvenliJsonString);
        await prefs.setStringList('saglik_kayitlari', kayitlar);

        List<Map<String, dynamic>> geciciListe = [];
        for (var k in kayitlar) {
          try { geciciListe.add(jsonDecode(k)); } catch (_) {}
        }

        setState(() {
          _tumGecmisTahliller = geciciListe;
          _yukleniyor = false;
        });
      }
    } catch (e) {
      setState(() { _hataMesaji = "Kodlama veya Veri Hatasi: $e"; _yukleniyor = false; });
    }
  }

  void _doktoraRaporGonder(String platform) async {
    if (_tumGecmisTahliller.isEmpty) return;

    String rapor = "📋 SERAY TEKNOLOJİ SAĞLIK YÖNETİM RAPORU\n"
        "Sayın Doktorum, hastanızın geçmişten günümüze tüm tahlil gelişim dökümü aşağıdadır:\n\n";

    for (var tahlil in _tumGecmisTahliller) {
      rapor += "📅 Tahlil Tarihi: ${tahlil['tarih'] ?? '-'}\n"
          "🩸 Açlık Kan Şekeri: ${tahlil['seker']} mg/dL\n"
          "❤️ Tansiyon: ${tahlil['tansiyonUst']}/${tahlil['tansiyonAlt']} mmHg\n"
          "💓 Nabız: ${tahlil['nabiz']} bpm\n"
          "🧪 Toplam Kolesterol: ${tahlil['kolesterol']} mg/dL (LDL: ${tahlil['ldl']} / HDL: ${tahlil['hdl']})\n"
          "🧪 Trigliserid: ${tahlil['trigliserid']} mg/dL\n"
          "🫁 Karaciğer (AST/ALT): ${tahlil['ast']} / ${tahlil['alt']} U/L\n"
          "🫘 Böbrek (Üre/Kreatinin): ${tahlil['ure']} / ${tahlil['kreatinin']}\n"
          "🩸 Hemoglobin (Kan): ${tahlil['hemoglobin']} g/dL\n"
          "💊 Vitaminler (B12/D3): ${tahlil['b12']} / ${tahlil['d_vitamini']}\n"
          "🦋 Tiroid (TSH): ${tahlil['tsh']} uIU/mL\n"
          "-----------------------------------------\n\n";
    }

    if (platform == "whatsapp") {
      await Share.share(rapor, subject: 'E-Nabız Tahlil Geçmişi');
    } else {
      final file = await _raporuPdfyeCevirVeKaydet(rapor, 'tahlil_gecmis_raporu');
      await Share.shareXFiles([XFile(file.path)], text: 'Doktor Bey, kronolojik tüm tahlil dökümüm ektedir.');
    }
  }

  void _secimMenuGoster() {
    showModalBottomSheet(
      context: context,
      builder: (context) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(
            leading: const Icon(Icons.message, color: Colors.green),
            title: const Text("WhatsApp ile Gönder"),
            onTap: () { Navigator.pop(context); _doktoraRaporGonder("whatsapp"); },
          ),
          ListTile(
            leading: const Icon(Icons.email, color: Colors.blue),
            title: const Text("E-Posta / Doküman Olarak Gönder"),
            onTap: () { Navigator.pop(context); _doktoraRaporGonder("email"); },
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('E-Nabız Zaman Tüneli'), backgroundColor: Colors.teal),
      body: _yukleniyor
          ? const Center(child: CircularProgressIndicator(color: Colors.teal))
          : _hataMesaji != null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.wifi_off, size: 64, color: Colors.grey),
                        const SizedBox(height: 16),
                        const Text(
                          "Analiz Tamamlanamadı",
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          "İnternet bağlantınızı kontrol edip tekrar deneyin.",
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.black54),
                        ),
                        const SizedBox(height: 20),
                        ElevatedButton.icon(
                          onPressed: () {
                            setState(() { _yukleniyor = true; _hataMesaji = null; });
                            _analiziBaslat();
                          },
                          icon: const Icon(Icons.refresh),
                          label: const Text("Tekrar Dene"),
                          style: ElevatedButton.styleFrom(backgroundColor: Colors.teal, foregroundColor: Colors.white),
                        ),
                        const SizedBox(height: 16),
                        ExpansionTile(
                          title: const Text("Teknik Detay", style: TextStyle(fontSize: 12, color: Colors.grey)),
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(_hataMesaji!, style: const TextStyle(fontSize: 11, color: Colors.grey)),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                )
              : Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: ElevatedButton.icon(
                        onPressed: _secimMenuGoster,
                        icon: const Icon(Icons.share),
                        label: const Text("TÜM ZAMAN TÜNELİNİ DOKTORA GÖNDER"),
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.teal, foregroundColor: Colors.white, minimumSize: const Size.fromHeight(50)),
                      ),
                    ),
                    Expanded(
                      child: SingleChildScrollView(
                        scrollDirection: Axis.vertical,
                        child: SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Padding(
                            padding: const EdgeInsets.all(12.0),
                            child: _dinamikTabloyuOlustur(),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
    );
  }

  Widget _dinamikTabloyuOlustur() {
    List<DataColumn> sutunlar = [
      const DataColumn(label: Text('Sağlık Kalemi', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.teal))),
    ];
    for (var tahlil in _tumGecmisTahliller) {
      sutunlar.add(DataColumn(label: Text(tahlil['tarih'] ?? 'Bilinmiyor', style: const TextStyle(fontWeight: FontWeight.bold))));
    }

    return DataTable(
      border: TableBorder.all(color: Colors.grey.shade300),
      columns: sutunlar,
      rows: [
        _dinamikSatirOlustur('Açlık Kan Şekeri (mg/dL)', 'seker'),
        _dinamikSatirOlustur('Büyük Tansiyon (Üst)', 'tansiyonUst'),
        _dinamikSatirOlustur('Küçük Tansiyon (Alt)', 'tansiyonAlt'),
        _dinamikSatirOlustur('Nabız (bpm)', 'nabiz'),
        _dinamikSatirOlustur('Toplam Kolesterol (mg/dL)', 'kolesterol'),
        _dinamikSatirOlustur('LDL Kolesterol', 'ldl'),
        _dinamikSatirOlustur('HDL Kolesterol', 'hdl'),
        _dinamikSatirOlustur('Trigliserid', 'trigliserid'),
        _dinamikSatirOlustur('Karaciğer AST (U/L)', 'ast'),
        _dinamikSatirOlustur('Karaciğer ALT (U/L)', 'alt'),
        _dinamikSatirOlustur('Üre (mg/dL)', 'ure'),
        _dinamikSatirOlustur('Kreatinin (mg/dL)', 'kreatinin'),
        _dinamikSatirOlustur('Hemoglobin (Kan)', 'hemoglobin'),
        _dinamikSatirOlustur('Vitamin B12', 'b12'),
        _dinamikSatirOlustur('Vitamin D3', 'd_vitamini'),
        _dinamikSatirOlustur('Tiroid TSH (uIU/mL)', 'tsh'),
      ],
    );
  }

  DataRow _dinamikSatirOlustur(String satirBasligi, String jsonAnahtari) {
    List<DataCell> hucreler = [DataCell(Text(satirBasligi, style: const TextStyle(fontWeight: FontWeight.w500)))];
    for (var tahlil in _tumGecmisTahliller) {
      var deger = tahlil[jsonAnahtari];
      hucreler.add(DataCell(Text(deger != null && deger != 0 ? deger.toString() : '-')));
    }
    return DataRow(cells: hucreler);
  }
}
