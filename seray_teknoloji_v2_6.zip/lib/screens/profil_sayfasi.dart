import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'profil_kayit_ekrani.dart';

class ProfilSayfasi extends StatefulWidget {
  const ProfilSayfasi({Key? key}) : super(key: key);

  @override
  _ProfilSayfasiState createState() => _ProfilSayfasiState();
}

class _ProfilSayfasiState extends State<ProfilSayfasi> {
  String _ad = "..."; 
  String _soyad = "..."; 
  int _yas = 0;

  @override
  void initState() { 
    super.initState(); 
    _verileriYukle(); 
  }

  Future<void> _verileriYukle() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _ad = prefs.getString('user_ad') ?? "Bilinmiyor";
      _soyad = prefs.getString('user_soyad') ?? "Bilinmiyor";
      _yas = prefs.getInt('user_yas') ?? 0;
    });
  }

  Future<void> _cikisYapVeSifirla() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (mounted) {
      Navigator.pushAndRemoveUntil(
        context, 
        MaterialPageRoute(builder: (context) => const ProfilKayitEkrani()), 
        (route) => false,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profil Y\u00f6netimi'), // Profil Yönetimi
        backgroundColor: Colors.teal, 
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 20),
            Card(
              color: Colors.teal.shade50,
              elevation: 2,
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  children: [
                    const Icon(Icons.account_circle, size: 80, color: Colors.teal),
                    const SizedBox(height: 12),
                    Text(
                      "$_ad $_soyad", 
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 22, color: Colors.black87),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      "Kay\u0131tl\u0131 Ya\u015f Bilgisi: $_yas", // Kayıtlı Yaş Bilgisi
                      style: const TextStyle(fontSize: 15, color: Colors.black54),
                    ),
                  ],
                ),
              ),
            ),
            const Spacer(),
            ElevatedButton.icon(
              onPressed: () {
                final TextEditingController onayController = TextEditingController();
                bool onayGecerli = false;
                showDialog(
                  context: context,
                  builder: (context) => StatefulBuilder(
                    builder: (context, setDialogState) => AlertDialog(
                      title: const Text("Tüm Verileri Sıfırla"),
                      content: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text("Bu işlem profil bilgilerinizi ve tüm tahlil geçmişinizi kalıcı olarak silecektir. Bu geri alınamaz."),
                          const SizedBox(height: 16),
                          const Text("Onaylamak için aşağıya \"SİL\" yazın:", style: TextStyle(fontWeight: FontWeight.bold)),
                          const SizedBox(height: 8),
                          TextField(
                            controller: onayController,
                            decoration: const InputDecoration(border: OutlineInputBorder(), hintText: "SİL"),
                            onChanged: (deger) {
                              setDialogState(() { onayGecerli = deger.trim().toUpperCase() == "SİL"; });
                            },
                          ),
                        ],
                      ),
                      actions: [
                        TextButton(onPressed: () => Navigator.pop(context), child: const Text("İptal")),
                        TextButton(
                          onPressed: onayGecerli ? _cikisYapVeSifirla : null,
                          child: Text("Kalıcı Olarak Sil", style: TextStyle(color: onayGecerli ? Colors.red : Colors.grey)),
                        ),
                      ],
                    ),
                  ),
                );
              },
              icon: const Icon(Icons.delete_forever),
              label: const Text("TÜM VERİLERİ SIFIRLA", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red.shade700, 
                foregroundColor: Colors.white, 
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
