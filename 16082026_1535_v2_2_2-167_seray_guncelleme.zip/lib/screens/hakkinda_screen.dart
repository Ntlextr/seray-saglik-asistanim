import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import '../theme/sablon.dart';

class HakkindaScreen extends StatelessWidget {
  const HakkindaScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        shape: AppSablon.appBarSekli,
        clipBehavior: Clip.antiAlias,
        title: const Text('Uygulama Hakkında', style: TextStyle(color: Color(0xFF111424), fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Color(0xFF111424)),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32.0, vertical: 24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // 1. ŞIK LOGO ALANI (Modern ve Kurumsal Sağlık İkonu)
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.blue.shade50,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.health_and_safety_rounded, 
                  size: 80, 
                  color: Colors.blue.shade700
                ),
              ),
              const SizedBox(height: 32),
              
              // 2. İSTEDİĞİNİZ TAM KURUMSAL HİYERARŞİ DİZİLİMİ
              Text(
                'Seray Teknoloji',
                style: TextStyle(
                  fontSize: 26, 
                  fontWeight: FontWeight.bold, 
                  color: Colors.grey.shade900,
                  letterSpacing: 0.5
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Sağlık Asistanım',
                style: TextStyle(
                  fontSize: 20, 
                  fontWeight: FontWeight.w600, 
                  color: Colors.blue.shade600,
                  letterSpacing: 0.3
                ),
              ),
              const SizedBox(height: 24),
              
              const Divider(width: 120, thickness: 1.5, color: Colors.blue),
              const SizedBox(height: 24),
              
              // 3. BİZİM OTOMASYONUN ARTIRDIĞI SÜRÜMÜ OTOMATİK ÇEKEN DİNAMİK ALAN
              FutureBuilder<PackageInfo>(
                future: PackageInfo.fromPlatform(),
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    // GitHub Actions'ın otomatik bastığı güncel versiyon numarasını ekrana yansıtır
                    return Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      decoration: BoxDecoration(
                        color: Colors.grey.shade100,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Text(
                        'Versiyon: v${snapshot.data!.version}',
                        style: TextStyle(
                          fontSize: 14, 
                          fontWeight: FontWeight.w500, 
                          color: Colors.grey.shade700
                        ),
                      ),
                    );
                  }
                  return Text(
                    'Versiyon: v1.50.x',
                    style: TextStyle(fontSize: 14, color: Colors.grey.shade500),
                  );
                },
              ),
              const SizedBox(height: 40),

              // Talep/soru için iletişim e-postası — dokununca mail uygulaması
              // "seraysaglikasistanim@gmail.com" adresine hazır olarak açılır.
              InkWell(
                onTap: () => launchUrl(Uri.parse('mailto:seraysaglikasistanim@gmail.com')),
                borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'İletişim: SERAY TEKNOLOJİ',
                          style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.grey.shade800),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          'Talep ve sorularınız için',
                          style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                        ),
                        const SizedBox(height: 4),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.email_outlined, size: 16, color: Colors.blue.shade600),
                            const SizedBox(width: 6),
                            Text(
                              'seraysaglikasistanim@gmail.com',
                              style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.blue.shade600),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),

              // Telif Hakkı ve Kurumsal Dipnot
              Text(
                '© 2026 Seray Teknoloji. Tüm hakları saklıdır.',
                style: TextStyle(fontSize: 12, color: Colors.grey.shade400),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
