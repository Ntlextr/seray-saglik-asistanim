import 'dart:io';
import 'package:flutter/material.dart';
import 'package:open_file/open_file.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:read_pdf_text/read_pdf_text.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import '../theme/renkler.dart';
import '../theme/sablon.dart';
import '../services/veritabani_yardimcisi.dart';
import '../services/api_service.dart';
import '../services/ses_servisi.dart';
import '../services/pdf_rapor_servisi.dart';
import '../services/profil_yoneticisi.dart';

// RAPOR ANALİZİ: Kullanıcının e-Nabız'daki radyolojik tetkik/konsültasyon
// gibi YAZILI (anlatı tarzı) raporlarını fotoğrafını çekip AI'ye
// okutup yorumlatmasını sağlar — önceden bunu Gemini/ChatGPT'ye elle
// yaptırıyordu, artık uygulama içinde, sonuç kalıcı olarak SQL'e
// kaydediliyor ve tarih/konuya göre eskiye dönük tekrar bakılabiliyor.
class RaporEkrani extends StatefulWidget {
  const RaporEkrani({Key? key}) : super(key: key);

  @override
  State<RaporEkrani> createState() => _RaporEkraniState();
}  // --- RaporEkrani sonu ---

class _RaporEkraniState extends State<RaporEkrani> {
  List<Map<String, dynamic>> _raporlar = [];
  bool _yukleniyor = true;
  String _aramaMetni = '';
  int? _acikRaporId;

  @override
  void initState() {
    super.initState();
    _raporlariYukle();
  }  // --- initState() sonu ---

  Future<void> _raporlariYukle() async {
    final liste = await VeritabaniYardimcisi().raporlariGetir();
    if (mounted) {
      setState(() {
        _raporlar = liste;
        _yukleniyor = false;
      });
    }
  }  // --- _raporlariYukle() sonu ---

  List<Map<String, dynamic>> get _filtreliRaporlar {
    if (_aramaMetni.trim().isEmpty) return _raporlar;
    final aranan = _aramaMetni.trim().toLowerCase();
    return _raporlar.where((r) {
      final baslik = (r['baslik'] ?? '').toString().toLowerCase();
      final tarih = (r['tarih'] ?? '').toString().toLowerCase();
      return baslik.contains(aranan) || tarih.contains(aranan);
    }).toList();
  }  // --- _filtreliRaporlar getter sonu ---

  Future<void> _fotografSecVeAnalizEt() async {
    final secim = await showModalBottomSheet<String>(
      context: context,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.photo_camera),
              title: const Text('Fotoğraf Çek'),
              onTap: () => Navigator.pop(context, 'kamera'),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library),
              title: const Text('Galeriden Seç'),
              onTap: () => Navigator.pop(context, 'galeri'),
            ),
            // ÖNEMLİ: Kullanıcı fark etti — sadece fotoğraf kabul
            // ediyorduk, e-Nabız'daki gibi PDF yükleme yoktu. Bazı
            // raporlar (özellikle e-Nabız'dan indirilenler) doğrudan
            // PDF olarak geliyor, fotoğrafını çekmeye gerek kalmasın.
            ListTile(
              leading: const Icon(Icons.picture_as_pdf),
              title: const Text('Dosyadan PDF Seç'),
              onTap: () => Navigator.pop(context, 'pdf'),
            ),
          ],
        ),
      ),
    );
    if (secim == null) return;

    if (secim == 'pdf') {
      await _pdfSecVeAnalizEt();
      return;
    }

    final kaynak = secim == 'kamera' ? ImageSource.camera : ImageSource.gallery;
    final secilenDosya = await ImagePicker().pickImage(source: kaynak, maxWidth: 1400, imageQuality: 80);
    if (secilenDosya == null) return;

    if (!mounted) return;
    _yukleniyorPenceresiGoster();

    try {
      final belgeler = await getApplicationDocumentsDirectory();
      final raporFotoKlasoru = Directory('${belgeler.path}/rapor_fotograflari');
      if (!await raporFotoKlasoru.exists()) {
        await raporFotoKlasoru.create(recursive: true);
      }
      final hedefYolu = '${raporFotoKlasoru.path}/rapor_${DateTime.now().millisecondsSinceEpoch}.jpg';
      final kaliciDosya = await File(secilenDosya.path).copy(hedefYolu);

      final sonuc = await ApiService.raporFotografiniAnalizEt(kaliciDosya);
      await _sonucuKaydet(sonuc, kaliciDosya.path, 'resim');
    } catch (e) {
      _hataGoster(e);
    }
  }  // --- _fotografSecVeAnalizEt() sonu ---

  Future<void> _pdfSecVeAnalizEt() async {
    final sonucSecim = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pdf']);
    if (sonucSecim == null || sonucSecim.files.single.path == null) return;
    final secilenYol = sonucSecim.files.single.path!;

    if (!mounted) return;
    _yukleniyorPenceresiGoster();

    try {
      final metin = await ReadPdfText.getPDFtext(secilenYol);
      if (metin.trim().isEmpty) {
        throw Exception(
            'PDF\'ten metin okunamadı — bu, taranmış (fotoğraf gibi) bir PDF olabilir. '
            'Bu tür PDF\'ler için lütfen sayfanın fotoğrafını çekip "Fotoğraf Çek/Galeriden Seç" ile yükleyin.');
      }

      // Belgenin kendisini de (fotoğraflar gibi) kalıcı klasöre kopyalıyoruz
      // — kullanıcı "belgenin kendisi de saklansın" dedi, sadece AI
      // yorumunu değil, orijinal PDF'i de sonradan görebilsin/paylaşabilsin.
      final belgeler = await getApplicationDocumentsDirectory();
      final raporFotoKlasoru = Directory('${belgeler.path}/rapor_fotograflari');
      if (!await raporFotoKlasoru.exists()) {
        await raporFotoKlasoru.create(recursive: true);
      }
      final hedefYolu = '${raporFotoKlasoru.path}/rapor_${DateTime.now().millisecondsSinceEpoch}.pdf';
      final kaliciDosya = await File(secilenYol).copy(hedefYolu);

      final sonuc = await ApiService.raporMetniniAnalizEt(metin);
      await _sonucuKaydet(sonuc, kaliciDosya.path, 'pdf');
    } catch (e) {
      _hataGoster(e);
    }
  }  // --- _pdfSecVeAnalizEt() sonu ---

  void _yukleniyorPenceresiGoster() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (d) => const AlertDialog(
        content: Row(
          children: [
            CircularProgressIndicator(),
            SizedBox(width: 20),
            Expanded(child: Text('Yapay zeka raporu okuyor ve yorumluyor...')),
          ],
        ),
      ),
    );
  }  // --- _yukleniyorPenceresiGoster() sonu ---

  Future<void> _sonucuKaydet(Map<String, String> sonuc, String belgeYolu, String belgeTuru) async {
    final simdi = DateTime.now();
    final bugunTarihi = '${simdi.day.toString().padLeft(2, '0')}.${simdi.month.toString().padLeft(2, '0')}.${simdi.year}';
    final aiTarihi = sonuc['tarih'] ?? '';
    final gecerliTarihMi = RegExp(r'^\d{1,2}\.\d{1,2}\.\d{4}$').hasMatch(aiTarihi);
    final tarih = gecerliTarihMi ? aiTarihi : bugunTarihi;

    await VeritabaniYardimcisi().raporEkle({
      'baslik': sonuc['baslik'] ?? 'Rapor',
      'tarih': tarih,
      'ai_yorumu': sonuc['yorum'] ?? '',
      'gorsel_yolu': belgeYolu,
      'belge_turu': belgeTuru,
    });

    if (mounted) Navigator.pop(context);
    await _raporlariYukle();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('✅ "${sonuc['baslik']}" raporu kaydedildi.')),
      );
    }
  }  // --- _sonucuKaydet() sonu ---

  void _hataGoster(Object e) {
    if (mounted) Navigator.pop(context);
    if (mounted) {
      showDialog(
        context: context,
        builder: (d) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: const Text('Rapor Analiz Edilemedi'),
          content: Text('Hata: $e'),
          actions: [TextButton(onPressed: () => Navigator.pop(d), child: const Text('Tamam'))],
        ),
      );
    }
  }  // --- _hataGoster() sonu ---

  // Belgenin KENDİSİNİ görüntülemek için — resimse tam ekran gösterir,
  // PDF'se telefonun kendi PDF görüntüleyicisiyle AÇAR. ÖNEMLİ DÜZELTME:
  // eskiden PDF'lerde yanlışlıkla Paylaş (Share) penceresi açılıyordu —
  // kullanıcı fark etti, artık open_file ile doğrudan görüntüleniyor.
  // Cihazda hiç PDF görüntüleyici yoksa (nadir), açma başarısız olur ve
  // o zaman kullanıcıya Paylaş'a yönlendiren bir mesaj gösteriyoruz.
  Future<void> _belgeyiGoster(Map<String, dynamic> rapor) async {
    final yol = rapor['gorsel_yolu'] as String?;
    if (yol == null || !File(yol).existsSync()) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Belge dosyası bulunamadı.')),
      );
      return;
    }
    final tur = rapor['belge_turu'] ?? 'resim';
    if (tur == 'pdf') {
      final sonuc = await OpenFile.open(yol);
      if (sonuc.type != ResultType.done && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('PDF açılamadı (görüntüleyici uygulama bulunamadı). Paylaşarak açmayı deneyebilirsiniz.'),
            action: SnackBarAction(label: 'Paylaş', onPressed: () => Share.shareXFiles([XFile(yol)], subject: rapor['baslik'] ?? 'Rapor')),
          ),
        );
      }
      return;
    }
    if (!mounted) return;
    showDialog(
      context: context,
      builder: (d) => Dialog(
        insetPadding: const EdgeInsets.all(12),
        child: Stack(
          children: [
            InteractiveViewer(child: Image.file(File(yol))),
            Positioned(
              top: 4,
              right: 4,
              child: CircleAvatar(
                backgroundColor: Colors.black54,
                child: IconButton(icon: const Icon(Icons.close, color: Colors.white), onPressed: () => Navigator.pop(d)),
              ),
            ),
          ],
        ),
      ),
    );
  }  // --- _belgeyiGoster() sonu ---

  Future<void> _raporSil(int id) async {
    final onay = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Raporu Sil'),
        content: const Text('Bu raporu kalıcı olarak silmek istediğinize emin misiniz?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Vazgeç')),
          TextButton(onPressed: () => Navigator.pop(d, true), child: const Text('Sil', style: TextStyle(color: Colors.red))),
        ],
      ),
    );
    if (onay != true) return;
    await VeritabaniYardimcisi().raporSil(id);
    await _raporlariYukle();
  }  // --- _raporSil() sonu ---

  Future<void> _raporuYazdir(Map<String, dynamic> rapor) async {
    try {
      final ad = (await ProfilYoneticisi().aktifProfil()).ad;
      await PdfRaporServisi.analizRaporuYazdir(
        kullaniciAdi: ad,
        baslik: '${rapor['baslik']} (${rapor['tarih']})',
        analizMetni: (rapor['ai_yorumu'] ?? '').toString(),
      );
    } catch (e) {
      if (mounted) {
        showDialog(
          context: context,
          builder: (d) => AlertDialog(
            title: const Text('PDF Oluşturulamadı'),
            content: SelectableText(e.toString()),
            actions: [TextButton(onPressed: () => Navigator.pop(d), child: const Text('Kapat'))],
          ),
        );
      }
    }
  }  // --- _raporuYazdir() sonu ---

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        shape: AppSablon.appBarSekli,
        clipBehavior: Clip.antiAlias,
        title: const Text('Rapor Analizi'),
        backgroundColor: AppRenkleri.aktif,
        foregroundColor: Colors.white,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Tarih veya konuya göre ara (örn. "MR", "08.2026")',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
                isDense: true,
              ),
              onChanged: (v) => setState(() => _aramaMetni = v),
            ),
          ),
          if (_yukleniyor)
            const Expanded(child: Center(child: CircularProgressIndicator()))
          else if (_raporlar.isEmpty)
            Expanded(
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.description_outlined, size: 64, color: Colors.grey.shade400),
                      const SizedBox(height: 12),
                      const Text(
                        'Henüz bir rapor eklenmedi.\nRöntgen, MR, konsültasyon gibi '
                        'raporlarınızın fotoğrafını çekin — yapay zeka okuyup '
                        'yorumlasın, burada saklansın.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.grey),
                      ),
                    ],
                  ),
                ),
              ),
            )
          else
            Expanded(
              child: ListView.builder(
                // ÖNEMLİ DÜZELTME: FAB sağdaki ikon satırıyla çakışmasın diye
                // sola taşınmıştı, ama liste altında hiç boşluk YOKTU — açık
                // (genişletilmiş) bir rapor kartının metni ekranın en altına
                // kadar uzayınca, üstüne binen FAB o metni de kapatıyordu.
                // Artık liste altına FAB'ın yüksekliği kadar boşluk bırakılıyor.
                padding: const EdgeInsets.fromLTRB(12, 0, 12, 88),
                itemCount: _filtreliRaporlar.length,
                itemBuilder: (context, index) {
                  final rapor = _filtreliRaporlar[index];
                  final id = rapor['id'] as int;
                  final acik = _acikRaporId == id;
                  return Card(
                    margin: const EdgeInsets.only(bottom: 10),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
                    child: Column(
                      children: [
                        ListTile(
                          leading: GestureDetector(
                            onTap: () => _belgeyiGoster(rapor),
                            child: CircleAvatar(
                              backgroundColor: AppRenkleri.aktif.shade50,
                              backgroundImage: (rapor['belge_turu'] != 'pdf' &&
                                      rapor['gorsel_yolu'] != null &&
                                      File(rapor['gorsel_yolu']).existsSync())
                                  ? FileImage(File(rapor['gorsel_yolu']))
                                  : null,
                              child: (rapor['belge_turu'] == 'pdf')
                                  ? Icon(Icons.picture_as_pdf, color: AppRenkleri.aktif.shade700)
                                  : (rapor['gorsel_yolu'] == null || !File(rapor['gorsel_yolu']).existsSync())
                                      ? Icon(Icons.description, color: AppRenkleri.aktif.shade700)
                                      : null,
                            ),
                          ),
                          title: Text(rapor['baslik'] ?? 'Rapor', style: const TextStyle(fontWeight: FontWeight.bold)),
                          subtitle: Text(rapor['tarih'] ?? ''),
                          trailing: IconButton(
                            icon: Icon(acik ? Icons.expand_less : Icons.expand_more),
                            onPressed: () => setState(() => _acikRaporId = acik ? null : id),
                          ),
                          onTap: () => setState(() => _acikRaporId = acik ? null : id),
                        ),
                        if (acik)
                          Padding(
                            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Divider(),
                                SelectableText(
                                  (rapor['ai_yorumu'] ?? '').toString(),
                                  style: const TextStyle(fontSize: 14, height: 1.4),
                                ),
                                const SizedBox(height: 8),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    IconButton(
                                      icon: Icon(Icons.visibility_outlined, color: AppRenkleri.aktif),
                                      tooltip: rapor['belge_turu'] == 'pdf' ? 'PDF\'i Görüntüle' : 'Belgeyi Görüntüle',
                                      onPressed: () => _belgeyiGoster(rapor),
                                    ),
                                    IconButton(
                                      icon: Icon(Icons.share_outlined, color: AppRenkleri.aktif),
                                      tooltip: 'Paylaş',
                                      onPressed: () => Share.shareXFiles([XFile(rapor['gorsel_yolu'] as String? ?? '')], subject: rapor['baslik'] ?? 'Rapor'),
                                    ),
                                    IconButton(
                                      icon: Icon(Icons.volume_up, color: AppRenkleri.aktif),
                                      tooltip: 'Sesli Dinle',
                                      onPressed: () => SesServisi.konus((rapor['ai_yorumu'] ?? '').toString()),
                                    ),
                                    IconButton(
                                      icon: Icon(Icons.print_outlined, color: AppRenkleri.aktif),
                                      tooltip: 'Yazdır',
                                      onPressed: () => _raporuYazdir(rapor),
                                    ),
                                    IconButton(
                                      icon: const Icon(Icons.delete_outline, color: Colors.red),
                                      tooltip: 'Sil',
                                      onPressed: () => _raporSil(id),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                      ],
                    ),
                  );
                },
              ),
            ),
        ],
      ),
      // ÖNEMLİ: Kullanıcı fark etti — "Rapor Ekle" butonu (varsayılan olarak
      // sağ altta) genişleyen rapor kartındaki sağa hizalı ikonların
      // (Belgeyi Görüntüle/Sesli Dinle/Yazdır/Sil) üzerine biniyordu. Sol
      // alta taşındı, ikon satırıyla artık çakışmıyor.
      floatingActionButtonLocation: FloatingActionButtonLocation.startFloat,
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _fotografSecVeAnalizEt,
        backgroundColor: AppRenkleri.aktif,
        icon: const Icon(Icons.add_a_photo, color: Colors.white),
        label: const Text('Rapor Ekle', style: TextStyle(color: Colors.white)),
      ),
    );
  }  // --- build() sonu ---
}  // --- _RaporEkraniState sonu ---
