import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import '../services/profil_yoneticisi.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import '../theme/renkler.dart';
import '../theme/sablon.dart';
import '../services/veritabani_yardimcisi.dart';
import '../services/bildirim_servisi.dart';
import '../services/api_service.dart';
import '../services/pdf_rapor_servisi.dart';
import '../services/ses_servisi.dart';
import '../widgets/ust_menu.dart';
import 'gecmis_ilaclar_ekrani.dart';

class IlacEkrani extends StatefulWidget {
  const IlacEkrani({Key? key}) : super(key: key);
  @override
  _IlacEkraniState createState() => _IlacEkraniState();
}

class _IlacEkraniState extends State<IlacEkrani> {
  List<Map<String, dynamic>> _ilacListesi = [];

  // ÖNEMLİ: Beslenme ekranındaki yemek fotoğrafı mantığıyla AYNI —
  // ImagePicker'ın geçici dosya yolu yerine kalıcı bir klasöre kopyalanıyor,
  // yoksa fotoğraf sistem tarafından silinebilir/yedeğe girmeyebilir.
  Future<File> _fotografiKaliciKlasoreKopyala(File kaynak) async {
    final belgeler = await getApplicationDocumentsDirectory();
    final klasor = Directory('${belgeler.path}/ilac_fotograflari');
    if (!await klasor.exists()) {
      await klasor.create(recursive: true);
    }
    final dosyaAdi = 'ilac_${DateTime.now().millisecondsSinceEpoch}.jpg';
    final hedefYolu = '${klasor.path}/$dosyaAdi';
    return kaynak.copy(hedefYolu);
  }  // --- _fotografiKaliciKlasoreKopyala() sonu ---

  @override
  void initState() {
    super.initState();
    BildirimServisi.baslat();
    _ilaclariYukle();
  }

  Future<void> _ilaclariYukle() async {
    final veriler = await VeritabaniYardimcisi().ilaclariGetir();
    if (mounted) {
      setState(() {
        _ilacListesi = veriler;
      });
    }
    // Kategorisi henüz belirlenmemiş ilaçlar için (yeni eklenen veya eski
    // sürümden gelen) arka planda sessizce kategori tahmini iste — kullanıcı
    // hiçbir şeye dokunmadan, liste kendiliğinden "Tansiyon", "Kalp" gibi
    // etiketlerle dolar.
    for (final ilac in veriler) {
      final mevcutKategori = ilac['kategori']?.toString();
      if (mevcutKategori == null || mevcutKategori.isEmpty) {
        _kategoriArkaPlandaGetir(int.parse(ilac['id'].toString()), ilac['ad'].toString());
      }
    }
  }

  // İlacın adına bakarak AI'dan kısa bir kategori (Tansiyon/Kalp/Prostat vb.)
  // ister — mevcut ⓘ bilgi kartıyla AYNI önbelleği (SharedPreferences)
  // kullanır, bu yüzden ekstra maliyet SADECE ilk kez soruluyorsa oluşur.
  // Sessiz/en iyi çaba: hata olursa kategori boş kalır, kullanıcı hiçbir şey
  // fark etmez.
  Future<void> _kategoriArkaPlandaGetir(int ilacId, String ad) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final anahtar = 'ilac_bilgi_${ad.trim().toLowerCase()}';
      Map<String, String>? bilgi;
      final kayitliJson = prefs.getString(anahtar);
      if (kayitliJson != null) {
        bilgi = Map<String, String>.from(jsonDecode(kayitliJson));
      } else {
        bilgi = await ApiService.ilacBilgisiUret(ad);
        await prefs.setString(anahtar, jsonEncode(bilgi));
      }
      final kategori = bilgi['kategori'] ?? '';
      if (kategori.isNotEmpty) {
        await VeritabaniYardimcisi().ilacGuncelle(ilacId, {'kategori': kategori});
        if (mounted) await _ilaclariYukleSessiz();
      }
    } catch (_) {
      // Sessizce geç — kategori sadece "varsa güzel" bir ek bilgi.
    }
  }  // --- _kategoriArkaPlandaGetir() sonu ---

  // _ilaclariYukle()'nin döngüye girmemesi için: sadece listeyi tazeler,
  // eksik kategorileri tekrar taramaz.
  Future<void> _ilaclariYukleSessiz() async {
    final veriler = await VeritabaniYardimcisi().ilaclariGetir();
    if (mounted) setState(() => _ilacListesi = veriler);
  }  // --- _ilaclariYukleSessiz() sonu ---

  // "Candexcil" gibi kullanıcının kendi girdiği bir ilaç için AI'dan "ne için
  // kullanılır" bilgisi ister; sonucu SharedPreferences'ta kalıcı önbelleğe
  // alır (aynı ilaç için bir daha sorulmaz) — tahlil bilgi kartlarıyla aynı desen.
  // Sesli okuma / paylaşım için ilaç bilgisi haritasını tek metne çevirir.
  String _ilacBilgiMetni(String ilacAdi, Map<String, String> bilgi) {
    final parcalar = <String>[ilacAdi];
    if ((bilgi['etkenMadde'] ?? '').isNotEmpty) parcalar.add('Etken Madde: ${bilgi['etkenMadde']}');
    parcalar.add('Ne İçin Kullanılır: ${bilgi['neIcin'] ?? '-'}');
    parcalar.add('Dikkat: ${bilgi['dikkat'] ?? '-'}');
    return parcalar.join('\n');
  }  // --- _ilacBilgiMetni() sonu ---

  Future<void> _ilacBilgisiGoster(String ilacAdi) async {
    Map<String, String>? bilgi;
    String? hata;
    bool yukleniyor = true;
    bool baslatildiMi = false;

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) {
          Future<void> yukle() async {
            final prefs = await SharedPreferences.getInstance();
            final anahtar = 'ilac_bilgi_${ilacAdi.trim().toLowerCase()}';
            final kayitliJson = prefs.getString(anahtar);
            if (kayitliJson != null) {
              try {
                setDialogState(() {
                  bilgi = Map<String, String>.from(jsonDecode(kayitliJson));
                  yukleniyor = false;
                });
                return;
              } catch (_) {}
            }
            try {
              final sonuc = await ApiService.ilacBilgisiUret(ilacAdi);
              await prefs.setString(anahtar, jsonEncode(sonuc));
              setDialogState(() {
                bilgi = sonuc;
                yukleniyor = false;
              });
            } catch (e) {
              setDialogState(() {
                hata = 'Bilgi alınamadı, lütfen tekrar deneyin.';
                yukleniyor = false;
              });
            }
          }

          if (!baslatildiMi) {
            baslatildiMi = true;
            WidgetsBinding.instance.addPostFrameCallback((_) => yukle());
          }

          return AlertDialog(
            title: Row(
              children: [
                Expanded(child: Text(ilacAdi, overflow: TextOverflow.ellipsis)),
                if (!yukleniyor && hata == null && bilgi != null) ...[
                  IconButton(
                    icon: const Icon(Icons.volume_up, size: 22),
                    tooltip: 'Sesli Dinle',
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                    onPressed: () => SesServisi.konus(_ilacBilgiMetni(ilacAdi, bilgi!)),
                  ),
                  const SizedBox(width: 8),
                  IconButton(
                    icon: const Icon(Icons.share_outlined, size: 22),
                    tooltip: 'Paylaş',
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                    onPressed: () async {
                      final ad = (await ProfilYoneticisi().aktifProfil()).ad;
                      await PdfRaporServisi.analizRaporuOlusturVePaylas(
                        kullaniciAdi: ad,
                        baslik: '$ilacAdi İlaç Bilgisi',
                        analizMetni: _ilacBilgiMetni(ilacAdi, bilgi!),
                      );
                    },
                  ),
                  const SizedBox(width: 8),
                  IconButton(
                    icon: const Icon(Icons.print_outlined, size: 22),
                    tooltip: 'Yazdır',
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                    onPressed: () async {
                      final ad = (await ProfilYoneticisi().aktifProfil()).ad;
                      await PdfRaporServisi.analizRaporuYazdir(
                        kullaniciAdi: ad,
                        baslik: '$ilacAdi İlaç Bilgisi',
                        analizMetni: _ilacBilgiMetni(ilacAdi, bilgi!),
                      );
                    },
                  ),
                ],
              ],
            ),
            content: SizedBox(
              width: double.maxFinite,
              child: yukleniyor
                  ? const Padding(
                      padding: EdgeInsets.symmetric(vertical: 20),
                      child: Center(child: CircularProgressIndicator()),
                    )
                  : hata != null
                      ? Text(hata!)
                      : Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if ((bilgi?['etkenMadde'] ?? '').isNotEmpty) ...[
                              Text('Etken Madde', style: TextStyle(fontWeight: FontWeight.bold, color: AppRenkleri.aktif)),
                              Text(bilgi!['etkenMadde']!),
                              const SizedBox(height: 10),
                            ],
                            Text('Ne İçin Kullanılır', style: TextStyle(fontWeight: FontWeight.bold, color: AppRenkleri.aktif)),
                            Text(bilgi?['neIcin'] ?? '-'),
                            const SizedBox(height: 10),
                            Text('Dikkat', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.orange.shade800)),
                            Text(bilgi?['dikkat'] ?? '-', style: const TextStyle(fontSize: 12)),
                          ],
                        ),
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context), child: const Text('Kapat')),
            ],
          );
        },
      ),
    );
  }  // --- _ilacBilgisiGoster() sonu ---

  // Doktor ilacı değiştirdiğinde/kestiğinde kullanılır — ilacı silmek
  // yerine "sonlandırır", nedeni not olarak saklanır. Sonlandırılan ilaç
  // aktif listeden kaybolur ama verisi (geçmişiyle birlikte) kalır.
  Future<void> _ilaciSonlandirDialogu(Map<String, dynamic> ilac) async {
    final notController = TextEditingController();
    final onay = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('"${ilac['ad']}" Sonlandırılsın mı?'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Bu ilaç aktif listeden kaldırılır ama geçmişi saklanır. '
                'İsterseniz nedenini (örn. "Doktor yerine X ilacını yazdı") not edebilirsiniz.'),
            const SizedBox(height: 12),
            TextField(
              controller: notController,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: 'Neden / Yerine Ne Yazıldı (isteğe bağlı)',
                border: OutlineInputBorder(),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Vazgeç')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.orange.shade700),
            onPressed: () => Navigator.pop(d, true),
            child: const Text('Sonlandır', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
    if (onay != true) return;
    final ilacId = int.parse(ilac['id'].toString());
    await VeritabaniYardimcisi().ilaciSonlandir(id: ilacId, not: notController.text.trim());
    try {
      await BildirimServisi.iptalEt(ilacId);
    } catch (_) {}
    await _ilaclariYukle();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('"${ilac['ad']}" sonlandırıldı, geçmişte saklandı.')),
      );
    }
  }  // --- _ilaciSonlandirDialogu() sonu ---

  void _ilacFormunuAc({Map<String, dynamic>? duzenlenecekIlac}) {
    final adController = TextEditingController(text: duzenlenecekIlac?['ad']?.toString() ?? '');
    final dozController = TextEditingController(text: duzenlenecekIlac?['dozaj']?.toString() ?? '');
    String secilenTip = duzenlenecekIlac?['tip']?.toString() ?? 'Hap';
    TimeOfDay secilenSaat = const TimeOfDay(hour: 9, minute: 0);
    // ÖNEMLİ: Kullanıcı istedi — ilacın reçete/yazılma tarihi, ileride
    // doktor değişikliği geçmişi için gerekli.
    DateTime yazildigiTarih = () {
      final kayitli = DateTime.tryParse(duzenlenecekIlac?['yazildigi_tarih']?.toString() ?? '');
      return kayitli ?? DateTime.now();
    }();

    // Kutu fotoğrafı — düzenlemede varsa mevcut yol, yoksa null (henüz seçilmedi).
    File? secilenFoto = (duzenlenecekIlac?['fotograf_yolu'] != null && duzenlenecekIlac!['fotograf_yolu'].toString().isNotEmpty)
        ? File(duzenlenecekIlac['fotograf_yolu'].toString())
        : null;
    bool aiTaniyorCalisiyor = false;
    
    if (duzenlenecekIlac != null && duzenlenecekIlac['saat'] != null) {
      final parcalar = duzenlenecekIlac['saat'].toString().split(':');
      if (parcalar.length == 2) {
        final saat = int.tryParse(parcalar[0].trim());
        final temizDakikaMetni = parcalar[1].replaceAll(RegExp(r'[^0-9]'), '').trim();
        final dakika = int.tryParse(temizDakikaMetni);
        if (saat != null && dakika != null) {
          secilenSaat = TimeOfDay(hour: saat, minute: dakika);
        }
      }
    }

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: Text(duzenlenecekIlac == null ? 'İlaç Ekle' : 'İlacı Düzenle'),
          content: SingleChildScrollView(
            child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Kutu fotoğrafı seçici (yemek fotoğrafıyla aynı desen)
              GestureDetector(
                onTap: () async {
                  final kaynak = await showModalBottomSheet<ImageSource>(
                    context: context,
                    builder: (context) => SafeArea(
                      child: Wrap(children: [
                        ListTile(
                          leading: const Icon(Icons.camera_alt),
                          title: const Text('Fotoğraf Çek'),
                          onTap: () => Navigator.pop(context, ImageSource.camera),
                        ),
                        ListTile(
                          leading: const Icon(Icons.photo_library),
                          title: const Text('Galeriden Seç'),
                          onTap: () => Navigator.pop(context, ImageSource.gallery),
                        ),
                      ]),
                    ),
                  );
                  if (kaynak == null) return;
                  final XFile? secilen = await ImagePicker().pickImage(source: kaynak, maxWidth: 640, imageQuality: 65);
                  if (secilen != null) {
                    final kaliciDosya = await _fotografiKaliciKlasoreKopyala(File(secilen.path));
                    setDialogState(() => secilenFoto = kaliciDosya);
                  }
                },
                child: Container(
                  height: 100,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade100,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.grey.shade300),
                  ),
                  child: secilenFoto != null
                      ? ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: Image.file(secilenFoto!, fit: BoxFit.cover, width: double.infinity),
                        )
                      : const Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.camera_alt, color: Colors.grey, size: 28),
                              SizedBox(height: 4),
                              Text('Kutu Fotoğrafı Ekle (isteğe bağlı)', style: TextStyle(color: Colors.grey, fontSize: 12)),
                            ],
                          ),
                        ),
                ),
              ),
              if (secilenFoto != null) ...[
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.deepPurple,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                    ),
                    onPressed: aiTaniyorCalisiyor
                        ? null
                        : () async {
                            setDialogState(() => aiTaniyorCalisiyor = true);
                            final sonuc = await ApiService.ilacKutusundanTani(secilenFoto!);
                            final adEslesme = RegExp(r'İlaç Adı:\s*(.+)').firstMatch(sonuc);
                            final bulunanAd = adEslesme?.group(1)?.trim();
                            setDialogState(() {
                              if (bulunanAd != null && bulunanAd.isNotEmpty && bulunanAd != 'Okunamadı') {
                                adController.text = bulunanAd;
                              }
                              // ÖNEMLİ: Doz (mg/adet) alanına kutudaki mg'yi
                              // YAZMIYORUZ artık — o zaten isme eklendi (örn.
                              // "Planor 75 mg"). Bu alan "kaç adet alıyorsunuz"
                              // demek, kutu bunu bilemez — sadece boşsa "1"
                              // (adet) varsayılanı koyuyoruz, kullanıcı
                              // gerçek kullanım miktarını kendisi girer.
                              if (dozController.text.trim().isEmpty) {
                                dozController.text = '1';
                              }
                              aiTaniyorCalisiyor = false;
                            });
                            if (context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                content: Text((bulunanAd != null && bulunanAd != 'Okunamadı')
                                    ? 'Kutudan okundu: $bulunanAd — kaç adet aldığınızı "Doz" alanından kontrol edin.'
                                    : 'Kutu okunamadı, adı elle girebilirsiniz.'),
                              ));
                            }
                          },
                    icon: aiTaniyorCalisiyor
                        ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                        : const Icon(Icons.auto_awesome, size: 16),
                    label: Text(aiTaniyorCalisiyor ? 'Kutu Okunuyor...' : 'Kutudan Tanı (AI)'),
                  ),
                ),
              ],
              const SizedBox(height: 12),
              TextField(controller: adController, decoration: const InputDecoration(labelText: 'İlaç Adı')),
              const SizedBox(height: 12),
              SegmentedButton<String>(
                segments: const [
                  ButtonSegment(value: 'Hap', label: Text('Hap / İlaç'), icon: Icon(Icons.medication)),
                  ButtonSegment(value: 'İnsülin', label: Text('İnsülin'), icon: Icon(Icons.vaccines)),
                ],
                selected: {secilenTip},
                onSelectionChanged: (yeniSecim) => setDialogState(() => secilenTip = yeniSecim.first),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: dozController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: secilenTip == 'İnsülin' ? 'Doz (ünite)' : 'Doz (mg / adet)',
                  hintText: secilenTip == 'İnsülin' ? 'Örn: 10' : 'Örn: 500 mg',
                ),
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Hatırlatma Saati:', style: TextStyle(fontSize: 15)),
                  TextButton.icon(
                    icon: const Icon(Icons.access_time),
                    label: Text(
                      // DÜZELTME: Saat gösterimini her zaman '09:00', '14:00' şeklinde 24 saatlik standart formata zorladık
                      '${secilenSaat.hour.toString().padLeft(2, '0')}:${secilenSaat.minute.toString().padLeft(2, '0')}', 
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    onPressed: () async {
                      final yeniSaat = await showTimePicker(
                        context: context, 
                        initialTime: secilenSaat,
                        builder: (context, child) {
                          // Sistem saat seçicisini 24 saat formatına zorluyoruz
                          return MediaQuery(
                            data: MediaQuery.of(context).copyWith(alwaysUse24HourFormat: true),
                            child: child!,
                          );
                        },
                      );
                      if (yeniSaat != null) setDialogState(() => secilenSaat = yeniSaat);
                    },
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Yazıldığı Tarih:', style: TextStyle(fontSize: 15)),
                  TextButton.icon(
                    icon: const Icon(Icons.event_note),
                    label: Text(
                      '${yazildigiTarih.day.toString().padLeft(2, '0')}.${yazildigiTarih.month.toString().padLeft(2, '0')}.${yazildigiTarih.year}',
                      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                    ),
                    onPressed: () async {
                      final secim = await showDatePicker(
                        context: context,
                        initialDate: yazildigiTarih,
                        firstDate: DateTime(2015),
                        lastDate: DateTime.now(),
                      );
                      if (secim != null) setDialogState(() => yazildigiTarih = secim);
                    },
                  ),
                ],
              ),
            ],
          ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Vazgeç')),
            TextButton(
              onPressed: () async {
                if (adController.text.trim().isEmpty) return;
                
                // DÜZELTME: Veritabanına kaydederken her zaman '09:00', '14:00' formatında yazdırıyoruz
                final standartSaatMetni = '${secilenSaat.hour.toString().padLeft(2, '0')}:${secilenSaat.minute.toString().padLeft(2, '0')}';
                
                final veri = {
                  'ad': adController.text.trim(), 
                  'dozaj': dozController.text.trim(), 
                  'saat': standartSaatMetni,
                  'tip': secilenTip,
                  'birim': secilenTip == 'İnsülin' ? 'ünite' : 'adet',
                  'fotograf_yolu': secilenFoto?.path,
                  'yazildigi_tarih': yazildigiTarih.toIso8601String(),
                };
                
                int ilacId;
                if (duzenlenecekIlac == null) {
                  ilacId = await VeritabaniYardimcisi().ilacEkle(veri);
                } else {
                  ilacId = int.parse(duzenlenecekIlac['id'].toString());
                  await VeritabaniYardimcisi().ilacGuncelle(ilacId, veri);
                }
                
                String? hataMesaji;
                try {
                  await BildirimServisi.ilacHatirlaticisiKur(id: ilacId, ilacAdi: adController.text.trim(), saat: secilenSaat, tip: secilenTip);
                } catch (e) {
                  hataMesaji = e.toString();
                  debugPrint('Hatırlatıcı kurulamadı: $e');
                }

                if (context.mounted) Navigator.pop(context);
                await _ilaclariYukle();
                if (context.mounted) {
                  // ÖNEMLİ: Önceden alt köşede 6 saniye duran bir SnackBar'dı
                  // — kullanıcı "daha kısa ve tam ortada olsun" istedi.
                  // SnackBar ekranın ortasında gösterilemez (bottom-anchored
                  // bir bileşen), o yüzden kısa süre sonra kendiliğinden
                  // kapanan, ekranın tam ortasında bir onay kutusu kullandık.
                  showDialog(
                    context: context,
                    barrierDismissible: true,
                    builder: (dialogContext) {
                      Future.delayed(const Duration(milliseconds: 1500), () {
                        if (dialogContext.mounted) Navigator.of(dialogContext).pop();
                      });
                      return Dialog(
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                        child: Padding(
                          padding: const EdgeInsets.all(22),
                          child: Text(
                            hataMesaji == null
                                ? 'Alarm kuruldu: $standartSaatMetni'
                                : 'ALARM KURULAMADI: $hataMesaji',
                            textAlign: TextAlign.center,
                            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
                          ),
                        ),
                      );
                    },
                  );
                }
              },
              child: Text(duzenlenecekIlac == null ? 'EKLE' : 'KAYDET'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        shape: AppSablon.appBarSekli,
        clipBehavior: Clip.antiAlias,
        title: FittedBox(
          fit: BoxFit.scaleDown,
          alignment: Alignment.centerLeft,
          child: const Text('İlaçlarım & Alarmlar', maxLines: 1),
        ),
        backgroundColor: AppRenkleri.aktif,
        foregroundColor: Colors.white,
        actions: [
          // ÖNEMLİ DÜZELTME: Kullanıcı istedi — alttaki "İlaç Ekle" FAB'ı
          // alt menüyle çakışıyordu. Artık üstte, her zaman görünür sabit
          // bir "+" ikonu var; FAB kaldırıldı.
          IconButton(
            icon: const Icon(Icons.add_alarm, size: 28),
            tooltip: 'İlaç Ekle',
            onPressed: () => _ilacFormunuAc(),
          ),
          IconButton(
            icon: const Icon(Icons.print_outlined),
            tooltip: 'İlaç Listesini Yazdır/Paylaş (doktora götürmek için)',
            onPressed: () async {
              final ad = (await ProfilYoneticisi().aktifProfil()).ad;
              await PdfRaporServisi.ilaclarListesiOlusturVePaylas(kullaniciAdi: ad);
            },
          ),
          IconButton(
            icon: const Icon(Icons.history),
            tooltip: 'Geçmiş İlaçlar',
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const GecmisIlaclarEkrani())),
          ),
          const UstMenu(),
        ],
      ),
      body: _ilacListesi.isEmpty
          ? const Center(child: Text('Henüz ilaç eklemediniz.'))
          : ListView.builder(
              // ÖNEMLİ: Alt boşluk arttırıldı — "İlaç Ekle" (FAB) butonu
              // önceden listenin en altındaki ilacın düzenle/sil ikonlarının
              // ÜSTÜNE biniyordu, onlara dokunmayı zorlaştırıyordu.
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 90),
              itemCount: _ilacListesi.length,
              itemBuilder: (context, index) {
                final ilac = _ilacListesi[index];
                final tip = ilac['tip']?.toString() ?? 'Hap';
                final birim = ilac['birim']?.toString() ?? (tip == 'İnsülin' ? 'ünite' : 'adet');
                final isInsulin = tip == 'İnsülin';
                final fotografYolu = ilac['fotograf_yolu']?.toString();
                final fotografVarMi = fotografYolu != null && fotografYolu.isNotEmpty && File(fotografYolu).existsSync();
                return Card(
                  margin: const EdgeInsets.only(bottom: 8),
                  child: ListTile(
                    dense: true,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
                    leading: fotografVarMi
                        ? ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: Image.file(File(fotografYolu!), width: 40, height: 40, fit: BoxFit.cover),
                          )
                        : Icon(isInsulin ? Icons.vaccines : Icons.medication, color: AppRenkleri.aktif),
                    title: Text(
                      ilac['ad'].toString(),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                    ),
                    // ÖNEMLİ: Önceden "Doz: ... | Saat: ..." + ayrı satırda uzun
                    // "🔔 Hatırlatma Sesi Aktif" cümlesi vardı — 2 satır tutuyordu.
                    // Artık tek satırda, kısa bir 🔔 ikonuyla — kart yüksekliği
                    // yaklaşık yarıya indi, ekrana çok daha fazla ilaç sığıyor.
                    // YENİ: kategori (varsa) en üstte küçük, renkli bir etiket
                    // olarak — "hangi rahatsızlık için" sorusuna anında cevap.
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if ((ilac['kategori']?.toString() ?? '').isNotEmpty)
                          Text(ilac['kategori'].toString(), style: TextStyle(fontSize: 11, color: AppRenkleri.aktif.shade700, fontWeight: FontWeight.w600)),
                        Text('${ilac['dozaj']} $birim  •  ${ilac['saat']}  🔔', style: const TextStyle(fontSize: 12)),
                      ],
                    ),
                    // ÖNEMLİ DÜZELTME: Önceden Bilgi/Düzenle/Sil için 3 AYRI
                    // ikon vardı — bu, ilaç ismine kalan yeri daraltıp ismin
                    // küçülerek okunmaz hale gelmesine sebep oluyordu. Artık
                    // tek bir ⋮ (üç nokta) menüsünde toplanıyor, isme çok
                    // daha fazla yer kalıyor.
                    trailing: PopupMenuButton<String>(
                      icon: const Icon(Icons.more_vert),
                      onSelected: (secim) async {
                        if (secim == 'bilgi') {
                          _ilacBilgisiGoster(ilac['ad'].toString());
                        } else if (secim == 'duzenle') {
                          _ilacFormunuAc(duzenlenecekIlac: ilac);
                        } else if (secim == 'sonlandir') {
                          await _ilaciSonlandirDialogu(ilac);
                        } else if (secim == 'sil') {
                          final ilacId = int.parse(ilac['id'].toString());
                          try {
                            await VeritabaniYardimcisi().ilacSil(ilacId);
                          } catch (e) {
                            debugPrint('İlaç silinirken hata: $e');
                          }
                          try {
                            await BildirimServisi.iptalEt(ilacId);
                          } catch (e) {
                            debugPrint('Hatırlatıcı iptal edilemedi: $e');
                          }
                          await _ilaclariYukle();
                        }
                      },
                      itemBuilder: (context) => [
                        const PopupMenuItem(
                          value: 'bilgi',
                          child: ListTile(
                            contentPadding: EdgeInsets.zero,
                            leading: Icon(Icons.info_outline, color: Colors.blue),
                            title: Text('Bilgi'),
                          ),
                        ),
                        PopupMenuItem(
                          value: 'duzenle',
                          child: ListTile(
                            contentPadding: EdgeInsets.zero,
                            leading: Icon(Icons.edit, color: AppRenkleri.aktif),
                            title: const Text('Düzenle'),
                          ),
                        ),
                        // ÖNEMLİ: Kullanıcı istedi — doktor ilacı değiştirirse
                        // SİLMEK yerine "Sonlandır" ile bir neden/not girip
                        // geçmişte saklanabilsin (Sil ile veri tamamen kaybolur).
                        const PopupMenuItem(
                          value: 'sonlandir',
                          child: ListTile(
                            contentPadding: EdgeInsets.zero,
                            leading: Icon(Icons.event_busy, color: Colors.orange),
                            title: Text('Sonlandır (Doktor Değiştirdi)'),
                          ),
                        ),
                        const PopupMenuItem(
                          value: 'sil',
                          child: ListTile(
                            contentPadding: EdgeInsets.zero,
                            leading: Icon(Icons.delete, color: Colors.red),
                            title: Text('Sil'),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}
