import 'dart:async';
import '../theme/renkler.dart';
import '../theme/sablon.dart';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

// Kamera + flaş kullanarak parmak ucundan nabız (PPG) ölçümü.
// Parmak kameranın üzerine kapatılınca, flaş kırmızı ışığın parmaktan
// geçişini kan akışına göre değiştirir; bu titreşimi ölçüp BPM'e çeviririz.
//
// v2 - Rework notları:
// - Parmak algılama artık ham parlaklık yerine görüntü varyansına (türdeşlik)
//   bakıyor: parmak lens+flaşı kapladığında görüntü neredeyse tek renk olur.
//   Bu, cihazdan cihaza / ortam ışığına göre değişmeyen çok daha sağlam bir işaret.
// - Parmak algılanır algılanmaz kamera exposure ve odak KİLİTLENİYOR; aksi halde
//   otomatik pozlama sürekli ayar yaparak küçük nabız sinyalini bozuyordu.
// - Sinyal artık "detrend" ediliyor (yavaş taban çizgisi kayması çıkarılıyor),
//   parmak hafif oynasa bile yanlış tepe sayımı önleniyor.
// - Ölçüm sırasında CANLI sinyal kalitesi gösteriliyor; kötüyse kullanıcı
//   20 saniye beklemeden anında düzeltebiliyor.
//
// NOT: Telefon kamerasıyla yapılan bu tür ölçümler, özel donanımlı nabız
// sensörleri kadar hassas olamaz. Sinyal kalitesi düşükse (parmak hafif
// oynadı, ışık sızdırdı vb.) sonuç yerine "güvenilir ölçüm alınamadı"
// mesajı gösteriyoruz — yanlış bir sayı vermektense hiç vermemeyi tercih ediyoruz.
class NabizOlcumEkrani extends StatefulWidget {
  const NabizOlcumEkrani({Key? key}) : super(key: key);
  @override
  State<NabizOlcumEkrani> createState() => _NabizOlcumEkraniState();
}

class _NabizOlcumEkraniState extends State<NabizOlcumEkrani> with SingleTickerProviderStateMixin {
  CameraController? _controller;
  final List<double> _kirmizilikOrnekleri = [];
  final List<DateTime> _ornekZamanlari = [];
  Timer? _sureTimer;
  int _kalanSaniye = 15;
  bool _olculuyor = false;
  bool _hazirlaniyor = true;
  bool _parmakVarMi = false;
  bool _pozlamaKilitli = false;
  String _hataMesaji = '';
  int? _sonucBpm;
  bool _sinyalZayif = false;
  int? _sonucStres;
  int? _sonucEnerji;

  // Canlı sinyal kalitesi göstergesi için
  String _canliKalite = 'bekleniyor'; // bekleniyor | iyi | zayif

  late final AnimationController _pulseController;

  static int _olcumSuresiSaniyeSabit = 15; // 'basit' için varsayılan
  int get _olcumSuresiSaniye => _yontem == 'fft' ? 20 : _olcumSuresiSaniyeSabit;
  // Ayarlar'dan seçilen ölçüm yöntemi: 'basit' (tepe sayma) | 'fft' (frekans analizi)
  String _yontem = 'fft';
  // Parmak lens+flaşı tam kapladığında görüntü neredeyse tek renk olur
  // (düşük standart sapma). Bu eşik cihazdan cihaza fazla değişmez çünkü
  // mutlak parlaklığa değil, görüntünün "türdeşliğine" bakıyor.
  static const double _parmakStdEsigi = 9.0;
  // Parmak durumu değişikliğini onaylamak için art arda kaç kare gerektiği
  int _kararliKareSayaci = 0;
  static const int _kararliliKEsigi = 5;

  @override
  void initState() {
    super.initState();
    _yontemiYukle();
    // Ölçüm sırasında kalbin etrafında sürekli genişleyip solan "sonar" halkası
    _pulseController = AnimationController(vsync: this, duration: const Duration(milliseconds: 1000))..repeat();
    _kameraKur();
  }  // --- initState() sonu ---

  Future<void> _yontemiYukle() async {
    final prefs = await SharedPreferences.getInstance();
    final kayitli = prefs.getString('nabiz_yontemi') ?? 'fft';
    if (mounted) setState(() => _yontem = kayitli);
  }  // --- _yontemiYukle() sonu ---

  Future<void> _kameraKur() async {
    final izin = await Permission.camera.request();
    if (!izin.isGranted) {
      setState(() { _hataMesaji = 'Kamera izni verilmeden ölçüm yapılamaz.'; _hazirlaniyor = false; });
      return;
    }
    try {
      final kameralar = await availableCameras();
      final arkaKamera = kameralar.firstWhere(
        (k) => k.lensDirection == CameraLensDirection.back,
        orElse: () => kameralar.first,
      );
      _controller = CameraController(arkaKamera, ResolutionPreset.low, enableAudio: false);
      await _controller!.initialize();
      await _controller!.setFlashMode(FlashMode.torch);
      setState(() => _hazirlaniyor = false);
      _controller!.startImageStream(_kareIslendi);
    } catch (e) {
      setState(() { _hataMesaji = 'Kamera başlatılamadı: $e'; _hazirlaniyor = false; });
    }
  }  // --- _kameraKur() sonu ---

  void _kareIslendi(CameraImage kare) {
    if (!mounted) return;
    final yDuzlemi = kare.planes[0].bytes;

    double toplam = 0;
    int sayac = 0;
    for (int i = 0; i < yDuzlemi.length; i += 37) {
      toplam += yDuzlemi[i];
      sayac++;
    }
    if (sayac == 0) return;
    final ortalama = toplam / sayac;

    double varyansToplam = 0;
    for (int i = 0; i < yDuzlemi.length; i += 37) {
      final fark = yDuzlemi[i] - ortalama;
      varyansToplam += fark * fark;
    }
    final stdSapma = sqrt(varyansToplam / sayac);

    // Parmak kamera+flaşı tam kapattığında görüntü neredeyse tek renk
    // (düşük varyans) olur; parmak yokken sahne çok daha "gürültülü"dür.
    // ortalama > 10 kontrolü, tamamen ışıksız/kapalı (örn. cepte) durumları eler.
    final parmakVarAday = stdSapma < _parmakStdEsigi && ortalama > 10;

    // Kararlılık payı (hysteresis/debounce): eşik sınırında sinyal bir aday
    // kareden diğerine gidip gelebilir. Durumu değiştirmeden önce art arda
    // birkaç kare aynı sonucu vermeli — aksi halde her titremede exposure
    // kilitleme/serbest bırakma tetikleniyor, bu da bazı telefonlarda flaşın
    // sönüp yanmasına (titremesine) sebep oluyordu.
    if (parmakVarAday == _parmakVarMi) {
      _kararliKareSayaci = 0;
    } else {
      _kararliKareSayaci++;
      if (_kararliKareSayaci >= _kararliliKEsigi) {
        _kararliKareSayaci = 0;
        final yeniParmakVar = parmakVarAday;
        if (mounted) {
          setState(() => _parmakVarMi = yeniParmakVar);
          if (yeniParmakVar) {
            _pozlamayiKilitle();
            if (!_olculuyor && _sonucBpm == null) _olcumeBasla();
          } else {
            _pozlamayiSerbestBirak();
          }
        }
      }
    }

    final parmakVar = _parmakVarMi;

    if (_olculuyor && parmakVar) {
      _kirmizilikOrnekleri.add(ortalama);
      _ornekZamanlari.add(DateTime.now());
    }
  }  // --- _kareIslendi() sonu ---

  // Parmak algılanır algılanmaz otomatik pozlama/odağı kilitle — aksi halde
  // kamera sürekli kendi kendine ayar yaparak küçük nabız titreşimini boğar.
  Future<void> _pozlamayiKilitle() async {
    if (_pozlamaKilitli || _controller == null) return;
    _pozlamaKilitli = true;
    try {
      await _controller!.setExposureMode(ExposureMode.locked);
      await _controller!.setFocusMode(FocusMode.locked);
      // Bazı cihazlarda exposure/focus kilitlemek flaşı da kapatıyor
      // (bilinen bir davranış) — bu yüzden kilitten hemen sonra flaşı
      // tekrar zorla açıyoruz.
      await _controller!.setFlashMode(FlashMode.torch);
    } catch (_) {
      // Bazı cihazlar/lensler bu modu desteklemeyebilir; sorun değil, devam.
    }
  }  // --- _pozlamayiKilitle() sonu ---

  Future<void> _pozlamayiSerbestBirak() async {
    if (!_pozlamaKilitli || _controller == null) return;
    _pozlamaKilitli = false;
    try {
      await _controller!.setExposureMode(ExposureMode.auto);
      await _controller!.setFocusMode(FocusMode.auto);
    } catch (_) {}
  }  // --- _pozlamayiSerbestBirak() sonu ---

  void _olcumeBasla() {
    setState(() {
      _olculuyor = true;
      _kalanSaniye = _olcumSuresiSaniye;
      _kirmizilikOrnekleri.clear();
      _ornekZamanlari.clear();
      _sonucBpm = null;
      _sinyalZayif = false;
      _sonucStres = null;
      _sonucEnerji = null;
      _canliKalite = 'bekleniyor';
    });
    _sureTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        _kalanSaniye--;
        _canliKaliteyiGuncelle();
      });
      // Güvenlik kontrolü: flaş herhangi bir sebeple sönmüşse tekrar aç.
      _controller?.setFlashMode(FlashMode.torch).catchError((_) {});
      if (_kalanSaniye <= 0) {
        timer.cancel();
        _olcumuBitirVeHesapla();
      }
    });
  }  // --- _olcumeBasla() sonu ---

  // Son ~2.5 saniyelik örneklere bakarak kullanıcıya anlık geri bildirim verir.
  // Böylece 15 saniyenin sonunu beklemeden "parmağını daha sıkı kapat" gibi
  // bir uyarı görebiliyor.
  void _canliKaliteyiGuncelle() {
    if (_kirmizilikOrnekleri.length < 20) return;
    final sonOrnekSayisi = min(75, _kirmizilikOrnekleri.length);
    final sonOrnekler = _kirmizilikOrnekleri.sublist(_kirmizilikOrnekleri.length - sonOrnekSayisi);
    final acGenlik = _acGenligiHesapla(sonOrnekler);
    _canliKalite = acGenlik >= 1.2 ? 'iyi' : 'zayif';
  }  // --- _canliKaliteyiGuncelle() sonu ---

  void _olcumuBitirVeHesapla() {
    setState(() => _olculuyor = false);
    _pozlamayiSerbestBirak();
    final sonuc = _yontem == 'fft'
        ? _bpmHesaplaFFT(_kirmizilikOrnekleri, _ornekZamanlari)
        : _bpmHesapla(_kirmizilikOrnekleri, _ornekZamanlari);

    // Stres/Enerji, kullanılan yöntemden bağımsız olarak tepe (atım)
    // zamanlarından hesaplanır — FFT sadece ortalama frekansı verdiği için
    // atım-atım aralıkları burada ayrıca çıkarılır.
    ({int stres, int enerji})? stresEnerji;
    if (sonuc.$1 != null) {
      final ac = _acBileseniHesapla(_kirmizilikOrnekleri);
      final tepeZamanlari = _tepeZamanlariniBul(ac, _ornekZamanlari);
      stresEnerji = _stresEnerjiHesapla(tepeZamanlari, sonuc.$1!);
    }

    setState(() {
      _sonucBpm = sonuc.$1;
      _sinyalZayif = sonuc.$2;
      _sonucStres = stresEnerji?.stres;
      _sonucEnerji = stresEnerji?.enerji;
    });
  }  // --- _olcumuBitirVeHesapla() sonu ---

  // Ham sinyali yumuşatıp (hızlı hareketli ortalama) ardından yavaş kayan
  // bir taban çizgisini çıkararak (detrend) sadece nabız kaynaklı titreşimi
  // (AC bileşeni) elde eder. Parmağın hafif oynaması ya da ışığın azıcık
  // sızması gibi yavaş değişimler böylece devre dışı kalır.
  List<double> _acBileseniHesapla(List<double> ornekler) {
    final List<double> hizli = [];
    for (int i = 0; i < ornekler.length; i++) {
      final baslangic = max(0, i - 2);
      final parca = ornekler.sublist(baslangic, i + 1);
      hizli.add(parca.reduce((a, b) => a + b) / parca.length);
    }

    // Yavaş taban çizgisi: ~1.2 saniyelik pencere (yaklaşık 30fps varsayımıyla ~36 örnek)
    const yavasPencere = 36;
    final List<double> ac = [];
    for (int i = 0; i < hizli.length; i++) {
      final baslangic = max(0, i - yavasPencere);
      final parca = hizli.sublist(baslangic, i + 1);
      final taban = parca.reduce((a, b) => a + b) / parca.length;
      ac.add(hizli[i] - taban);
    }
    return ac;
  }  // --- _acBileseniHesapla() sonu ---

  double _acGenligiHesapla(List<double> ornekler) {
    if (ornekler.length < 10) return 0;
    final ac = _acBileseniHesapla(ornekler);
    final enBuyuk = ac.reduce((a, b) => a > b ? a : b);
    final enKucuk = ac.reduce((a, b) => a < b ? a : b);
    return enBuyuk - enKucuk;
  }  // --- _acGenligiHesapla() sonu ---

  // ================= GELİŞMİŞ (FFT) YÖNTEM =================
  // "Tepe say" yerine sinyali frekans bileşenlerine ayırıp, fizyolojik
  // olarak makul bant (40-200 BPM) içindeki BASKIN frekansı buluyoruz.
  // Bu, tekil gürültü tepelerinden çok daha az etkilenir çünkü tüm
  // sinyalin ortak periyodikliğine bakar, tek tek tepe noktalarına değil.
  (int?, bool) _bpmHesaplaFFT(List<double> ornekler, List<DateTime> zamanlar) {
    if (ornekler.length < 60 || zamanlar.length < 2) return (null, true);
    final ac = _acBileseniHesapla(ornekler);

    final t0 = zamanlar.first;
    final List<double> zamanSaniye = zamanlar.map((z) => z.difference(t0).inMilliseconds / 1000.0).toList();
    final toplamSure = zamanSaniye.last;
    if (toplamSure < 5) return (null, true); // FFT için çok kısa

    // Kamera kare hızı sabit olmadığından, önce düzenli aralıklı (uniform)
    // bir zaman ızgarasına yeniden örnekliyoruz (doğrusal enterpolasyon).
    const ornekHizi = 20.0; // Hz
    final ornekSayisi = (toplamSure * ornekHizi).floor();
    if (ornekSayisi < 64) return (null, true);

    final List<double> duzenli = List.filled(ornekSayisi, 0.0);
    int kaynakIndex = 0;
    for (int i = 0; i < ornekSayisi; i++) {
      final t = i / ornekHizi;
      while (kaynakIndex < zamanSaniye.length - 2 && zamanSaniye[kaynakIndex + 1] < t) {
        kaynakIndex++;
      }
      final t1 = zamanSaniye[kaynakIndex];
      final t2 = zamanSaniye[kaynakIndex + 1];
      final v1 = ac[kaynakIndex];
      final v2 = ac[kaynakIndex + 1];
      final aralik = t2 - t1;
      final oran = aralik > 0 ? ((t - t1) / aralik).clamp(0.0, 1.0) : 0.0;
      duzenli[i] = v1 + (v2 - v1) * oran;
    }

    // FFT algoritması 2'nin kuvveti uzunluk gerektirir → sıfır-doldurma (zero-pad)
    int fftUzunluk = 1;
    while (fftUzunluk < ornekSayisi) {
      fftUzunluk *= 2;
    }
    if (fftUzunluk < 256) fftUzunluk = 256; // yeterli frekans çözünürlüğü için

    final re = List<double>.filled(fftUzunluk, 0.0);
    final im = List<double>.filled(fftUzunluk, 0.0);
    for (int i = 0; i < ornekSayisi; i++) {
      // Hann penceresi: sinyalin başı/sonu keskin kesilmesin diye (spektral sızıntıyı azaltır)
      final pencere = 0.5 - 0.5 * cos(2 * pi * i / (ornekSayisi - 1));
      re[i] = duzenli[i] * pencere;
    }

    _fftUygula(re, im);

    // Fizyolojik bant: 40-200 BPM = 0.667 - 3.333 Hz
    final binHz = ornekHizi / fftUzunluk;
    final yariUzunluk = fftUzunluk ~/ 2;
    final minBin = (0.667 / binHz).floor().clamp(1, yariUzunluk - 1);
    final maxBin = (3.333 / binHz).ceil().clamp(1, yariUzunluk - 1);

    double enBuyukGuc = 0;
    int enIyiBin = -1;
    double toplamGuc = 0;
    for (int b = minBin; b <= maxBin; b++) {
      final guc = re[b] * re[b] + im[b] * im[b];
      toplamGuc += guc;
      if (guc > enBuyukGuc) {
        enBuyukGuc = guc;
        enIyiBin = b;
      }
    }
    if (enIyiBin < 0 || toplamGuc <= 0) return (null, true);

    // Baskın frekansın, banttaki ortalama güce oranı — ne kadar "belirgin" bir tepe var?
    // Düşükse, ortada gerçek bir periyodik nabız sinyali değil, gürültü var demektir.
    final bandGenisligi = maxBin - minBin + 1;
    final belirginlikOrani = enBuyukGuc / (toplamGuc / bandGenisligi);
    if (belirginlikOrani < 2.2) return (null, true);

    final frekansHz = enIyiBin * binHz;
    final bpm = (frekansHz * 60).round();
    if (bpm < 40 || bpm > 200) return (null, false);
    return (bpm, false);
  }  // --- _bpmHesaplaFFT() sonu ---

  // Yerinde (in-place), iteratif radix-2 Cooley-Tukey FFT.
  // re/im: giriş sinyali (im=0 ile başlar), uzunluk 2'nin kuvveti olmalı.
  // Sonuçta re/im, sinyalin frekans-alanı (karmaşık) karşılığını içerir.
  void _fftUygula(List<double> re, List<double> im) {
    final n = re.length;

    // Bit-ters sıralama (bit-reversal permutation)
    for (int i = 1, j = 0; i < n; i++) {
      int bit = n >> 1;
      for (; (j & bit) != 0; bit >>= 1) {
        j ^= bit;
      }
      j ^= bit;
      if (i < j) {
        final tr = re[i]; re[i] = re[j]; re[j] = tr;
        final ti = im[i]; im[i] = im[j]; im[j] = ti;
      }
    }

    // Kademeli (butterfly) birleştirme
    for (int uzunluk = 2; uzunluk <= n; uzunluk <<= 1) {
      final aci = -2 * pi / uzunluk;
      final wRe = cos(aci);
      final wIm = sin(aci);
      final yari = uzunluk >> 1;
      for (int i = 0; i < n; i += uzunluk) {
        double curRe = 1.0, curIm = 0.0;
        for (int k = 0; k < yari; k++) {
          final uRe = re[i + k];
          final uIm = im[i + k];
          final vRe = re[i + k + yari] * curRe - im[i + k + yari] * curIm;
          final vIm = re[i + k + yari] * curIm + im[i + k + yari] * curRe;
          re[i + k] = uRe + vRe;
          im[i + k] = uIm + vIm;
          re[i + k + yari] = uRe - vRe;
          im[i + k + yari] = uIm - vIm;
          final yeniCurRe = curRe * wRe - curIm * wIm;
          final yeniCurIm = curRe * wIm + curIm * wRe;
          curRe = yeniCurRe;
          curIm = yeniCurIm;
        }
      }
    }
  }  // --- _fftUygula() sonu ---

  // Tepe-noktası (peak detection) algoritması, detrend edilmiş AC sinyali üzerinde:
  // 1) Sinyali yumuşat + taban kaymasını çıkar (detrend)
  // 2) Genlik çok düşükse → sinyal zayıf, güvenme
  // 3) Sıfırın üzerindeki tepe noktalarını say ama art arda gelen çok yakın
  //    "sahte" tepeleri (gürültü) saymamak için minimum bir zaman aralığı
  //    (refrakter süre) uygula
  // Detrend edilmiş AC sinyalinde tepe (kalp atışı) zamanlarını bulur.
  // Hem Basit BPM hesabında hem de HRV/Stres-Enerji hesabında ortak kullanılır.
  List<DateTime> _tepeZamanlariniBul(List<double> ac, List<DateTime> zamanlar) {
    const minTepeAraligiMs = 270;
    DateTime? sonTepeZamani;
    final List<DateTime> tepeler = [];
    for (int i = 1; i < ac.length - 1; i++) {
      final tepeMi = ac[i] > 0 && ac[i] > ac[i - 1] && ac[i] >= ac[i + 1];
      if (!tepeMi) continue;
      final zaman = zamanlar[i];
      if (sonTepeZamani == null || zaman.difference(sonTepeZamani).inMilliseconds >= minTepeAraligiMs) {
        tepeler.add(zaman);
        sonTepeZamani = zaman;
      }
    }
    return tepeler;
  }  // --- _tepeZamanlariniBul() sonu ---

  (int?, bool) _bpmHesapla(List<double> ornekler, List<DateTime> zamanlar) {
    if (ornekler.length < 40 || zamanlar.length < 2) return (null, true);

    final ac = _acBileseniHesapla(ornekler);
    final enBuyuk = ac.reduce((a, b) => a > b ? a : b);
    final enKucuk = ac.reduce((a, b) => a < b ? a : b);
    final genlik = enBuyuk - enKucuk;

    // Genlik çok düşükse (parmak hafif oynadı, ışık sızdırdı vb.) sinyal
    // güvenilir değildir — yanlış bir BPM vermektense uyarı verelim.
    if (genlik < 1.2) return (null, true);

    // En hızlı fizyolojik olarak makul kalp atışı ~220 bpm → iki tepe
    // arasında en az ~270ms olmalı. Bu süreden daha yakın "tepeleri"
    // gürültü sayıp atlıyoruz.
    final tepeZamanlari = _tepeZamanlariniBul(ac, zamanlar);
    final tepeSayisi = tepeZamanlari.length;

    final toplamSaniye = zamanlar.last.difference(zamanlar.first).inMilliseconds / 1000.0;
    if (toplamSaniye <= 0) return (null, true);

    final bpm = (tepeSayisi / toplamSaniye) * 60;
    if (bpm < 40 || bpm > 180) return (null, false);
    return (bpm.round(), false);
  }  // --- _bpmHesapla() sonu ---

  // --- STRES / ENERJİ (HRV tabanlı, kaba bir gösterge — klinik bir ölçüm DEĞİL) ---
  // Atımlar arası süre farklarının (RR aralıkları) ne kadar değişken olduğuna
  // bakan RMSSD adlı standart bir HRV metriği hesaplanır. Yüksek değişkenlik
  // genelde daha sakin/dinlenmiş bir duruma işaret eder, düşük değişkenlik
  // ise daha gergin/yorgun bir duruma. Referans sağlık uygulamalarındaki
  // "Stres/Enerji" göstergeleri de aynı mantıkla, kesin tıbbi bir ölçüm
  // iddiası olmadan, kaba bir fikir vermek için kullanılır.
  ({int stres, int enerji})? _stresEnerjiHesapla(List<DateTime> tepeZamanlari, int bpm) {
    if (tepeZamanlari.length < 5) return null; // güvenilir HRV için yeterli atım yok

    final List<double> rrAralik = [];
    for (int i = 1; i < tepeZamanlari.length; i++) {
      rrAralik.add(tepeZamanlari[i].difference(tepeZamanlari[i - 1]).inMilliseconds.toDouble());
    }
    if (rrAralik.length < 4) return null;

    double kareFarkToplami = 0;
    for (int i = 1; i < rrAralik.length; i++) {
      final fark = rrAralik[i] - rrAralik[i - 1];
      kareFarkToplami += fark * fark;
    }
    final rmssd = sqrt(kareFarkToplami / (rrAralik.length - 1));

    // Kaba eşleme: RMSSD ~10ms altı yüksek gerginlik, ~60ms üstü çok sakin
    // kabul edilip 0-100 aralığına ölçekleniyor.
    final stres = (100 - ((rmssd - 10) / 50 * 100)).clamp(5, 95).round();
    // Enerji: yüksek stres ve yüksek istirahat nabzı enerjiyi aşağı çeker.
    final enerjiCiCap = 100 - stres * 0.6 - (bpm > 90 ? 15 : 0);
    final enerji = enerjiCiCap.clamp(5, 95).round();
    return (stres: stres, enerji: enerji);
  }  // --- _stresEnerjiHesapla() sonu ---

  @override
  void dispose() {
    _sureTimer?.cancel();
    _pulseController.dispose();
    _controller?.dispose();
    super.dispose();
  }  // --- dispose() sonu ---

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        shape: AppSablon.appBarSekli,
        clipBehavior: Clip.antiAlias,
        title: const Text('Nabız Ölçümü'),
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        elevation: 0,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Center(
              child: Text(
                _yontem == 'fft' ? 'FFT' : 'Basit',
                style: const TextStyle(color: Colors.white54, fontSize: 12, fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ],
      ),
      body: Center(
        child: _hazirlaniyor
            ? const CircularProgressIndicator(color: Colors.white)
            : _hataMesaji.isNotEmpty
                ? Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text(_hataMesaji, style: const TextStyle(color: Colors.white, fontSize: 15), textAlign: TextAlign.center),
                  )
                : _sonucBpm != null || _sinyalZayif
                    ? _sonucGoster()
                    : _olcumEkrani(),
      ),
    );
  }  // --- build() sonu ---

  // Kalp ikonu + etrafında genişleyip solan "sonar" halkası animasyonu
  Widget _animasyonluKalp() {
    return SizedBox(
      width: 160,
      height: 160,
      child: Stack(
        alignment: Alignment.center,
        children: [
          if (_olculuyor)
            AnimatedBuilder(
              animation: _pulseController,
              builder: (context, child) {
                final t = _pulseController.value; // 0 -> 1 döngü
                return Opacity(
                  opacity: (1 - t).clamp(0.0, 1.0),
                  child: Transform.scale(
                    scale: 0.6 + t * 0.9,
                    child: Container(
                      width: 140, height: 140,
                      decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Colors.red, width: 2)),
                    ),
                  ),
                );
              },
            ),
          TweenAnimationBuilder<double>(
            tween: Tween(begin: 0.9, end: 1.12),
            duration: const Duration(milliseconds: 550),
            curve: Curves.easeInOut,
            builder: (context, deger, child) => Transform.scale(scale: deger, child: child),
            child: Icon(Icons.favorite, color: _parmakVarMi ? Colors.red : Colors.red.shade900, size: 84),
          ),
          // Küçük, canlı kamera önizlemesi — hangi kameranın/lensin aktif
          // olduğunu görebilmen için istemiştin. Parmak kapatınca zaten
          // görüntü neredeyse tek renk (kırmızımsı) olur, bu normal.
          if (_controller != null && _controller!.value.isInitialized)
            Positioned(
              right: 4,
              top: 4,
              child: ClipOval(
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white54, width: 1.5),
                  ),
                  child: FittedBox(
                    fit: BoxFit.cover,
                    child: SizedBox(
                      width: _controller!.value.previewSize?.height ?? 100,
                      height: _controller!.value.previewSize?.width ?? 100,
                      child: CameraPreview(_controller!),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }  // --- _animasyonluKalp() sonu ---

  Widget _kaliteRozeti() {
    final iyi = _canliKalite == 'iyi';
    final bekleniyor = _canliKalite == 'bekleniyor';
    final renk = bekleniyor ? Colors.white54 : (iyi ? Colors.greenAccent : Colors.orange);
    final metin = bekleniyor ? 'Sinyal ölçülüyor...' : (iyi ? 'Sinyal kalitesi: İyi ✓' : 'Sinyal zayıf — parmağı daha sıkı kapatın');
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(bekleniyor ? Icons.hourglass_top : (iyi ? Icons.check_circle : Icons.warning_amber_rounded), color: renk, size: 16),
        const SizedBox(width: 6),
        Text(metin, style: TextStyle(color: renk, fontSize: 13)),
      ],
    );
  }  // --- _kaliteRozeti() sonu ---

  Widget _olcumEkrani() {
    final yuzde = _olculuyor ? (((_olcumSuresiSaniye - _kalanSaniye) / _olcumSuresiSaniye) * 100).round() : 0;
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _animasyonluKalp(),
          const SizedBox(height: 24),
          if (!_parmakVarMi && !_olculuyor) ...[
            const Text(
              'Parmağınızı arka kameranın ve flaşın\nüzerine hafifçe kapatın',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white, fontSize: 16),
            ),
            const SizedBox(height: 20),
            // Otomatik algılama bazı telefonlarda (kamera/sensör farkları
            // yüzünden) hiç tetiklenmeyebiliyor. Bu durumda kullanıcı takılıp
            // kalmasın diye elle başlatma imkanı veriyoruz.
            TextButton.icon(
              onPressed: _olcumeBasla,
              icon: const Icon(Icons.play_circle_outline, color: Colors.white70),
              label: const Text('Otomatik algılamıyor mu? Elle Başlat', style: TextStyle(color: Colors.white70)),
            ),
          ]
          else if (!_parmakVarMi && _olculuyor)
            const Text(
              'Parmağınız algılanamıyor, lütfen\nkamerayı tam kapatın',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.orange, fontSize: 15),
            )
          else if (_olculuyor)
            Column(
              children: [
                Text('Ölçülüyor... (%$yuzde)', style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                const Text('Parmağınızı sabit tutun, hafifçe bastırın', style: TextStyle(color: Colors.white70, fontSize: 13)),
                const SizedBox(height: 12),
                _kaliteRozeti(),
                const SizedBox(height: 16),
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: LinearProgressIndicator(
                    value: yuzde / 100,
                    minHeight: 8,
                    color: Colors.red,
                    backgroundColor: Colors.white24,
                  ),
                ),
              ],
            )
          else
            const Text('Parmak algılandı ✓ Ölçüm başlıyor...', style: TextStyle(color: Colors.greenAccent, fontSize: 15)),
          const SizedBox(height: 32),
        ],
      ),
    );
  }  // --- _olcumEkrani() sonu ---

  Widget _stresEnerjiGostergesi(String etiket, int yuzde, Color renk) {
    return Column(
      children: [
        SizedBox(
          width: 64,
          height: 64,
          child: Stack(
            alignment: Alignment.center,
            children: [
              CircularProgressIndicator(
                value: yuzde / 100,
                strokeWidth: 6,
                backgroundColor: Colors.white24,
                valueColor: AlwaysStoppedAnimation<Color>(renk),
              ),
              Text('%$yuzde', style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.bold)),
            ],
          ),
        ),
        const SizedBox(height: 6),
        Text(etiket, style: const TextStyle(color: Colors.white70, fontSize: 12)),
      ],
    );
  }  // --- _stresEnerjiGostergesi() sonu ---

  Widget _sonucGoster() {
    final bpm = _sonucBpm;
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          if (bpm == null) ...[
            const Icon(Icons.error_outline, color: Colors.orange, size: 60),
            const SizedBox(height: 16),
            Text(
              _sinyalZayif
                  ? 'Sinyal çok zayıf algılandı.\nParmağınızı flaşın üzerine biraz daha\nsıkı ve sabit kapatıp tekrar deneyin.'
                  : 'Güvenilir bir ölçüm alınamadı.\nLütfen parmağınızı sabit tutup tekrar deneyin.',
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white, fontSize: 15),
            ),
          ] else ...[
            const Icon(Icons.favorite, color: Colors.red, size: 70),
            const SizedBox(height: 12),
            Text('$bpm', style: const TextStyle(color: Colors.white, fontSize: 56, fontWeight: FontWeight.bold)),
            const Text('BPM', style: TextStyle(color: Colors.white70, fontSize: 16)),
            if (_sonucStres != null && _sonucEnerji != null) ...[
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _stresEnerjiGostergesi('Stres', _sonucStres!, Colors.orangeAccent),
                  const SizedBox(width: 28),
                  _stresEnerjiGostergesi('Enerji', _sonucEnerji!, Colors.lightBlueAccent),
                ],
              ),
              const SizedBox(height: 8),
              const Text(
                '*Kalp atışı değişkenliğinden kaba bir tahmindir, tıbbi bir ölçüm değildir.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white38, fontSize: 10),
              ),
            ],
          ],
          const SizedBox(height: 32),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextButton(
                onPressed: () {
                  setState(() { _sonucBpm = null; _sinyalZayif = false; _sonucStres = null; _sonucEnerji = null; });
                  if (_parmakVarMi) _olcumeBasla();
                },
                child: const Text('Tekrar Ölç', style: TextStyle(color: Colors.white70)),
              ),
              const SizedBox(width: 16),
              if (bpm != null)
                ElevatedButton(
                  onPressed: () => Navigator.pop(context, bpm),
                  style: ElevatedButton.styleFrom(backgroundColor: AppRenkleri.aktif, foregroundColor: Colors.white),
                  child: const Text('Bu Sonucu Kullan'),
                ),
            ],
          ),
        ],
      ),
    );
  }  // --- _sonucGoster() sonu ---
}
