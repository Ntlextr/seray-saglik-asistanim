import 'dart:async';
import '../theme/renkler.dart';
import '../theme/sablon.dart';
import '../services/dil_servisi.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'seker_ekle_ekrani.dart';
import 'tansiyon_ekle_ekrani.dart';
import 'su_kilo_ekrani.dart';
import 'beslenme_ekrani.dart';
import 'ilac_ekrani.dart';
import 'yapay_zeka_ekrani.dart';
import 'rapor_ekrani.dart';
import '../services/veritabani_yardimcisi.dart';
import '../services/adim_servisi.dart';
import '../services/widget_servisi.dart';
import '../widgets/ust_menu.dart';

class AnaSayfa extends StatefulWidget {
  const AnaSayfa({Key? key}) : super(key: key);

  @override
  _AnaSayfaState createState() => _AnaSayfaState();
}

class _AnaSayfaState extends State<AnaSayfa> {
  // Alt menüde sekme değiştirdiğinde main.dart bu ekranı YENİDEN KURUYOR
  // (veri tazelensin diye). Bu "static" bayrak sayesinde karşılama banner'ı
  // uygulama açıldığında sadece BİR KEZ gösteriliyor, her "Özet"e dönüşte değil.
  static bool _buOturumdaGosterildi = false;

  String _kullaniciAdi = "...";
  String _cinsiyet = "Bay";
  List<Map<String, dynamic>> _sonSekerler = [];
  List<Map<String, dynamic>> _sonTansiyonlar = [];
  int _bugunSuMl = 0;
  double? _sonKilo;
  int _bugunAdim = 0;
  Timer? _adimYenilemeTimer;
  static const int _gunlukSuHedefiMl = 2000;

  // Karşılama banner'ı popup DEĞİL; ekrana girince görünür, birkaç
  // saniye sonra kendiliğinden solup kaybolur.
  bool _selamGorunur = true;
  bool _selamSoluyor = false;
  Timer? _selamZamanlayici;
  Timer? _selamKaybolmaZamanlayici;

  // Widget ekleme bannerı — kullanıcı ekleyince veya kapatınca bir daha
  // görünmesin diye SharedPreferences'ta kalıcı olarak saklanıyor.
  bool _widgetBanneriGizli = false;

  String get _hitap => DilServisi.dilKodu == 'en' ? '' : ((_cinsiyet == 'Bayan' || _cinsiyet == 'Kadın') ? 'Hanım' : 'Bey');

  String get _selamlama {
    final saat = DateTime.now().hour;
    if (saat >= 5 && saat < 12) return DilServisi.metin('selamlamaGunaydin');
    if (saat >= 12 && saat < 18) return DilServisi.metin('selamlamaIyiGunler');
    if (saat >= 18 && saat < 23) return DilServisi.metin('selamlamaIyiAksamlar');
    return DilServisi.metin('selamlamaIyiGeceler');
  }

  // YENİ: 5 hızlı ekleme seçeneğini (Şeker/Tansiyon/Su&Kilo/Yemek/İlaç)
  // artık sayfa içinde büyük butonlar olarak değil, "+" kayan düğmesine
  // basınca açılan bir alt sayfa (bottom sheet) listesi olarak gösteriyor.
  void _hizliEkleMenusunuGoster(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (sheetContext) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 8),
              Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.grey.shade300, borderRadius: BorderRadius.circular(2))),
              const SizedBox(height: 8),
              ListTile(
                leading: Icon(Icons.bloodtype, color: AppRenkleri.aktif),
                title: Text(DilServisi.metin('sekerEkle')),
                onTap: () {
                  Navigator.pop(sheetContext);
                  Navigator.push(context, MaterialPageRoute(builder: (context) => SekerEkleEkrani())).then((_) => _verileriTazele());
                },
              ),
              ListTile(
                leading: Icon(Icons.favorite, color: AppRenkleri.aktif),
                title: Text(DilServisi.metin('tansiyonEkle')),
                onTap: () {
                  Navigator.pop(sheetContext);
                  Navigator.push(context, MaterialPageRoute(builder: (context) => TansiyonEkleEkrani())).then((_) => _verileriTazele());
                },
              ),
              ListTile(
                leading: Icon(Icons.water_drop, color: AppRenkleri.aktif),
                title: Text(DilServisi.metin('suKiloBaslik')),
                onTap: () {
                  Navigator.pop(sheetContext);
                  Navigator.push(context, MaterialPageRoute(builder: (context) => const SuKiloEkrani())).then((_) => _verileriTazele());
                },
              ),
              ListTile(
                leading: Icon(Icons.restaurant, color: AppRenkleri.aktif),
                title: Text(DilServisi.metin('yemekEkle')),
                onTap: () {
                  Navigator.pop(sheetContext);
                  Navigator.push(context, MaterialPageRoute(builder: (context) => const BeslenmeEkrani())).then((_) => _verileriTazele());
                },
              ),
              ListTile(
                leading: Icon(Icons.medication, color: AppRenkleri.aktif),
                title: Text(DilServisi.metin('ilacEkle')),
                onTap: () {
                  Navigator.pop(sheetContext);
                  Navigator.push(context, MaterialPageRoute(builder: (context) => const IlacEkrani())).then((_) => _verileriTazele());
                },
              ),
              const SizedBox(height: 8),
            ],
          ),
        );
      },
    );
  }  // --- _hizliEkleMenusunuGoster() sonu ---

  String _tarihiBicimlendir(String? isoTarih) {
    if (isoTarih == null) return '';
    final t = DateTime.tryParse(isoTarih);
    if (t == null) return isoTarih;
    String iki(int n) => n.toString().padLeft(2, '0');
    return '${iki(t.day)}.${iki(t.month)}.${t.year} ${iki(t.hour)}:${iki(t.minute)}';
  }

  @override
  void initState() {
    super.initState();
    _verileriTazele();
    if (!_buOturumdaGosterildi) {
      _buOturumdaGosterildi = true;
      _selamZamanlayici = Timer(const Duration(seconds: 5), () {
        if (!mounted) return;
        setState(() => _selamSoluyor = true);
        _selamKaybolmaZamanlayici = Timer(const Duration(milliseconds: 1400), () {
          if (mounted) setState(() => _selamGorunur = false);
        });
      });
    } else {
      // Bu oturumda zaten gösterildi — tekrar açılmasın.
      _selamGorunur = false;
    }
    AdimServisi.baslat();
    _adimYenilemeTimer = Timer.periodic(const Duration(seconds: 5), (_) async {
      final adim = await AdimServisi.bugunkuAdimGetir();
      if (mounted) setState(() => _bugunAdim = adim);
      WidgetServisi.guncelle(adim: adim, suMl: _bugunSuMl);
    });
  }

  @override
  void dispose() {
    _selamZamanlayici?.cancel();
    _selamKaybolmaZamanlayici?.cancel();
    _adimYenilemeTimer?.cancel();
    super.dispose();
  }

  Future<void> _verileriTazele() async {
    final prefs = await SharedPreferences.getInstance();
    final sekerler = await VeritabaniYardimcisi().sekerleriGetir();
    final tansiyonlar = await VeritabaniYardimcisi().tansiyonlariGetir();
    final bugunSu = await VeritabaniYardimcisi().bugunToplamSuGetir();
    final kiloKayitlari = await VeritabaniYardimcisi().kiloKayitlariniGetir();

    setState(() {
      // Hem profil_kayit_ekrani hem eski kayıt anahtarları kontrol ediliyor
      _kullaniciAdi = prefs.getString('kullanici_ad') ?? 
                       prefs.getString('user_ad') ?? 
                       "Kullanıcı";
      _cinsiyet = prefs.getString('kullanici_cinsiyet') ?? 
                  prefs.getString('user_cinsiyet') ?? 
                  "Bay";
                  
      _sonSekerler = sekerler;
      _sonTansiyonlar = tansiyonlar;
      _bugunSuMl = bugunSu;
      _sonKilo = kiloKayitlari.isNotEmpty ? (kiloKayitlari.first['kilo'] as num?)?.toDouble() : null;
      _widgetBanneriGizli = prefs.getBool('widget_banneri_gizli') ?? false;
    });
    WidgetServisi.guncelle(adim: _bugunAdim, suMl: _bugunSuMl);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(
        shape: AppSablon.appBarSekli,
        clipBehavior: Clip.antiAlias,
        title: Text(DilServisi.metin('anaSayfaBaslik'), style: const TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: AppRenkleri.aktif,
        foregroundColor: Colors.white,
        elevation: 0,
        actions: const [UstMenu()],
      ),
      // ÖNEMLİ DÜZELTME: 5 büyük ekleme butonu, sayfayı gereksiz yere
      // uzatıp "veri giriş paneli" hissi veriyordu — kullanıcının poster
      // referansında hiç ekleme butonu yoktu, tek ekrana sığan sade bir
      // dashboard vardı. Butonlar artık sayfa içeriğinden hiç yer
      // kaplamayan bir "+" kayan düğmesinin (FAB) arkasına taşındı.
      floatingActionButton: FloatingActionButton(
        backgroundColor: AppRenkleri.aktif,
        onPressed: () => _hizliEkleMenusunuGoster(context),
        child: const Icon(Icons.add, color: Colors.white),
      ),
      body: Stack(
        children: [
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [

              // ADIM ÖZETİ
              Container(
                padding: const EdgeInsets.all(16),
                margin: const EdgeInsets.only(bottom: 8),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
                ),
                child: Row(
                  children: [
                    const CircleAvatar(
                      backgroundColor: Color(0xFFFFF3E0),
                      child: Icon(Icons.directions_walk, color: Colors.orange),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('${DilServisi.metin('adimBaslik')}: $_bugunAdim', style: const TextStyle(fontWeight: FontWeight.bold)),
                          Text('${DilServisi.metin('tahminiYakilanKalori')}: ${(_bugunAdim * 0.04).round()} kcal', style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              // SU ÖZETİ
              Container(
                padding: const EdgeInsets.all(16),
                margin: const EdgeInsets.only(bottom: 8),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
                ),
                child: Row(
                  children: [
                    const CircleAvatar(
                      backgroundColor: Color(0xFFE1F5FE),
                      child: Icon(Icons.water_drop, color: Colors.lightBlue),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('${DilServisi.metin('suBaslik')}: ${(_bugunSuMl / 1000).toStringAsFixed(1)} L / ${(_gunlukSuHedefiMl / 1000).toStringAsFixed(0)} L', style: const TextStyle(fontWeight: FontWeight.bold)),
                          Text(
                            _bugunSuMl >= _gunlukSuHedefiMl
                                ? '🎉 ${DilServisi.metin('bugunkuHedefeUlastiniz')}'
                                : '${DilServisi.metin('bugunKelime')} ${(_gunlukSuHedefiMl - _bugunSuMl).clamp(0, _gunlukSuHedefiMl)} mL ${DilServisi.metin('kaldiTek')}',
                            style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              // KİLO ÖZETİ
              if (_sonKilo != null)
                Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
                  ),
                  child: ListTile(
                    leading: const CircleAvatar(
                      backgroundColor: Color(0xFFF3E5F5),
                      child: Icon(Icons.monitor_weight, color: Colors.purple),
                    ),
                    title: Text(
                      '${DilServisi.metin('kiloBaslik')}: ${_sonKilo!.toStringAsFixed(1)} kg',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text(DilServisi.metin('enSonKaydedilenOlcum')),
                  ),
                ),
              if (_sonKilo != null) const SizedBox(height: 8),

              // ŞEKER ÖLÇÜMÜ
              if (_sonSekerler.isNotEmpty)
                Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
                  ),
                  child: ListTile(
                    leading: const CircleAvatar(
                      backgroundColor: Color(0xFFFFEBEE),
                      child: Icon(Icons.bloodtype, color: Colors.red),
                    ),
                    title: Text(
                      '${DilServisi.metin('kanSekeriBaslik')}: ${_sonSekerler.first['deger']} mg/dL',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text(
                      '${DilServisi.metin('durumBaslik')}: ${DilServisi.durumGoster(_sonSekerler.first['durum']?.toString() ?? DilServisi.metin('durumBelirtilmedi'))}\n${DilServisi.metin('tarihBaslik')}: ${_tarihiBicimlendir(_sonSekerler.first['tarih']?.toString())}',
                    ),
                  ),
                ),

              if (_sonSekerler.isNotEmpty && _sonTansiyonlar.isNotEmpty)
                const SizedBox(height: 8),

              // TANSİYON ÖLÇÜMÜ
              if (_sonTansiyonlar.isNotEmpty)
                Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
                  ),
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: const Color(0xE8E0F2F1),
                      child: Icon(Icons.favorite, color: AppRenkleri.aktif),
                    ),
                    title: Text(
                      '${DilServisi.metin('tansiyon')}: ${_sonTansiyonlar.first['buyuk']}/${_sonTansiyonlar.first['kucuk']} mmHg',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text(
                      '${DilServisi.metin('tarihBaslik')}: ${_tarihiBicimlendir(_sonTansiyonlar.first['tarih']?.toString())}',
                    ),
                  ),
                ),

              if (_sonSekerler.isEmpty && _sonTansiyonlar.isEmpty)
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
                  ),
                  child: Center(
                    child: Text(
                      DilServisi.metin('henuzOlcumYok'),
                      style: const TextStyle(color: Colors.grey),
                    ),
                  ),
                ),

            ],
              ),
            ),
          ),
          // KARŞILAMA OVERLAY'İ — popup DEĞİL: ekranın ortasında belirir,
          // birkaç saniye sonra bulut gibi yavaşça büyüyüp solarak kaybolur.
          // IgnorePointer sayesinde altındaki içeriğe dokunmaya engel olmaz.
          if (_selamGorunur)
            Positioned.fill(
              child: IgnorePointer(
                child: Center(
                  child: AnimatedOpacity(
                    opacity: _selamSoluyor ? 0.0 : 1.0,
                    duration: const Duration(milliseconds: 1400),
                    curve: Curves.easeOut,
                    child: AnimatedScale(
                      scale: _selamSoluyor ? 1.25 : 1.0,
                      duration: const Duration(milliseconds: 1400),
                      curve: Curves.easeOut,
                      child: Container(
                        margin: const EdgeInsets.symmetric(horizontal: 32),
                        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
                        decoration: BoxDecoration(
                          color: AppRenkleri.aktif.shade50,
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.12), blurRadius: 16, offset: const Offset(0, 6))],
                        ),
                        child: Text(
                          '$_selamlama, $_kullaniciAdi${_hitap.isEmpty ? "" : " $_hitap"} 🌤️',
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Color(0xFF006655)),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
      // NOT: Alt navigasyon menüsü artık sadece main.dart'taki
      // AnaEkranYonlendirici içinde tek bir yerden yönetiliyor.
      // Burada ikinci bir bottomNavigationBar OLMAMALI, aksi halde
      // eski (Ana Sayfa/Şeker/Tansiyon/Profil) menü ile yeni
      // (Özet/Analizler/İlaçlarım/Profil) menü çakışır.
    );
  }
}
