import 'package:flutter/material.dart';

// Uygulamanın görsel ŞABLON sistemi. Renk sisteminden (AppRenkleri, aynı
// klasördeki renkler.dart) TAMAMEN bağımsız — ikisi birlikte, üst üste
// çalışır: renk paleti "hangi ton", şablon ise "hangi his" (köşeler,
// yoğunluk, üst menü şekli, font, ikon stili) sorusuna cevap verir.
// main.dart, uygulama açılırken (runApp'tan ÖNCE) kayıtlı tercihi okuyup
// sablonAdi değerini ayarlar; Ayarlar ekranından değiştirilebilir.
//
// ÖNEMLİ TASARIM KARARI: "Klasik" şablonun tüm değerleri, mevcut kodda
// zaten sabit yazılı olan değerlerle (örn. BorderRadius.circular(12),
// standart AppBar, standart yoğunluk, standart font) BİREBİR AYNI ya da
// null (Flutter'ın kendi varsayılanı). Yani bu sistem hiç eklenmemiş gibi
// davranır ta ki kullanıcı Ayarlar'dan bilinçli olarak başka bir şablon
// seçene kadar — mevcut düzen hiçbir şekilde bozulmaz.
class AppSablon {
  static String sablonAdi = 'klasik'; // klasik | modern_yuvarlak | enerjik

  static bool get modernMi => sablonAdi == 'modern_yuvarlak';
  static bool get enerjikMi => sablonAdi == 'enerjik';

  // Kart / kutu / buton köşe yarıçapı. Enerjik'te en yuvarlak (30).
  static double get kartYaricapi {
    if (enerjikMi) return 30.0;
    if (modernMi) return 22.0;
    return 12.0;
  }

  // ÜST MENÜ ŞEKLİ: 26 ekranın hiçbiri kendi AppBar şeklini tanımlamıyor,
  // bu yüzden burada tek bir yerde belirlenen şekil TÜM ekranlara otomatik
  // yansıyor. Klasik'te null (Flutter'ın standart, düz köşeli AppBar'ı,
  // mevcut görünümle birebir aynı). Modern'de alt kenarları yuvarlatılmış
  // bir "kart gibi" üst menü. Enerjik'te daha da belirgin yuvarlatma.
  static ShapeBorder? get appBarSekli {
    if (enerjikMi) {
      return const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(bottomLeft: Radius.circular(36), bottomRight: Radius.circular(36)),
      );
    }
    if (modernMi) {
      return const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(bottomLeft: Radius.circular(26), bottomRight: Radius.circular(26)),
      );
    }
    return null;
  }

  // GENEL YOĞUNLUK: Klasik dışındaki şablonlarda Material bileşenlerinin
  // (liste satırları, butonlar, form alanları) varsayılan iç boşluğu
  // biraz artırılıyor — "daha ferah" his. Klasik'te standart (mevcutla
  // birebir aynı).
  static VisualDensity get yogunluk => modernMi || enerjikMi ? VisualDensity.comfortable : VisualDensity.standard;

  // KART GÖLGESİ: Modern'de kartlar gölgesiz/düz (elevation 0) — "flat"
  // modern bir görünüm. Enerjik'te ise TAM TERSİNE belirgin, "kabartılmış"
  // bir gölge (elevation 4) — canlı/dinamik bir his. Klasik'te Flutter'ın
  // standart gölgesi (mevcutla birebir aynı, null = tema override etmiyor).
  static double? get kartGolgesi {
    if (enerjikMi) return 4.0;
    if (modernMi) return 0.0;
    return null;
  }

  // FONT AİLESİ: Enerjik'te uygulamanın içinde zaten gömülü olan
  // DejaVuSans fontuna geçiliyor (pubspec.yaml'da tanımlı, PDF
  // oluşturmak için zaten kullanılıyordu — yeni bir font indirmeye/internet
  // bağlantısına gerek yok, sıfır risk). Klasik/Modern'de null (Flutter'ın
  // varsayılan sistem fontu, mevcutla birebir aynı).
  static String? get fontAilesi => enerjikMi ? 'DejaVuSans' : null;

  static String get adi {
    if (enerjikMi) return 'Enerjik';
    if (modernMi) return 'Modern Yuvarlak';
    return 'Klasik';
  }

  static String get aciklama {
    if (enerjikMi) {
      return 'Farklı yazı fontu, en yuvarlak köşeler, belirgin gölgeli kartlar, dolgun (rounded) ikonlar, canlı rozet renkleri';
    }
    if (modernMi) {
      return 'Yuvarlak köşeler, düz üst menü, ferah/gölgesiz kartlar, büyük ikonlar, ince çizgili (outline) ikon stili';
    }
    return 'Mevcut, bilinen görünüm';
  }

  // Ana Sayfa hızlı erişim ikonlarının boyutu. Klasik'te mevcut sabit
  // değer (20) ile birebir aynı. Modern/Enerjik'te belirgin şekilde büyük
  // + arkasında dairesel rozet (bkz. ana_sayfa.dart).
  static double get ikonBoyutu => modernMi || enerjikMi ? 30.0 : 20.0;

  // Ana Sayfa ikon rozetinin arka plan rengi/saydamlığı. Modern'de soluk,
  // yarı saydam beyaz (ince/minimal his). Enerjik'te DAHA CANLI, daha az
  // saydam — "kabarık/dolgun rozet" hissi.
  static Color get ikonRozetiRengi => enerjikMi ? Colors.white.withOpacity(0.35) : Colors.white.withOpacity(0.22);
}
