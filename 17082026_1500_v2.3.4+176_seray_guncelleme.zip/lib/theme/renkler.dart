import 'package:flutter/material.dart';

// Uygulamanın renk paletleri. Ayarlar'dan birkaç renk teması seçilebilir.
// "aktif" getter'ı, Ayarlar'da seçilen temaya göre otomatik olarak doğru
// paleti döndürür. main.dart, uygulama açılırken (runApp'tan ÖNCE) kayıtlı
// tercihi okuyup temaAdi değerini ayarlar.
class AppRenkleri {
  // Geriye dönük uyumluluk için tutuluyor (eski kod/pref bunu okuyabilir);
  // asıl seçim artık temaAdi ile yapılıyor.
  static bool cocukTemasiAktif = false;
  static String temaAdi = 'turkuaz'; // turkuaz | cocuk | mavi | yesil | turuncu | kirmizi | sari | lacivert | bordo

  static const MaterialColor turkuaz = MaterialColor(0xFF00BFB2, <int, Color>{
    50: Color(0xFFE0F7F5),
    100: Color(0xFFB3ECE8),
    200: Color(0xFF80E0D9),
    300: Color(0xFF4DD4CA),
    400: Color(0xFF26CAC0),
    500: Color(0xFF00BFB2),
    600: Color(0xFF00ACA0),
    700: Color(0xFF00968A),
    800: Color(0xFF007D73),
    900: Color(0xFF005A52),
  });

  // Önceden "Çocuk Dostu" olarak adlandırılıyordu — kullanıcı isteğiyle
  // "Mor" olarak yeniden adlandırıldı (renk paleti aynı kaldı).
  static const MaterialColor cocukRenkli = MaterialColor(0xFFAB47BC, <int, Color>{
    50: Color(0xFFF3E5F5),
    100: Color(0xFFE1BEE7),
    200: Color(0xFFCE93D8),
    300: Color(0xFFBA68C8),
    400: Color(0xFFAB47BC),
    500: Color(0xFF9C27B0),
    600: Color(0xFF8E24AA),
    700: Color(0xFF7B1FA2),
    800: Color(0xFF6A1B9A),
    900: Color(0xFF4A148C),
  });

  static const MaterialColor mavi = MaterialColor(0xFF1E88E5, <int, Color>{
    50: Color(0xFFE3F2FD),
    100: Color(0xFFBBDEFB),
    200: Color(0xFF90CAF9),
    300: Color(0xFF64B5F6),
    400: Color(0xFF42A5F5),
    500: Color(0xFF1E88E5),
    600: Color(0xFF1976D2),
    700: Color(0xFF1565C0),
    800: Color(0xFF0D47A1),
    900: Color(0xFF0A3880),
  });

  static const MaterialColor yesil = MaterialColor(0xFF43A047, <int, Color>{
    50: Color(0xFFE8F5E9),
    100: Color(0xFFC8E6C9),
    200: Color(0xFFA5D6A7),
    300: Color(0xFF81C784),
    400: Color(0xFF66BB6A),
    500: Color(0xFF43A047),
    600: Color(0xFF388E3C),
    700: Color(0xFF2E7D32),
    800: Color(0xFF1B5E20),
    900: Color(0xFF14481A),
  });

  static const MaterialColor turuncu = MaterialColor(0xFFFB8C00, <int, Color>{
    50: Color(0xFFFFF3E0),
    100: Color(0xFFFFE0B2),
    200: Color(0xFFFFCC80),
    300: Color(0xFFFFB74D),
    400: Color(0xFFFFA726),
    500: Color(0xFFFB8C00),
    600: Color(0xFFF57C00),
    700: Color(0xFFEF6C00),
    800: Color(0xFFE65100),
    900: Color(0xFFBF4700),
  });

  static const MaterialColor kirmizi = MaterialColor(0xFFE53935, <int, Color>{
    50: Color(0xFFFFEBEE),
    100: Color(0xFFFFCDD2),
    200: Color(0xFFEF9A9A),
    300: Color(0xFFE57373),
    400: Color(0xFFEF5350),
    500: Color(0xFFE53935),
    600: Color(0xFFD32F2F),
    700: Color(0xFFC62828),
    800: Color(0xFFB71C1C),
    900: Color(0xFF8E1414),
  });

  static const MaterialColor sari = MaterialColor(0xFFFBC02D, <int, Color>{
    50: Color(0xFFFFFDE7),
    100: Color(0xFFFFF9C4),
    200: Color(0xFFFFF59D),
    300: Color(0xFFFFF176),
    400: Color(0xFFFFEE58),
    500: Color(0xFFFBC02D),
    600: Color(0xFFF9A825),
    700: Color(0xFFF57F17),
    800: Color(0xFFE65100),
    900: Color(0xFFBF5F00),
  });

  static const MaterialColor lacivert = MaterialColor(0xFF283593, <int, Color>{
    50: Color(0xFFE8EAF6),
    100: Color(0xFFC5CAE9),
    200: Color(0xFF9FA8DA),
    300: Color(0xFF7986CB),
    400: Color(0xFF5C6BC0),
    500: Color(0xFF283593),
    600: Color(0xFF283593),
    700: Color(0xFF1A237E),
    800: Color(0xFF141B66),
    900: Color(0xFF0D1240),
  });

  static const MaterialColor bordo = MaterialColor(0xFF6D4C41, <int, Color>{
    50: Color(0xFFEFEBE9),
    100: Color(0xFFD7CCC8),
    200: Color(0xFFBCAAA4),
    300: Color(0xFF8D6E63),
    400: Color(0xFF795548),
    500: Color(0xFF6D4C41),
    600: Color(0xFF5D4037),
    700: Color(0xFF4E342E),
    800: Color(0xFF3E2723),
    900: Color(0xFF2A1A16),
  });

  static MaterialColor get aktif {
    switch (temaAdi) {
      case 'cocuk':
        return cocukRenkli;
      case 'mavi':
        return mavi;
      case 'yesil':
        return yesil;
      case 'turuncu':
        return turuncu;
      case 'kirmizi':
        return kirmizi;
      case 'sari':
        return sari;
      case 'lacivert':
        return lacivert;
      case 'bordo':
        return bordo;
      case 'turkuaz':
      default:
        return turkuaz;
    }
  }
}
