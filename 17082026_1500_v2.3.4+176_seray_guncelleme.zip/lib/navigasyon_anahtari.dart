import 'package:flutter/material.dart';

// main.dart ve bildirim_servisi.dart bu anahtarı paylaşır. Bildirim servisi,
// bir widget'a bağlı olmadan (statik/arka plan kod içinden) tam ekran alarm
// sayfasını açabilmek için bunu kullanır.
final GlobalKey<NavigatorState> navigasyonAnahtari = GlobalKey<NavigatorState>();
