import 'dart:async';
import 'dart:convert';
import 'package:pedometer/pedometer.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'saglik_baglantisi_servisi.dart';

// Telefonun kendi adım sayar sensörünü (pedometer) kullanarak günlük adım
// takibi yapar. Uygulama açıkken güncellenir; geçmiş, cihazda (SharedPreferences)
// son 30 gün için saklanır.
class AdimServisi {
  static StreamSubscription<StepCount>? _abonelik;
  static int sonBilinenAdim = 0;

  // Teşhis amaçlı: adım sayar neden çalışmıyor sorusuna cevap vermek için.
  static String? sonHata;
  static bool izinVerildiMi = false;
  static bool akisBasladiMi = false;

  static String _bugunTarihMetni() {
    final t = DateTime.now();
    return '${t.year}-${t.month.toString().padLeft(2, '0')}-${t.day.toString().padLeft(2, '0')}';
  }

  static Future<void> baslat() async {
    sonHata = null;
    try {
      final izin = await Permission.activityRecognition.request();
      izinVerildiMi = izin.isGranted;
      if (!izin.isGranted) {
        sonHata = 'İzin verilmedi (durum: $izin). Ayarlar\'dan Seray\'a "Fiziksel Aktivite" iznini elle verin.';
        return;
      }
      // Zaten dinliyorsak (baslat() daha önce başarıyla çalıştıysa) tekrar
      // abone olmaya gerek yok.
      if (_abonelik != null) {
        akisBasladiMi = true;
        return;
      }
      _abonelik = Pedometer.stepCountStream.listen(
        _adimGeldi,
        onError: (e) {
          sonHata = 'Adım sensörü hata verdi: $e (bu telefonda donanım adım sayar sensörü olmayabilir)';
          akisBasladiMi = false;
        },
      );
      akisBasladiMi = true;
    } catch (e) {
      sonHata = 'Adım sayar başlatılamadı: $e';
      akisBasladiMi = false;
    }
  }  // --- baslat() sonu ---

  static Future<void> _adimGeldi(StepCount olay) async {
    final prefs = await SharedPreferences.getInstance();
    final bugun = _bugunTarihMetni();
    final kayitliTarih = prefs.getString('adim_baseline_tarih');
    int taban = prefs.getInt('adim_baseline_sayim') ?? olay.steps;

    if (kayitliTarih != bugun) {
      // Yeni gün başladı: şu ana kadarki (dünün) nihai adım sayısını ÖMÜR
      // BOYU TOPLAMA ekle — rozet/mesafe hesaplaması bunu kullanır. 30
      // günlük geçmiş (adim_gecmis) dolup taştıkça eski günler silindiği
      // için, ömür boyu toplamı ayrı ve sürekli büyüyen bir sayaçta tutmak
      // gerekiyor.
      if (kayitliTarih != null) {
        final gecmisMetinOnceki = prefs.getString('adim_gecmis') ?? '{}';
        final Map<String, dynamic> gecmisOnceki = jsonDecode(gecmisMetinOnceki);
        final dunkuAdim = (gecmisOnceki[kayitliTarih] as num?)?.toInt() ?? 0;
        final mevcutOmurToplam = prefs.getInt('adim_omur_toplam') ?? 0;
        await prefs.setInt('adim_omur_toplam', mevcutOmurToplam + dunkuAdim);
      }
      // Yeni gün başladı: bugünün adım sayacını sıfırlamak için şu anki
      // kümülatif sayıyı "taban" (başlangıç noktası) olarak kaydet.
      taban = olay.steps;
      await prefs.setString('adim_baseline_tarih', bugun);
      await prefs.setInt('adim_baseline_sayim', taban);
    }

    final bugunkuAdim = (olay.steps - taban).clamp(0, 999999);
    sonBilinenAdim = bugunkuAdim;

    final gecmisMetin = prefs.getString('adim_gecmis') ?? '{}';
    final Map<String, dynamic> gecmis = jsonDecode(gecmisMetin);
    gecmis[bugun] = bugunkuAdim;
    if (gecmis.length > 30) {
      final anahtarlar = gecmis.keys.toList()..sort();
      while (gecmis.length > 30) {
        gecmis.remove(anahtarlar.removeAt(0));
      }
    }
    await prefs.setString('adim_gecmis', jsonEncode(gecmis));
  }

  static Future<int> bugunkuAdimGetir() async {
    final prefs = await SharedPreferences.getInstance();
    final bugun = _bugunTarihMetni();
    final gecmisMetin = prefs.getString('adim_gecmis') ?? '{}';
    final Map<String, dynamic> gecmis = jsonDecode(gecmisMetin);
    final yerelAdim = (gecmis[bugun] as num?)?.toInt() ?? sonBilinenAdim;

    // Health Connect'te bugüne ait daha büyük bir sayı varsa onu kullan —
    // uygulama arka planda/kapalıyken de OS seviyesinde sayılmış demektir.
    // Health Connect'e ulaşılamazsa (izin yok, kurulu değil, hata) yerel
    // sayıma sessizce geri dönülür, kullanıcı bir şey fark etmez.
    try {
      final hcAdim = await SaglikBaglantisiServisi.gununAdimSayisi(DateTime.now());
      if (hcAdim != null && hcAdim > yerelAdim) {
        gecmis[bugun] = hcAdim;
        await prefs.setString('adim_gecmis', jsonEncode(gecmis));
        sonBilinenAdim = hcAdim;
        return hcAdim;
      }
    } catch (_) {}

    return yerelAdim;
  }  // --- bugunkuAdimGetir() sonu ---

  static Future<List<MapEntry<String, int>>> sonYediGunGetir() async {
    final prefs = await SharedPreferences.getInstance();
    final gecmisMetin = prefs.getString('adim_gecmis') ?? '{}';
    final Map<String, dynamic> gecmis = jsonDecode(gecmisMetin);

    // Son 7 gün için Health Connect'te yerelden büyük bir değer varsa,
    // geçmişi onunla güncelle — uygulama o gün hiç açılmamış olsa bile
    // gerçek adım sayısı grafik/özet ekranlarında görünsün.
    try {
      final bugun = DateTime.now();
      for (int i = 0; i < 7; i++) {
        final gun = bugun.subtract(Duration(days: i));
        final anahtar = '${gun.year}-${gun.month.toString().padLeft(2, '0')}-${gun.day.toString().padLeft(2, '0')}';
        final hcAdim = await SaglikBaglantisiServisi.gununAdimSayisi(gun);
        final yerelAdim = (gecmis[anahtar] as num?)?.toInt() ?? 0;
        if (hcAdim != null && hcAdim > yerelAdim) {
          gecmis[anahtar] = hcAdim;
        }
      }
      await prefs.setString('adim_gecmis', jsonEncode(gecmis));
    } catch (_) {}

    final anahtarlar = gecmis.keys.toList()..sort();
    final sonYedi = anahtarlar.length > 7 ? anahtarlar.sublist(anahtarlar.length - 7) : anahtarlar;
    return sonYedi.map((k) => MapEntry(k, (gecmis[k] as num).toInt())).toList();
  }  // --- sonYediGunGetir() sonu ---

  // Ortalama bir yürüyüşte adım başına ~0.04 kcal harcanır (kabaca tahmin).
  static double kaloriTahminEt(int adim) => adim * 0.04;

  // Ortalama adım uzunluğu ~0.7m kabul edilerek kilometre tahmini.
  static double mesafeTahminEt(int adim) => adim * 0.0007;

  // Rozet/motivasyon amaçlı: bugüne kadarki TÜM adımların toplamı (geçmiş
  // günler + bugünün o anki sayısı). "adim_gecmis" sadece son 30 günü
  // tuttuğu için, bu ayrı ve hiç silinmeyen bir sayaçtan geliyor.
  static Future<int> omurBoyuToplamAdimGetir() async {
    final prefs = await SharedPreferences.getInstance();
    final omurToplam = prefs.getInt('adim_omur_toplam') ?? 0;
    final bugunku = await bugunkuAdimGetir();
    return omurToplam + bugunku;
  }  // --- omurBoyuToplamAdimGetir() sonu ---
}
