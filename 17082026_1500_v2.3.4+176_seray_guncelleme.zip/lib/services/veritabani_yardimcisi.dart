import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'package:archive/archive.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'profil_sabitleri.dart';

class VeritabaniYardimcisi {
  static final VeritabaniYardimcisi _instance = VeritabaniYardimcisi._internal();
  static Database? _database;

  factory VeritabaniYardimcisi() => _instance;
  VeritabaniYardimcisi._internal();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  // AİLE TAKİBİ: Her profilin AYRI bir .db dosyası vardır. Hangi dosyanın
  // açılacağını, o an aktif olan profil belirler (SharedPreferences'tan
  // doğrudan okunuyor — ProfilYoneticisi'ni import ETMİYORUZ, çünkü o da
  // bu dosyayı kullanıyor, döngüsel import olurdu; sadece ortak, minik
  // ProfilSabitleri dosyasına bağımlıyız).
  Future<String> _aktifDbDosyaAdi() async {
    final prefs = await SharedPreferences.getInstance();
    final profilId = prefs.getString(ProfilSabitleri.aktifProfilAnahtari) ?? ProfilSabitleri.varsayilanProfilId;
    return ProfilSabitleri.dbDosyaAdi(profilId);
  }  // --- _aktifDbDosyaAdi() sonu ---

  Future<Database> _initDatabase() async {
    String path = join(await getDatabasesPath(), await _aktifDbDosyaAdi());
    return await openDatabase(
      path,
      version: 11,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
  }  // --- _initDatabase() sonu ---

  // ProfilYoneticisi profil değiştirdiğinde çağırır — açık veritabanı
  // bağlantısını kapatıp sıfırlar, bir sonraki erişimde YENİ profilin
  // dosyası açılır.
  Future<void> baglantiyiKapatVeSifirla() async {
    if (_database != null) {
      await _database!.close();
      _database = null;
    }
  }  // --- baglantiyiKapatVeSifirla() sonu ---

  Future _onCreate(Database db, int version) async {
    await db.execute(
        'CREATE TABLE seker_olcumleri (id INTEGER PRIMARY KEY AUTOINCREMENT, deger INTEGER, durum TEXT, tarih TEXT, sms_gonderildi INTEGER DEFAULT 0)');
    await db.execute(
        'CREATE TABLE tansiyon_olcumleri (id INTEGER PRIMARY KEY AUTOINCREMENT, buyuk INTEGER, kucuk INTEGER, nabiz INTEGER, tarih TEXT, sms_gonderildi INTEGER DEFAULT 0)');
    await db.execute(
        "CREATE TABLE ilaclar (id INTEGER PRIMARY KEY AUTOINCREMENT, ad TEXT, dozaj TEXT, saat TEXT, tip TEXT DEFAULT 'Hap', birim TEXT DEFAULT 'adet', fotograf_yolu TEXT, kategori TEXT, yazildigi_tarih TEXT, sonlandirildi_mi INTEGER DEFAULT 0, sonlandirma_tarihi TEXT, sonlandirma_notu TEXT)");
    await db.execute(
        'CREATE TABLE enabiz_tahlilleri (id INTEGER PRIMARY KEY AUTOINCREMENT, tarih TEXT, tahlil_adi TEXT, sonuc TEXT, referans_degeri TEXT, kategori TEXT)');
    await db.execute(
        'CREATE TABLE enabiz_yorumlari (id INTEGER PRIMARY KEY AUTOINCREMENT, tarih TEXT, yorum TEXT)');
    await db.execute(
        'CREATE TABLE beslenme_kayitlari (id INTEGER PRIMARY KEY AUTOINCREMENT, yemek_adi TEXT, kalori TEXT, resim_yolu TEXT, tarih TEXT, ai_analiz TEXT, protein TEXT, karbonhidrat TEXT, yag TEXT)');
    // v3: Yeni tablolar
    await db.execute(
        'CREATE TABLE su_takibi (id INTEGER PRIMARY KEY AUTOINCREMENT, miktar_ml INTEGER, tarih TEXT)');
    await db.execute(
        'CREATE TABLE kilo_takibi (id INTEGER PRIMARY KEY AUTOINCREMENT, kilo REAL, tarih TEXT)');
    // v4: Seray AI geçmiş sohbetleri
    await db.execute(
        'CREATE TABLE sohbet_oturumlari (id INTEGER PRIMARY KEY AUTOINCREMENT, baslik TEXT, mesajlar_json TEXT, tarih TEXT)');
    // Radyoloji/patoloji/konsültasyon gibi YAZILI (anlatı tarzı) tıbbi
    // raporların fotoğrafı + AI yorumu — tahlil (sayısal) sonuçlarından
    // AYRI bir tablo, çünkü yapısı tamamen farklı (tek bir konu/başlık +
    // uzun serbest metin, satır-satır tahlil değil).
    await db.execute(
        'CREATE TABLE raporlar (id INTEGER PRIMARY KEY AUTOINCREMENT, baslik TEXT, tarih TEXT, ai_yorumu TEXT, gorsel_yolu TEXT, belge_turu TEXT DEFAULT \'resim\')');
    // İlaç İçildi/Atlandı takibi: her doz zamanı için ayrı bir kayıt —
    // ilac_id silinmiş bir ilaca ait olsa bile (o ilaç sonradan silinirse)
    // ilac_adi'nı BAĞIMSIZ olarak sakladık ki geçmiş kaybolmasın.
    await db.execute(
        'CREATE TABLE ilac_gecmisi (id INTEGER PRIMARY KEY AUTOINCREMENT, ilac_id INTEGER, ilac_adi TEXT, tarih_saat TEXT, durum TEXT)');
  }

  Future _onUpgrade(Database db, int eskiSurum, int yeniSurum) async {
    if (eskiSurum < 2) {
      await db.execute(
          "ALTER TABLE ilaclar ADD COLUMN tip TEXT DEFAULT 'Hap'");
      await db.execute(
          "ALTER TABLE ilaclar ADD COLUMN birim TEXT DEFAULT 'adet'");
      await db.execute(
          'CREATE TABLE IF NOT EXISTS beslenme_kayitlari (id INTEGER PRIMARY KEY AUTOINCREMENT, yemek_adi TEXT, kalori TEXT, resim_yolu TEXT, tarih TEXT)');
    }
    if (eskiSurum < 3) {
      await db.execute(
          'CREATE TABLE IF NOT EXISTS su_takibi (id INTEGER PRIMARY KEY AUTOINCREMENT, miktar_ml INTEGER, tarih TEXT)');
      await db.execute(
          'CREATE TABLE IF NOT EXISTS kilo_takibi (id INTEGER PRIMARY KEY AUTOINCREMENT, kilo REAL, tarih TEXT)');
    }
    if (eskiSurum < 4) {
      try {
        await db.execute('ALTER TABLE beslenme_kayitlari ADD COLUMN ai_analiz TEXT');
      } catch (_) {
        // Sütun zaten varsa (tekrar çalışırsa) sessizce geç.
      }
      await db.execute(
          'CREATE TABLE IF NOT EXISTS sohbet_oturumlari (id INTEGER PRIMARY KEY AUTOINCREMENT, baslik TEXT, mesajlar_json TEXT, tarih TEXT)');
    }
    if (eskiSurum < 5) {
      try {
        await db.execute('ALTER TABLE enabiz_tahlilleri ADD COLUMN kategori TEXT');
      } catch (_) {
        // Sütun zaten varsa sessizce geç.
      }
    }
    if (eskiSurum < 6) {
      try {
        await db.execute('ALTER TABLE ilaclar ADD COLUMN fotograf_yolu TEXT');
      } catch (_) {
        // Sütun zaten varsa sessizce geç.
      }
    }
    if (eskiSurum < 7) {
      try {
        await db.execute('ALTER TABLE ilaclar ADD COLUMN kategori TEXT');
      } catch (_) {
        // Sütun zaten varsa sessizce geç.
      }
    }
    if (eskiSurum < 8) {
      // Acil durum kişisine bu ölçüm için SMS gönderilip gönderilmediğini
      // (0/1) tutar — kullanıcı geçmiş listede hangi kritik ölçüm için
      // haber verdiğini görebilsin diye.
      try {
        await db.execute('ALTER TABLE seker_olcumleri ADD COLUMN sms_gonderildi INTEGER DEFAULT 0');
      } catch (_) {}
      try {
        await db.execute('ALTER TABLE tansiyon_olcumleri ADD COLUMN sms_gonderildi INTEGER DEFAULT 0');
      } catch (_) {}
    }
    if (eskiSurum < 9) {
      try {
        await db.execute(
            'CREATE TABLE IF NOT EXISTS raporlar (id INTEGER PRIMARY KEY AUTOINCREMENT, baslik TEXT, tarih TEXT, ai_yorumu TEXT, gorsel_yolu TEXT)');
      } catch (_) {}
    }
    if (eskiSurum < 10) {
      // Kullanıcı fark etti: Rapor Analizi sadece fotoğraf kabul ediyordu,
      // PDF yükleme yoktu. PDF desteği eklenince, bir raporun fotoğraf mı
      // yoksa PDF mi olduğunu ayırt etmek için bu sütun gerekti.
      try {
        await db.execute("ALTER TABLE raporlar ADD COLUMN belge_turu TEXT DEFAULT 'resim'");
      } catch (_) {}
    }
    if (eskiSurum < 11) {
      // Beslenme: tam makro takibi (kullanıcı "Detaylı daha iyi olur" dedi).
      try {
        await db.execute('ALTER TABLE beslenme_kayitlari ADD COLUMN protein TEXT');
      } catch (_) {}
      try {
        await db.execute('ALTER TABLE beslenme_kayitlari ADD COLUMN karbonhidrat TEXT');
      } catch (_) {}
      try {
        await db.execute('ALTER TABLE beslenme_kayitlari ADD COLUMN yag TEXT');
      } catch (_) {}
      // İlaç: reçete tarihi + doktor değişikliği geçmişi.
      try {
        await db.execute('ALTER TABLE ilaclar ADD COLUMN yazildigi_tarih TEXT');
      } catch (_) {}
      try {
        await db.execute('ALTER TABLE ilaclar ADD COLUMN sonlandirildi_mi INTEGER DEFAULT 0');
      } catch (_) {}
      try {
        await db.execute('ALTER TABLE ilaclar ADD COLUMN sonlandirma_tarihi TEXT');
      } catch (_) {}
      try {
        await db.execute('ALTER TABLE ilaclar ADD COLUMN sonlandirma_notu TEXT');
      } catch (_) {}
      // İlaç İçildi/Atlandı takibi.
      try {
        await db.execute(
            'CREATE TABLE IF NOT EXISTS ilac_gecmisi (id INTEGER PRIMARY KEY AUTOINCREMENT, ilac_id INTEGER, ilac_adi TEXT, tarih_saat TEXT, durum TEXT)');
      } catch (_) {}
    }
  }

  // --- BULUT / WHATSAPP YEDEKLEME ---
  // sadeceProfilIdleri: null ise TÜM profiller yedeklenir (varsayılan/admin
  // davranış). Belirli bir liste verilirse (örn. bir Ek Profil sadece
  // kendini yedeklerken, ya da Ana Profil'de kullanıcı seçmeli kutucuklarla
  // sadece bazılarını seçtiğinde), SADECE o profiller yedeklenir.
  Future<void> veritabaniYedekleHafizaya({List<String>? sadeceProfilIdleri}) async {
    // AİLE TAKİBİ: Artık tek bir sabit dosya değil, AKTİF profilin dosyası
    // var olmalı (yoksa henüz hiç veri girilmemiştir, yedek boş olur).
    final aktifDbDosyaAdi = await _aktifDbDosyaAdi();
    String dbYolu = join(await getDatabasesPath(), aktifDbDosyaAdi);
    File dbDosyasi = File(dbYolu);
    if (!await dbDosyasi.exists()) return;

    // ÖNEMLİ DÜZELTME: SQLite (Android'de varsayılan olarak) "WAL" modunda
    // çalışabilir — bu durumda EN SON eklenen kayıtlar bir süre asıl .db
    // dosyasına değil, ayrı bir geçici "-wal" dosyasına yazılır ve arka
    // planda kendiliğinden "checkpoint" olana kadar orada kalır. Yedek
    // alırken doğrudan .db dosyasını kopyaladığımız için, henüz checkpoint
    // olmamış en taze kayıtlar (örn. az önce eklenen bir ölçüm) yedeğe HİÇ
    // girmiyordu — kullanıcının "son değişiklikler gelmedi" şikayetinin
    // sebebi büyük olasılıkla bu. Şimdi yedekten hemen önce AKTİF profilin
    // veritabanına "bekleyen her şeyi asıl dosyaya yaz" komutu (checkpoint)
    // veriyoruz. (Diğer profillerin dosyaları zaten o an açık olmadığı
    // için WAL'da bekleyen veri biriktirmiyor, checkpoint'e gerek yok.)
    try {
      final db = await database;
      await db.rawQuery('PRAGMA wal_checkpoint(TRUNCATE)');
    } catch (_) {
      // Checkpoint desteklenmiyorsa (WAL modu kapalıysa) sorun değil, .db
      // dosyası zaten güncel olur — sessizce geç.
    }

    final simdi = DateTime.now();
    String iki(int n) => n.toString().padLeft(2, '0');
    final tarihEtiketi = '${iki(simdi.day)}-${iki(simdi.month)}-${simdi.year}_${iki(simdi.hour)}${iki(simdi.minute)}';

    // ÖNEMLİ: Yedek artık sadece veritabanını değil, yemek fotoğraflarını da
    // tek bir .zip dosyasının içinde topluyor. Önceden sadece .db paylaşılıyordu;
    // fotoğrafların gerçek dosyaları hiç yedeğe girmiyordu, uygulama silinip
    // yeniden kurulunca kayboluyordu. Artık "sil → yeniden kur → yedekten
    // yükle" akışında fotoğraflar da geri geliyor.
    final arsiv = Archive();

    // 1) Veritabanları — sadeceProfilIdleri verilmemişse TÜM profiller
    // (Ana Profil'in "hepsini yedekle" davranışı), verilmişse SADECE o
    // profiller (Ek Profil'in kendini yedeklemesi, ya da Ana Profil'in
    // seçmeli kutucuklarla belirlediği alt küme) dahil edilir.
    final prefs = await SharedPreferences.getInstance();
    final tumProfilAdlari = <String, String>{ProfilSabitleri.varsayilanProfilId: 'Ana Profil'};
    final profilListesiHam = prefs.getString(ProfilSabitleri.profilListesiAnahtari);
    if (profilListesiHam != null) {
      try {
        final liste = jsonDecode(profilListesiHam) as List;
        for (final p in liste) {
          final id = (p as Map)['id'];
          final ad = p['ad'];
          if (id is String) tumProfilAdlari[id] = (ad is String && ad.isNotEmpty) ? ad : id;
        }
      } catch (_) {
        // Profil listesi bozuksa sadece varsayılan profille devam et.
      }
    }
    final dahilEdilecekIdler = sadeceProfilIdleri ?? tumProfilAdlari.keys.toList();

    // Geri yüklerken hangi .db dosyasının hangi profile ait olduğunu
    // (ve GERÇEK adını) bilebilmemiz için, dahil edilen profillerin
    // id+ad eşleşmesini küçük bir JSON olarak zip'e ekliyoruz.
    final metaListesi = [
      for (final id in dahilEdilecekIdler)
        {'id': id, 'ad': tumProfilAdlari[id] ?? id}
    ];
    final metaBaytlar = utf8.encode(jsonEncode(metaListesi));
    arsiv.addFile(ArchiveFile('profiller_meta.json', metaBaytlar.length, metaBaytlar));

    for (final pid in dahilEdilecekIdler) {
      final dosyaAdi = ProfilSabitleri.dbDosyaAdi(pid);
      final f = File(join(await getDatabasesPath(), dosyaAdi));
      if (await f.exists()) {
        final baytlar = await f.readAsBytes();
        arsiv.addFile(ArchiveFile(dosyaAdi, baytlar.length, baytlar));
      }
    }

    // 2) Yemek fotoğrafları klasörü (varsa)
    final belgeler = await getApplicationDocumentsDirectory();
    final fotoKlasoru = Directory('${belgeler.path}/yemek_fotograflari');
    if (await fotoKlasoru.exists()) {
      final dosyalar = fotoKlasoru.listSync().whereType<File>();
      for (final dosya in dosyalar) {
        final baytlar = await dosya.readAsBytes();
        final dosyaAdi = dosya.path.split('/').last;
        arsiv.addFile(ArchiveFile('yemek_fotograflari/$dosyaAdi', baytlar.length, baytlar));
      }
    }

    // 3) İlaç kutusu fotoğrafları klasörü (varsa)
    final ilacFotoKlasoru = Directory('${belgeler.path}/ilac_fotograflari');
    if (await ilacFotoKlasoru.exists()) {
      final dosyalar = ilacFotoKlasoru.listSync().whereType<File>();
      for (final dosya in dosyalar) {
        final baytlar = await dosya.readAsBytes();
        final dosyaAdi = dosya.path.split('/').last;
        arsiv.addFile(ArchiveFile('ilac_fotograflari/$dosyaAdi', baytlar.length, baytlar));
      }
    }

    // 3b) Rapor Analizi fotoğrafları klasörü (varsa)
    final raporFotoKlasoru = Directory('${belgeler.path}/rapor_fotograflari');
    if (await raporFotoKlasoru.exists()) {
      final dosyalar = raporFotoKlasoru.listSync().whereType<File>();
      for (final dosya in dosyalar) {
        final baytlar = await dosya.readAsBytes();
        final dosyaAdi = dosya.path.split('/').last;
        arsiv.addFile(ArchiveFile('rapor_fotograflari/$dosyaAdi', baytlar.length, baytlar));
      }
    }

    // 4) Profil fotoğrafı (varsa)
    final profilFoto = File('${belgeler.path}/profil_foto.jpg');
    if (await profilFoto.exists()) {
      final baytlar = await profilFoto.readAsBytes();
      arsiv.addFile(ArchiveFile('profil_foto.jpg', baytlar.length, baytlar));
    }

    // 5) TÜM TERCİHLER (SharedPreferences) — ÖNEMLİ DÜZELTME: Önceden yedek
    // SADECE veritabanını (ölçümler) içeriyordu; isim/yaş/fotoğraf, hedefler
    // (kilo/adım/su), tema seçimi, adım geçmişi/ömür boyu toplam, önbellek
    // gibi HER ŞEY SharedPreferences'ta tutulduğu için yedeğe hiç girmiyordu.
    // "Sil → yeniden kur → yedekten yükle" sonrası kullanıcı sanki ilk kez
    // açıyormuş gibi profil kaydından baştan geçmek zorunda kalıyordu.
    final tercihler = await SharedPreferences.getInstance();
    final tumTercihler = <String, dynamic>{};
    for (final anahtar in tercihler.getKeys()) {
      tumTercihler[anahtar] = tercihler.get(anahtar);
    }
    final tercihlerJson = utf8.encode(jsonEncode(tumTercihler));
    arsiv.addFile(ArchiveFile('tercihler.json', tercihlerJson.length, tercihlerJson));

    final zipBaytlari = ZipEncoder().encode(arsiv);
    final gecici = await getTemporaryDirectory();
    final yedekAdi = 'seray_yedek_$tarihEtiketi.zip';
    final yedekYolu = join(gecici.path, yedekAdi);
    await File(yedekYolu).writeAsBytes(zipBaytlari!);

    await Share.shareXFiles(
      [XFile(yedekYolu, name: yedekAdi)],
      text: 'Seray Sağlık Asistanım Güvenli Bulut Yedek Dosyası (veritabanı + profil + fotoğraflar) — $tarihEtiketi',
    );
  }  // --- veritabaniYedekleHafizaya() sonu ---

  // Bir yedek .zip'in İÇİNDE hangi profillerin bulunduğunu, dosyayı
  // GERÇEKTEN geri yüklemeden önce görebilmek için — Ana Profil'in "hangi
  // profilleri geri yükleyeyim?" seçmeli kutucuklarını doldurmak için
  // kullanılır. profiller_meta.json varsa GERÇEK adları okur, yoksa
  // (eski format bir yedekse) genel bir isim üretir.
  Future<List<Map<String, String>>> yedekIcerigindekiProfilleriListele(String zipYolu) async {
    final zipBaytlari = await File(zipYolu).readAsBytes();
    final arsiv = ZipDecoder().decodeBytes(zipBaytlari);
    final metaAdlar = <String, String>{};
    for (final dosya in arsiv) {
      if (dosya.isFile && dosya.name == 'profiller_meta.json') {
        try {
          final liste = jsonDecode(utf8.decode(dosya.content as List<int>)) as List;
          for (final p in liste) {
            final id = (p as Map)['id'];
            final ad = p['ad'];
            if (id is String) metaAdlar[id] = (ad is String && ad.isNotEmpty) ? ad : id;
          }
        } catch (_) {}
      }
    }
    final sonuc = <Map<String, String>>[];
    for (final dosya in arsiv) {
      if (!dosya.isFile) continue;
      if (dosya.name == 'seray_saglik_asistanim.db' ||
          (dosya.name.startsWith('seray_saglik_asistanim_') && dosya.name.endsWith('.db'))) {
        final id = dosya.name == 'seray_saglik_asistanim.db'
            ? ProfilSabitleri.varsayilanProfilId
            : dosya.name.replaceFirst('seray_saglik_asistanim_', '').replaceFirst('.db', '');
        final ad = metaAdlar[id] ?? (id == ProfilSabitleri.varsayilanProfilId ? 'Ana Profil' : 'Profil ($id)');
        sonuc.add({'id': id, 'ad': ad, 'dosyaAdi': dosya.name});
      }
    }
    return sonuc;
  }  // --- yedekIcerigindekiProfilleriListele() sonu ---

  // sadeceProfilIdleri: null ise zip içindeki TÜM profiller geri yüklenir.
  // Belirli bir liste verilirse, SADECE o profillerin veritabanı dosyaları
  // yazılır — kullanıcının seçmeli kutucuklarla belirlediği alt küme.
  Future<bool> yedegiGeriYukle(String secilenYedekYolu, {List<String>? sadeceProfilIdleri}) async {
    try {
      if (_database != null) {
        await _database!.close();
        _database = null;
      }
      String asilDbYolu =
          join(await getDatabasesPath(), 'seray_saglik_asistanim.db');

      if (secilenYedekYolu.toLowerCase().endsWith('.zip')) {
        // Yeni format: veritabanı + yemek fotoğrafları bir arada.
        final zipBaytlari = await File(secilenYedekYolu).readAsBytes();
        final arsiv = ZipDecoder().decodeBytes(zipBaytlari);

        final belgeler = await getApplicationDocumentsDirectory();
        final fotoKlasoru = Directory('${belgeler.path}/yemek_fotograflari');
        if (!await fotoKlasoru.exists()) {
          await fotoKlasoru.create(recursive: true);
        }
        final ilacFotoKlasoru = Directory('${belgeler.path}/ilac_fotograflari');
        if (!await ilacFotoKlasoru.exists()) {
          await ilacFotoKlasoru.create(recursive: true);
        }
        final raporFotoKlasoru = Directory('${belgeler.path}/rapor_fotograflari');
        if (!await raporFotoKlasoru.exists()) {
          await raporFotoKlasoru.create(recursive: true);
        }

        for (final dosya in arsiv) {
          if (!dosya.isFile) continue;
          final icerik = dosya.content as List<int>;
          if (dosya.name == 'seray_saglik_asistanim.db' ||
              (dosya.name.startsWith('seray_saglik_asistanim_') && dosya.name.endsWith('.db'))) {
            // AİLE TAKİBİ: yedekte birden fazla profilin veritabanı dosyası
            // olabilir (örn. "seray_saglik_asistanim_profil_123.db") — her
            // biri KENDİ dosya adıyla, olduğu gibi geri yazılıyor. Sadece
            // varsayılan profilin dosyası "asilDbYolu" sabit adını kullanıyor,
            // diğerleri kendi adlarıyla.
            // Kullanıcı seçmeli kutucuklarla belirli profilleri seçtiyse
            // (sadeceProfilIdleri dolu), listede OLMAYAN profillerin dosyası
            // atlanır — zip içinde olsa bile diske yazılmaz.
            if (sadeceProfilIdleri != null) {
              final buDosyaninIdsi = dosya.name == 'seray_saglik_asistanim.db'
                  ? ProfilSabitleri.varsayilanProfilId
                  : dosya.name.replaceFirst('seray_saglik_asistanim_', '').replaceFirst('.db', '');
              if (!sadeceProfilIdleri.contains(buDosyaninIdsi)) continue;
            }
            final hedefYol = dosya.name == 'seray_saglik_asistanim.db'
                ? asilDbYolu
                : join(await getDatabasesPath(), dosya.name);
            await File(hedefYol).writeAsBytes(icerik);
          } else if (dosya.name.startsWith('yemek_fotograflari/')) {
            final dosyaAdi = dosya.name.split('/').last;
            await File('${fotoKlasoru.path}/$dosyaAdi').writeAsBytes(icerik);
          } else if (dosya.name.startsWith('ilac_fotograflari/')) {
            final dosyaAdi = dosya.name.split('/').last;
            await File('${ilacFotoKlasoru.path}/$dosyaAdi').writeAsBytes(icerik);
          } else if (dosya.name.startsWith('rapor_fotograflari/')) {
            final dosyaAdi = dosya.name.split('/').last;
            await File('${raporFotoKlasoru.path}/$dosyaAdi').writeAsBytes(icerik);
          } else if (dosya.name == 'profil_foto.jpg') {
            await File('${belgeler.path}/profil_foto.jpg').writeAsBytes(icerik);
          } else if (dosya.name == 'tercihler.json') {
            // ÖNEMLİ: isim/yaş/fotoğraf, hedefler, tema, adım geçmişi gibi
            // TÜM tercihleri geri yazıyoruz — SharedPreferences'ın kendi
            // tipine göre (String/int/double/bool/List<String>) doğru
            // setter'ı seçiyoruz, yoksa runtime hatası olur.
            try {
              final tercihler = await SharedPreferences.getInstance();
              final Map<String, dynamic> kayitliTercihler = jsonDecode(utf8.decode(icerik));
              for (final girdi in kayitliTercihler.entries) {
                final deger = girdi.value;
                if (deger is String) {
                  await tercihler.setString(girdi.key, deger);
                } else if (deger is bool) {
                  await tercihler.setBool(girdi.key, deger);
                } else if (deger is int) {
                  await tercihler.setInt(girdi.key, deger);
                } else if (deger is double) {
                  await tercihler.setDouble(girdi.key, deger);
                } else if (deger is List) {
                  await tercihler.setStringList(girdi.key, deger.map((e) => e.toString()).toList());
                }
              }
              // Fotoğraf yeni kalıcı yola geri yüklendiği için, eski yedekte
              // (varsa) kayıtlı geçici/eski yol yerine doğru yolu zorluyoruz.
              final profilFotoYolu = '${belgeler.path}/profil_foto.jpg';
              if (await File(profilFotoYolu).exists()) {
                await tercihler.setString('kullanici_foto_yolu', profilFotoYolu);
                await tercihler.setString('user_foto_yolu', profilFotoYolu);
              }
            } catch (_) {
              // Tercihler bozuksa/okunamıyorsa sessizce geç — en azından
              // veritabanı ve fotoğraflar zaten geri yüklenmiş olur.
            }
          }
        }
      } else {
        // Eski format: sadece .db dosyası (geriye dönük uyumluluk).
        File yeniYedekDosyasi = File(secilenYedekYolu);
        await yeniYedekDosyasi.copy(asilDbYolu);
      }

      _database = await _initDatabase();
      return true;
    } catch (e) {
      return false;
    }
  }  // --- yedegiGeriYukle() sonu ---

  // --- ŞEKER ---
  Future<int> sekerEkle(Map<String, dynamic> veri) async {
    Database db = await database;
    return await db.insert('seker_olcumleri', veri);
  }  // --- sekerEkle() sonu ---

  Future<List<Map<String, dynamic>>> sekerleriGetir() async {
    Database db = await database;
    return await db.query('seker_olcumleri', orderBy: 'id DESC');
  }

  Future<int> sekerSil(int id) async {
    Database db = await database;
    return await db
        .delete('seker_olcumleri', where: 'id = ?', whereArgs: [id]);
  }  // --- sekerSil() sonu ---

  // Acil durum kişisine bu ölçüm için SMS gerçekten gönderildiğinde
  // (kullanıcı "Mesaj Gönder" deyip SMS uygulamasını açtığında) çağrılır.
  Future<void> sekerSmsGonderildiIsaretle(int id) async {
    Database db = await database;
    await db.update('seker_olcumleri', {'sms_gonderildi': 1}, where: 'id = ?', whereArgs: [id]);
  }  // --- sekerSmsGonderildiIsaretle() sonu ---

  // --- TANSİYON ---
  Future<int> tansiyonEkle(Map<String, dynamic> veri) async {
    Database db = await database;
    return await db.insert('tansiyon_olcumleri', veri);
  }  // --- tansiyonEkle() sonu ---

  Future<List<Map<String, dynamic>>> tansiyonlariGetir() async {
    Database db = await database;
    return await db.query('tansiyon_olcumleri', orderBy: 'id DESC');
  }

  Future<int> tansiyonSil(int id) async {
    Database db = await database;
    return await db
        .delete('tansiyon_olcumleri', where: 'id = ?', whereArgs: [id]);
  }  // --- tansiyonSil() sonu ---

  Future<void> tansiyonSmsGonderildiIsaretle(int id) async {
    Database db = await database;
    await db.update('tansiyon_olcumleri', {'sms_gonderildi': 1}, where: 'id = ?', whereArgs: [id]);
  }  // --- tansiyonSmsGonderildiIsaretle() sonu ---

  // --- İLAÇ ---
  Future<int> ilacEkle(Map<String, dynamic> veri) async {
    Database db = await database;
    return await db.insert('ilaclar', veri);
  }  // --- ilacEkle() sonu ---

  Future<int> ilacGuncelle(int id, Map<String, dynamic> veri) async {
    Database db = await database;
    return await db
        .update('ilaclar', veri, where: 'id = ?', whereArgs: [id]);
  }  // --- ilacGuncelle() sonu ---

  Future<List<Map<String, dynamic>>> ilaclariGetir() async {
    Database db = await database;
    // ÖNEMLİ: Sonlandırılan (doktor tarafından değiştirilen/kesilen)
    // ilaçlar artık aktif listede GÖRÜNMEZ — "Geçmiş İlaçlar" bölümünden
    // ayrıca görülebilir (sonlandirilmisIlaclariGetir()).
    return await db.query('ilaclar', where: 'sonlandirildi_mi IS NULL OR sonlandirildi_mi = 0', orderBy: 'id DESC');
  }

  Future<int> ilacSil(int id) async {
    Database db = await database;
    return await db.delete('ilaclar', where: 'id = ?', whereArgs: [id]);
  }  // --- ilacSil() sonu ---

  // YENİ: İçtim/Atladım sonrası bildirimi kapatırken günlük alarmı DOĞRU
  // şekilde yeniden kurabilmek için tek bir ilacın kaydını (saat/tip dahil)
  // id ile çekiyoruz.
  Future<Map<String, dynamic>?> ilacBul(int id) async {
    Database db = await database;
    final sonuc = await db.query('ilaclar', where: 'id = ?', whereArgs: [id], limit: 1);
    return sonuc.isEmpty ? null : sonuc.first;
  }  // --- ilacBul() sonu ---

  // --- BESLENME ---
  Future<int> beslenmeEkle(Map<String, dynamic> veri) async {
    final db = await database;
    return await db.insert('beslenme_kayitlari', veri);
  }  // --- beslenmeEkle() sonu ---

  Future<List<Map<String, dynamic>>> beslenmeKayitlariniGetir() async {
    final db = await database;
    return await db.query('beslenme_kayitlari', orderBy: 'tarih DESC');
  }

  Future<int> beslenmeSil(int id) async {
    final db = await database;
    return await db
        .delete('beslenme_kayitlari', where: 'id = ?', whereArgs: [id]);
  }  // --- beslenmeSil() sonu ---

  Future<int> beslenmeGuncelle(int id, Map<String, dynamic> veri) async {
    final db = await database;
    return await db.update('beslenme_kayitlari', veri, where: 'id = ?', whereArgs: [id]);
  }  // --- beslenmeGuncelle() sonu ---

  // --- RAPOR ANALİZİ (radyoloji/patoloji/konsültasyon vb. YAZILI raporlar) ---
  Future<int> raporEkle(Map<String, dynamic> veri) async {
    Database db = await database;
    return await db.insert('raporlar', veri);
  }  // --- raporEkle() sonu ---

  Future<List<Map<String, dynamic>>> raporlariGetir() async {
    Database db = await database;
    return await db.query('raporlar', orderBy: 'id DESC');
  }  // --- raporlariGetir() sonu ---

  Future<void> raporSil(int id) async {
    Database db = await database;
    await db.delete('raporlar', where: 'id = ?', whereArgs: [id]);
  }  // --- raporSil() sonu ---

  // --- İLAÇ İÇİLDİ/ATLANDI TAKİBİ ---
  Future<int> ilacGecmisineKaydet({required int? ilacId, required String ilacAdi, required String durum}) async {
    Database db = await database;
    return await db.insert('ilac_gecmisi', {
      'ilac_id': ilacId,
      'ilac_adi': ilacAdi,
      'tarih_saat': DateTime.now().toIso8601String(),
      'durum': durum, // 'icildi' | 'atlandi'
    });
  }  // --- ilacGecmisineKaydet() sonu ---

  Future<List<Map<String, dynamic>>> ilacGecmisiniGetir({int? ilacId}) async {
    Database db = await database;
    if (ilacId != null) {
      return await db.query('ilac_gecmisi', where: 'ilac_id = ?', whereArgs: [ilacId], orderBy: 'id DESC');
    }
    return await db.query('ilac_gecmisi', orderBy: 'id DESC');
  }  // --- ilacGecmisiniGetir() sonu ---

  // Bir ilacı SİLMEK yerine "sonlandırır" — doktor değişikliği/tedavi
  // bitişi gibi durumlarda geçmiş kaybolmasın diye. Sonlandırılan ilaç
  // aktif listede görünmez ama "Geçmiş İlaçlar"da kalır.
  Future<void> ilaciSonlandir({required int id, required String not}) async {
    Database db = await database;
    await db.update(
      'ilaclar',
      {
        'sonlandirildi_mi': 1,
        'sonlandirma_tarihi': DateTime.now().toIso8601String(),
        'sonlandirma_notu': not,
      },
      where: 'id = ?',
      whereArgs: [id],
    );
  }  // --- ilaciSonlandir() sonu ---

  Future<List<Map<String, dynamic>>> sonlandirilmisIlaclariGetir() async {
    Database db = await database;
    return await db.query('ilaclar', where: 'sonlandirildi_mi = 1', orderBy: 'sonlandirma_tarihi DESC');
  }  // --- sonlandirilmisIlaclariGetir() sonu ---

  // --- E-NABIZ TAHLİL ---
  Future<int> tahlilEkle(Map<String, dynamic> veri) async {
    Database db = await database;
    return await db.insert('enabiz_tahlilleri', veri);
  }  // --- tahlilEkle() sonu ---

  Future<List<Map<String, dynamic>>> tumTahlilleriGetir() async {
    Database db = await database;
    return await db.query('enabiz_tahlilleri', orderBy: 'id DESC');
  }

  // Belirli bir tarihe ait tüm tahlilleri sil (yeniden yükleme için)
  Future<void> tariheTahlilleriSil(String tarih) async {
    Database db = await database;
    await db.delete('enabiz_tahlilleri',
        where: 'tarih = ?', whereArgs: [tarih]);
  }  // --- tariheTahlilleriSil() sonu ---

  // --- E-NABIZ YORUM ---
  Future<int> yorumEkle(Map<String, dynamic> veri) async {
    Database db = await database;
    return await db.insert('enabiz_yorumlari', veri);
  }  // --- yorumEkle() sonu ---

  Future<List<Map<String, dynamic>>> yorumlariGetir() async {
    Database db = await database;
    return await db.query('enabiz_yorumlari', orderBy: 'id DESC');
  }

  // --- SU TAKİBİ ---
  Future<int> suEkle(int miktarMl) async {
    final db = await database;
    return await db.insert('su_takibi', {
      'miktar_ml': miktarMl,
      'tarih': DateTime.now().toIso8601String(),
    });
  }  // --- suEkle() sonu ---

  /// Bugünkü toplam su tüketimi (mL)
  Future<int> bugunToplamSuGetir() async {
    final db = await database;
    final simdi = DateTime.now();
    final baslangic =
        DateTime(simdi.year, simdi.month, simdi.day).toIso8601String();
    final bitis =
        DateTime(simdi.year, simdi.month, simdi.day, 23, 59, 59).toIso8601String();
    final sonuc = await db.rawQuery(
      'SELECT COALESCE(SUM(miktar_ml), 0) as toplam FROM su_takibi WHERE tarih >= ? AND tarih <= ?',
      [baslangic, bitis],
    );
    return (sonuc.first['toplam'] as int?) ?? 0;
  }  // --- bugunToplamSuGetir() sonu ---

  Future<List<Map<String, dynamic>>> suKayitlariniGetir({int limit = 50}) async {
    final db = await database;
    return await db.query('su_takibi', orderBy: 'tarih DESC', limit: limit);
  }

  Future<int> suKaydiSil(int id) async {
    final db = await database;
    return await db.delete('su_takibi', where: 'id = ?', whereArgs: [id]);
  }  // --- suKaydiSil() sonu ---

  // --- KİLO TAKİBİ ---
  Future<int> kiloEkle(double kilo) async {
    final db = await database;
    return await db.insert('kilo_takibi', {
      'kilo': kilo,
      'tarih': DateTime.now().toIso8601String(),
    });
  }  // --- kiloEkle() sonu ---

  Future<List<Map<String, dynamic>>> kiloKayitlariniGetir({int limit = 60}) async {
    final db = await database;
    return await db.query('kilo_takibi', orderBy: 'tarih DESC', limit: limit);
  }

  Future<int> kiloKaydiSil(int id) async {
    final db = await database;
    return await db.delete('kilo_takibi', where: 'id = ?', whereArgs: [id]);
  }  // --- kiloKaydiSil() sonu ---

  // Su hedefi: kullanıcı elle ayarlamadıysa, diyetisyenlerin kullandığı
  // genel formülle (kilo x 30 ml) en son kilo ölçümüne göre otomatik
  // hesaplanır. Elle ayarlanmışsa (Su & Kilo ekranındaki "Düzenle") o değer
  // öncelikli — kilo değişse bile otomatik hesaba dönmez.
  Future<int> suHedefiMlGetir() async {
    final prefs = await SharedPreferences.getInstance();
    final manuel = prefs.getInt('su_hedefi_ml_manuel');
    if (manuel != null) return manuel;
    final kilolar = await kiloKayitlariniGetir();
    if (kilolar.isNotEmpty) {
      final kilo = (kilolar.first['kilo'] as num?)?.toDouble();
      if (kilo != null && kilo > 0) {
        return (kilo * 30).round().clamp(1000, 4000);
      }
    }
    return 2000;
  }  // --- suHedefiMlGetir() sonu ---

  // --- SERAY AI SOHBET GEÇMİŞİ ---
  Future<int> sohbetOturumuKaydet({required String baslik, required String mesajlarJson}) async {
    final db = await database;
    return await db.insert('sohbet_oturumlari', {
      'baslik': baslik,
      'mesajlar_json': mesajlarJson,
      'tarih': DateTime.now().toIso8601String(),
    });
  }

  Future<int> sohbetOturumuGuncelle(int id, String mesajlarJson) async {
    final db = await database;
    return await db.update('sohbet_oturumlari', {'mesajlar_json': mesajlarJson},
        where: 'id = ?', whereArgs: [id]);
  }  // --- sohbetOturumuGuncelle() sonu ---

  Future<List<Map<String, dynamic>>> sohbetOturumlariniGetir() async {
    final db = await database;
    return await db.query('sohbet_oturumlari', orderBy: 'tarih DESC');
  }

  Future<int> sohbetOturumuSil(int id) async {
    final db = await database;
    return await db.delete('sohbet_oturumlari', where: 'id = ?', whereArgs: [id]);
  }  // --- sohbetOturumuSil() sonu ---

  // --- VERİTABANI SIFIRLAMA ---
  Future<void> veritabaniSifirla() async {
    Database db = await database;
    await db.delete('seker_olcumleri');
    await db.delete('tansiyon_olcumleri');
    await db.delete('ilaclar');
    await db.delete('enabiz_tahlilleri');
    await db.delete('enabiz_yorumlari');
    await db.delete('beslenme_kayitlari');
    await db.delete('su_takibi');
    await db.delete('kilo_takibi');
    await db.delete('sohbet_oturumlari');
  }  // --- veritabaniSifirla() sonu ---
}
