import 'dart:convert';
import 'dart:math';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:package_info_plus/package_info_plus.dart';

// YENİ SERVİS: Admin panelin "kaç kişi kullanıyor, kim nerede" görebilmesi
// için ad-soyad + şehir + "en son ne zaman kullanıldı" bilgisini worker.js
// üzerinden Cloudflare KV'ye gönderiyor. ÖNEMLİ — buradan KESİNLİKLE
// gönderilmeyenler: şeker, tansiyon, ilaç, kilo, su, adım gibi HİÇBİR
// sağlık verisi. Onlar sadece cihazda kalmaya devam ediyor (bkz. KVKK
// madde 1-2, bu değişiklikle birlikte güncellendi).
class IstatistikServisi {
  static const String _temelAdres = 'https://empty-union-ce11.serdarcirak.workers.dev';
  static const String _appSecret = 'Yn2zTv72M5R2BfKhkx8vnZRb9pZnNMfeU-jgbGLdoI8';
  static const String _cihazIdAnahtari = 'istatistik_cihaz_id';

  // Cihaza SESSİZCE, kullanıcı hiçbir şey yapmadan bir kere üretilip
  // SharedPreferences'ta saklanan rastgele bir kimlik. Kişisel bilgi
  // İÇERMEZ (isim/telefon/e-posta değil), sadece "bu kayıt hangi cihaza
  // ait" eşleştirmesi için kullanılır.
  static Future<String> cihazIdGetir() async {
    final prefs = await SharedPreferences.getInstance();
    String? id = prefs.getString(_cihazIdAnahtari);
    if (id == null) {
      final rastgele = Random.secure();
      final parcalar = List.generate(4, (_) => rastgele.nextInt(0xFFFFFFFF).toRadixString(16).padLeft(8, '0'));
      id = '${DateTime.now().millisecondsSinceEpoch.toRadixString(36)}-${parcalar.join('-')}';
      await prefs.setString(_cihazIdAnahtari, id);
    }
    return id;
  }  // --- cihazIdGetir() sonu ---

  // Profil kaydedildiğinde (ilk kayıt veya güncelleme) çağrılır. Kullanıcı
  // ilgili rıza maddesini onaylamadıysa hiç çağrılmaz (bkz.
  // profil_kayit_ekrani.dart).
  static Future<void> kaydet({required String adSoyad, required String sehir}) async {
    try {
      final id = await cihazIdGetir();
      final surumBilgisi = await PackageInfo.fromPlatform();
      await http
          .post(
            Uri.parse('$_temelAdres/kullanici-kaydet'),
            headers: {'Content-Type': 'application/json', 'X-Seray-Key': _appSecret},
            body: jsonEncode({
              'id': id,
              'adSoyad': adSoyad,
              'sehir': sehir,
              'surum': '${surumBilgisi.version}+${surumBilgisi.buildNumber}',
            }),
          )
          .timeout(const Duration(seconds: 8));
    } catch (_) {
      // İnternet yoksa sessizce geç — bir sonraki açılışta veya profil
      // güncellemesinde tekrar denenecek, kullanıcıyı hiç etkilemez.
    }
  }  // --- kaydet() sonu ---

  // Uygulama her açıldığında (main.dart) sessizce çağrılır — sadece "son
  // aktif" zaman damgasını günceller, yeni bir kayıt OLUŞTURMAZ (kullanıcı
  // profilini/rızasını hiç kaydetmediyse bu istek worker'da karşılığı
  // olmayan bir id göndermiş olur, worker bunu sessizce yok sayar).
  static Future<void> aktiviteBildir() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      // Kullanıcı istatistik rızasını vermediyse hiç göndermiyoruz.
      final rizaVerildi = prefs.getBool('riza_istatistik_onay') ?? false;
      if (!rizaVerildi) return;
      final id = await cihazIdGetir();
      await http
          .post(
            Uri.parse('$_temelAdres/kullanici-aktivite'),
            headers: {'Content-Type': 'application/json', 'X-Seray-Key': _appSecret},
            body: jsonEncode({'id': id}),
          )
          .timeout(const Duration(seconds: 8));
    } catch (_) {
      // Sessizce geç — kullanıcıyı asla bekletmemeli/etkilememeli.
    }
  }  // --- aktiviteBildir() sonu ---
}  // --- IstatistikServisi sonu ---
