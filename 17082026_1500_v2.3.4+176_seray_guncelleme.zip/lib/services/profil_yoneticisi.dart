import 'dart:convert';
import 'dart:io';
import 'package:path/path.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';
import 'profil_sabitleri.dart';
import 'veritabani_yardimcisi.dart';

// AİLE TAKİBİ: Telefona uygulamayı kuran kişi, kendi profilinin yanına
// başka kişilerin (annesi, babası, takip ettiği bir yakını) profilini de
// ekleyip aralarında geçiş yaparak HER BİRİNİN verilerini AYRI AYRI takip
// edebilir. Her profilin kendi veritabanı (ölçümler, ilaçlar, e-Nabız
// tahlilleri, beslenme, sohbet geçmişi) TAMAMEN AYRIDIR. Uygulama
// ayarları (tema, PIN kilidi, bildirim tercihleri, dil) ise CİHAZ
// genelinde ORTAK kalır — bunlar bir profile değil, telefonun/kullanımın
// kendisine ait tercihlerdir.
class ProfilBilgisi {
  final String id;
  final String ad;
  ProfilBilgisi({required this.id, required this.ad});

  Map<String, dynamic> toJson() => {'id': id, 'ad': ad};
  factory ProfilBilgisi.fromJson(Map<String, dynamic> j) =>
      ProfilBilgisi(id: j['id'] as String, ad: j['ad'] as String);
}  // --- ProfilBilgisi sonu ---

class ProfilYoneticisi {
  static final ProfilYoneticisi _instance = ProfilYoneticisi._internal();
  factory ProfilYoneticisi() => _instance;
  ProfilYoneticisi._internal();

  Future<List<ProfilBilgisi>> profilleriGetir() async {
    final prefs = await SharedPreferences.getInstance();
    final ham = prefs.getString(ProfilSabitleri.profilListesiAnahtari);
    if (ham == null) {
      return [ProfilBilgisi(id: ProfilSabitleri.varsayilanProfilId, ad: 'Ben')];
    }
    try {
      final liste = (jsonDecode(ham) as List)
          .map((e) => ProfilBilgisi.fromJson(e as Map<String, dynamic>))
          .toList();
      if (liste.isEmpty) {
        return [ProfilBilgisi(id: ProfilSabitleri.varsayilanProfilId, ad: 'Ben')];
      }
      return liste;
    } catch (_) {
      return [ProfilBilgisi(id: ProfilSabitleri.varsayilanProfilId, ad: 'Ben')];
    }
  }  // --- profilleriGetir() sonu ---

  Future<void> _listeyiKaydet(List<ProfilBilgisi> liste) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      ProfilSabitleri.profilListesiAnahtari,
      jsonEncode(liste.map((p) => p.toJson()).toList()),
    );
  }  // --- _listeyiKaydet() sonu ---

  Future<String> aktifProfilId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(ProfilSabitleri.aktifProfilAnahtari) ?? ProfilSabitleri.varsayilanProfilId;
  }  // --- aktifProfilId() sonu ---

  Future<ProfilBilgisi> aktifProfil() async {
    final id = await aktifProfilId();
    final liste = await profilleriGetir();
    return liste.firstWhere((p) => p.id == id, orElse: () => liste.first);
  }  // --- aktifProfil() sonu ---

  // Yeni bir profil ekler (örn. "Annem"), listeye kaydeder — AKTİF yapmaz,
  // kullanıcı isterse ayrıca "Bu Profile Geç" der.
  Future<ProfilBilgisi> profilEkle(String ad) async {
    final liste = await profilleriGetir();
    // İlk kez ikinci bir profil ekleniyorsa, listeye "varsayilan" profili
    // de (o ana kadar sadece zımnen var olan) açıkça eklemek gerekir —
    // yoksa profilleriGetir() ham veri boş olduğu için hep tek bir
    // "Ben" profili üretir, gerçek listeyle senkron kalmaz.
    if (liste.length == 1 && liste.first.id == ProfilSabitleri.varsayilanProfilId) {
      final prefs = await SharedPreferences.getInstance();
      if (prefs.getString(ProfilSabitleri.profilListesiAnahtari) == null) {
        final kayitliAd = '${prefs.getString('kullanici_ad') ?? ''} ${prefs.getString('kullanici_soyad') ?? ''}'.trim();
        if (kayitliAd.isNotEmpty) {
          liste[0] = ProfilBilgisi(id: ProfilSabitleri.varsayilanProfilId, ad: kayitliAd);
        }
      }
    }
    final yeniId = 'profil_${DateTime.now().millisecondsSinceEpoch}';
    final yeni = ProfilBilgisi(id: yeniId, ad: ad.trim().isEmpty ? 'Yeni Profil' : ad.trim());
    liste.add(yeni);
    await _listeyiKaydet(liste);
    return yeni;
  }  // --- profilEkle() sonu ---

  Future<void> profilAdiniGuncelle(String id, String yeniAd) async {
    final liste = await profilleriGetir();
    final index = liste.indexWhere((p) => p.id == id);
    if (index == -1) return;
    liste[index] = ProfilBilgisi(id: id, ad: yeniAd.trim().isEmpty ? liste[index].ad : yeniAd.trim());
    await _listeyiKaydet(liste);
  }  // --- profilAdiniGuncelle() sonu ---

  // Bir profili KALICI olarak siler — kendi veritabanı dosyasını,
  // (varsayılan DEĞİLSE) profile özel tercihlerini de kaldırır. Son kalan
  // TEK profil silinemez (uygulamanın en az bir profili olmalı).
  // Varsayılan profilin veritabanı ASLA silinmez (o, uygulamanın en
  // başından beri var olan orijinal verisidir — güvenlik için dokunulmuyor).
  Future<bool> profilSil(String id) async {
    final liste = await profilleriGetir();
    if (liste.length <= 1) return false;
    liste.removeWhere((p) => p.id == id);
    await _listeyiKaydet(liste);

    final aktif = await aktifProfilId();
    if (aktif == id) {
      await aktifProfiliDegistir(liste.first.id);
    }

    if (id != ProfilSabitleri.varsayilanProfilId) {
      try {
        final yol = join(await getDatabasesPath(), ProfilSabitleri.dbDosyaAdi(id));
        final dosya = File(yol);
        if (await dosya.exists()) await dosya.delete();
      } catch (_) {}

      final prefs = await SharedPreferences.getInstance();
      final onEk = 'profil_${id}_';
      final silinecekler = prefs.getKeys().where((k) => k.startsWith(onEk)).toList();
      for (final k in silinecekler) {
        await prefs.remove(k);
      }
    }
    return true;
  }  // --- profilSil() sonu ---

  // Aktif profili değiştirir VE veritabanı bağlantısını sıfırlar — bir
  // sonraki veritabanı erişiminde YENİ profilin dosyası açılır. Ekranın
  // yeniden yüklenmesi (Ana Sayfa'ya dönmek gibi) çağıran tarafın işidir.
  Future<void> aktifProfiliDegistir(String id) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(ProfilSabitleri.aktifProfilAnahtari, id);
    await VeritabaniYardimcisi().baglantiyiKapatVeSifirla();
  }  // --- aktifProfiliDegistir() sonu ---

  // Profile özel bir SharedPreferences anahtarı üretir — örn. "kullanici_ad"
  // anahtarı, "Annem" profilinde "profil_1234567_kullanici_ad" olur. Bu
  // sayede her profilin kendi adı/boyu/hedef kilosu/acil durum kişisi AYRI
  // tutulur. VARSAYILAN profil için önek EKLENMEZ — mevcut kullanıcıların
  // halihazırda kayıtlı verisi önekSİZ anahtarlarda duruyor, önek eklersek
  // "birden bire kayboldu" gibi görünürdü. Sadece SONRADAN eklenen
  // profiller önek alır. Tema/PIN/dil gibi ORTAK ayarlar bu fonksiyonu HİÇ
  // kullanmaz, düz anahtarlarıyla kalmaya devam eder.
  Future<String> profilAnahtari(String temelAnahtar) async {
    final id = await aktifProfilId();
    if (id == ProfilSabitleri.varsayilanProfilId) return temelAnahtar;
    return 'profil_${id}_$temelAnahtar';
  }  // --- profilAnahtari() sonu ---

  // Profil fotoğrafının dosya yolu — VARSAYILAN profil için eski/sabit
  // "profil_foto.jpg" adı korunuyor (geriye dönük uyumluluk), yeni
  // profiller kendi adlarıyla ayrı dosyalar kullanıyor. Önceden TÜM
  // profiller aynı sabit dosya adını paylaşıyordu — "Annem" profilindeyken
  // bile kullanıcının kendi fotoğrafı görünüyordu, bu onu düzeltiyor.
  Future<String> profilFotoYolu(String belgelerYolu) async {
    final id = await aktifProfilId();
    final dosyaAdi = id == ProfilSabitleri.varsayilanProfilId ? 'profil_foto.jpg' : 'profil_foto_$id.jpg';
    return '$belgelerYolu/$dosyaAdi';
  }  // --- profilFotoYolu() sonu ---
}  // --- ProfilYoneticisi sonu ---
