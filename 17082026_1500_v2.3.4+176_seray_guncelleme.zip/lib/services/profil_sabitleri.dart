// Profil sistemi için ORTAK, bağımlılığı OLMAYAN sabitler.
// VeritabaniYardimcisi hem ProfilYoneticisi'ne, hem de ProfilYoneticisi
// VeritabaniYardimcisi'ne ihtiyaç duyduğu için (biri veritabanı dosya
// adını belirlemek için aktif profili bilmeli, diğeri profil silinince
// veritabanı dosyasını silmeli) bu sabitler DÖNGÜSEL IMPORT'U önlemek
// için ayrı, minik bir dosyada tutuluyor.
class ProfilSabitleri {
  static const String aktifProfilAnahtari = 'aktif_profil_id_v1';
  static const String profilListesiAnahtari = 'profiller_listesi_v1';
  // Uygulamanın en başından beri var olan TEK/ilk profil — ID'si sabit ve
  // veritabanı dosya adı DEĞİŞMİYOR ("seray_saglik_asistanim.db", öneksiz).
  // Böylece mevcut kullanıcıların verisi, çoklu profil özelliği eklendikten
  // sonra da hiç taşınmadan aynı yerde kalmaya devam ediyor.
  static const String varsayilanProfilId = 'varsayilan';

  static String dbDosyaAdi(String profilId) {
    if (profilId == varsayilanProfilId) return 'seray_saglik_asistanim.db';
    return 'seray_saglik_asistanim_$profilId.db';
  }  // --- dbDosyaAdi() sonu ---
}
