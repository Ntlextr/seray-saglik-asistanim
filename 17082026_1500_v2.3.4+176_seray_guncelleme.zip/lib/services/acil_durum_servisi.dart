import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:android_intent_plus/android_intent.dart';
import '../theme/renkler.dart';
import 'profil_yoneticisi.dart';

// Kritik bir ölçüm (çok yüksek/düşük şeker veya tansiyon) kaydedildiğinde,
// kullanıcının önceden Ayarlar'dan belirlediği bir yakınına SMS ile haber
// vermesini kolaylaştırır.
//
// ÖNEMLİ — NEDEN OTOMATİK/SESSİZ SMS GÖNDERİLMİYOR: Android, uygulamaların
// arka planda kullanıcıya sormadan SMS göndermesine (SEND_SMS izni) Play
// Store politikası gereği çok sıkı kısıtlama getiriyor — bu izni isteyen
// uygulamalar genellikle reddediliyor (varsayılan SMS/telefon uygulaması
// değilse). Bu yüzden burada native SMS uygulamasını, mesaj ÖNCEDEN
// DOLDURULMUŞ şekilde AÇIYORUZ — kullanıcı sadece "Gönder"e basıyor, ekstra
// izin gerekmiyor ve Play Store'da sorun çıkarmıyor.
class AcilDurumServisi {
  static const MethodChannel _kanal = MethodChannel('com.serayteknoloji.saglik_asistanim/sms');

  // Telefonun varsayılan SMS uygulamasının paket adını (örn.
  // "com.google.android.apps.messaging") native taraftan sorar. Sonuç,
  // birden fazla mesajlaşma uygulaması yüklüyken (WhatsApp vb.) Android'in
  // "Şununla aç" seçim penceresini ATLAYIP doğrudan SMS uygulamasını
  // açmak için kullanılır. Herhangi bir sebeple alınamazsa null döner —
  // o zaman eski (seçim penceresi gösteren) yönteme sessizce dönülür.
  //
  // NOT (MIUI): Bu telefonlarda (Redmi/Xiaomi) bu API'nin güvenilmez
  // şekilde null döndüğü doğrulandı — kod her zaman aşağıdaki yedek
  // yönteme (seçim penceresi) düşüyor, bu NORMAL ve sorunsuz çalışıyor.
  static Future<String?> _varsayilanSmsPaketiniAl() async {
    try {
      return await _kanal.invokeMethod<String>('varsayilanSmsPaketi');
    } catch (_) {
      return null;
    }
  }  // --- _varsayilanSmsPaketiniAl() sonu ---

  // onGonderildi: kullanıcı gerçekten "Gönder"e basıp SMS uygulaması
  // açıldıktan SONRA çağrılır — çağıran taraf (şeker/tansiyon ekle
  // ekranları) bu ölçümü veritabanında "sms_gonderildi" olarak
  // işaretleyebilsin diye. NOT: kullanıcının SMS'i GERÇEKTEN gönderip
  // göndermediğini (uygulamayı açtıktan sonra "Gönder"e basıp basmadığını)
  // Android bize bildirmiyor — bu yüzden "gönderildi" burada aslında
  // "gönderme ekranı başarıyla açıldı" anlamına gelir, kesin teslim
  // garantisi değildir.
  static Future<void> tehlikeliOlcumBildir(
    BuildContext context, {
    required String olcumOzeti,
    VoidCallback? onGonderildi,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    final py = ProfilYoneticisi();
    final ad = prefs.getString(await py.profilAnahtari('acil_kisi_ad')) ?? '';
    final telefon = prefs.getString(await py.profilAnahtari('acil_kisi_telefon')) ?? '';
    if (telefon.trim().isEmpty) return; // Acil durum kişisi ayarlanmamış — sessizce geç.

    if (!context.mounted) return;
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('⚠️ Kritik Ölçüm'),
        content: Text(
          '$olcumOzeti\n\n${ad.isNotEmpty ? ad : 'Acil durum kişiniz'}\'e haber vermek ister misiniz?',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Vazgeç')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppRenkleri.aktif),
            onPressed: () async {
              Navigator.pop(dialogContext);
              // ÖNEMLİ DÜZELTME: Önceden burada kullanici_ad/kullanici_soyad
              // (o an aktif profile göre zaten doğru okunuyor olsa da) ayrı
              // ayrı okunuyordu — artık ProfilYoneticisi'nin sakladığı GERÇEK
              // profil adı kullanılıyor, daha güvenilir ve tek kaynak.
              final hastaAdi = (await ProfilYoneticisi().aktifProfil()).ad;
              final hastaCumlesi = hastaAdi.isNotEmpty ? '$hastaAdi\'nin ' : '';
              final mesajDuz = '${hastaCumlesi}$olcumOzeti Lütfen kontrol edebilir misin? — Seray Sağlık Asistanım';

              // ÖNCE: varsayılan SMS uygulamasını doğrudan hedeflemeyi dene
              // (seçim penceresi çıkmadan direkt açılır).
              final ham = await _varsayilanSmsPaketiniAl();
              final hataMesaji = (ham != null && ham.startsWith('HATA:')) ? ham.substring(5) : null;
              final paketAdi = hataMesaji == null ? ham : null;

              if (paketAdi != null && paketAdi.isNotEmpty) {
                try {
                  final intent = AndroidIntent(
                    action: 'android.intent.action.SENDTO',
                    data: 'smsto:$telefon',
                    package: paketAdi,
                    arguments: {'sms_body': mesajDuz},
                  );
                  await intent.launch();
                  onGonderildi?.call();
                  return;
                } catch (_) {
                  // Bu paket adıyla açılamadı — aşağıdaki yedek yönteme düş.
                }
              }

              // YEDEK YÖNTEM: varsayılan SMS paketi alınamazsa (MIUI gibi
              // cihazlarda genelde budur), eski yöntemle devam et —
              // "smsto:" adresi WhatsApp gibi diğer uygulamalar tarafından
              // da yakalanabilir, kullanıcı bir seçim penceresi görebilir.
              final mesaj = Uri.encodeComponent(mesajDuz);
              final uri = Uri.parse('smsto:$telefon?body=$mesaj');
              try {
                await launchUrl(uri);
                onGonderildi?.call();
              } catch (_) {
                if (dialogContext.mounted) {
                  ScaffoldMessenger.of(dialogContext).showSnackBar(
                    const SnackBar(content: Text('Mesaj uygulaması açılamadı.')),
                  );
                }
              }
            },
            child: const Text('Mesaj Gönder', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }  // --- tehlikeliOlcumBildir() sonu ---
}
