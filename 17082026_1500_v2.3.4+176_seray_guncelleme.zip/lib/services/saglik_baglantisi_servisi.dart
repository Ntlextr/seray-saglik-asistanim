import 'package:health/health.dart';

// Google'ın Health Connect'i (Android'in sistem seviyesi sağlık veri
// deposu) ile konuşur. Adım sensörünü doğrudan biz dinlemesek bile,
// telefonun kendi sistemi arka planda 7/24 adım sayıyor ve bunu Health
// Connect'e yazıyor — biz sadece o veriyi OKUYORUZ. Bu sayede uygulama
// kapalıyken de gerçek adım geçmişine ulaşabiliyoruz.
//
// ÖNEMLİ: Health Connect Android'in kendisi (Android 14+) ya da ayrı bir
// uygulama (Play Store'dan "Health Connect") olarak bulunur. Kurulu
// değilse / izin verilmezse / paket API'sinde bir uyuşmazlık olursa bu
// servis SESSİZCE null döner — çağıran taraf (adim_servisi.dart) o zaman
// eskisi gibi kendi yerel sayımını kullanmaya devam eder. Yani bu entegre
// bozulsa bile mevcut adım sayar ÇALIŞMAYA DEVAM EDER.
class SaglikBaglantisiServisi {
  static final Health _health = Health();
  static bool _yapilandirildi = false;

  // Teşhis amaçlı: son izinIste() çağrısında bir hata oluştuysa burada
  // saklanır — Ayarlar ekranı bunu kullanıcıya gösterip bize bildirmesini
  // sağlayabilir (normalde sessiz geçilen hatalar artık görünür oluyor).
  static String? sonHata;

  static Future<void> _yapilandir() async {
    if (_yapilandirildi) return;
    await _health.configure();
    _yapilandirildi = true;
  }  // --- _yapilandir() sonu ---

  // Health Connect'ten adım okuma izni ister. Kullanıcı daha önce izin
  // verdiyse tekrar sormadan true döner.
  static Future<bool> izinIste() async {
    sonHata = null;
    try {
      await _yapilandir();

      // Önce Health Connect'in cihazda GERÇEKTEN kullanılabilir olup
      // olmadığını kontrol ediyoruz — kurulu değilse veya güncellenmesi
      // gerekiyorsa requestAuthorization hiçbir pencere göstermeden
      // sessizce false döner; bu yüzden sebebi burada netleştiriyoruz.
      final durum = await _health.getHealthConnectSdkStatus();
      if (durum != HealthConnectSdkStatus.sdkAvailable) {
        sonHata = 'Health Connect kullanılamıyor (durum: $durum). '
            'Play Store\'dan Health Connect uygulamasını yükleyin veya güncelleyin, sonra tekrar deneyin.';
        return false;
      }

      const tipler = [HealthDataType.STEPS];
      const izinler = [HealthDataAccess.READ];
      final zatenVar = await _health.hasPermissions(tipler, permissions: izinler) ?? false;
      if (zatenVar) return true;
      final sonuc = await _health.requestAuthorization(tipler, permissions: izinler);
      if (!sonuc) {
        sonHata = 'Health Connect izin penceresinde "İzin Ver" seçilmedi ya da pencere hiç açılmadı. '
            'Health Connect uygulamasını doğrudan açıp Seray Sağlık Asistanım\'a elle izin vermeyi deneyin.';
      }
      return sonuc;
    } catch (e) {
      sonHata = e.toString();
      return false;
    }
  }  // --- izinIste() sonu ---

  // Belirtilen günün TAMAMI için (o gün henüz bitmediyse şu ana kadar)
  // Health Connect'teki toplam adım sayısını döner. Herhangi bir sorunda
  // (izin yok, Health Connect kurulu değil, API hatası) null döner.
  static Future<int?> gununAdimSayisi(DateTime gun) async {
    try {
      await _yapilandir();
      final baslangic = DateTime(gun.year, gun.month, gun.day);
      final simdi = DateTime.now();
      final gunSonu = baslangic.add(const Duration(days: 1));
      final bitis = gunSonu.isAfter(simdi) ? simdi : gunSonu;
      if (!bitis.isAfter(baslangic)) return null;

      final toplam = await _health.getTotalStepsInInterval(baslangic, bitis);
      return toplam;
    } catch (e) {
      return null;
    }
  }  // --- gununAdimSayisi() sonu ---
}  // --- SaglikBaglantisiServisi sonu ---
