import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';

// Firebase Crashlytics kurulumu.
//
// ÖNEMLİ: android/app/google-services.json dosyası eklenmeden bu paket
// gerçek anlamda çalışmaz (Firebase projesi Console'da kurulmalı, uygulama
// oraya kaydedilmeli, indirilen google-services.json bu yola konmalı).
// Dosya yoksa Firebase.initializeApp() hata fırlatır — bu servis bunu
// SESSİZCE yakalar, uygulama normal şekilde çalışmaya devam eder, sadece
// çökme raporlaması pasif kalır. Dosya eklendiğinde bir sonraki derlemede
// otomatik aktif olur, ekstra kod değişikliği gerekmez.
bool crashlyticsAktifMi = false;

Future<void> crashRaporlamayiBaslat() async {
  try {
    await Firebase.initializeApp();
    crashlyticsAktifMi = true;

    // Flutter çatısı içindeki (widget build, layout vb.) hatalar
    FlutterError.onError = (FlutterErrorDetails details) {
      FirebaseCrashlytics.instance.recordFlutterFatalError(details);
    };
    // Flutter dışındaki (async, izole thread vb.) yakalanmamış hatalar
    PlatformDispatcher.instance.onError = (error, stack) {
      FirebaseCrashlytics.instance.recordError(error, stack, fatal: true);
      return true;
    };
  } catch (e) {
    // google-services.json henüz eklenmemiş olabilir — bu normal, sessizce
    // geç. Uygulamanın geri kalanı hiç etkilenmez.
    crashlyticsAktifMi = false;
  }
}  // --- crashRaporlamayiBaslat() sonu ---

// Kritik ama uygulamayı çökertmeyen hataları (try/catch içinde
// yakalananları) manuel olarak Crashlytics'e göndermek için — Crashlytics
// aktif değilse (google-services.json yoksa) hiçbir şey yapmaz.
void crashKaydet(Object hata, StackTrace? yigin, {String? aciklama}) {
  if (!crashlyticsAktifMi) return;
  FirebaseCrashlytics.instance.recordError(hata, yigin, reason: aciklama);
}  // --- crashKaydet() sonu ---
