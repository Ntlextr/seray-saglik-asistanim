import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../theme/renkler.dart';
import '../services/dil_servisi.dart';

// GÖRSEL KİMLİK / ŞABLON TURU (madde 5): uygulamanın ana özelliklerini kısaca
// tanıtan kaydırmalı bir tanıtım ekranı. Kritik izinler/profil akışına henüz
// bağlanmadı (riski azaltmak için) — şimdilik Ayarlar > "Uygulama Turu"
// üzerinden manuel açılabiliyor. İleride ilk açılışta otomatik gösterilmek
// istenirse SharedPreferences'taki 'tanitim_turu_gosterildi' bayrağı zaten
// buraya hazır, main.dart'a bağlanması yeterli.
class TanitimTuruEkrani extends StatefulWidget {
  const TanitimTuruEkrani({Key? key}) : super(key: key);

  @override
  State<TanitimTuruEkrani> createState() => _TanitimTuruEkraniState();
}

class _TanitimSayfasi {
  final IconData ikon;
  final String baslik;
  final String aciklama;
  const _TanitimSayfasi({required this.ikon, required this.baslik, required this.aciklama});
}

class _TanitimTuruEkraniState extends State<TanitimTuruEkrani> {
  final PageController _controller = PageController();
  int _sayfa = 0;

  static List<_TanitimSayfasi> get _sayfalar => [
    _TanitimSayfasi(
      ikon: Icons.favorite_rounded,
      baslik: DilServisi.metin('turuBaslik1'),
      aciklama: DilServisi.metin('turuAciklama1'),
    ),
    _TanitimSayfasi(
      ikon: Icons.medication_rounded,
      baslik: DilServisi.metin('turuBaslik2'),
      aciklama: DilServisi.metin('turuAciklama2'),
    ),
    _TanitimSayfasi(
      ikon: Icons.auto_awesome_rounded,
      baslik: DilServisi.metin('turuBaslik3'),
      aciklama: DilServisi.metin('turuAciklama3'),
    ),
    _TanitimSayfasi(
      ikon: Icons.family_restroom_rounded,
      baslik: DilServisi.metin('turuBaslik4'),
      aciklama: DilServisi.metin('turuAciklama4'),
    ),
  ];

  Future<void> _turuGosterildiOlarakIsaretle() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('tanitim_turu_gosterildi', true);
  }  // --- _turuGosterildiOlarakIsaretle() sonu ---

  @override
  Widget build(BuildContext context) {
    final sonSayfaMi = _sayfa == _sayfalar.length - 1;
    return Scaffold(
      backgroundColor: AppRenkleri.aktif,
      body: SafeArea(
        child: Column(
          children: [
            Align(
              alignment: Alignment.topRight,
              child: TextButton(
                onPressed: () async {
                  await _turuGosterildiOlarakIsaretle();
                  if (mounted) Navigator.pop(context);
                },
                child: Text(DilServisi.metin('turuGec'), style: const TextStyle(color: Colors.white70)),
              ),
            ),
            Expanded(
              child: PageView.builder(
                controller: _controller,
                itemCount: _sayfalar.length,
                onPageChanged: (i) => setState(() => _sayfa = i),
                itemBuilder: (context, i) {
                  final s = _sayfalar[i];
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 32),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 120,
                          height: 120,
                          decoration: const BoxDecoration(color: Colors.white24, shape: BoxShape.circle),
                          child: Icon(s.ikon, size: 60, color: Colors.white),
                        ),
                        const SizedBox(height: 32),
                        Text(
                          s.baslik,
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 14),
                        Text(
                          s.aciklama,
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: Colors.white70, fontSize: 15, height: 1.4),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                _sayfalar.length,
                (i) => AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  width: i == _sayfa ? 22 : 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: i == _sayfa ? Colors.white : Colors.white38,
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: AppRenkleri.aktif,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                  ),
                  onPressed: () async {
                    if (sonSayfaMi) {
                      await _turuGosterildiOlarakIsaretle();
                      if (mounted) Navigator.pop(context);
                    } else {
                      _controller.nextPage(duration: const Duration(milliseconds: 300), curve: Curves.easeInOut);
                    }
                  },
                  child: Text(sonSayfaMi ? DilServisi.metin('turuBaslayalim') : DilServisi.metin('turuIleri'), style: const TextStyle(fontWeight: FontWeight.bold)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }  // --- build() sonu ---
}
