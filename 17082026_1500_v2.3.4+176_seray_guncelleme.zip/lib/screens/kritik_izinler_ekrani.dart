import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../theme/renkler.dart';
import '../theme/sablon.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:permission_handler/permission_handler.dart';
import '../services/bildirim_servisi.dart';
import '../services/saglik_baglantisi_servisi.dart';
import '../services/dil_servisi.dart';

// İlaç hatırlatmalarının GÜVENİLİR çalışması için gereken telefon
// ayarlarını kullanıcıya adım adım anlatan, zorunlu bir ilk kurulum ekranı.
// Bazı telefon markaları (özellikle Xiaomi/Redmi/POCO - MIUI) bu ayarlar
// açılmadan uygulamaları arka planda kapatıp bildirimleri engelliyor.
class KritikIzinlerEkrani extends StatefulWidget {
  final VoidCallback onTamamlandi;
  const KritikIzinlerEkrani({Key? key, required this.onTamamlandi}) : super(key: key);

  @override
  State<KritikIzinlerEkrani> createState() => _KritikIzinlerEkraniState();
}

class _KritikIzinlerEkraniState extends State<KritikIzinlerEkrani> with WidgetsBindingObserver {
  bool _pilAyariGorundu = false;
  bool _otomatikBaslatmaGorundu = false;
  bool _digerIzinlerGorundu = false;
  bool _calismaZamaniIzinleriVerildi = false;

  // "Hepsini Aç" akışı: kullanıcı MIUI ayar sayfasından uygulamaya geri
  // döndüğünde (didChangeAppLifecycleState "resumed"), bir sonraki maddeyi
  // otomatik açar — böylece tek tek karta dokunmak yerine tek başlatıp
  // geri dönüş geri dönüş ilerleyebiliyor. Adım toggle'larının kendisi
  // yine elle yapılmalı (Android/MIUI kısıtı, bkz. ekranın üstündeki not).
  bool _sirayliModAktif = false;
  int _sirayliSonrakiAdim = 1; // 2 = otomatik başlatma sırada, 3 = diğer izinler sırada

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }  // --- initState() sonu ---

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed || !_sirayliModAktif) return;
    // Kullanıcı ayar sayfasından uygulamaya yeni döndü — küçük bir
    // gecikmeyle sıradaki adımı otomatik aç (ekran geçişinin oturması için).
    Future.delayed(const Duration(milliseconds: 500), () async {
      if (!mounted || !_sirayliModAktif) return;
      if (_sirayliSonrakiAdim == 2) {
        setState(() => _sirayliSonrakiAdim = 3);
        await _otomatikBaslatmayiAc();
      } else if (_sirayliSonrakiAdim == 3) {
        setState(() { _sirayliSonrakiAdim = 4; _sirayliModAktif = false; });
        await _digerIzinleriAc();
      }
    });
  }  // --- didChangeAppLifecycleState() sonu ---

  Future<void> _hepsiniAcBaslat() async {
    setState(() { _sirayliModAktif = true; _sirayliSonrakiAdim = 2; });
    await _pilAyariniAc();
  }  // --- _hepsiniAcBaslat() sonu ---

  Future<void> _pilAyariniAc() async {
    await BildirimServisi.pilOptimizasyonuGorMezdenGel();
    if (mounted) setState(() => _pilAyariGorundu = true);
  }  // --- _pilAyariniAc() sonu ---

  Future<void> _otomatikBaslatmayiAc() async {
    await BildirimServisi.otomatikBaslatmaAyariniAc();
    if (mounted) setState(() => _otomatikBaslatmaGorundu = true);
  }  // --- _otomatikBaslatmayiAc() sonu ---

  Future<void> _digerIzinleriAc() async {
    await BildirimServisi.uygulamaAyarlariniAc();
    if (mounted) setState(() => _digerIzinlerGorundu = true);
  }  // --- _digerIzinleriAc() sonu ---

  bool get _hepsiTamam => _pilAyariGorundu && _otomatikBaslatmaGorundu && _digerIzinlerGorundu && _calismaZamaniIzinleriVerildi;

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }  // --- dispose() sonu ---

  Future<void> _tamamlaVeDevamEt() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('kritik_izinler_gosterildi', true);
    widget.onTamamlandi();
  }

  // Diğer uygulamalarda olduğu gibi: dokununca sistemin kendi izin
  // pencereleri art arda açılır, kullanıcı "İzin Ver" der ve biter —
  // ayarlar sayfasına yönlendirme YOK. Kamera (nabız ölçümü), mikrofon
  // (Seray AI sohbet) ve hareket sensörü (adım sayar) burada tek seferde
  // toplanıyor; artık ilgili ekranlara ilk girişte ayrı ayrı sorulmuyor.
  Future<void> _calismaZamaniIzinleriniIste() async {
    await Permission.camera.request();
    await Permission.microphone.request();
    await Permission.activityRecognition.request();
    if (mounted) setState(() => _calismaZamaniIzinleriVerildi = true);
  }  // --- _calismaZamaniIzinleriniIste() sonu ---

  // Health Connect İSTEĞE BAĞLI — cihazda kurulu olmayabilir, bu yüzden
  // _hepsiTamam şartına dahil edilmedi. Amaç: adım sayarın uygulama
  // kapalıyken de OS seviyesinde biriktirdiği veriyi okuyabilmek.
  bool _healthConnectDenendi = false;
  Future<void> _healthConnectIzinIste() async {
    await SaglikBaglantisiServisi.izinIste();
    if (mounted) setState(() => _healthConnectDenendi = true);
  }  // --- _healthConnectIzinIste() sonu ---

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        shape: AppSablon.appBarSekli,
        clipBehavior: Clip.antiAlias,
        title: FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(DilServisi.metin('kritikIzinlerBaslik'))),
        backgroundColor: AppRenkleri.aktif,
        foregroundColor: Colors.white,
        automaticallyImplyLeading: false,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.amber.shade50,
                  borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
                  border: Border.all(color: Colors.amber.shade200),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.warning_amber_rounded, color: Colors.orange),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        DilServisi.metin('kritikIzinlerUyari'),
                        style: const TextStyle(fontSize: 13, height: 1.4),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // Tek dokunuşla 1-2-3'ü sırayla başlatır: her ayar sayfasından
              // geri döndüğünde bir sonraki otomatik açılır. Toggle'ların
              // kendisi yine elle açılmalı (Android/MIUI kısıtı).
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: _sirayliModAktif ? null : _hepsiniAcBaslat,
                  icon: const Icon(Icons.playlist_add_check),
                  label: Text(_sirayliModAktif
                      ? DilServisi.metin('sirayliAcilirMesaj')
                      : DilServisi.metin('hepsiniAcButon')),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppRenkleri.aktif,
                    side: BorderSide(color: AppRenkleri.aktif),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                ),
              ),
              const SizedBox(height: 20),

              _izinKarti(
                numara: '1',
                baslik: DilServisi.metin('izin1Baslik'),
                aciklama: DilServisi.metin('izin1Aciklama'),
                tamamlandiMi: _pilAyariGorundu,
                onTap: _pilAyariniAc,
              ),
              const SizedBox(height: 14),

              _izinKarti(
                numara: '2',
                baslik: DilServisi.metin('izin2Baslik'),
                aciklama: DilServisi.metin('izin2Aciklama'),
                tamamlandiMi: _otomatikBaslatmaGorundu,
                onTap: _otomatikBaslatmayiAc,
              ),
              const SizedBox(height: 14),

              _izinKarti(
                numara: '3',
                baslik: DilServisi.metin('izin3Baslik'),
                aciklama: DilServisi.metin('izin3Aciklama'),
                tamamlandiMi: _digerIzinlerGorundu,
                onTap: _digerIzinleriAc,
              ),
              const SizedBox(height: 14),

              _izinKarti(
                numara: '4',
                baslik: DilServisi.metin('izin4Baslik'),
                aciklama: DilServisi.metin('izin4Aciklama'),
                tamamlandiMi: _calismaZamaniIzinleriVerildi,
                onTap: _calismaZamaniIzinleriniIste,
              ),
              const SizedBox(height: 14),

              _izinKarti(
                numara: '5',
                baslik: DilServisi.metin('izin5Baslik'),
                aciklama: DilServisi.metin('izin5Aciklama'),
                tamamlandiMi: _healthConnectDenendi,
                onTap: _healthConnectIzinIste,
                playStorePaketAdi: 'com.google.android.apps.healthdata',
              ),

              const SizedBox(height: 28),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _hepsiTamam ? AppRenkleri.aktif : Colors.grey.shade400,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
                  ),
                  onPressed: _tamamlaVeDevamEt,
                  child: Text(_hepsiTamam ? DilServisi.metin('tamamladimDevam') : DilServisi.metin('simdilikGecDevam')),
                ),
              ),
              const SizedBox(height: 8),
              Center(
                child: Text(
                  DilServisi.metin('kritikIzinlerAltNot'),
                  style: TextStyle(fontSize: 12, color: Colors.grey.shade500),
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _izinKarti({
    required String numara,
    required String baslik,
    required String aciklama,
    required bool tamamlandiMi,
    required VoidCallback onTap,
    String? playStorePaketAdi, // Verilirse, kartın altına "Play Store'da Aç" bağlantısı eklenir.
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: tamamlandiMi ? Colors.green.shade50 : Colors.grey.shade50,
          borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
          border: Border.all(color: tamamlandiMi ? Colors.green.shade300 : Colors.grey.shade300),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CircleAvatar(
              radius: 15,
              backgroundColor: tamamlandiMi ? Colors.green : AppRenkleri.aktif,
              child: tamamlandiMi
                  ? const Icon(Icons.check, color: Colors.white, size: 18)
                  : Text(numara, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(baslik, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  const SizedBox(height: 3),
                  Text(aciklama, style: TextStyle(fontSize: 12, color: Colors.grey.shade700, height: 1.3)),
                  if (playStorePaketAdi != null) ...[
                    const SizedBox(height: 6),
                    InkWell(
                      onTap: () => launchUrl(
                        Uri.parse('market://details?id=$playStorePaketAdi'),
                        mode: LaunchMode.externalApplication,
                      ).onError((_, __) => launchUrl(
                            Uri.parse('https://play.google.com/store/apps/details?id=$playStorePaketAdi'),
                            mode: LaunchMode.externalApplication,
                          )),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.shop, size: 14, color: AppRenkleri.aktif.shade700),
                          const SizedBox(width: 4),
                          Text(DilServisi.metin('playStoredaAc'),
                              style: TextStyle(fontSize: 12, color: AppRenkleri.aktif.shade700, fontWeight: FontWeight.w600)),
                        ],
                      ),
                    ),
                  ],
                ],
              ),
            ),
            Icon(Icons.chevron_right, color: Colors.grey.shade400),
          ],
        ),
      ),
    );
  }
}
