import 'package:flutter/material.dart';

// Native splash (flutter_native_splash) kapanır kapanmaz kısa süreliğine
// gösterilen, Flutter tarafında animasyonlu bir geçiş ekranı. Logo önce
// büyüyerek+belirerek gelir, sonra bir kalp atışı gibi hafifçe zıplar,
// altında da uygulama adı belirir. Toplam ~1.8 saniye sürer, sonunda
// "sonraki" ekrana (gerçek başlangıç akışına) geçer. Dış bir animasyon
// dosyasına (Lottie/GIF) ihtiyaç duymadan, saf Flutter animasyonlarıyla
// yapılıyor — ekstra paket/bağımlılık eklemiyor.
class SplashAnimasyonEkrani extends StatefulWidget {
  final Widget sonraki;
  const SplashAnimasyonEkrani({Key? key, required this.sonraki}) : super(key: key);

  @override
  State<SplashAnimasyonEkrani> createState() => _SplashAnimasyonEkraniState();
}  // --- SplashAnimasyonEkrani sonu ---

class _SplashAnimasyonEkraniState extends State<SplashAnimasyonEkrani> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _logoOlcek;
  late final Animation<double> _logoOpaklik;
  late final Animation<double> _kalpAtisi;
  late final Animation<double> _yaziOpaklik;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800));

    // 0.0 - 0.45: logo büyüyerek + belirerek gelir
    _logoOlcek = Tween<double>(begin: 0.6, end: 1.0).animate(
      CurvedAnimation(parent: _controller, curve: const Interval(0.0, 0.45, curve: Curves.easeOutBack)),
    );
    _logoOpaklik = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _controller, curve: const Interval(0.0, 0.35, curve: Curves.easeOut)),
    );
    // 0.45 - 0.75: kalp atışı gibi hafif zıplama (1.0 -> 1.08 -> 1.0)
    _kalpAtisi = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 1.0, end: 1.08).chain(CurveTween(curve: Curves.easeOut)), weight: 50),
      TweenSequenceItem(tween: Tween(begin: 1.08, end: 1.0).chain(CurveTween(curve: Curves.easeIn)), weight: 50),
    ]).animate(CurvedAnimation(parent: _controller, curve: const Interval(0.45, 0.75)));
    // 0.55 - 0.85: uygulama adı belirir
    _yaziOpaklik = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _controller, curve: const Interval(0.55, 0.85, curve: Curves.easeOut)),
    );

    _controller.forward();
    _controller.addStatusListener((durum) {
      if (durum == AnimationStatus.completed) {
        Future.delayed(const Duration(milliseconds: 250), () {
          if (mounted) {
            Navigator.of(context).pushReplacement(
              MaterialPageRoute(builder: (context) => widget.sonraki),
            );
          }
        });
      }
    });
  }  // --- initState() sonu ---

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }  // --- dispose() sonu ---

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: AnimatedBuilder(
          animation: _controller,
          builder: (context, child) {
            final olcek = _logoOlcek.value * (_controller.value >= 0.45 ? _kalpAtisi.value : 1.0);
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Opacity(
                  opacity: _logoOpaklik.value,
                  child: Transform.scale(
                    scale: olcek,
                    child: Image.asset('assets/images/app_logo.png', width: 160, height: 160),
                  ),
                ),
                const SizedBox(height: 18),
                Opacity(
                  opacity: _yaziOpaklik.value,
                  child: const Column(
                    children: [
                      Text('SERAY', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: Color(0xFF023e8a), letterSpacing: 1.5)),
                      Text('SAĞLIK ASİSTANIM', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Color(0xFF00bfb2), letterSpacing: 1.0)),
                    ],
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }  // --- build() sonu ---
}  // --- _SplashAnimasyonEkraniState sonu ---
