import 'dart:convert';
import 'package:flutter/material.dart';
import '../services/dil_servisi.dart';
import 'package:http/http.dart' as http;
import '../theme/renkler.dart';

import '../theme/sablon.dart';

// Tek bir kütüphane kartını temsil eder. "tablo" doluysa (satır-sütun
// yapılandırılmış veri — isim/ölçü/miktar), detay ekranı GERÇEK BİR TABLO
// çizer. "tablo" boşsa (eski/düz metin kartlar), "aciklama" düz metin
// olarak gösterilir — böylece kutuphane.json'daki eski kartlar da bozulmadan
// çalışmaya devam eder.
class _KutuphaneKarti {
  final String baslik;
  final String aciklama;
  final List<Map<String, String>>? tablo;
  _KutuphaneKarti({required this.baslik, required this.aciklama, this.tablo});
}  // --- _KutuphaneKarti sonu ---

// "Gıda Değişim Listesi" — Bilgi Kütüphanesi'nden AYRI bir ekran. Kütüphane
// düz kart listesi gösterirken, burası bir İÇİNDEKİLER (kılavuz) yapısı
// sunuyor: önce ANA BAŞLIKLAR (kategoriler) listelenir, birine dokununca
// o kategorinin İÇİNDEKİ maddeler (numaralı) görünür, bir maddeye dokununca
// da tam detay (varsa gerçek satır-sütun TABLO) açılır. Kütüphane ekranıyla
// AYNI iki JSON dosyasını (kutuphane.json + degisim_listeleri_kartlari.json)
// kaynak olarak kullanır — veri tek yerde tutuluyor, sadece SUNUM farklı.
class GidaDegisimListesiEkrani extends StatefulWidget {
  const GidaDegisimListesiEkrani({Key? key}) : super(key: key);
  @override
  State<GidaDegisimListesiEkrani> createState() => _GidaDegisimListesiEkraniState();
}  // --- GidaDegisimListesiEkrani sonu ---

class _GidaDegisimListesiEkraniState extends State<GidaDegisimListesiEkrani> {
  bool _yukleniyor = true;
  String? _hata;
  final Map<String, List<_KutuphaneKarti>> _kategoriler = {};

  @override
  void initState() {
    super.initState();
    _icerigiYukle();
  }  // --- initState() sonu ---

  Future<void> _icerigiYukle() async {
    const temelAdres = 'https://raw.githubusercontent.com/Ntlextr/seray-saglik-asistanim/main/';
    // ÖNEMLİ DÜZELTME: Kullanıcı fark etti — bu ekran Bilgi Kütüphanesi ile
    // AYNI iki dosyayı okuyup birleştirdiği için ikisi de birebir aynı 4
    // kategoriyi gösteriyordu. Artık SADECE kendi değişim tablosu
    // dosyasını (degisim_listeleri_kartlari.json) okuyor, Kütüphane'nin
    // genel bilgi dosyasına hiç dokunmuyor.
    final dosyaAdlari = ['degisim_listeleri_kartlari.json'];

    final gruplar = <String, List<_KutuphaneKarti>>{};
    bool enAzBirTanesiBasariliMi = false;
    String? sonHata;

    for (final dosyaAdi in dosyaAdlari) {
      try {
        final response = await http
            .get(Uri.parse('$temelAdres$dosyaAdi'))
            .timeout(const Duration(seconds: 10));
        if (response.statusCode == 200) {
          final List liste = jsonDecode(utf8.decode(response.bodyBytes));
          for (final k in liste) {
            final kategori = (k['kategori'] ?? 'Genel').toString();
            List<Map<String, String>>? tablo;
            if (k['tablo'] is List) {
              tablo = (k['tablo'] as List)
                  .map<Map<String, String>>((satir) => {
                        'isim': (satir['isim'] ?? '').toString(),
                        'olcu': (satir['olcu'] ?? '').toString(),
                        'miktar': (satir['miktar'] ?? '').toString(),
                      })
                  .toList();
            }
            gruplar.putIfAbsent(kategori, () => []).add(_KutuphaneKarti(
                  baslik: (k['baslik'] ?? '').toString(),
                  aciklama: (k['aciklama'] ?? '').toString(),
                  tablo: tablo,
                ));
          }
          enAzBirTanesiBasariliMi = true;
        } else {
          sonHata = '$dosyaAdi alınamadı (Kod ${response.statusCode})';
        }
      } catch (e) {
        sonHata = '$dosyaAdi alınamadı';
      }
    }

    if (!mounted) return;
    if (enAzBirTanesiBasariliMi) {
      setState(() {
        _kategoriler.clear();
        _kategoriler.addAll(gruplar);
        _yukleniyor = false;
      });
    } else {
      setState(() { _hata = '${sonHata ?? DilServisi.metin('icerikAlinamadi')}. Dosyalar GitHub\'a yüklendi mi?'; _yukleniyor = false; });
    }
  }  // --- _icerigiYukle() sonu ---

  @override
  Widget build(BuildContext context) {
    final kategoriAdlari = _kategoriler.keys.toList()..sort();
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(
        shape: AppSablon.appBarSekli,
        clipBehavior: Clip.antiAlias,
        title: Text(DilServisi.metin('gidaDegisimListesi')),
        backgroundColor: AppRenkleri.aktif,
        foregroundColor: Colors.white,
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          setState(() => _yukleniyor = true);
          await _icerigiYukle();
        },
        child: _yukleniyor
            ? const Center(child: CircularProgressIndicator())
            : _hata != null
                ? ListView(
                    children: [
                      const SizedBox(height: 120),
                      Icon(Icons.wifi_off, size: 48, color: Colors.grey.shade400),
                      const SizedBox(height: 12),
                      Center(child: Text(_hata!, style: TextStyle(color: Colors.grey.shade600), textAlign: TextAlign.center)),
                      const SizedBox(height: 12),
                      Center(
                        child: TextButton.icon(
                          onPressed: _icerigiYukle,
                          icon: const Icon(Icons.refresh),
                          label: Text(DilServisi.metin('tekrarDene')),
                        ),
                      ),
                    ],
                  )
                : kategoriAdlari.isEmpty
                    ? Center(child: Text(DilServisi.metin('henuzIcerikYok')))
                    : ListView.builder(
                        padding: const EdgeInsets.all(12),
                        itemCount: kategoriAdlari.length,
                        itemBuilder: (context, index) {
                          final kategori = kategoriAdlari[index];
                          final kartlar = _kategoriler[kategori]!;
                          return Card(
                            margin: const EdgeInsets.only(bottom: 10),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                            child: ListTile(
                              leading: CircleAvatar(
                                backgroundColor: AppRenkleri.aktif.shade50,
                                child: Icon(Icons.folder_open, color: AppRenkleri.aktif.shade700),
                              ),
                              title: Text(kategori, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                              subtitle: Text('${kartlar.length} ${DilServisi.metin('madde')}'),
                              trailing: const Icon(Icons.chevron_right),
                              onTap: () => Navigator.push(
                                context,
                                MaterialPageRoute(builder: (_) => _KategoriMaddeleriEkrani(baslik: kategori, kartlar: kartlar)),
                              ),
                            ),
                          );
                        },
                      ),
      ),
    );
  }  // --- build() sonu ---
}  // --- _GidaDegisimListesiEkraniState sonu ---

// Bir kategorinin içindeki maddeleri NUMARALI liste olarak gösterir,
// maddeye dokununca detayını açar (tablo varsa gerçek tablo, yoksa metin).
class _KategoriMaddeleriEkrani extends StatelessWidget {
  final String baslik;
  final List<_KutuphaneKarti> kartlar;
  const _KategoriMaddeleriEkrani({required this.baslik, required this.kartlar});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(
        shape: AppSablon.appBarSekli,
        clipBehavior: Clip.antiAlias,
        title: Text(baslik),
        backgroundColor: AppRenkleri.aktif,
        foregroundColor: Colors.white,
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: kartlar.length,
        itemBuilder: (context, index) {
          final kart = kartlar[index];
          return Card(
            margin: const EdgeInsets.only(bottom: 8),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: AppRenkleri.aktif.shade50,
                child: Text('${index + 1}', style: TextStyle(color: AppRenkleri.aktif.shade700, fontWeight: FontWeight.bold)),
              ),
              title: Text(kart.baslik),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => _KartDetayEkrani(kart: kart)),
              ),
            ),
          );
        },
      ),
    );
  }  // --- build() sonu ---
}  // --- _KategoriMaddeleriEkrani sonu ---

// Kartın tam detayını gösterir. "tablo" doluysa gerçek satır-sütun tablo
// çizer (Yiyecek Adı | Ölçü | Miktar); yoksa düz metin (aciklama) gösterir.
class _KartDetayEkrani extends StatelessWidget {
  final _KutuphaneKarti kart;
  const _KartDetayEkrani({required this.kart});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(
        shape: AppSablon.appBarSekli,
        clipBehavior: Clip.antiAlias,
        title: Text(kart.baslik),
        backgroundColor: AppRenkleri.aktif,
        foregroundColor: Colors.white,
      ),
      body: kart.tablo != null && kart.tablo!.isNotEmpty
          ? SingleChildScrollView(
              padding: const EdgeInsets.all(12),
              child: Card(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
                clipBehavior: Clip.antiAlias,
                child: Table(
                  border: TableBorder.all(color: Colors.grey.shade300, width: 1),
                  columnWidths: const {
                    0: FlexColumnWidth(2.2),
                    1: FlexColumnWidth(2),
                    2: FlexColumnWidth(1.2),
                  },
                  children: [
                    TableRow(
                      decoration: BoxDecoration(color: AppRenkleri.aktif.shade50),
                      children: [
                        _hucre(DilServisi.metin('yiyecekAdi'), kalin: true),
                        _hucre(DilServisi.metin('ortalamaOlcu'), kalin: true),
                        _hucre(DilServisi.metin('miktar'), kalin: true),
                      ],
                    ),
                    for (final satir in kart.tablo!)
                      TableRow(
                        children: [
                          _hucre(satir['isim'] ?? ''),
                          _hucre(satir['olcu'] ?? ''),
                          _hucre(satir['miktar'] ?? ''),
                        ],
                      ),
                  ],
                ),
              ),
            )
          : Padding(
              padding: const EdgeInsets.all(16),
              child: SingleChildScrollView(
                child: SelectableText(kart.aciklama, style: const TextStyle(fontSize: 14, height: 1.4)),
              ),
            ),
    );
  }  // --- build() sonu ---

  Widget _hucre(String metin, {bool kalin = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
      child: Text(
        metin,
        style: TextStyle(fontSize: 13, fontWeight: kalin ? FontWeight.bold : FontWeight.normal),
      ),
    );
  }  // --- _hucre() sonu ---
}  // --- _KartDetayEkrani sonu ---
