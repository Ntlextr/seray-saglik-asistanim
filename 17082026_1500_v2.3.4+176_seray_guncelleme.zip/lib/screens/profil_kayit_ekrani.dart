import "package:seray_saglik_asistanim/screens/ana_sayfa.dart";
import '../theme/renkler.dart';
import '../theme/sablon.dart';
import '../services/il_ilce_verisi.dart';
import '../services/dil_servisi.dart';
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import '../services/profil_yoneticisi.dart';
import '../services/istatistik_servisi.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:seray_saglik_asistanim/main.dart';
import 'kritik_izinler_ekrani.dart';

class ProfilKayitEkrani extends StatefulWidget {
  const ProfilKayitEkrani({Key? key}) : super(key: key);

  @override
  State<ProfilKayitEkrani> createState() => _ProfilKayitEkraniState();
}

class _ProfilKayitEkraniState extends State<ProfilKayitEkrani> {
  final GlobalKey<_ProfilKayitFormState> _formKey = GlobalKey<_ProfilKayitFormState>();

  bool _kullanimKosullari = false;
  bool _gizlilikPolitikasi = false;
  bool _aydinlatmaMetni = false;
  bool _rizaMetni = false;
  bool _kampanyaOnay = false;

  bool _kullanimOkundu = false;
  bool _gizlilikOkundu = false;
  bool _aydinlatmaOkundu = false;
  bool _rizaOkundu = false;

  // ======== AÇIK RIZA — MADDE MADDE ONAY ========
  // KVKK'nın "parçalı rıza" ilkesi gereği her madde AYRI işaretlenebilir
  // olmalı — tek bir "hepsini kabul et" kutusu yeterli değil. Bu 5 bayrak,
  // SharedPreferences'a ayrı ayrı kaydedilir; ileride Ayarlar ekranından
  // tek tek değiştirilebilir hâle getirilebilir.
  //
  // _rizaSaglikVerisi ZORUNLUDUR — uygulamanın temel işlevi (ölçüm kaydı)
  // bu veri olmadan çalışamaz. Diğer 4 madde İSTEĞE BAĞLIDIR; işaretlenmese
  // bile "Okudum, Kabul Ediyorum"a basılıp devam edilebilir, yalnızca o
  // maddeyle ilgili özellik (yedekleme/SMS/bildirim/AI analizi) etkilenir.
  bool _rizaSaglikVerisi = false;
  bool _rizaAiAnalizi = false;
  bool _rizaYedekleme = false;
  bool _rizaSmsAcil = false;
  bool _rizaBildirim = false;
  // YENİ: sağlık verisinden AYRI — sadece ad-soyad+şehir+kullanım
  // istatistiği için, opsiyonel (zorunlu değil).
  bool _rizaIstatistik = false;

  Future<void> _rizaTercihleriniKaydet() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('riza_saglik_verisi', _rizaSaglikVerisi);
    await prefs.setBool('riza_ai_analizi', _rizaAiAnalizi);
    await prefs.setBool('riza_yedekleme', _rizaYedekleme);
    await prefs.setBool('riza_sms_acil', _rizaSmsAcil);
    await prefs.setBool('riza_bildirim', _rizaBildirim);
    await prefs.setBool('riza_istatistik_onay', _rizaIstatistik);
  }  // --- _rizaTercihleriniKaydet() sonu ---


  // KVKK/Rıza METİNLERİ artık Cloudflare'den çekiliyor (Ayarlar ekranındaki
  // gibi) — internet yoksa aşağıdaki yerel yedek metinler gösterilir.
  static const String _yerelKvkkYedek = '''
KİŞİSEL VERİLERİN KORUNMASI AYDINLATMA METNİ

0. Veri Sorumlusunun Kimliği
6698 sayılı Kişisel Verilerin Korunması Kanunu ("KVKK") uyarınca, aşağıda açıklanan kişisel verileriniz veri sorumlusu sıfatıyla Seray Teknoloji ("Uygulama", "biz") tarafından bu metinde açıklanan amaç ve kapsamda işlenmektedir. İletişim: seraysaglikasistanim@gmail.com

1. Toplanan Veriler
Ad-soyad, yaş, diyabet durumu gibi profil bilgileriniz; girdiğiniz tansiyon, kan şekeri, nabız, kilo, su, adım, ilaç/insülin, beslenme ve e-Nabız tahlil sonuçlarınızı içeren özel nitelikli sağlık verileriniz; onayınızla girdiğiniz acil durum kişisinin adı/telefonu; Seray AI sohbet geçmişiniz; cihaz ve hata (crash) kayıtları işlenir. Ayrıca, uygulamamızı kaç kişinin kullandığını görebilmemiz ve genel kullanım istatistiklerini takip edebilmemiz amacıyla ad-soyadınız ve yaşadığınız şehir, kayıt sırasında ayrıca alınır; bu bilgi şeker/tansiyon/ilaç gibi sağlık verilerinizden TAMAMEN AYRIDIR.

2. Verilerin Saklanma Yeri
Tüm ölçüm/sağlık verileriniz öncelikli olarak kendi cihazınızda (yerel SQLite veritabanında) saklanır. Ad-soyad ve şehir bilginiz ile uygulamayı ne sıklıkla kullandığınıza dair genel istatistikler ise (madde 1'de açıklandığı gibi) merkezi bir sistemde ayrıca tutulur — bu, sağlık verilerinizin cihazınızın dışına çıkması anlamına gelmez, sadece kimlik/kullanım bilgisi için geçerlidir. Kendi isteğinizle yapacağınız veri yedekleme/geri yükleme işlemleri için Firebase ve Google Drive güvenli bulut altyapıları kullanılır; bu yedekleme verileri şifreli tutulur ve üçüncü şahıslarla paylaşılmaz.

3. Yapay Zeka Analizi
e-Nabız tahlillerinizi, ilaçlarınızı veya beslenme kayıtlarınızı analiz ettirmek ya da Seray AI'a soru sormak istediğinizde, ilgili içerik veri güvenliğini ve API gizliliğini sağlamak amacıyla aracı bir Cloudflare Worker sunucusu üzerinden şifreli bağlantıyla (HTTPS) yapay zeka servis sağlayıcısına (OpenAI GPT-4o-mini) iletilir. Gönderilen verilerde gerçek kimlik bilgileriniz yer almaz, yalnızca ölçüm rakamları/sorunuz analiz edilir; bu içerik yapay zeka modellerini eğitmek amacıyla kullanılmaz veya sunucularda saklanmaz.

4. Kritik Ölçüm Bildirimi
Çok yüksek/çok düşük bir ölçüm kaydettiğinizde, sizin onayınızla ve sizin tetiklemenizle, Ayarlar'da belirlediğiniz acil durum kişisine cihazınızın kendi SMS uygulaması üzerinden bilgilendirme mesajı gönderme seçeneği sunulur; bu mesaj Uygulama sunucularından değil, doğrudan cihazınızdan gönderilir.

5. Cihaz İzinleri
Uygulama; kamera (nabız ölçümü ve ilaç kutusu fotoğrafı için), bildirimler (ilaç/su hatırlatmaları için), adım sayar/hareket sensörü ve isteğe bağlı Health Connect izinlerini yalnızca ilgili özellik kullanıldığında talep eder.

6. Yedekleme ve Paylaşım
"Yedekle" veya "Sonuçları Paylaş" özelliklerini kullandığınızda, oluşturulan dosya yalnızca sizin seçtiğiniz uygulama, kişi veya Firebase/Google Drive bulut hesabınızla paylaşılır. Bu paylaşımın sorumluluğu kullanıcıya aittir.

7. Hukuki Sebep
Genel kullanım verileri KVKK m.5/2 (meşru menfaat, sözleşmenin ifası) kapsamında; sağlık verisi gibi özel nitelikli verileriniz ise KVKK m.6 uyarınca yalnızca açık rızanızla işlenir (bkz. Açık Rıza Metni).

8. Haklarınız (KVKK m.11)
Verilerinizin işlenip işlenmediğini öğrenme; işlenmişse bilgi talep etme; işlenme amacına uygun kullanılıp kullanılmadığını öğrenme; yurt içinde/yurt dışında aktarıldığı kişileri bilme; eksik/yanlış işlenmişse düzeltilmesini isteme; KVKK'da öngörülen şartlarda silinmesini/yok edilmesini isteme; bu işlemlerin aktarılan taraflara bildirilmesini isteme; kanuna aykırı işlenme nedeniyle zarara uğramanız halinde zararın giderilmesini talep etme haklarına sahipsiniz. Uygulama içinden "Verileri Sıfırla" butonuna basmanız veya uygulamayı cihazınızdan silmeniz, yerel veritabanındaki tüm verilerinizi kalıcı olarak temizler. Sorularınız için seraysaglikasistanim@gmail.com adresinden bize ulaşabilirsiniz.

9. Sorumluluk Reddi
Uygulamanın kullanımından doğabilecek her türlü veri kaybı, cihaz arızası veya diğer teknik sorunlardan Seray Teknoloji sorumlu tutulamaz; uygulamanın kullanımı tamamen kullanıcının kendi sorumluluğundadır. Uygulama tıbbi teşhis veya tedavi amacı taşımaz, sağlıkla ilgili kararlarınız için mutlaka doktorunuza danışın.
''';
  static const String _yerelRizaYedek = '''
AÇIK RIZA METNİ

Bu metin, yukarıdaki Aydınlatma Metni'nden ayrıdır. Sağlık verileriniz yalnızca onay verdiğiniz madde ölçüsünde işlenir; onaylamadığınız bir madde varsa yalnızca o özellik çalışmaz, uygulamanın temel ölçüm/kayıt kullanımı bu onaylara bağlı değildir.

☐ Şeker, tansiyon, nabız, kilo, su, adım, ilaç ve beslenme verilerim dahil sağlık verilerimin, uygulama içinde bana hizmet sunulması amacıyla işlenmesine,
☐ e-Nabız tahlillerimin, ilaçlarımın/beslenme kayıtlarımın ve Seray AI'a sorduğum soruların; anonimleştirilerek, aracı bir Cloudflare Worker sunucusu üzerinden yapay zeka servis sağlayıcısına (OpenAI GPT-4o-mini) iletilip analiz edilmesine,
☐ Verilerimin kendi isteğimle Firebase ve Google Drive altyapısında şifreli olarak yedeklenmesine (isteğe bağlı — onay vermezsem verilerim yalnızca cihazımda kalır),
☐ Kritik bir ölçüm kaydettiğimde, belirlediğim acil durum kişisine SMS ile bilgilendirme gönderme seçeneğinin bana sunulmasına,
☐ İlaç ve su hatırlatmalarımın zamanında iletilmesi için bildirim gönderilmesine
☐ Ad-soyadımın ve şehir bilgimin, uygulama istatistiklerini takip etme amacıyla merkezi bir sistemde saklanmasına (sağlık verilerimden ayrı olarak — bu onayı vermesem bile temel ölçüm/kayıt özelliklerini kullanabileceğimi biliyorum)

açık rıza gösteriyorum. Bu veriler yalnızca o anki analiz/seslendirme ve yedekleme işlemleri için kullanılır; yapay zeka modellerini eğitmek amacıyla üçüncü taraflarca saklanmaz veya işlenmez. Uygulamanın kesinlikle bir doktor teşhisi koymadığını, tıbbi tavsiye vermediğini ve acil klinik müdahale aracı olmadığını kabul ediyorum. Bu onayları dilediğim zaman Ayarlar ekranından geri çekebilirim; geri çekmem, öncesinde gerçekleştirilmiş işlemleri geçersiz kılmaz.
''';
  String _kvkkIcerik = _yerelKvkkYedek;
  String _rizaIcerik = _yerelRizaYedek;

  @override
  void initState() {
    super.initState();
    _icerigiCloudflaredanCek();
  }

  Future<void> _icerigiCloudflaredanCek() async {
    try {
      final response = await http
          .get(Uri.parse('https://empty-union-ce11.serdarcirak.workers.dev/icerik'))
          .timeout(const Duration(seconds: 8));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (mounted) {
          setState(() {
            _kvkkIcerik = data['kvkk'] ?? _yerelKvkkYedek;
            _rizaIcerik = data['riza'] ?? _yerelRizaYedek;
          });
        }
      }
    } catch (_) {
      // İnternet yoksa yerel yedek metinler zaten gösteriliyor.
    }
  }

  bool get _kayitButonuAktifMi {
    return _aydinlatmaOkundu && _rizaOkundu;
  }

  void _metniOkuVeOnayla({
    required String baslik,
    required String icerik,
    required Function(bool) onOnay,
  }) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        return DraggableScrollableSheet(
          initialChildSize: 0.75,
          minChildSize: 0.5,
          maxChildSize: 0.95,
          expand: false,
          builder: (context, scrollController) {
            return Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    baslik,
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF111424),
                    ),
                  ),
                  const SizedBox(height: 15),
                  Expanded(
                    child: ListView(
                      controller: scrollController,
                      children: [
                        Text(
                          icerik,
                          style: const TextStyle(
                            fontSize: 15,
                            color: Colors.black87,
                            height: 1.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 15),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF111424),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
                        ),
                      ),
                      onPressed: () {
                        onOnay(true);
                        Navigator.pop(context);
                      },
                      child: const Text(
                        'Okudum, Kabul Ediyorum',
                        style: TextStyle(color: Colors.white, fontSize: 16),
                      ),
                    ),
                  )
                ],
              ),
            );
          },
        );
      },
    );
  }

  // ======== AÇIK RIZA — MADDE MADDE İŞARETLENEBİLİR EKRAN ========
  // Aydınlatma Metni'nden farklı olarak burada tek "kabul et" butonu
  // yetmiyor: her rıza maddesi kendi başına, gerçekten dokunulabilir bir
  // Checkbox ile işaretlenmeli (KVKK'nın "parçalı rıza" ilkesi). Sağlık
  // verisi maddesi zorunlu (uygulama onsuz çalışamaz); diğer 4 madde
  // isteğe bağlı — işaretlenmese de devam edilebilir.
  void _rizaMetniniGosterVeOnayla() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            bool zorunluIsaretliMi() => _rizaSaglikVerisi;

            Widget rizaMaddesi({
              required String baslik,
              required bool zorunlu,
              required bool deger,
              required void Function(bool) onDegisti,
            }) {
              return CheckboxListTile(
                value: deger,
                onChanged: (v) => setSheetState(() => onDegisti(v ?? false)),
                controlAffinity: ListTileControlAffinity.leading,
                contentPadding: EdgeInsets.zero,
                dense: false,
                title: Text(
                  baslik,
                  style: TextStyle(
                    fontSize: 14.5,
                    height: 1.4,
                    color: Colors.black87,
                    fontWeight: zorunlu ? FontWeight.w600 : FontWeight.normal,
                  ),
                ),
                subtitle: zorunlu
                    ? Padding(
                        padding: const EdgeInsets.only(top: 2),
                        child: Text(DilServisi.metin('rizaZorunlu'),
                            style: const TextStyle(fontSize: 11.5, color: Colors.redAccent)),
                      )
                    : Padding(
                        padding: const EdgeInsets.only(top: 2),
                        child: Text(DilServisi.metin('rizaIstegeBagli'),
                            style: const TextStyle(fontSize: 11.5, color: Colors.grey)),
                      ),
              );
            }  // --- rizaMaddesi() sonu ---

            return DraggableScrollableSheet(
              initialChildSize: 0.85,
              minChildSize: 0.5,
              maxChildSize: 0.95,
              expand: false,
              builder: (context, scrollController) {
                return Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    children: [
                      Container(
                        width: 40,
                        height: 4,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade300,
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      const SizedBox(height: 20),
                      const Text(
                        'Açık Rıza Metni',
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Color(0xFF111424)),
                      ),
                      const SizedBox(height: 15),
                      Expanded(
                        child: ListView(
                          controller: scrollController,
                          children: [
                            const Text(
                              'Sağlık verileriniz yalnızca aşağıda ayrı ayrı onay verdiğiniz madde ölçüsünde işlenir. Zorunlu madde dışındakiler işaretlenmese de devam edebilirsiniz — yalnızca ilgili özellik çalışmaz.',
                              style: TextStyle(fontSize: 13.5, color: Colors.black54, height: 1.4),
                            ),
                            const SizedBox(height: 12),
                            rizaMaddesi(
                              baslik: 'Şeker, tansiyon, nabız, kilo, su, adım, ilaç ve beslenme verilerim dahil sağlık verilerimin, uygulama içinde bana hizmet sunulması amacıyla işlenmesine izin veriyorum.',
                              zorunlu: true,
                              deger: _rizaSaglikVerisi,
                              onDegisti: (v) => _rizaSaglikVerisi = v,
                            ),
                            const Divider(height: 1),
                            rizaMaddesi(
                              baslik: 'e-Nabız tahlillerimin, ilaçlarımın/beslenme kayıtlarımın ve Seray AI\'a sorduğum soruların, aracı bir Cloudflare Worker üzerinden yapay zeka servis sağlayıcısına iletilip analiz edilmesine izin veriyorum.',
                              zorunlu: false,
                              deger: _rizaAiAnalizi,
                              onDegisti: (v) => _rizaAiAnalizi = v,
                            ),
                            const Divider(height: 1),
                            rizaMaddesi(
                              baslik: 'Verilerimin kendi isteğimle Firebase ve Google Drive altyapısında şifreli olarak yedeklenmesine izin veriyorum.',
                              zorunlu: false,
                              deger: _rizaYedekleme,
                              onDegisti: (v) => _rizaYedekleme = v,
                            ),
                            const Divider(height: 1),
                            rizaMaddesi(
                              baslik: 'Kritik bir ölçüm kaydettiğimde, belirlediğim acil durum kişisine SMS ile bilgilendirme gönderme seçeneğinin bana sunulmasına izin veriyorum.',
                              zorunlu: false,
                              deger: _rizaSmsAcil,
                              onDegisti: (v) => _rizaSmsAcil = v,
                            ),
                            const Divider(height: 1),
                            rizaMaddesi(
                              baslik: 'İlaç ve su hatırlatmalarımın zamanında iletilmesi için bildirim gönderilmesine izin veriyorum.',
                              zorunlu: false,
                              deger: _rizaBildirim,
                              onDegisti: (v) => _rizaBildirim = v,
                            ),
                            const Divider(height: 1),
                            rizaMaddesi(
                              baslik: 'Ad-soyadımın ve şehir bilgimin, uygulama istatistiklerini takip etme amacıyla merkezi bir sistemde saklanmasına izin veriyorum (sağlık verilerimden ayrı olarak — bu onayı vermesem bile temel ölçüm/kayıt özelliklerini kullanabileceğimi biliyorum).',
                              zorunlu: false,
                              deger: _rizaIstatistik,
                              onDegisti: (v) => _rizaIstatistik = v,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 15),
                      SizedBox(
                        width: double.infinity,
                        height: 50,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: zorunluIsaretliMi() ? const Color(0xFF111424) : Colors.grey.shade300,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
                          ),
                          onPressed: !zorunluIsaretliMi()
                              ? null
                              : () async {
                                  await _rizaTercihleriniKaydet();
                                  setState(() {
                                    _rizaOkundu = true;
                                    _rizaMetni = true;
                                  });
                                  if (context.mounted) Navigator.pop(context);
                                },
                          child: Text(
                            zorunluIsaretliMi() ? 'Onaylarımı Kaydet' : 'Devam etmek için zorunlu maddeyi işaretleyin',
                            style: TextStyle(
                              color: zorunluIsaretliMi() ? Colors.white : Colors.grey.shade600,
                              fontSize: 15,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            );
          },
        );
      },
    );
  }  // --- _rizaMetniniGosterVeOnayla() sonu ---

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        shape: AppSablon.appBarSekli,
        clipBehavior: Clip.antiAlias,
        title: Text(
          DilServisi.metin('profilKayitBaslik'),
          style: const TextStyle(
            color: Color(0xFF111424),
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Color(0xFF111424)),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(bottom: 20.0),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Image.asset(
                    'assets/images/seray_banner.png',
                    width: double.infinity,
                    fit: BoxFit.fitWidth,
                    errorBuilder: (context, error, stackTrace) => Container(
                      width: double.infinity,
                      height: 90,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(color: AppRenkleri.aktif, borderRadius: BorderRadius.circular(16)),
                      child: const Text('SERAY SAĞLIK ASİSTANIM', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18)),
                    ),
                  ),
                ),
              ),
              ProfilKayitForm(key: _formKey),
              const SizedBox(height: 30),
              const Divider(height: 1),
              const SizedBox(height: 20),
              _buildYasalSatir(
                baslik: 'Aydınlatma metni',
                isZorunlu: true,
                value: _aydinlatmaMetni,
                onTap: () {
                  _metniOkuVeOnayla(
                    baslik: 'KVKK Aydınlatma Metni',
                    icerik: _kvkkIcerik,
                    onOnay: (onay) => setState(() {
                      _aydinlatmaOkundu = onay;
                      _aydinlatmaMetni = onay;
                    }),
                  );
                },
              ),

              _buildYasalSatir(
                baslik: 'Rıza metni',
                isZorunlu: true,
                value: _rizaMetni,
                onTap: () => _rizaMetniniGosterVeOnayla(),
              ),

              const SizedBox(height: 32),

              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _kayitButonuAktifMi ? const Color(0xFF111424) : Colors.grey.shade300,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                    elevation: _kayitButonuAktifMi ? 2 : 0,
                  ),
                  onPressed: _kayitButonuAktifMi
                      ? () async {
                          final basarili = await _formKey.currentState?.profiliKaydet() ?? false;
                          if (!basarili) {
                            if (mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text(DilServisi.metin('ilIlceSecin'))),
                              );
                            }
                            return;
                          }
                          final prefs = await SharedPreferences.getInstance();
                          // ÖNEMLİ: İzinler CİHAZ genelinde verilir, profile
                          // özel değildir — "is_logged_in" zaten TRUE ise
                          // (yani bu, uygulamanın İLK kurulumu değil, sonradan
                          // eklenen bir AİLE profili) izin sihirbazını tekrar
                          // göstermeye gerek yok, doğrudan Ana Sayfa'ya gidilir.
                          final zatenKuruluMu = prefs.getBool('is_logged_in') ?? false;
                          await prefs.setBool('is_logged_in', true);

                          if (mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text(DilServisi.metin('profilKaydedildi'))),
                            );
                            if (zatenKuruluMu) {
                              Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(builder: (context) => const AnaEkranYonlendirici()),
                              );
                              return;
                            }
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                builder: (context) => KritikIzinlerEkrani(
                                  onTamamlandi: () {
                                    Navigator.pushReplacement(
                                      context,
                                      MaterialPageRoute(builder: (context) => const AnaEkranYonlendirici()),
                                    );
                                  },
                                ),
                              ),
                            );
                          }
                        }
                      : null,
                  child: Text(
                    'Sonraki',
                    style: TextStyle(
                      color: _kayitButonuAktifMi ? Colors.white : Colors.grey.shade600,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildYasalSatir({
    required String baslik,
    required bool isZorunlu,
    required bool value,
    required VoidCallback onTap,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 4),
      padding: const EdgeInsets.symmetric(vertical: 6),
      decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Colors.grey.shade300))),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: GestureDetector(
              onTap: onTap,
              child: RichText(
                text: TextSpan(
                  style: const TextStyle(fontSize: 14, color: Colors.black87),
                  children: [
                    if (isZorunlu)
                      const TextSpan(text: '* ', style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
                    const TextSpan(text: 'Okudum ve kabul ediyorum '),
                    TextSpan(text: baslik, style: const TextStyle(fontWeight: FontWeight.bold, decoration: TextDecoration.underline)),
                  ],
                ),
              ),
            ),
          ),
          Switch(
            value: value,
            activeColor: const Color(0xFF00cc88),
            onChanged: (bool newValue) {
              onTap();
            },
          ),
        ],
      ),
    );
  }
}
class ProfilKayitForm extends StatefulWidget {
  const ProfilKayitForm({Key? key}) : super(key: key);

  @override
  State<ProfilKayitForm> createState() => _ProfilKayitFormState();
}

class _ProfilKayitFormState extends State<ProfilKayitForm> {
  final _adController = TextEditingController();
  final _soyadController = TextEditingController();
  final _yasController = TextEditingController();
  final _boyController = TextEditingController();
  // ÖNEMLİ DEĞİŞİKLİK: Şehir artık serbest metin değil, gerçek Türkiye
  // verisiyle (81 il, 957 ilçe — bkz. il_ilce_verisi.dart) iki kademeli
  // (İl seçilince İlçe listesi değişir) ZORUNLU bir seçici. İstatistik
  // amaçlı — sağlık verisi DEĞİLDİR.
  String? _secilenIl;
  String? _secilenIlce;
  String _cinsiyet = 'Bay';
  String _diyabetTuru = 'Tip 2 Diyabet';
  String? _fotoYolu;

  @override
  void initState() {
    super.initState();
    _mevcutBilgileriYukle();
  }

  Future<void> _mevcutBilgileriYukle() async {
    final prefs = await SharedPreferences.getInstance();
    final py = ProfilYoneticisi();
    final adAnahtari = await py.profilAnahtari('kullanici_ad');
    final soyadAnahtari = await py.profilAnahtari('kullanici_soyad');
    final yasAnahtari = await py.profilAnahtari('kullanici_yas');
    final boyAnahtari = await py.profilAnahtari('kullanici_boy');
    final cinsiyetAnahtari = await py.profilAnahtari('kullanici_cinsiyet');
    final diyabetAnahtari = await py.profilAnahtari('kullanici_diyabet_turu');
    final fotoAnahtari = await py.profilAnahtari('kullanici_foto_yolu');
    final ilAnahtari = await py.profilAnahtari('kullanici_il');
    final ilceAnahtari = await py.profilAnahtari('kullanici_ilce');
    setState(() {
      _adController.text = prefs.getString(adAnahtari) ?? '';
      _soyadController.text = prefs.getString(soyadAnahtari) ?? '';
      _yasController.text = prefs.getString(yasAnahtari) ?? '';
      _boyController.text = prefs.getString(boyAnahtari) ?? '';
      _cinsiyet = prefs.getString(cinsiyetAnahtari) ?? 'Bay';
      _diyabetTuru = prefs.getString(diyabetAnahtari) ?? 'Tip 2 Diyabet';
      _fotoYolu = prefs.getString(fotoAnahtari);
      _secilenIl = prefs.getString(ilAnahtari);
      _secilenIlce = prefs.getString(ilceAnahtari);
    });
  }

  Future<void> _fotoSec() async {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (context) {
        return SafeArea(
          child: Wrap(
            children: [
              ListTile(
                leading: const Icon(Icons.photo_camera),
                title: Text(DilServisi.metin('kameradanCek')),
                onTap: () async {
                  Navigator.pop(context);
                  await _fotografiAl(ImageSource.camera);
                },
              ),
              ListTile(
                leading: const Icon(Icons.photo_library),
                title: Text(DilServisi.metin('galeridenSec')),
                onTap: () async {
                  Navigator.pop(context);
                  await _fotografiAl(ImageSource.gallery);
                },
              ),
              if (_fotoYolu != null)
                ListTile(
                  leading: const Icon(Icons.delete_outline, color: Colors.red),
                  title: Text(DilServisi.metin('fotografiKaldir'), style: const TextStyle(color: Colors.red)),
                  onTap: () async {
                    Navigator.pop(context);
                    final prefs = await SharedPreferences.getInstance();
                    await prefs.remove(await ProfilYoneticisi().profilAnahtari('kullanici_foto_yolu'));
                    setState(() => _fotoYolu = null);
                  },
                ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _fotografiAl(ImageSource kaynak) async {
    try {
      // ÖNEMLİ DÜZELTME: Kamera izni verilmemişse (özellikle silinip yeniden
      // kurulan cihazlarda — izinler HER zaman sıfırlanır), ImagePicker
      // hiçbir hata fırlatmadan SESSİZCE null dönüyordu — kullanıcı "iki kez
      // denedim, olmadı" diyip kalıyordu, sebebi hiç görünmüyordu. Artık
      // kameradan çekmeden önce izin açıkça isteniyor ve reddedilirse
      // kullanıcıya NEDEN gösteriliyor.
      if (kaynak == ImageSource.camera) {
        final izin = await Permission.camera.request();
        if (!izin.isGranted) {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(DilServisi.metin('kameraIzniVerilmedi'))),
            );
          }
          return;
        }
      }
      final XFile? secilen = await ImagePicker().pickImage(source: kaynak, maxWidth: 500, imageQuality: 65);
      if (secilen != null) {
        // ÖNEMLİ DÜZELTME: Önceden ImagePicker'ın GEÇİCİ (cache) dosya
        // yolu doğrudan kaydediliyordu — sistem bu dosyayı istediği an
        // silebilir, üstelik yedeğe de hiç girmiyordu. Artık yemek/ilaç
        // fotoğraflarıyla AYNI yöntemle kalıcı bir dosyaya kopyalanıyor.
        final belgeler = await getApplicationDocumentsDirectory();
        final hedefYolu = await ProfilYoneticisi().profilFotoYolu(belgeler.path);
        final kaliciDosya = await File(secilen.path).copy(hedefYolu);
        // Aynı önbellek düzeltmesi (bkz. profil_sayfasi.dart) — aynı dosya
        // yoluna ikinci kez fotoğraf kaydedilince Flutter eskisini gösterir.
        await FileImage(kaliciDosya).evict();
        setState(() => _fotoYolu = kaliciDosya.path);
      } else if (mounted) {
        // secilen null ise ya kullanıcı vazgeçti ya da galeri/kamera
        // erişimi engellendi — sessizce geçmek yerine kısa bir bilgi ver.
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(DilServisi.metin('fotografSecilmedi'))),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(DilServisi.metin('fotografSecimSorunu'))));
      }
    }
  }

  // ÖNEMLİ DEĞİŞİKLİK: artık Future<bool> döndürüyor — İl/İlçe seçilmemişse
  // (artık ZORUNLU) kayıt reddedilir, çağıran taraf false görüp kullanıcıyı
  // uyarabilir.
  Future<bool> profiliKaydet() async {
    if (_secilenIl == null || _secilenIlce == null) {
      return false;
    }
    final prefs = await SharedPreferences.getInstance();
    final py = ProfilYoneticisi();
    await prefs.setString(await py.profilAnahtari('kullanici_ad'), _adController.text.trim());
    await prefs.setString(await py.profilAnahtari('kullanici_soyad'), _soyadController.text.trim());
    await prefs.setString(await py.profilAnahtari('kullanici_yas'), _yasController.text.trim());
    await prefs.setString(await py.profilAnahtari('kullanici_boy'), _boyController.text.trim());
    await prefs.setString(await py.profilAnahtari('kullanici_cinsiyet'), _cinsiyet);
    await prefs.setString(await py.profilAnahtari('kullanici_diyabet_turu'), _diyabetTuru);
    await prefs.setString(await py.profilAnahtari('kullanici_il'), _secilenIl!);
    await prefs.setString(await py.profilAnahtari('kullanici_ilce'), _secilenIlce!);
    if (_fotoYolu != null) {
      await prefs.setString(await py.profilAnahtari('kullanici_foto_yolu'), _fotoYolu!);
    }
    // Bu profilin görünen adını (Ayarlar > Profiller listesindeki) da
    // güncel tut — kullanıcı adını sonradan değiştirirse liste eski
    // kalmasın diye.
    final aktifId = await py.aktifProfilId();
    final tamAd = '${_adController.text.trim()} ${_soyadController.text.trim()}'.trim();
    if (tamAd.isNotEmpty) {
      await py.profilAdiniGuncelle(aktifId, tamAd);
    }
    // YENİ: kullanıcı "istatistik" rıza maddesini onayladıysa (Ayarlar'da
    // veya ilk kayıt sırasında), ad-soyad+şehir'i admin panel için
    // worker.js'e gönder. Onaylamadıysa hiçbir şey gönderilmez.
    final istatistikRizasi = prefs.getBool('riza_istatistik_onay') ?? false;
    final sehirMetni = '$_secilenIl / $_secilenIlce';
    if (istatistikRizasi && tamAd.isNotEmpty) {
      // ignore: unawaited_futures
      IstatistikServisi.kaydet(adSoyad: tamAd, sehir: sehirMetni);
    }
    return true;
  }

  @override
  void dispose() {
    _adController.dispose();
    _boyController.dispose();
    _soyadController.dispose();
    _yasController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(DilServisi.metin('kisiselBilgiler'), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Color(0xFF111424))),
        const SizedBox(height: 16),
        Center(
          child: GestureDetector(
            onTap: _fotoSec,
            child: Stack(
              children: [
                CircleAvatar(
                  radius: 50,
                  backgroundColor: AppRenkleri.aktif.shade50,
                  backgroundImage: _fotoYolu != null ? FileImage(File(_fotoYolu!)) : null,
                  child: _fotoYolu == null ? Icon(Icons.person, size: 50, color: AppRenkleri.aktif) : null,
                ),
                Positioned(
                  bottom: 0,
                  right: 0,
                  child: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(color: AppRenkleri.aktif, shape: BoxShape.circle),
                    child: const Icon(Icons.camera_alt, size: 18, color: Colors.white),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 20),
        TextField(
          controller: _adController,
          decoration: InputDecoration(labelText: DilServisi.metin('adiniz'), border: OutlineInputBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)), prefixIcon: const Icon(Icons.person)),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _soyadController,
          decoration: InputDecoration(labelText: DilServisi.metin('soyadiniz'), border: OutlineInputBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)), prefixIcon: const Icon(Icons.person_outline)),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _yasController,
          keyboardType: TextInputType.number,
          decoration: InputDecoration(labelText: DilServisi.metin('yasiniz'), border: OutlineInputBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)), prefixIcon: const Icon(Icons.cake)),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _boyController,
          keyboardType: TextInputType.number,
          decoration: InputDecoration(
            labelText: DilServisi.metin('boyunuz'),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            prefixIcon: const Icon(Icons.height),
            helperText: 'Vücut kitle endeksi ve ideal kilo hesaplaması için kullanılır',
          ),
        ),
        const SizedBox(height: 12),
        // İl/İlçe — İl seçilince İlçe listesi otomatik güncellenir, İlçe
        // değeri il değişince sıfırlanır (eski ilin ilçesi yeni ilde
        // anlamsız kalmasın diye). İkisi de ARTIK ZORUNLU.
        DropdownButtonFormField<String>(
          value: _secilenIl,
          decoration: InputDecoration(labelText: DilServisi.metin('il'), border: OutlineInputBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)), prefixIcon: const Icon(Icons.location_city)),
          isExpanded: true,
          items: IlIlceVerisi.iller.map((il) => DropdownMenuItem(value: il, child: Text(il))).toList(),
          onChanged: (val) {
            setState(() {
              _secilenIl = val;
              _secilenIlce = null;
            });
          },
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: _secilenIlce,
          decoration: InputDecoration(
            labelText: DilServisi.metin('ilce'),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            prefixIcon: const Icon(Icons.map_outlined),
            helperText: 'Sağlık veriniz değildir, sadece uygulama istatistikleri için',
          ),
          isExpanded: true,
          items: (_secilenIl == null ? const <String>[] : (IlIlceVerisi.ilIlceleri[_secilenIl] ?? const <String>[]))
              .map((ilce) => DropdownMenuItem(value: ilce, child: Text(ilce)))
              .toList(),
          onChanged: _secilenIl == null
              ? null
              : (val) => setState(() => _secilenIlce = val),
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: _cinsiyet,
          decoration: InputDecoration(labelText: DilServisi.metin('cinsiyet'), border: OutlineInputBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)), prefixIcon: const Icon(Icons.wc)),
          items: [DropdownMenuItem(value: 'Bay', child: Text(DilServisi.metin('cinsiyetBay'))), DropdownMenuItem(value: 'Bayan', child: Text(DilServisi.metin('cinsiyetBayan')))],
          onChanged: (val) {
            if (val != null) setState(() => _cinsiyet = val);
          },
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: _diyabetTuru,
          decoration: InputDecoration(labelText: DilServisi.metin('diyabetTuru'), border: OutlineInputBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)), prefixIcon: const Icon(Icons.bloodtype)),
          items: const [
            DropdownMenuItem(value: 'Tip 1 Diyabet', child: Text(DilServisi.metin('diyabetTip1'))),
            DropdownMenuItem(value: 'Tip 2 Diyabet', child: Text(DilServisi.metin('diyabetTip2'))),
            DropdownMenuItem(value: 'Gizli Şeker (Prediyabet)', child: Text(DilServisi.metin('diyabetGizli'))),
            DropdownMenuItem(value: 'Gebelik Diyabeti', child: Text(DilServisi.metin('diyabetGebelik'))),
            DropdownMenuItem(value: 'Diyabet Hastası Değilim', child: Text(DilServisi.metin('diyabetYok'))),
          ],
          onChanged: (val) {
            if (val != null) setState(() => _diyabetTuru = val);
          },
        ),
      ],
    );
  }
}
