import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:local_auth/local_auth.dart';
import '../theme/renkler.dart';

import '../theme/sablon.dart';
import '../services/dil_servisi.dart';

// PIN Kilidi ekranı: hem YENİ PIN BELİRLEME hem de MEVCUT PIN'İ DOĞRULAMA
// için kullanılır (mod parametresiyle). PIN VE kurtarma kelimesi,
// SharedPreferences'a basit bir karıştırma (hash) ile saklanır — düz metin
// olarak tutulmaz, ama amaç askeri seviye şifreleme değil: telefonu eline
// alan birinin sağlık verilerini rastgele görmesini engellemek.
//
// KURTARMA MEKANİZMASI: PIN her belirlendiğinde/değiştirildiğinde kullanıcı
// ayrıca bir "kurtarma kelimesi" belirler. PIN'i unutursa, doğrulama
// ekranındaki "PIN'i Unuttum" bağlantısıyla bu kelimeyi girip yeni bir PIN
// belirleyebilir. Kurtarma kelimesi henüz ayarlanmamışsa (eski kurulumlar,
// bu özellik eklenmeden önce PIN belirlemiş kullanıcılar), kullanıcıya
// açıkça bilgi verilir.
enum PinKilitModu { belirle, dogrula }

enum _Adim { pinGir, kurtarmaCevabiGir, yeniPinBelirle, yeniPinTekrar, kurtarmaKelimesiBelirle }

String _metinKaristir(String metin) {
  int toplam = 0;
  final normalize = metin.trim().toLowerCase();
  for (int i = 0; i < normalize.length; i++) {
    toplam = (toplam * 31 + normalize.codeUnitAt(i) + i * 7) & 0x7FFFFFFF;
  }
  return '$toplam-${normalize.length}';
}  // --- _metinKaristir() sonu ---

class PinKilitEkrani extends StatefulWidget {
  final PinKilitModu mod;
  final VoidCallback onBasarili;
  final VoidCallback? onVazgec; // sadece geri/iptal gösterilecekse verilir
  const PinKilitEkrani({Key? key, required this.mod, required this.onBasarili, this.onVazgec}) : super(key: key);

  @override
  State<PinKilitEkrani> createState() => _PinKilitEkraniState();
}  // --- PinKilitEkrani sonu ---

class _PinKilitEkraniState extends State<PinKilitEkrani> {
  final TextEditingController _controller = TextEditingController();
  late _Adim _adim;
  String? _ilkGirilenPin; // belirleme akışında "tekrar gir" adımı için tutulur
  String? _hataMesaji;

  @override
  void initState() {
    super.initState();
    _adim = widget.mod == PinKilitModu.dogrula ? _Adim.pinGir : _Adim.yeniPinBelirle;
    // Doğrulama ekranı açılır açılmaz — kullanıcı parmak izini AÇMIŞSA —
    // otomatik olarak parmak izi iste. Bu sayede çoğu zaman PIN yazmaya
    // hiç gerek kalmaz; başarısız/iptal olursa normal PIN alanı zaten
    // ekranda hazır bekliyor.
    if (widget.mod == PinKilitModu.dogrula) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _biyometriDene());
    }
  }  // --- initState() sonu ---

  Future<void> _biyometriDene() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final biyometriAktif = prefs.getBool('biyometri_aktif') ?? false;
      if (!biyometriAktif) return;
      final auth = LocalAuthentication();
      final destekleniyorMu = await auth.isDeviceSupported();
      final kayitliBiyometriVarMi = await auth.canCheckBiometrics;
      if (!destekleniyorMu || !kayitliBiyometriVarMi) return;
      final basarili = await auth.authenticate(
        localizedReason: DilServisi.metin('pinBiyometriNeden'),
        options: const AuthenticationOptions(biometricOnly: true, stickyAuth: true),
      );
      if (basarili && mounted) {
        widget.onBasarili();
      }
    } catch (_) {
      // Biyometri kullanılamıyorsa (donanım hatası, iptal vb.) sessizce
      // geç — kullanıcı zaten PIN'ini yazabilir, akışı kesmeye gerek yok.
    }
  }  // --- _biyometriDene() sonu ---

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }  // --- dispose() sonu ---

  Future<void> _pinDogrula() async {
    final girilen = _controller.text.trim();
    if (girilen.length != 4) {
      setState(() => _hataMesaji = DilServisi.metin('pin4Hane'));
      return;
    }
    final prefs = await SharedPreferences.getInstance();
    final kayitliHash = prefs.getString('pin_kilit_hash');
    if (_metinKaristir(girilen) == kayitliHash) {
      widget.onBasarili();
    } else {
      setState(() {
        _hataMesaji = DilServisi.metin('pinYanlis');
        _controller.clear();
      });
    }
  }  // --- _pinDogrula() sonu ---

  Future<void> _pinUnuttumTiklandi() async {
    final prefs = await SharedPreferences.getInstance();
    final kurtarmaVarMi = prefs.getString('pin_kurtarma_hash') != null;
    if (!kurtarmaVarMi) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: Text(DilServisi.metin('kurtarmaBilgisiYok')),
          content: Text(DilServisi.metin('kurtarmaBilgisiYokAciklama')),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: Text(DilServisi.metin('anladim')))],
        ),
      );
      return;
    }
    setState(() {
      _adim = _Adim.kurtarmaCevabiGir;
      _controller.clear();
      _hataMesaji = null;
    });
  }  // --- _pinUnuttumTiklandi() sonu ---

  Future<void> _kurtarmaCevabiDogrula() async {
    final girilen = _controller.text.trim();
    if (girilen.isEmpty) {
      setState(() => _hataMesaji = DilServisi.metin('kurtarmaKelimesiGirin'));
      return;
    }
    final prefs = await SharedPreferences.getInstance();
    final kayitliHash = prefs.getString('pin_kurtarma_hash');
    if (_metinKaristir(girilen) == kayitliHash) {
      setState(() {
        _adim = _Adim.yeniPinBelirle;
        _controller.clear();
        _hataMesaji = null;
        _ilkGirilenPin = null;
      });
    } else {
      setState(() {
        _hataMesaji = DilServisi.metin('kurtarmaYanlis');
        _controller.clear();
      });
    }
  }  // --- _kurtarmaCevabiDogrula() sonu ---

  Future<void> _yeniPinAdimi() async {
    final girilen = _controller.text.trim();
    if (girilen.length != 4) {
      setState(() => _hataMesaji = DilServisi.metin('pin4Hane'));
      return;
    }
    if (_adim == _Adim.yeniPinBelirle) {
      setState(() {
        _ilkGirilenPin = girilen;
        _adim = _Adim.yeniPinTekrar;
        _controller.clear();
        _hataMesaji = null;
      });
      return;
    }
    // _Adim.yeniPinTekrar
    if (girilen != _ilkGirilenPin) {
      setState(() {
        _hataMesaji = DilServisi.metin('pinEslesmedi');
        _adim = _Adim.yeniPinBelirle;
        _ilkGirilenPin = null;
        _controller.clear();
      });
      return;
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('pin_kilit_hash', _metinKaristir(girilen));
    await prefs.setBool('pin_kilit_aktif', true);
    setState(() {
      _adim = _Adim.kurtarmaKelimesiBelirle;
      _controller.clear();
      _hataMesaji = null;
    });
  }  // --- _yeniPinAdimi() sonu ---

  Future<void> _kurtarmaKelimesiKaydet() async {
    final girilen = _controller.text.trim();
    if (girilen.length < 3) {
      setState(() => _hataMesaji = DilServisi.metin('kurtarmaMinKarakter'));
      return;
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('pin_kurtarma_hash', _metinKaristir(girilen));
    widget.onBasarili();
  }  // --- _kurtarmaKelimesiKaydet() sonu ---

  void _devamEt() {
    switch (_adim) {
      case _Adim.pinGir:
        _pinDogrula();
        break;
      case _Adim.kurtarmaCevabiGir:
        _kurtarmaCevabiDogrula();
        break;
      case _Adim.yeniPinBelirle:
      case _Adim.yeniPinTekrar:
        _yeniPinAdimi();
        break;
      case _Adim.kurtarmaKelimesiBelirle:
        _kurtarmaKelimesiKaydet();
        break;
    }
  }  // --- _devamEt() sonu ---

  String get _baslik {
    switch (_adim) {
      case _Adim.pinGir:
        return DilServisi.metin('pinGirBaslik');
      case _Adim.kurtarmaCevabiGir:
        return DilServisi.metin('pinKurtarmaCevapBaslik');
      case _Adim.yeniPinBelirle:
        return DilServisi.metin('pinYeniBelirleBaslik');
      case _Adim.yeniPinTekrar:
        return DilServisi.metin('pinYeniTekrarBaslik');
      case _Adim.kurtarmaKelimesiBelirle:
        return DilServisi.metin('pinKurtarmaBelirleBaslik');
    }
  }  // --- _baslik sonu ---

  String get _aciklama {
    switch (_adim) {
      case _Adim.kurtarmaCevabiGir:
        return DilServisi.metin('pinKurtarmaCevapAciklama');
      case _Adim.kurtarmaKelimesiBelirle:
        return DilServisi.metin('pinKurtarmaBelirleAciklama');
      default:
        return '';
    }
  }  // --- _aciklama sonu ---

  bool get _pinAlaniMi => _adim != _Adim.kurtarmaCevabiGir && _adim != _Adim.kurtarmaKelimesiBelirle;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: widget.onVazgec != null
          ? AppBar(
        shape: AppSablon.appBarSekli,
        clipBehavior: Clip.antiAlias,
              backgroundColor: Colors.white,
              elevation: 0,
              iconTheme: const IconThemeData(color: Color(0xFF111424)),
              leading: IconButton(icon: const Icon(Icons.close), onPressed: widget.onVazgec),
            )
          : null,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(32),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  _adim == _Adim.kurtarmaCevabiGir || _adim == _Adim.kurtarmaKelimesiBelirle
                      ? Icons.help_outline
                      : Icons.lock_outline,
                  size: 64,
                  color: AppRenkleri.aktif,
                ),
                const SizedBox(height: 24),
                Text(_baslik, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
                if (_aciklama.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Text(_aciklama, style: TextStyle(fontSize: 13, color: Colors.grey.shade700), textAlign: TextAlign.center),
                ],
                const SizedBox(height: 24),
                TextField(
                  key: ValueKey(_adim),
                  controller: _controller,
                  autofocus: true,
                  obscureText: _pinAlaniMi,
                  keyboardType: _pinAlaniMi ? TextInputType.number : TextInputType.text,
                  maxLength: _pinAlaniMi ? 4 : null,
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: _pinAlaniMi ? 28 : 18, letterSpacing: _pinAlaniMi ? 12 : 0),
                  decoration: const InputDecoration(counterText: '', border: OutlineInputBorder()),
                  onSubmitted: (_) => _devamEt(),
                ),
                if (_hataMesaji != null) ...[
                  const SizedBox(height: 8),
                  Text(_hataMesaji!, style: const TextStyle(color: Colors.red, fontSize: 13), textAlign: TextAlign.center),
                ],
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppRenkleri.aktif,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                    onPressed: _devamEt,
                    child: Text(DilServisi.metin('onayla'), style: const TextStyle(color: Colors.white, fontSize: 16)),
                  ),
                ),
                if (_adim == _Adim.pinGir) ...[
                  const SizedBox(height: 12),
                  TextButton(onPressed: _pinUnuttumTiklandi, child: Text(DilServisi.metin('pinUnuttum'))),
                  IconButton(
                    icon: Icon(Icons.fingerprint, size: 36, color: AppRenkleri.aktif),
                    tooltip: DilServisi.metin('parmakIziIleAc'),
                    onPressed: _biyometriDene,
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }  // --- build() sonu ---
}  // --- _PinKilitEkraniState sonu ---
