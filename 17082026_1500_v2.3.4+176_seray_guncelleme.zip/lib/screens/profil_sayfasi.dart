import 'dart:io';
import '../theme/renkler.dart';
import '../theme/sablon.dart';
import 'package:flutter/material.dart';
import '../services/dil_servisi.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import '../widgets/ust_menu.dart';
import '../services/veritabani_yardimcisi.dart';
import '../services/profil_yoneticisi.dart';
import 'profil_kayit_ekrani.dart';
import '../services/adim_servisi.dart';

class ProfilSayfasi extends StatefulWidget {
  const ProfilSayfasi({Key? key}) : super(key: key);
  @override
  _ProfilSayfasiState createState() => _ProfilSayfasiState();
}

class _ProfilSayfasiState extends State<ProfilSayfasi> {
  String _ad = "..."; 
  String _soyad = "...";
  String _yas = "0";
  String _boy = "";
  String _diyabetTipi = "Yok";
  String? _fotoYolu;

  // SQL sorgularından hesaplanan ortalamalar
  double? _ortalamaSeker;
  double? _ortalamaBuyukTansiyon;
  double? _ortalamaKucukTansiyon;
  double? _ortalamaSu;
  double? _ortalamaAdim;

  @override
  void initState() { 
    super.initState(); 
    _yukle(); 
    _ortalamalariHesapla();
  }

  Future<void> _ortalamalariHesapla() async {
    final sekerler = await VeritabaniYardimcisi().sekerleriGetir();
    final tansiyonlar = await VeritabaniYardimcisi().tansiyonlariGetir();
    final suKayitlari = await VeritabaniYardimcisi().suKayitlariniGetir();
    final adimGecmisi = await AdimServisi.sonYediGunGetir();

    double? ortSeker;
    if (sekerler.isNotEmpty) {
      final toplam = sekerler.fold<int>(0, (t, s) => t + (int.tryParse(s['deger'].toString()) ?? 0));
      ortSeker = toplam / sekerler.length;
    }

    double? ortBuyuk, ortKucuk;
    if (tansiyonlar.isNotEmpty) {
      final toplamBuyuk = tansiyonlar.fold<int>(0, (t, s) => t + (int.tryParse(s['buyuk'].toString()) ?? 0));
      final toplamKucuk = tansiyonlar.fold<int>(0, (t, s) => t + (int.tryParse(s['kucuk'].toString()) ?? 0));
      ortBuyuk = toplamBuyuk / tansiyonlar.length;
      ortKucuk = toplamKucuk / tansiyonlar.length;
    }

    double? ortSu;
    if (suKayitlari.isNotEmpty) {
      // Günlere göre grupla, sonra günlük ortalamayı al (aksi halde tek
      // günde çok bardak içmek yanıltıcı yüksek bir ortalama verir).
      final Map<String, int> gunluk = {};
      for (final k in suKayitlari) {
        final t = DateTime.tryParse(k['tarih']?.toString() ?? '');
        if (t == null) continue;
        final anahtar = '${t.year}-${t.month}-${t.day}';
        gunluk[anahtar] = (gunluk[anahtar] ?? 0) + (int.tryParse(k['miktar_ml'].toString()) ?? 0);
      }
      if (gunluk.isNotEmpty) {
        ortSu = gunluk.values.reduce((a, b) => a + b) / gunluk.length;
      }
    }

    double? ortAdim;
    final dolular = adimGecmisi.where((e) => e.value > 0).toList();
    if (dolular.isNotEmpty) {
      ortAdim = dolular.fold<int>(0, (t, e) => t + e.value) / dolular.length;
    }

    if (mounted) {
      setState(() {
        _ortalamaSeker = ortSeker;
        _ortalamaBuyukTansiyon = ortBuyuk;
        _ortalamaKucukTansiyon = ortKucuk;
        _ortalamaSu = ortSu;
        _ortalamaAdim = ortAdim;
      });
    }
  }

  _yukle() async {
    final p = await SharedPreferences.getInstance();
    final py = ProfilYoneticisi();
    final adAnahtari = await py.profilAnahtari('kullanici_ad');
    final soyadAnahtari = await py.profilAnahtari('kullanici_soyad');
    final yasAnahtari = await py.profilAnahtari('kullanici_yas');
    final boyAnahtari = await py.profilAnahtari('kullanici_boy');
    final diyabetAnahtari = await py.profilAnahtari('kullanici_diyabet_turu');
    final fotoAnahtari = await py.profilAnahtari('kullanici_foto_yolu');
    final fotoAnahtariEski = await py.profilAnahtari('user_foto_yolu');
    setState(() {
      // DÜZELTME: İlk girişteki kayıt ekranıyla tam uyum için iki anahtar birden kontrol ediliyor
      _ad = p.getString(adAnahtari) ?? "";
      _soyad = p.getString(soyadAnahtari) ?? "";
      _yas = p.getString(yasAnahtari) ?? "0";
      _boy = p.getString(boyAnahtari) ?? "";
      _diyabetTipi = p.getString(diyabetAnahtari) ?? "Yok";
      _fotoYolu = p.getString(fotoAnahtari) ?? p.getString(fotoAnahtariEski);
    });
  }

  Future<void> _boyDuzenle() async {
    final controller = TextEditingController(text: _boy);
    final sonuc = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(DilServisi.metin('boyBilgisi')),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.number,
          autofocus: true,
          decoration: InputDecoration(
            labelText: DilServisi.metin('boyCm'),
            helperText: 'Vücut kitle endeksi ve ideal kilo hesaplaması için kullanılır',
            border: const OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: Text(DilServisi.metin('vazgec'))),
          ElevatedButton(
            onPressed: () => Navigator.pop(dialogContext, controller.text.trim()),
            child: Text(DilServisi.metin('kaydet')),
          ),
        ],
      ),
    );
    if (sonuc == null) return;
    final p = await SharedPreferences.getInstance();
    await p.setString(await ProfilYoneticisi().profilAnahtari('kullanici_boy'), sonuc);
    setState(() => _boy = sonuc);
  }  // --- _boyDuzenle() sonu ---

  Future<void> _fotoSec() async {
    final secim = await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.photo_camera), 
              title: Text(DilServisi.metin('fotografCek')), 
              onTap: () => Navigator.pop(context, ImageSource.camera)
            ),
            ListTile(
              leading: const Icon(Icons.photo_library), 
              title: Text(DilServisi.metin('galeridenSec')), 
              onTap: () => Navigator.pop(context, ImageSource.gallery)
            ),
          ],
        ),
      ),
    );
    if (secim == null) return;

    try {
      // ÖNEMLİ DÜZELTME: Kamera izni verilmemişse (özellikle silinip yeniden
      // kurulan cihazlarda — izinler HER zaman sıfırlanır), ImagePicker
      // hiçbir hata fırlatmadan SESSİZCE null dönüyordu. Artık kameradan
      // çekmeden önce izin açıkça isteniyor ve reddedilirse NEDEN gösteriliyor.
      if (secim == ImageSource.camera) {
        final izin = await Permission.camera.request();
        if (!izin.isGranted) {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(DilServisi.metin('kameraIzniVerilmedi'))),
            );
          }
          return;
        }
      }
      final secilenDosya = await ImagePicker().pickImage(source: secim, maxWidth: 500, imageQuality: 65);
      if (secilenDosya == null) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(DilServisi.metin('fotografSecilmedi'))));
        }
        return;
      }
      // ÖNEMLİ DÜZELTME: Aynı temp-dosya-yolu hatası burada da vardı —
      // artık kalıcı bir dosyaya kopyalanıyor (bkz. profil_kayit_ekrani.dart).
      final belgeler = await getApplicationDocumentsDirectory();
      final hedefYolu = await ProfilYoneticisi().profilFotoYolu(belgeler.path);
      final kaliciDosya = await File(secilenDosya.path).copy(hedefYolu);
      // ÖNEMLİ DÜZELTME: Flutter, aynı dosya YOLUNU önbellekte tutuyor —
      // yeni fotoğraf aynı isimle (profil_foto.jpg) kaydedilince ekranda
      // hâlâ ESKİ fotoğraf görünüyordu (kullanıcı "Kaldır"a basıp tekrar
      // çekene kadar fark etmiyordu, çünkü "Kaldır" önbelleği de temizliyor).
      // Artık kayıttan hemen sonra önbellek elle temizleniyor.
      await FileImage(kaliciDosya).evict();
      final p = await SharedPreferences.getInstance();
      final py = ProfilYoneticisi();
      await p.setString(await py.profilAnahtari('user_foto_yolu'), kaliciDosya.path);
      await p.setString(await py.profilAnahtari('kullanici_foto_yolu'), kaliciDosya.path);
      setState(() => _fotoYolu = kaliciDosya.path);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(DilServisi.metin('fotografAlinamadi')))
        );
      }
    }
  }

  Future<void> _cikisYap() async {
    final onay = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(DilServisi.metin('cikisYap')),
        content: Text(DilServisi.metin('cikisOnay')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: Text(DilServisi.metin('vazgec'))),
          TextButton(onPressed: () => Navigator.pop(context, true), child: Text(DilServisi.metin('cikisYapBuyuk'))),
        ],
      ),
    );
    if (onay != true) return;
    SystemNavigator.pop();
  }

  Widget _ortalamaKarti(IconData ikon, Color renk, String baslik, String deger) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: renk.withOpacity(0.08), borderRadius: BorderRadius.circular(14)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(ikon, color: renk, size: 22),
          const SizedBox(height: 6),
          Text(baslik, style: TextStyle(fontSize: 11, color: Colors.grey.shade700)),
          Text(deger, style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: renk)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        shape: AppSablon.appBarSekli,
        clipBehavior: Clip.antiAlias,
        title: Text(DilServisi.metin('profil')), 
        backgroundColor: AppRenkleri.aktif, 
        foregroundColor: Colors.white, 
        actions: const [UstMenu()]
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(color: AppRenkleri.aktif.shade50, borderRadius: BorderRadius.circular(16)),
                child: Column(
                  children: [
                    GestureDetector(
                      onTap: _fotoSec,
                      child: Stack(
                        children: [
                          CircleAvatar(
                            radius: 45,
                            backgroundColor: AppRenkleri.aktif,
                            backgroundImage: _fotoYolu != null ? FileImage(File(_fotoYolu!)) : null,
                            child: _fotoYolu == null ? const Icon(Icons.person, size: 50, color: Colors.white) : null,
                          ),
                          Positioned(
                            bottom: 0,
                            right: 0,
                            child: Container(
                              padding: const EdgeInsets.all(4),
                              decoration: const BoxDecoration(color: Colors.orange, shape: BoxShape.circle),
                              child: const Icon(Icons.camera_alt, size: 16, color: Colors.white),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Flexible(
                          child: Text('$_ad $_soyad', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
                        ),
                        const SizedBox(width: 6),
                        // ÖNEMLİ: Önceden sadece Boy düzenlenebiliyordu — Ad/
                        // Soyad/Yaş/Cinsiyet/Diyabet Türü için hiçbir düzenleme
                        // yolu yoktu. Bu ikon, doldurulmuş hâliyle Profil Kaydı
                        // formunu açar; kaydedince BU EKRAN da otomatik tazelenir.
                        InkWell(
                          borderRadius: BorderRadius.circular(20),
                          onTap: () async {
                            await Navigator.push(
                              context,
                              MaterialPageRoute(builder: (_) => const ProfilKayitEkrani()),
                            );
                            if (mounted) await _yukle();
                          },
                          child: Padding(
                            padding: const EdgeInsets.all(4),
                            child: Icon(Icons.edit, size: 18, color: AppRenkleri.aktif.shade700),
                          ),
                        ),
                      ],
                    ),
                    const Divider(height: 32),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(DilServisi.metin('kayitliYas'), style: const TextStyle(fontSize: 16)),
                        Text('$_yas', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppRenkleri.aktif)),
                      ],
                    ),
                    const SizedBox(height: 8),
                    InkWell(
                      onTap: _boyDuzenle,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(DilServisi.metin('boyCm'), style: const TextStyle(fontSize: 16)),
                          Row(
                            children: [
                              Text(
                                _boy.isEmpty ? DilServisi.metin('ekle') : '$_boy cm',
                                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppRenkleri.aktif),
                              ),
                              const SizedBox(width: 4),
                              Icon(Icons.edit, size: 16, color: AppRenkleri.aktif),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(DilServisi.metin('diyabetDurumu'), style: const TextStyle(fontSize: 16)),
                        Text(_diyabetTipi, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppRenkleri.aktif)),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // ORTALAMALAR — veritabanındaki tüm ölçümlerin özeti
              Text(DilServisi.metin('genelOrtalamalar'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
              const SizedBox(height: 10),
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                childAspectRatio: 1.6,
                children: [
                  _ortalamaKarti(Icons.bloodtype, Colors.red, DilServisi.metin('sekerKelime'),
                      _ortalamaSeker != null ? '${_ortalamaSeker!.toStringAsFixed(0)} mg/dL' : '—'),
                  _ortalamaKarti(Icons.favorite, Colors.pink, DilServisi.metin('tansiyon'),
                      _ortalamaBuyukTansiyon != null ? '${_ortalamaBuyukTansiyon!.toStringAsFixed(0)}/${_ortalamaKucukTansiyon!.toStringAsFixed(0)}' : '—'),
                  _ortalamaKarti(Icons.water_drop, Colors.blue, DilServisi.metin('gunlukSu'),
                      _ortalamaSu != null ? '${(_ortalamaSu! / 1000).toStringAsFixed(1)} L' : '—'),
                  _ortalamaKarti(Icons.directions_walk, Colors.deepOrange, DilServisi.metin('gunlukAdim'),
                      _ortalamaAdim != null ? _ortalamaAdim!.toStringAsFixed(0) : '—'),
                ],
              ),

              const SizedBox(height: 8),
              Text(DilServisi.metin('yedeklemeMenuNotu'), textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, color: Colors.grey)),
              const SizedBox(height: 32),
              ElevatedButton.icon(
                onPressed: _cikisYap,
                icon: const Icon(Icons.logout),
                label: Text(DilServisi.metin('cikisYapBuyuk')),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.grey.shade700, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 14)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
