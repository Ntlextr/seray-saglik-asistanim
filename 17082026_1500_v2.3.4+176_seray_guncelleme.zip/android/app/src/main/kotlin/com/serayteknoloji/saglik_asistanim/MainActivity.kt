package com.serayteknoloji.saglik_asistanim

import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import android.provider.Telephony

// ÖNEMLİ: local_auth (parmak izi/biyometrik kilit) paketi androidx Biometric
// kütüphanesini kullanıyor — bu, normal FlutterActivity yerine
// FlutterFragmentActivity gerektiriyor. Değiştirilmezse parmak izi isteği
// sessizce başarısız olur ya da çöker.
class MainActivity: FlutterFragmentActivity() {
    // Acil durum SMS'i gönderirken, birden fazla mesajlaşma uygulaması
    // (WhatsApp vb.) kurulu olan telefonlarda Android bir seçim penceresi
    // gösteriyordu — kullanıcı "direkt SMS uygulamasına gitsin" istedi.
    // Bunun için TELEFONUN VARSAYILAN SMS uygulamasının paket adını
    // (örn. "com.android.mms" ya da "com.google.android.apps.messaging")
    // Dart tarafına bildiren küçük bir köprü.
    private val kanalAdi = "com.serayteknoloji.saglik_asistanim/sms"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, kanalAdi).setMethodCallHandler { call, result ->
            if (call.method == "varsayilanSmsPaketi") {
                try {
                    // NOT: android.telephony.SmsManager sınıfının static bir
                    // getDefaultSmsPackage() metodu YOK (önceki denemede bunu
                    // yanlışlıkla varsaymıştık, derleme hatası verdi) — doğru
                    // ve tek güvenilir yol android.provider.Telephony.Sms'teki
                    // context tabanlı sürüm.
                    val paket: String? = Telephony.Sms.getDefaultSmsPackage(this)
                    result.success(paket)
                } catch (e: Exception) {
                    // "HATA:" öneki ile gerçek hata mesajını Dart tarafına
                    // taşıyoruz — böylece teşhis penceresinde "null döndü"
                    // yerine GERÇEK sebebi (izin hatası, vs.) görebiliyoruz.
                    result.success("HATA:${e.message ?: e.toString()}")
                }
            } else {
                result.notImplemented()
            }
        }
    }  // --- configureFlutterEngine() sonu ---
}
