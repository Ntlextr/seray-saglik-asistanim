package com.serayteknoloji.saglik_asistanim

import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.SharedPreferences
import android.widget.RemoteViews
import es.antonborri.home_widget.HomeWidgetLaunchIntent
import es.antonborri.home_widget.HomeWidgetProvider

// Ana ekran widget'ı: Dart tarafı (widget_servisi.dart) HomeWidget.saveWidgetData
// ile "adim_metni" ve "su_metni" anahtarlarını kaydedip HomeWidget.updateWidget
// çağırınca, burası widgetData'dan okuyup ekrandaki metinleri günceller.
// Herhangi bir sorunda (veri henüz kaydedilmemiş vb.) varsayılan metinler
// gösterilir — widget hiçbir zaman çökmez, en kötü ihtimalle eski/varsayılan
// veri gösterir.
class SerayWidgetProvider : HomeWidgetProvider() {
    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray,
        widgetData: SharedPreferences
    ) {
        appWidgetIds.forEach { widgetId ->
            val views = RemoteViews(context.packageName, R.layout.seray_widget_layout).apply {
                val adimMetni = widgetData.getString("adim_metni", "0 adım") ?: "0 adım"
                val suMetni = widgetData.getString("su_metni", "0 mL su") ?: "0 mL su"
                setTextViewText(R.id.widget_adim, adimMetni)
                setTextViewText(R.id.widget_su, suMetni)

                // Widget'a dokununca uygulamayı açar (Özet ekranına düşer).
                val pendingIntent = HomeWidgetLaunchIntent.getActivity(context, MainActivity::class.java)
                setOnClickPendingIntent(R.id.widget_root, pendingIntent)
            }
            appWidgetManager.updateAppWidget(widgetId, views)
        }
    }  // --- onUpdate() sonu ---
}  // --- SerayWidgetProvider sonu ---
