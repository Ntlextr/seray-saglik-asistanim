package com.example.seray_saglik_asistanim

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
