# flutter_local_notifications, zamanlanmış bildirimleri SharedPreferences'a
# Gson ile JSON olarak kaydediyor. R8 kod küçültme jenerik tip bilgisini
# (generics) sildiğinde "Missing type parameter" hatasıyla çöküyor.
# Bu kurallar o bilgiyi korur.
-keep class com.dexterous.** { *; }
-keep class com.google.gson.** { *; }
-keep class * extends com.google.gson.reflect.TypeToken
-keep class com.google.gson.reflect.TypeToken { *; }
-keepattributes Signature
-keepattributes *Annotation*
-keepattributes EnclosingMethod
-keepattributes InnerClasses

# Flutter'ın kendi eklenti/embedding sınıfları için standart güvenli kurallar
-keep class io.flutter.app.** { *; }
-keep class io.flutter.plugin.**  { *; }
-keep class io.flutter.util.**  { *; }
-keep class io.flutter.view.**  { *; }
-keep class io.flutter.**  { *; }
-keep class io.flutter.plugins.**  { *; }

# Uygulama Google Play'in "Deferred Components" (parça yükleme) özelliğini
# kullanmıyor, ilgili kütüphane de projede yok. Flutter'ın motoru buna
# referans veriyor ama gerçekte hiç çağrılmıyor; R8'in bunu hata saymasını
# engelliyoruz.
-dontwarn com.google.android.play.core.**
-dontwarn io.flutter.embedding.engine.deferredcomponents.**

# read_pdf_text paketinin kullandığı PdfBox-Android, nadir kullanılan JPEG2000
# görüntü formatı için opsiyonel bir sınıfa (com.gemalto.jp2.JP2Decoder) referans
# veriyor ama bu sınıf projede yok (gerekmiyor da). R8'in bunu hata saymasını engelle.
-dontwarn com.gemalto.jp2.**
-dontwarn com.tom_roush.pdfbox.**
-dontwarn com.tom_roush.harmony.**
