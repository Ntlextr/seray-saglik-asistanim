import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiService {
  // Gemini ücretsiz tier modeli: gemini-1.5-flash
  // API anahtarı Ayarlar ekranından SharedPreferences'a kaydedilir.
  static const String _varsayilanModel = 'gemini-1.5-flash';
  static const String _apiUrl =
      'https://generativelanguage.googleapis.com/v1beta/models';

  static Future<String> _apiAnahtariniAl() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('gemini_api_key') ?? '';
  }

  // --- TAHLIL METNİ ANALİZİ ---
  static Future<String> tahlilMetniniAnalizEt(String metin) async {
    final apiKey = await _apiAnahtariniAl();
    if (apiKey.isEmpty) {
      return 'Lütfen Ayarlar ekranından Gemini API anahtarınızı girin.';
    }

    final prompt = '''
Sen kıdemli, şefkatli ve çok dikkatli bir sağlık asistanısın. Aşağıda kullanıcının e-Nabız sisteminden alınan tahlil sonuçları yer almaktadır.

Bu sonuçları teknik terimlere boğmadan, anlaşılır, sakinleştirici ve empatik bir dille analiz et.
Sınır değerlerin dışındaki sonuçları açıkça belirt ve doktora başvurulması gereken durumlar için nazikçe yönlendirme yap.
Asla teşhis koyma, ilaç önerme.

Tahlil Metni:
$metin
''';

    return await _metinSorgusu(prompt, apiKey);
  }

  // --- İKİ TAHLİL ARASINDAKİ KARŞILAŞTIRMA ANALİZİ ---
  static Future<String> karsilastirmaAnalizEt({
    required String yeniTarih,
    required Map<String, String> yeniDegerler,
    required String eskiTarih,
    required Map<String, String> eskiDegerler,
  }) async {
    final apiKey = await _apiAnahtariniAl();
    if (apiKey.isEmpty) {
      return 'Lütfen Ayarlar ekranından Gemini API anahtarınızı girin.';
    }

    final StringBuffer sb = StringBuffer();
    sb.writeln('$yeniTarih tarihli yeni sonuçlar:');
    yeniDegerler.forEach((ad, deger) => sb.writeln('- $ad: $deger'));
    sb.writeln('\n$eskiTarih tarihli önceki sonuçlar:');
    eskiDegerler.forEach((ad, deger) => sb.writeln('- $ad: $deger'));

    final prompt = '''
Sen deneyimli bir sağlık asistanısın. Aşağıda iki farklı tarihe ait laboratuvar tahlil sonuçları verilmiştir.

Bu iki tahlili karşılaştır:
- Belirgin iyileşme gösteren değerleri belirt
- Kötüleşen veya dikkat gerektiren değerleri vurgula
- Değişmeyen değerler hakkında kısa bilgi ver
- Genel değerlendirmeni samimi, sakinleştirici ve anlaşılır bir dille yap
- Teşhis koyma, ilaç önerme

${sb.toString()}
''';

    return await _metinSorgusu(prompt, apiKey);
  }

  // --- PDF METNİNDEN YAPILANDIRILMIŞ TAHLİL VERİLERİ ---
  static Future<List<Map<String, String>>> tahlilVerileriniJsonOlarakCikar(
      String metin) async {
    final apiKey = await _apiAnahtariniAl();
    if (apiKey.isEmpty) return [];

    final prompt = '''
Aşağıda bir e-Nabız tahlil sonuçları metni yer almaktadır. Bu metindeki HER BİR laboratuvar tahlilini tespit et.

SADECE aşağıdaki formatta, başka hiçbir açıklama veya markdown işareti olmadan, saf bir JSON dizisi döndür:
[
  {"tahlil_adi": "Tahlilin tam adı", "sonuc": "Sayısal sonuç değeri", "referans_araligi": "örn: 3.5-5.5"}
]

Kurallar:
- Sadece gerçek laboratuvar tahlili olan satırları dahil et.
- Referans aralığı yoksa "-" yaz.
- Hiç tahlil bulamazsan boş dizi [] döndür.

Tahlil Metni:
$metin
''';

    try {
      final url = Uri.parse('$_apiUrl/$_varsayilanModel:generateContent');
      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
          'x-goog-api-key': apiKey,
        },
        body: jsonEncode({
          'contents': [
            {
              'parts': [
                {'text': prompt}
              ]
            }
          ],
          'generationConfig': {'response_mime_type': 'application/json'}
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        String sonuc =
            data['candidates']?[0]?['content']?['parts']?[0]?['text'] ?? '[]';
        sonuc =
            sonuc.replaceAll('```json', '').replaceAll('```', '').trim();
        final List<dynamic> liste = jsonDecode(sonuc);
        return liste
            .map<Map<String, String>>((satir) => {
                  'tahlil_adi': (satir['tahlil_adi'] ?? '').toString(),
                  'sonuc': (satir['sonuc'] ?? '').toString(),
                  'referans_araligi':
                      (satir['referans_araligi'] ?? '-').toString(),
                })
            .where((s) =>
                s['tahlil_adi']!.isNotEmpty && s['sonuc']!.isNotEmpty)
            .toList();
      }
      return [];
    } catch (e) {
      return [];
    }
  }

  // --- YEMEK FOTOĞRAFINDAN KALORİ TAHMİNİ (Gemini Vision) ---
  static Future<String> fotograftanKaloriTahminEt(File fotografDosyasi) async {
    final apiKey = await _apiAnahtariniAl();
    if (apiKey.isEmpty) {
      return 'Lütfen Ayarlar ekranından Gemini API anahtarınızı girin.';
    }

    try {
      final baytlar = await fotografDosyasi.readAsBytes();
      final base64Gorsel = base64Encode(baytlar);

      final url = Uri.parse('$_apiUrl/$_varsayilanModel:generateContent');
      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
          'x-goog-api-key': apiKey,
        },
        body: jsonEncode({
          'contents': [
            {
              'parts': [
                {
                  'inline_data': {
                    'mime_type': 'image/jpeg',
                    'data': base64Gorsel,
                  }
                },
                {
                  'text':
                      'Bu fotoğraftaki yemek veya yiyeceği tanımla ve tahmini kalori miktarını belirt. '
                          'Türkçe yanıt ver. Şu formatta yanıt ver:\n'
                          'Yemek: [yemek adı]\n'
                          'Tahmini Kalori: [rakam] kcal\n'
                          'Açıklama: [kısa besin değeri bilgisi]'
                }
              ]
            }
          ]
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['candidates']?[0]?['content']?['parts']?[0]?['text'] ??
            'Yemek tanınamadı.';
      }
      return 'Kalori tahmini yapılamadı (Hata ${response.statusCode}).';
    } catch (e) {
      return 'Fotoğraf analizi sırasında hata oluştu: $e';
    }
  }

  // --- SERAY YAPAY ZEKA SAĞLIK DANIŞMANI ---
  static Future<String> serayileSohbet({
    required String kullaniciMesaji,
    required List<Map<String, String>> sohbetGecmisi,
  }) async {
    final apiKey = await _apiAnahtariniAl();
    if (apiKey.isEmpty) {
      return 'Lütfen Ayarlar ekranından Gemini API anahtarınızı girin.';
    }

    const String sistemPrompt = '''
Sen Seray Sağlık Asistanısın. Yaşlı ve orta yaşlı kullanıcılara yönelik, Türkçe konuşan, şefkatli ve sabırlı bir sağlık bilinci asistanısın.

TEMEL KURALLAR:
- Asla teşhis koyma
- Asla ilaç önerme veya doz değiştirme
- Her zaman doktor görüşü almanızı önermek için hatırlatma yap
- Anlaşılır, sade Türkçe kullan
- Sıcak, empatik ve sakinleştirici bir dil kullan
- Sağlık bilgisi konusunda destek ver, doktor yerine geçme

Şeker hastalığı, tansiyon, ilaç takibi, beslenme, egzersiz gibi konularda genel bilgi verebilirsin.
''';

    try {
      final List<Map<String, dynamic>> icerik = [];

      // Sistem mesajı
      icerik.add({
        'role': 'user',
        'parts': [
          {'text': sistemPrompt}
        ]
      });
      icerik.add({
        'role': 'model',
        'parts': [
          {
            'text':
                'Merhaba! Ben Seray Sağlık Asistanınızım. Size sağlık konularında destek olmaktan mutluluk duyarım. Lütfen sorularınızı sorabilirsiniz.'
          }
        ]
      });

      // Geçmiş sohbet
      for (final mesaj in sohbetGecmisi) {
        icerik.add({
          'role': mesaj['rol'] == 'kullanici' ? 'user' : 'model',
          'parts': [
            {'text': mesaj['metin'] ?? ''}
          ]
        });
      }

      // Yeni mesaj
      icerik.add({
        'role': 'user',
        'parts': [
          {'text': kullaniciMesaji}
        ]
      });

      final url = Uri.parse('$_apiUrl/$_varsayilanModel:generateContent');
      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
          'x-goog-api-key': apiKey,
        },
        body: jsonEncode({'contents': icerik}),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['candidates']?[0]?['content']?['parts']?[0]?['text'] ??
            'Yanıt oluşturulamadı.';
      }
      return 'Bağlantı hatası (Kod: ${response.statusCode}).';
    } catch (e) {
      return 'Bağlantı sırasında bir sorun oluştu: $e';
    }
  }

  // --- ORTAK METİN SORGULAMA ---
  static Future<String> _metinSorgusu(String prompt, String apiKey) async {
    try {
      final url = Uri.parse('$_apiUrl/$_varsayilanModel:generateContent');
      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
          'x-goog-api-key': apiKey,
        },
        body: jsonEncode({
          'contents': [
            {
              'parts': [
                {'text': prompt}
              ]
            }
          ]
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['candidates']?[0]?['content']?['parts']?[0]?['text'] ??
            'Analiz oluşturulamadı.';
      }
      return 'API Hatası (Kod ${response.statusCode}): ${response.body}';
    } catch (e) {
      return 'Yapay zeka analizi sırasında hata oluştu: $e';
    }
  }
}
