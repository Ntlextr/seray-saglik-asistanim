import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest_all.dart' as tz_data;
import 'package:android_intent_plus/android_intent.dart';
import '../navigasyon_anahtari.dart';
import '../screens/alarm_ekrani.dart';

// Uygulama tamamen kapalıyken "Ertele" butonuna basıldığında da çalışması
// için bu fonksiyon ayrı (top-level) ve @pragma ile işaretli olmak zorunda.
@pragma('vm:entry-point')
void bildirimArkaPlanYanitlandi(NotificationResponse yanit) {
  BildirimServisi._bildirimYanitlandi(yanit);
}

class BildirimServisi {
  static final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  static bool _hazir = false;

  static Future<void> baslat() async {
    if (_hazir) return;
    tz_data.initializeTimeZones();
    // Uygulama şu an için Türkiye saatine göre çalışıyor.
    tz.setLocalLocation(tz.getLocation('Europe/Istanbul'));

    const androidAyarlari = AndroidInitializationSettings('@mipmap/launcher_icon');
    const ayarlar = InitializationSettings(android: androidAyarlari);
    await _plugin.initialize(
      ayarlar,
      onDidReceiveNotificationResponse: _bildirimYanitlandi,
      onDidReceiveBackgroundNotificationResponse: bildirimArkaPlanYanitlandi,
    );

    final androidUygulama = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await androidUygulama?.requestNotificationsPermission();
    // Android 12+ cihazlarda hatırlatma alarmının tam zamanında çalması için
    // kullanıcıdan "Kesin Alarmlar" iznini iste (ayarlar ekranını açar).
    await androidUygulama?.requestExactAlarmsPermission();
    await androidUygulama?.createNotificationChannel(const AndroidNotificationChannel(
      'ilac_hatirlatma_kanali_v3',
      'İlaç Hatırlatmaları',
      description: 'Günlük ilaç saatlerinde çalan hatırlatmalar',
      importance: Importance.max,
      playSound: true,
      sound: UriAndroidNotificationSound('content://settings/system/notification_sound'),
      enableVibration: true,
    ));
    _hazir = true;
  }

  // Ayarlar ekranındaki "Kesin Alarm İznini Kontrol Et" butonu için.
  static Future<void> kesinAlarmIzniniIste() async {
    await baslat();
    final androidUygulama = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await androidUygulama?.requestExactAlarmsPermission();
  }

  // MIUI/HyperOS ve benzeri Android arayüzlerinde uygulama arka planda
  // öldürülmesin diye pil optimizasyonundan muaf tutulması için sistem
  // izin ekranını açar. Zaten izin verilmişse sistem hiçbir şey göstermez.
  static Future<void> pilOptimizasyonuGorMezdenGel() async {
    try {
      const intent = AndroidIntent(
        action: 'android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS',
        data: 'package:com.serayteknoloji.saglik_asistanim',
      );
      await intent.launch();
    } catch (_) {
      // Bazı cihazlarda bu ekran desteklenmeyebilir; sessizce geç.
    }
  }

  // "Ertele" butonuna basıldığında bildirimi 10 dakika sonrasına tekrar kurar.
  // Bildirimin gövdesine dokunulduğunda (veya kilitli ekranda tam ekran
  // açıldığında) tam ekran alarm sayfasını gösterir.
  static void _bildirimYanitlandi(NotificationResponse yanit) async {
    if (yanit.actionId == 'ertele') {
      final ilacAdi = yanit.payload ?? 'İlaç';
      await _plugin.zonedSchedule(
        yanit.id ?? 0,
        '💊 İlaç Hatırlatması (Ertelendi)',
        '$ilacAdi zamanı geldi!',
        tz.TZDateTime.now(tz.local).add(const Duration(minutes: 10)),
        _bildirimDetaylari(),
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
        payload: ilacAdi,
      );
    } else if (yanit.actionId == null || yanit.actionId == '') {
      // Kullanıcı butona değil, bildirimin kendisine dokundu (ya da tam
      // ekran uyarı otomatik açıldı).
      _alarmEkraniniAc(yanit.id ?? 0, yanit.payload ?? 'İlaç');
    }
  }

  static void _alarmEkraniniAc(int id, String ilacAdi) {
    final baglam = navigasyonAnahtari.currentState;
    if (baglam == null) return;
    baglam.push(MaterialPageRoute(
      builder: (_) => AlarmEkrani(bildirimId: id, ilacAdi: ilacAdi),
      fullscreenDialog: true,
    ));
  }

  // Uygulama bir bildirime dokunularak (tamamen kapalıyken) açıldıysa bunu
  // yakalar. main.dart, ilk kare çizildikten sonra bunu çağırır.
  static Future<void> baslangicBildirimineBak() async {
    final detaylar = await _plugin.getNotificationAppLaunchDetails();
    if (detaylar != null && detaylar.didNotificationLaunchApp) {
      final yanit = detaylar.notificationResponse;
      if (yanit != null && yanit.actionId != 'ertele' && yanit.actionId != 'kapat') {
        _alarmEkraniniAc(yanit.id ?? 0, yanit.payload ?? 'İlaç');
      }
    }
  }

  static NotificationDetails _bildirimDetaylari() {
    return NotificationDetails(
      android: AndroidNotificationDetails(
        'ilac_hatirlatma_kanali_v3',
        'İlaç Hatırlatmaları',
        channelDescription: 'Günlük ilaç saatlerinde çalan hatırlatmalar',
        importance: Importance.max,
        priority: Priority.high,
        playSound: true,
        fullScreenIntent: true,
        ongoing: true, // kaydırarak kapatılamasın
        autoCancel: false, // sadece butonlarla kapansın
        // FLAG_INSISTENT: Kapat'a basılana kadar ses/titreşim tekrar eder (alarm mantığı)
        additionalFlags: Int32List.fromList(<int>[4]),
        actions: [
          AndroidNotificationAction('ertele', 'Ertele', showsUserInterface: false, cancelNotification: true),
          AndroidNotificationAction('kapat', 'Kapat', cancelNotification: true),
        ],
      ),
    );
  }

  // Her gün aynı saatte tekrar eden ilaç alarmı kurar. id olarak ilacın
  // veritabanındaki id'si kullanılır, böylece silinince/düzenlenince eşleşir.
  static Future<void> ilacHatirlaticisiKur({required int id, required String ilacAdi, required TimeOfDay saat}) async {
    await baslat();
    final simdi = tz.TZDateTime.now(tz.local);
    var hedef = tz.TZDateTime(tz.local, simdi.year, simdi.month, simdi.day, saat.hour, saat.minute);
    if (hedef.isBefore(simdi)) hedef = hedef.add(const Duration(days: 1));

    await _plugin.zonedSchedule(
      id,
      '💊 İlaç Zamanı: $ilacAdi',
      '$ilacAdi ilacınızı almayı unutmayın.',
      hedef,
      _bildirimDetaylari(),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      matchDateTimeComponents: DateTimeComponents.time, // her gün aynı saatte tekrar eder
      uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
      payload: ilacAdi,
    );
  }

  static Future<void> iptalEt(int id) async {
    await baslat();
    await _plugin.cancel(id);
  }
}
