import 'dart:io';
import 'package:flutter/services.dart' show rootBundle;
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import 'veritabani_yardimcisi.dart';

class PdfRaporServisi {
  // Tahlil isimlerini PDF sütunlarına sığması için Seray AI standartlarında kısaltır
  static String _tahlilAdiniKisalt(String ad) {
    String t = ad.trim();
    if (t.contains('Alanin Aminotransferaz')) return 'ALT';
    if (t.contains('Aspartat Transaminaz')) return 'AST';
    if (t.contains('Gama Glutamil')) return 'GGT';
    if (t.contains('Açlık Kan Şekeri') || t.contains('Glukoz')) return 'Glukoz (AKŞ)';
    if (t.contains('Hemogram') || t.contains('Tam Kan')) return 'Hemogram';
    if (t.contains('Kreatinin')) return 'Kreatinin';
    if (t.contains('Trigliserid')) return 'Trigliserid';
    if (t.contains('Kolesterol')) return 'Kolesterol';
    if (t.contains('Vitamin B12')) return 'B12 Vitamini';
    if (t.contains('25-Hidroksi')) return 'D Vitamini';
    return t.length > 22 ? '${t.substring(0, 20)}..' : t;
  }

  // Günlük Şeker ve Tansiyon Ölçüm Raporı
  static Future<void> gunlukRaporuOlusturVePaylas({required String kullaniciAdi}) async {
    final sekerler = await VeritabaniYardimcisi().sekerleriGetir();
    final tansiyonlar = await VeritabaniYardimcisi().tansiyonlariGetir();

    final logoBaytlari = await rootBundle.load('assets/images/app_logo.png');
    final logo = pw.MemoryImage(logoBaytlari.buffer.asUint8List());

    final normalFontBaytlari = await rootBundle.load('assets/fonts/DejaVuSans.ttf');
    final kalinFontBaytlari = await rootBundle.load('assets/fonts/DejaVuSans-Bold.ttf');
    final normalFont = pw.Font.ttf(normalFontBaytlari);
    final kalinFont = pw.Font.ttf(kalinFontBaytlari);

    String tarihiBicimlendir(String? isoTarih) {
      if (isoTarih == null) return '-';
      final t = DateTime.tryParse(isoTarih);
      if (t == null) return isoTarih;
      String iki(int n) => n.toString().padLeft(2, '0');
      return '${iki(t.day)}.${iki(t.month)}.${t.year} ${iki(t.hour)}:${iki(t.minute)}';
    }

    final belge = pw.Document(theme: pw.ThemeData.withFont(base: normalFont, bold: kalinFont));
    belge.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        build: (context) => [
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.center,
            children: [
              pw.Image(logo, width: 50, height: 50),
              pw.SizedBox(width: 12),
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text('Seray Sağlık Asistanım', style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold)),
                  pw.Text('Ölçüm Raporu - $kullaniciAdi'),
                ],
              ),
            ],
          ),
          pw.SizedBox(height: 16),
          pw.Text('Kan Şekeri Ölçümleri', style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 6),
          pw.Table.fromTextArray(
            headers: ['Tarih / Saat', 'Değer (mg/dL)', 'Durum'],
            data: sekerler.map((s) => [tarihiBicimlendir(s['tarih']?.toString()), '${s['deger']}', '${s['durum'] ?? '-'}' ]).toList(),
          ),
          pw.SizedBox(height: 20),
          pw.Text('Tansiyon Ölçümleri', style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 6),
          pw.Table.fromTextArray(
            headers: ['Tarih / Saat', 'Büyük/Küçük', 'Nabız'],
            data: tansiyonlar.map((t) => [tarihiBicimlendir(t['tarih']?.toString()), '${t['buyuk']}/${t['kucuk']}', '${t['nabiz'] ?? '-'}' ]).toList(),
          ),
        ],
      ),
    );

    final gecici = await getTemporaryDirectory();
    final dosyaYolu = '${gecici.path}/seray_saglik_raporu.pdf';
    final dosya = File(dosyaYolu);
    await dosya.writeAsBytes(await belge.save());

    await Share.shareXFiles([XFile(dosyaYolu, name: 'seray_saglik_raporu.pdf')], text: 'Seray Sağlık Asistanım - Ölçüm Raporu');
  }

  // Akıllı e-Nabız Tahlil Matrisi PDF Raporu (Sütunlar Taşmaz, Sayfalar Halinde Basılır)
  static Future<void> enabizRaporuOlusturVePaylas({
    required Map<String, Map<String, String>> tabloVerisi,
    required List<String> tarihSutunlari,
    required String kullaniciAdi,
  }) async {
    final logoBaytlari = await rootBundle.load('assets/images/app_logo.png');
    final logo = pw.MemoryImage(logoBaytlari.buffer.asUint8List());
    final normalFontBaytlari = await rootBundle.load('assets/fonts/DejaVuSans.ttf');
    final kalinFontBaytlari = await rootBundle.load('assets/fonts/DejaVuSans-Bold.ttf');
    final normalFont = pw.Font.ttf(normalFontBaytlari);
    final kalinFont = pw.Font.ttf(kalinFontBaytlari);

    final belge = pw.Document(theme: pw.ThemeData.withFont(base: normalFont, bold: kalinFont));

    // Her PDF sayfasına en fazla 4 tarih sütunu basılır, fazlası sonraki sayfaya aktarılır
    const int sayfaBasiMaksSutun = 4;
    
    for (int i = 0; i < tarihSutunlari.length; i += sayfaBasiMaksSutun) {
      final altTarihler = tarihSutunlari.sublist(
        i, 
        (i + sayfaBasiMaksSutun < tarihSutunlari.length) ? i + sayfaBasiMaksSutun : tarihSutunlari.length
      );

      belge.addPage(
        pw.MultiPage(
          pageFormat: PdfPageFormat.a4.landscape, // Yatay A4 formatı ile maksimum görünürlük
          build: (context) => [
            pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
              children: [
                pw.Row(
                  children: [
                    pw.Image(logo, width: 40, height: 40),
                    pw.SizedBox(width: 10),
                    pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                      children: [
                        pw.Text('Seray Sağlık Asistanım - e-Nabız Tahlil Matrisi', style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
                        pw.Text('Hasta: $kullaniciAdi ${tarihSutunlari.length > sayfaBasiMaksSutun ? "(Sayfa ${(i ~/ sayfaBasiMaksSutun) + 1})" : ""}'),
                      ],
                    ),
                  ],
                ),
                pw.Text('Seray AI Analiz Raporu', style: pw.TextStyle(fontSize: 11, color: PdfColors.teal)),
              ],
            ),
            pw.SizedBox(height: 14),
            pw.Table.fromTextArray(
              border: pw.TableBorder.all(color: PdfColors.grey300, width: 0.5),
              headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10, color: PdfColors.white),
              headerDecoration: const pw.BoxDecoration(color: PdfColors.teal),
              cellStyle: const pw.TextStyle(fontSize: 9),
              cellAlignment: pw.Alignment.center,
              headers: ['Tahlil Adı / Referans', ...altTarihler],
              data: tabloVerisi.entries.map((entry) {
                final kisaltilmisAd = _tahlilAdiniKisalt(entry.key);
                final ref = entry.value["_ref"] ?? "-";
                final adVeRef = '$kisaltilmisAd\n(Ref: $ref)';
                
                return [
                  adVeRef,
                  ...altTarihler.map((t) => entry.value[t] ?? "-")
                ];
              }).toList(),
            ),
          ],
        ),
      );
    }

    final gecici = await getTemporaryDirectory();
    final dosyaYolu = '${gecici.path}/seray_enabiz_tahlil_raporu.pdf';
    final dosya = File(dosyaYolu);
    await dosya.writeAsBytes(await belge.save());

    await Share.shareXFiles([XFile(dosyaYolu, name: 'seray_enabiz_tahlil_raporu.pdf')], text: 'Seray Sağlık Asistanım - e-Nabız Tahlil Sonuçları');
  }
}
