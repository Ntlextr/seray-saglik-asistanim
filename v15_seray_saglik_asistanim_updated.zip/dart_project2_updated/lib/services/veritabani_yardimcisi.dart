import 'dart:async';
import 'dart:io';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:share_plus/share_plus.dart';

class VeritabaniYardimcisi {
  static final VeritabaniYardimcisi _instance = VeritabaniYardimcisi._internal();
  static Database? _database;

  factory VeritabaniYardimcisi() => _instance;
  VeritabaniYardimcisi._internal();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    String path = join(await getDatabasesPath(), 'seray_saglik_asistanim.db');
    return await openDatabase(
      path,
      version: 3,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
  }

  Future _onCreate(Database db, int version) async {
    await db.execute(
        'CREATE TABLE seker_olcumleri (id INTEGER PRIMARY KEY AUTOINCREMENT, deger INTEGER, durum TEXT, tarih TEXT)');
    await db.execute(
        'CREATE TABLE tansiyon_olcumleri (id INTEGER PRIMARY KEY AUTOINCREMENT, buyuk INTEGER, kucuk INTEGER, nabiz INTEGER, tarih TEXT)');
    await db.execute(
        "CREATE TABLE ilaclar (id INTEGER PRIMARY KEY AUTOINCREMENT, ad TEXT, dozaj TEXT, saat TEXT, tip TEXT DEFAULT 'Hap', birim TEXT DEFAULT 'adet')");
    await db.execute(
        'CREATE TABLE enabiz_tahlilleri (id INTEGER PRIMARY KEY AUTOINCREMENT, tarih TEXT, tahlil_adi TEXT, sonuc TEXT, referans_degeri TEXT)');
    await db.execute(
        'CREATE TABLE enabiz_yorumlari (id INTEGER PRIMARY KEY AUTOINCREMENT, tarih TEXT, yorum TEXT)');
    await db.execute(
        'CREATE TABLE beslenme_kayitlari (id INTEGER PRIMARY KEY AUTOINCREMENT, yemek_adi TEXT, kalori TEXT, resim_yolu TEXT, tarih TEXT)');
    // v3: Yeni tablolar
    await db.execute(
        'CREATE TABLE su_takibi (id INTEGER PRIMARY KEY AUTOINCREMENT, miktar_ml INTEGER, tarih TEXT)');
    await db.execute(
        'CREATE TABLE kilo_takibi (id INTEGER PRIMARY KEY AUTOINCREMENT, kilo REAL, tarih TEXT)');
  }

  Future _onUpgrade(Database db, int eskiSurum, int yeniSurum) async {
    if (eskiSurum < 2) {
      await db.execute(
          "ALTER TABLE ilaclar ADD COLUMN tip TEXT DEFAULT 'Hap'");
      await db.execute(
          "ALTER TABLE ilaclar ADD COLUMN birim TEXT DEFAULT 'adet'");
      await db.execute(
          'CREATE TABLE IF NOT EXISTS beslenme_kayitlari (id INTEGER PRIMARY KEY AUTOINCREMENT, yemek_adi TEXT, kalori TEXT, resim_yolu TEXT, tarih TEXT)');
    }
    if (eskiSurum < 3) {
      await db.execute(
          'CREATE TABLE IF NOT EXISTS su_takibi (id INTEGER PRIMARY KEY AUTOINCREMENT, miktar_ml INTEGER, tarih TEXT)');
      await db.execute(
          'CREATE TABLE IF NOT EXISTS kilo_takibi (id INTEGER PRIMARY KEY AUTOINCREMENT, kilo REAL, tarih TEXT)');
    }
  }

  // --- BULUT / WHATSAPP YEDEKLEME ---
  Future<void> veritabaniYedekleHafizaya() async {
    String dbYolu =
        join(await getDatabasesPath(), 'seray_saglik_asistanim.db');
    File dbDosyasi = File(dbYolu);
    if (await dbDosyasi.exists()) {
      await Share.shareXFiles(
        [XFile(dbDosyasi.path, name: 'seray_saglik_yedek.db')],
        text: 'Seray Sağlık Asistanım Güvenli Bulut Yedek Dosyası',
      );
    }
  }

  Future<bool> yedegiGeriYukle(String secilenYedekYolu) async {
    try {
      if (_database != null) {
        await _database!.close();
        _database = null;
      }
      String asilDbYolu =
          join(await getDatabasesPath(), 'seray_saglik_asistanim.db');
      File yeniYedekDosyasi = File(secilenYedekYolu);
      await yeniYedekDosyasi.copy(asilDbYolu);
      _database = await _initDatabase();
      return true;
    } catch (e) {
      return false;
    }
  }

  // --- ŞEKER ---
  Future<int> sekerEkle(Map<String, dynamic> veri) async {
    Database db = await database;
    return await db.insert('seker_olcumleri', veri);
  }

  Future<List<Map<String, dynamic>>> sekerleriGetir() async {
    Database db = await database;
    return await db.query('seker_olcumleri', orderBy: 'id DESC');
  }

  Future<int> sekerSil(int id) async {
    Database db = await database;
    return await db
        .delete('seker_olcumleri', where: 'id = ?', whereArgs: [id]);
  }

  // --- TANSİYON ---
  Future<int> tansiyonEkle(Map<String, dynamic> veri) async {
    Database db = await database;
    return await db.insert('tansiyon_olcumleri', veri);
  }

  Future<List<Map<String, dynamic>>> tansiyonlariGetir() async {
    Database db = await database;
    return await db.query('tansiyon_olcumleri', orderBy: 'id DESC');
  }

  Future<int> tansiyonSil(int id) async {
    Database db = await database;
    return await db
        .delete('tansiyon_olcumleri', where: 'id = ?', whereArgs: [id]);
  }

  // --- İLAÇ ---
  Future<int> ilacEkle(Map<String, dynamic> veri) async {
    Database db = await database;
    return await db.insert('ilaclar', veri);
  }

  Future<int> ilacGuncelle(int id, Map<String, dynamic> veri) async {
    Database db = await database;
    return await db
        .update('ilaclar', veri, where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Map<String, dynamic>>> ilaclariGetir() async {
    Database db = await database;
    return await db.query('ilaclar', orderBy: 'id DESC');
  }

  Future<int> ilacSil(int id) async {
    Database db = await database;
    return await db.delete('ilaclar', where: 'id = ?', whereArgs: [id]);
  }

  // --- BESLENME ---
  Future<int> beslenmeEkle(Map<String, dynamic> veri) async {
    final db = await database;
    return await db.insert('beslenme_kayitlari', veri);
  }

  Future<List<Map<String, dynamic>>> beslenmeKayitlariniGetir() async {
    final db = await database;
    return await db.query('beslenme_kayitlari', orderBy: 'tarih DESC');
  }

  Future<int> beslenmeSil(int id) async {
    final db = await database;
    return await db
        .delete('beslenme_kayitlari', where: 'id = ?', whereArgs: [id]);
  }

  // --- E-NABIZ TAHLİL ---
  Future<int> tahlilEkle(Map<String, dynamic> veri) async {
    Database db = await database;
    return await db.insert('enabiz_tahlilleri', veri);
  }

  Future<List<Map<String, dynamic>>> tumTahlilleriGetir() async {
    Database db = await database;
    return await db.query('enabiz_tahlilleri', orderBy: 'id DESC');
  }

  // Belirli bir tarihe ait tüm tahlilleri sil (yeniden yükleme için)
  Future<void> tariheTahlilleriSil(String tarih) async {
    Database db = await database;
    await db.delete('enabiz_tahlilleri',
        where: 'tarih = ?', whereArgs: [tarih]);
  }

  // --- E-NABIZ YORUM ---
  Future<int> yorumEkle(Map<String, dynamic> veri) async {
    Database db = await database;
    return await db.insert('enabiz_yorumlari', veri);
  }

  Future<List<Map<String, dynamic>>> yorumlariGetir() async {
    Database db = await database;
    return await db.query('enabiz_yorumlari', orderBy: 'id DESC');
  }

  // --- SU TAKİBİ ---
  Future<int> suEkle(int miktarMl) async {
    final db = await database;
    return await db.insert('su_takibi', {
      'miktar_ml': miktarMl,
      'tarih': DateTime.now().toIso8601String(),
    });
  }

  /// Bugünkü toplam su tüketimi (mL)
  Future<int> bugunToplamSuGetir() async {
    final db = await database;
    final simdi = DateTime.now();
    final baslangic =
        DateTime(simdi.year, simdi.month, simdi.day).toIso8601String();
    final bitis =
        DateTime(simdi.year, simdi.month, simdi.day, 23, 59, 59).toIso8601String();
    final sonuc = await db.rawQuery(
      'SELECT COALESCE(SUM(miktar_ml), 0) as toplam FROM su_takibi WHERE tarih >= ? AND tarih <= ?',
      [baslangic, bitis],
    );
    return (sonuc.first['toplam'] as int?) ?? 0;
  }

  Future<List<Map<String, dynamic>>> suKayitlariniGetir() async {
    final db = await database;
    return await db.query('su_takibi', orderBy: 'tarih DESC', limit: 50);
  }

  Future<int> suKaydiSil(int id) async {
    final db = await database;
    return await db.delete('su_takibi', where: 'id = ?', whereArgs: [id]);
  }

  // --- KİLO TAKİBİ ---
  Future<int> kiloEkle(double kilo) async {
    final db = await database;
    return await db.insert('kilo_takibi', {
      'kilo': kilo,
      'tarih': DateTime.now().toIso8601String(),
    });
  }

  Future<List<Map<String, dynamic>>> kiloKayitlariniGetir() async {
    final db = await database;
    return await db.query('kilo_takibi', orderBy: 'tarih DESC', limit: 60);
  }

  Future<int> kiloKaydiSil(int id) async {
    final db = await database;
    return await db.delete('kilo_takibi', where: 'id = ?', whereArgs: [id]);
  }

  // --- VERİTABANI SIFIRLAMA ---
  Future<void> veritabaniSifirla() async {
    Database db = await database;
    await db.delete('seker_olcumleri');
    await db.delete('tansiyon_olcumleri');
    await db.delete('ilaclar');
    await db.delete('enabiz_tahlilleri');
    await db.delete('enabiz_yorumlari');
    await db.delete('beslenme_kayitlari');
    await db.delete('su_takibi');
    await db.delete('kilo_takibi');
  }
}
