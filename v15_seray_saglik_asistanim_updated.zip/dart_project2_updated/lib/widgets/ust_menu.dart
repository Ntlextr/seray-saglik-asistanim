import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/veritabani_yardimcisi.dart';
import '../services/pdf_rapor_servisi.dart';
import '../screens/ayarlar_ekrani.dart';
import '../screens/kullanim_kilavuzu_ekrani.dart';
import '../screens/seray_asistan_ekrani.dart';
import '../screens/su_kilo_ekrani.dart';

class UstMenu extends StatelessWidget {
  const UstMenu({Key? key}) : super(key: key);

  Future<void> _yedekle(BuildContext context) async {
    await VeritabaniYardimcisi().veritabaniYedekleHafizaya();
  }

  Future<void> _yedekGeriYukle(BuildContext context) async {
    FilePickerResult? r = await FilePicker.platform.pickFiles();
    if (r != null) {
      final basarili = await VeritabaniYardimcisi().yedegiGeriYukle(r.files.single.path!);
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(basarili ? 'Yedek başarıyla yüklendi!' : 'Yedek yüklenemedi.'),
        ));
      }
    }
  }

  Future<void> _gunlukSonuclar(BuildContext context) async {
    final prefs = await SharedPreferences.getInstance();
    final ad = prefs.getString('kullanici_ad') ?? '';
    final soyad = prefs.getString('kullanici_soyad') ?? '';
    await PdfRaporServisi.gunlukRaporuOlusturVePaylas(kullaniciAdi: '$ad $soyad'.trim());
  }

  @override
  Widget build(BuildContext context) {
    return PopupMenuButton<String>(
      icon: const Icon(Icons.menu),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      onSelected: (secim) {
        switch (secim) {
          case 'seray':
            Navigator.push(context, MaterialPageRoute(builder: (_) => const SerayAsistanEkrani()));
            break;
          case 'su_kilo':
            Navigator.push(context, MaterialPageRoute(builder: (_) => const SuKiloEkrani()));
            break;
          case 'gunluk_sonuc':
            _gunlukSonuclar(context);
            break;
          case 'yedekle':
            _yedekle(context);
            break;
          case 'geri_yukle':
            _yedekGeriYukle(context);
            break;
          case 'ayarlar':
            Navigator.push(context, MaterialPageRoute(builder: (_) => const AyarlarEkrani()));
            break;
          case 'kilavuz':
            Navigator.push(context, MaterialPageRoute(builder: (_) => const KullanimKilavuzuEkrani()));
            break;
        }
      },
      itemBuilder: (context) => [
        const PopupMenuItem(
          value: 'seray',
          child: ListTile(
            leading: Icon(Icons.health_and_safety, color: Colors.teal),
            title: Text('Seray AI Asistan'),
            subtitle: Text('Sağlık danışmanınız', style: TextStyle(fontSize: 11)),
            dense: true,
          ),
        ),
        const PopupMenuItem(
          value: 'su_kilo',
          child: ListTile(
            leading: Icon(Icons.water_drop, color: Colors.blue),
            title: Text('Su & Kilo Takibi'),
            dense: true,
          ),
        ),
        const PopupMenuDivider(),
        const PopupMenuItem(
          value: 'gunluk_sonuc',
          child: ListTile(
            leading: Icon(Icons.picture_as_pdf, color: Colors.orange),
            title: Text('Günlük Sonuçları Paylaş'),
            dense: true,
          ),
        ),
        const PopupMenuItem(
          value: 'yedekle',
          child: ListTile(
            leading: Icon(Icons.backup),
            title: Text('Verileri Yedekle'),
            dense: true,
          ),
        ),
        const PopupMenuItem(
          value: 'geri_yukle',
          child: ListTile(
            leading: Icon(Icons.restore),
            title: Text('Yedek Bul ve Geri Yükle'),
            dense: true,
          ),
        ),
        const PopupMenuDivider(),
        const PopupMenuItem(
          value: 'ayarlar',
          child: ListTile(
            leading: Icon(Icons.settings),
            title: Text('Ayarlar'),
            dense: true,
          ),
        ),
        const PopupMenuItem(
          value: 'kilavuz',
          child: ListTile(
            leading: Icon(Icons.help_outline),
            title: Text('Kullanma Kılavuzu'),
            dense: true,
          ),
        ),
      ],
    );
  }
}
