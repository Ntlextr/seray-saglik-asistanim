import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import '../services/veritabani_yardimcisi.dart';

class SekerEkleEkrani extends StatefulWidget {
  const SekerEkleEkrani({Key? key}) : super(key: key);

  @override
  State<SekerEkleEkrani> createState() => _SekerEkleEkraniState();
}

class _SekerEkleEkraniState extends State<SekerEkleEkrani> {
  final FlutterTts _flutterTts = FlutterTts();
  bool _sesCaliniyor = false;
  bool _yukleniyor = true;

  // Veritabanından gelen gerçek ölçüm listesi
  List<Map<String, dynamic>> _olcumler = [];

  @override
  void initState() {
    super.initState();
    _olcumleriYukle();
  }

  Future<void> _olcumleriYukle() async {
    final liste = await VeritabaniYardimcisi().sekerleriGetir();
    if (!mounted) return;
    setState(() {
      _olcumler = liste;
      _yukleniyor = false;
    });
  }

  String _tarihiBicimlendir(String? isoTarih) {
    if (isoTarih == null) return '';
    final t = DateTime.tryParse(isoTarih);
    if (t == null) return isoTarih;
    String iki(int n) => n.toString().padLeft(2, '0');
    return '${iki(t.day)}.${iki(t.month)}.${t.year}';
  }

  // Kan şekerini 4 seviyeye ayırır: Çok Düşük (hipoglisemi), Düşük, Normal, Yüksek, Çok Yüksek
  // Düşük şeker eşikleri ölçüm tipinden bağımsızdır (hipoglisemi hipoglisemidir).
  String _sekerDurumu(String tip, int deger) {
    if (deger < 54) return 'Çok Düşük';
    if (deger < 70) return 'Düşük';
    if (tip == 'Açlık') {
      if (deger >= 250) return 'Çok Yüksek';
      if (deger > 125) return 'Yüksek';
    } else {
      if (deger >= 250) return 'Çok Yüksek';
      if (deger > 140) return 'Yüksek';
    }
    return 'Normal';
  }

  Color _sekerRengi(String durum) {
    switch (durum) {
      case 'Çok Yüksek':
      case 'Çok Düşük':
        return Colors.red.shade900;
      case 'Yüksek':
      case 'Düşük':
        return Colors.orange.shade800;
      default:
        return Colors.green.shade800;
    }
  }

  Color _sekerArkaPlanRengi(String durum) {
    switch (durum) {
      case 'Çok Yüksek':
      case 'Çok Düşük':
        return Colors.red.shade50;
      case 'Yüksek':
      case 'Düşük':
        return Colors.orange.shade50;
      default:
        return Colors.green.shade50;
    }
  }

  bool _acilMi(String durum) => durum == 'Çok Yüksek' || durum == 'Çok Düşük';

  String _durumuAyikla(String kayitliDurum) {
    if (kayitliDurum.contains('Çok Yüksek')) return 'Çok Yüksek';
    if (kayitliDurum.contains('Çok Düşük')) return 'Çok Düşük';
    if (kayitliDurum.contains('Yüksek')) return 'Yüksek';
    if (kayitliDurum.contains('Düşük')) return 'Düşük';
    return 'Normal';
  }

  // Yeni ölçüm ekleme penceresi
  void _yeniOlcumEkle() {
    final degerController = TextEditingController();
    String tip = 'Açlık';

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Padding(
              padding: EdgeInsets.only(
                left: 24,
                right: 24,
                top: 24,
                bottom: MediaQuery.of(context).viewInsets.bottom + 24,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Yeni Şeker Ölçümü',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: degerController,
                    keyboardType: TextInputType.number,
                    autofocus: true,
                    decoration: InputDecoration(
                      labelText: 'Şeker Değeri (mg/dL)',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                      prefixIcon: const Icon(Icons.bloodtype),
                    ),
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    value: tip,
                    decoration: InputDecoration(
                      labelText: 'Ölçüm Tipi',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    items: const [
                      DropdownMenuItem(value: 'Açlık', child: Text('Açlık Ölçümü')),
                      DropdownMenuItem(value: 'Tokluk', child: Text('Tokluk Ölçümü')),
                    ],
                    onChanged: (val) {
                      if (val != null) setModalState(() => tip = val);
                    },
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.teal,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      onPressed: () async {
                        final metin = degerController.text.trim();
                        final deger = int.tryParse(metin);
                        if (deger == null) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Lütfen geçerli bir sayı girin.')),
                          );
                          return;
                        }
                        String durum = _sekerDurumu(tip, deger);

                        await VeritabaniYardimcisi().sekerEkle({
                          'deger': deger,
                          'durum': '$tip - $durum',
                          'tarih': DateTime.now().toIso8601String(),
                        });

                        if (context.mounted) Navigator.pop(context);
                        await _olcumleriYukle();
                      },
                      child: const Text(
                        'Kaydet',
                        style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Future<void> _olcumSil(int id) async {
    await VeritabaniYardimcisi().sekerSil(id);
    await _olcumleriYukle();
  }

  // 🔊 ŞEKER DEĞERLERİNİ ANALİZ EDİP SESLİ OKUYAN FONKSİYON
  Future<void> _sekerAnaliziniSeslendir() async {
    if (_sesCaliniyor) {
      await _flutterTts.stop();
      setState(() => _sesCaliniyor = false);
      return;
    }

    if (_olcumler.isEmpty) {
      await _flutterTts.speak("Henüz kaydedilmiş bir şeker ölçümünüz bulunmamaktadır.");
      return;
    }

    final sonOlcum = _olcumler.first;
    int deger = sonOlcum['deger'] as int;
    String durumBilgisi = (sonOlcum['durum'] ?? '').toString();
    String tip = durumBilgisi.contains('Tokluk') ? 'Tokluk' : 'Açlık';
    final durum = _sekerDurumu(tip, deger);

    String durumMetni = "Son ölçümünüze göre $tip kan şekeri değeriniz $deger miligram bölü desilitredir. ";

    switch (durum) {
      case 'Çok Düşük':
        durumMetni += "Bu değer ciddi derecede düşük ve acil bir durum olabilir. Hemen hızlı emilen bir şeker kaynağı tüketin ve en kısa sürede bir doktora veya acil servise başvurun.";
        break;
      case 'Düşük':
        durumMetni += "Şekeriniz düşük seyretmektedir. Halsizlik veya titreme hissediyorsanız hızlı emilen bir şeker kaynağı tüketebilirsiniz.";
        break;
      case 'Çok Yüksek':
        durumMetni += "Bu değer normalin çok üzerinde ve acil bir durum olabilir. Lütfen en kısa sürede bir doktora veya acil servise başvurunuz.";
        break;
      case 'Yüksek':
        durumMetni += "Şekeriniz hedef değerlerin üzerinde çıkmıştır. Beslenmenizi gözden geçirmenizi ve doktorunuzla görüşmenizi öneririz.";
        break;
      default:
        durumMetni += "Şeker seyriniz tamamen ideal ve normal sınırlardadır. Tebrik ederiz.";
    }

    setState(() => _sesCaliniyor = true);
    await _flutterTts.setLanguage("tr-TR");
    await _flutterTts.setPitch(1.0);
    await _flutterTts.speak(durumMetni);

    _flutterTts.setCompletionHandler(() {
      if (mounted) setState(() => _sesCaliniyor = false);
    });
  }

  @override
  void dispose() {
    _flutterTts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Şeker Takibi', style: TextStyle(color: Color(0xFF111424), fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Color(0xFF111424)),
        actions: [
          IconButton(
            icon: Icon(
              _sesCaliniyor ? Icons.stop_circle : Icons.volume_up,
              color: Colors.blue,
              size: 28,
            ),
            onPressed: _sekerAnaliziniSeslendir,
          ),
          const SizedBox(width: 12),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _yeniOlcumEkle,
        backgroundColor: Colors.teal,
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text('Ölçüm Ekle', style: TextStyle(color: Colors.white)),
      ),
      body: _yukleniyor
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Ölçüm Geçmişiniz', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  Expanded(
                    child: _olcumler.isEmpty
                        ? const Center(
                            child: Text(
                              'Henüz kaydedilmiş bir ölçüm bulunmuyor.\nSağ alttaki + butonuyla ekleyebilirsiniz.',
                              textAlign: TextAlign.center,
                              style: TextStyle(color: Colors.grey),
                            ),
                          )
                        : ListView.builder(
                            itemCount: _olcumler.length,
                            itemBuilder: (context, index) {
                              final olcum = _olcumler[index];
                              final kayitliDurum = (olcum['durum'] ?? '').toString();
                              final durum = _durumuAyikla(kayitliDurum);
                              final acilMi = _acilMi(durum);
                              String tip = kayitliDurum.contains('Tokluk') ? 'Tokluk' : 'Açlık';

                              return Card(
                                margin: const EdgeInsets.symmetric(vertical: 6),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  side: acilMi ? BorderSide(color: Colors.red.shade400, width: 1.5) : BorderSide.none,
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 4),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      ListTile(
                                        leading: Icon(
                                          Icons.opacity,
                                          color: _sekerRengi(durum),
                                          size: 28,
                                        ),
                                        title: Text(
                                          '${olcum['deger']} mg/dL',
                                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                                        ),
                                        subtitle: Text('$tip Ölçümü - ${_tarihiBicimlendir(olcum['tarih']?.toString())}'),
                                        trailing: Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Container(
                                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                              decoration: BoxDecoration(
                                                color: _sekerArkaPlanRengi(durum),
                                                borderRadius: BorderRadius.circular(8),
                                              ),
                                              child: Text(
                                                durum,
                                                style: TextStyle(color: _sekerRengi(durum), fontWeight: FontWeight.bold),
                                              ),
                                            ),
                                            IconButton(
                                              icon: const Icon(Icons.delete_outline, color: Colors.grey),
                                              onPressed: () => _olcumSil(olcum['id'] as int),
                                            ),
                                          ],
                                        ),
                                      ),
                                      if (acilMi)
                                        Padding(
                                          padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                                          child: Row(
                                            children: [
                                              Icon(Icons.warning_amber_rounded, color: Colors.red.shade700, size: 18),
                                              const SizedBox(width: 6),
                                              Expanded(
                                                child: Text(
                                                  durum == 'Çok Düşük'
                                                      ? 'Bu değer acil olabilir. Hemen şeker/meyve suyu tüketin ve en kısa sürede doktora veya acil servise başvurun.'
                                                      : 'Bu değer acil olabilir. En kısa sürede bir doktora veya acil servise başvurun.',
                                                  style: TextStyle(color: Colors.red.shade700, fontSize: 12, fontWeight: FontWeight.bold),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                  ),
                ],
              ),
            ),
    );
  }
}
