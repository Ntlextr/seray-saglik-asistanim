import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'seker_ekle_ekrani.dart';
import 'tansiyon_ekle_ekrani.dart';
import '../services/veritabani_yardimcisi.dart';
import '../widgets/ust_menu.dart';

class AnaSayfa extends StatefulWidget {
  const AnaSayfa({Key? key}) : super(key: key);

  @override
  _AnaSayfaState createState() => _AnaSayfaState();
}

class _AnaSayfaState extends State<AnaSayfa> {
  String _kullaniciAdi = "...";
  String _cinsiyet = "Bay";
  List<Map<String, dynamic>> _sonSekerler = [];
  List<Map<String, dynamic>> _sonTansiyonlar = [];

  String get _hitap => (_cinsiyet == 'Bayan' || _cinsiyet == 'Kadın') ? 'Hanım' : 'Bey';

  String get _selamlama {
    final saat = DateTime.now().hour;
    if (saat >= 5 && saat < 12) return 'Günaydın';
    if (saat >= 12 && saat < 18) return 'İyi Günler';
    if (saat >= 18 && saat < 23) return 'İyi Akşamlar';
    return 'İyi Geceler';
  }

  String _tarihiBicimlendir(String? isoTarih) {
    if (isoTarih == null) return '';
    final t = DateTime.tryParse(isoTarih);
    if (t == null) return isoTarih;
    String iki(int n) => n.toString().padLeft(2, '0');
    return '${iki(t.day)}.${iki(t.month)}.${t.year} ${iki(t.hour)}:${iki(t.minute)}';
  }

  @override
  void initState() {
    super.initState();
    _verileriTazele();
  }

  Future<void> _verileriTazele() async {
    final prefs = await SharedPreferences.getInstance();
    final sekerler = await VeritabaniYardimcisi().sekerleriGetir();
    final tansiyonlar = await VeritabaniYardimcisi().tansiyonlariGetir();
    
    setState(() {
      // Hem profil_kayit_ekrani hem eski kayıt anahtarları kontrol ediliyor
      _kullaniciAdi = prefs.getString('kullanici_ad') ?? 
                       prefs.getString('user_ad') ?? 
                       "Kullanıcı";
      _cinsiyet = prefs.getString('kullanici_cinsiyet') ?? 
                  prefs.getString('user_cinsiyet') ?? 
                  "Bay";
                  
      _sonSekerler = sekerler;
      _sonTansiyonlar = tansiyonlar;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(
        backgroundColor: Colors.grey.shade50,
        foregroundColor: Colors.teal,
        elevation: 0,
        actions: const [UstMenu()],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // LOGO (Resim bulunamazsa ikon gösterir)
              Center(
                child: TweenAnimationBuilder(
                  duration: const Duration(seconds: 1),
                  tween: Tween<double>(begin: 0.8, end: 1.0),
                  builder: (context, double value, child) {
                    return Transform.scale(
                      scale: value,
                      child: child,
                    );
                  },
                  child: Image.asset(
                    'assets/images/app_icon.png',
                    height: 140,
                    width: 140,
                    fit: BoxFit.contain,
                    errorBuilder: (context, error, stackTrace) {
                      return Image.asset(
                        'assets/images/app_logo.png',
                        height: 140,
                        width: 140,
                        errorBuilder: (c, e, s) => const Icon(
                          Icons.health_and_safety,
                          size: 100,
                          color: Colors.teal,
                        ),
                      );
                    },
                  ),
                ),
              ),
              const SizedBox(height: 16),

              // DİNAMİK SELAMLAMA KARTI (Örn: İyi Akşamlar, Serdar Bey 🌤️)
              Card(
                color: Colors.teal.shade50,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                elevation: 0,
                child: Padding(
                  padding: const EdgeInsets.all(18.0),
                  child: Text(
                    '$_selamlama, $_kullaniciAdi $_hitap 🌤️',
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF006655),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),

              // HIZLI BUTONLAR
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.teal,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => SekerEkleEkrani(),
                          ),
                        ).then((_) => _verileriTazele());
                      },
                      icon: const Icon(Icons.bloodtype),
                      label: const Text('Şeker Ekle'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.teal.shade700,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => TansiyonEkleEkrani(),
                          ),
                        ).then((_) => _verileriTazele());
                      },
                      icon: const Icon(Icons.favorite),
                      label: const Text('Tansiyon Ekle'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),

              // SON ÖLÇÜMLER BAŞLIĞI
              const Text(
                'Son Ölçümleriniz',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF111424),
                ),
              ),
              const SizedBox(height: 12),

              // ŞEKER ÖLÇÜMÜ
              if (_sonSekerler.isNotEmpty)
                Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: ListTile(
                    leading: const CircleAvatar(
                      backgroundColor: Color(0xFFFFEBEE),
                      child: Icon(Icons.bloodtype, color: Colors.red),
                    ),
                    title: Text(
                      'Kan Şekeri: ${_sonSekerler.first['deger']} mg/dL',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text(
                      'Durum: ${_sonSekerler.first['durum'] ?? 'Belirtilmedi'}\nTarih: ${_tarihiBicimlendir(_sonSekerler.first['tarih']?.toString())}',
                    ),
                  ),
                ),

              // TANSİYON ÖLÇÜMÜ
              if (_sonTansiyonlar.isNotEmpty)
                Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: ListTile(
                    leading: const CircleAvatar(
                      backgroundColor: Color(0xE8E0F2F1),
                      child: Icon(Icons.favorite, color: Colors.teal),
                    ),
                    title: Text(
                      'Tansiyon: ${_sonTansiyonlar.first['buyuk']}/${_sonTansiyonlar.first['kucuk']} mmHg',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text(
                      'Tarih: ${_tarihiBicimlendir(_sonTansiyonlar.first['tarih']?.toString())}',
                    ),
                  ),
                ),

              if (_sonSekerler.isEmpty && _sonTansiyonlar.isEmpty)
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Center(
                    child: Text(
                      'Henüz kaydedilmiş bir ölçüm bulunmuyor.',
                      style: TextStyle(color: Colors.grey),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
      // NOT: Alt navigasyon menüsü artık sadece main.dart'taki
      // AnaEkranYonlendirici içinde tek bir yerden yönetiliyor.
      // Burada ikinci bir bottomNavigationBar OLMAMALI, aksi halde
      // eski (Ana Sayfa/Şeker/Tansiyon/Profil) menü ile yeni
      // (Özet/Analizler/İlaçlarım/Profil) menü çakışır.
    );
  }
}
