import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import '../services/bildirim_servisi.dart';

// Alarm saatinde açılan tam ekran uyarı. Telefon kilitli ya da kilitsiz,
// kullanıcı başka bir şey yapıyor olsa bile bu ekran öne çıkar. "Kapat"a
// basılana kadar hem bildirim sesi hem de sesli okuma (TTS) tekrar eder.
class AlarmEkrani extends StatefulWidget {
  final int bildirimId;
  final String ilacAdi;
  const AlarmEkrani({Key? key, required this.bildirimId, required this.ilacAdi}) : super(key: key);

  @override
  State<AlarmEkrani> createState() => _AlarmEkraniState();
}

class _AlarmEkraniState extends State<AlarmEkrani> {
  final FlutterTts _tts = FlutterTts();
  Timer? _tekrarZamanlayici;

  @override
  void initState() {
    super.initState();
    _sesliOkumayaBasla();
  }

  Future<void> _sesliOkumayaBasla() async {
    await _tts.setLanguage('tr-TR');
    await _tts.setSpeechRate(0.45);
    _tekrarSoyle();
    // Her 6 saniyede bir tekrar seslendir; kullanıcı Kapat'a basana kadar sürer.
    _tekrarZamanlayici = Timer.periodic(const Duration(seconds: 6), (_) => _tekrarSoyle());
  }

  Future<void> _tekrarSoyle() async {
    await _tts.speak('${widget.ilacAdi} ilacınızı alma vaktiniz geldi');
  }

  Future<void> _kapat() async {
    _tekrarZamanlayici?.cancel();
    await _tts.stop();
    await BildirimServisi.iptalEt(widget.bildirimId);
    if (mounted) Navigator.of(context).pop();
  }

  @override
  void dispose() {
    _tekrarZamanlayici?.cancel();
    _tts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false, // geri tuşuyla kapatılamasın, sadece "Kapat" butonuyla
      child: Scaffold(
        backgroundColor: Colors.teal.shade700,
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.medication, color: Colors.white, size: 96),
                const SizedBox(height: 24),
                const Text('İlaç Zamanı', style: TextStyle(color: Colors.white70, fontSize: 22)),
                const SizedBox(height: 8),
                Text(
                  widget.ilacAdi,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white, fontSize: 44, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 64),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    style: FilledButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: Colors.teal.shade700,
                      padding: const EdgeInsets.symmetric(vertical: 20),
                      textStyle: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                    ),
                    onPressed: _kapat,
                    child: const Text('KAPAT'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
