import "package:seray_saglik_asistanim/screens/ana_sayfa.dart";
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:seray_saglik_asistanim/main.dart';

class ProfilKayitEkrani extends StatefulWidget {
  const ProfilKayitEkrani({Key? key}) : super(key: key);

  @override
  State<ProfilKayitEkrani> createState() => _ProfilKayitEkraniState();
}

class _ProfilKayitEkraniState extends State<ProfilKayitEkrani> {
  final GlobalKey<_ProfilKayitFormState> _formKey = GlobalKey<_ProfilKayitFormState>();

  bool _kullanimKosullari = false;
  bool _gizlilikPolitikasi = false;
  bool _aydinlatmaMetni = false;
  bool _rizaMetni = false;
  bool _kampanyaOnay = false;

  bool _kullanimOkundu = false;
  bool _gizlilikOkundu = false;
  bool _aydinlatmaOkundu = false;
  bool _rizaOkundu = false;

  bool get _kayitButonuAktifMi {
    return _aydinlatmaOkundu && _rizaOkundu;
  }

  void _metniOkuVeOnayla({
    required String baslik,
    required String icerik,
    required Function(bool) onOnay,
  }) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        return DraggableScrollableSheet(
          initialChildSize: 0.75,
          minChildSize: 0.5,
          maxChildSize: 0.95,
          expand: false,
          builder: (context, scrollController) {
            return Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    baslik,
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF111424),
                    ),
                  ),
                  const SizedBox(height: 15),
                  Expanded(
                    child: ListView(
                      controller: scrollController,
                      children: [
                        Text(
                          icerik,
                          style: const TextStyle(
                            fontSize: 15,
                            color: Colors.black87,
                            height: 1.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 15),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF111424),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      onPressed: () {
                        onOnay(true);
                        Navigator.pop(context);
                      },
                      child: const Text(
                        'Okudum, Kabul Ediyorum',
                        style: TextStyle(color: Colors.white, fontSize: 16),
                      ),
                    ),
                  )
                ],
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text(
          'Profil Kaydı',
          style: TextStyle(
            color: Color(0xFF111424),
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Color(0xFF111424)),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(bottom: 20.0),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Image.asset(
                    'assets/images/seray_banner.png',
                    width: double.infinity,
                    fit: BoxFit.fitWidth,
                    errorBuilder: (context, error, stackTrace) => Container(
                      width: double.infinity,
                      height: 90,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(color: Colors.teal, borderRadius: BorderRadius.circular(16)),
                      child: const Text('SERAY SAĞLIK ASİSTANIM', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18)),
                    ),
                  ),
                ),
              ),
              ProfilKayitForm(key: _formKey),
              const SizedBox(height: 30),
              const Divider(height: 1),
              const SizedBox(height: 20),
              _buildYasalSatir(
                baslik: 'Aydınlatma metni',
                isZorunlu: true,
                value: _aydinlatmaMetni,
                onTap: () {
                  _metniOkuVeOnayla(
                    baslik: 'KVKK Aydınlatma Metni',
                    icerik: '6698 sayılı Kişisel Verilerin Korunması Kanunu uyarınca, Seray Teknoloji olarak sağlık verilerinizin işlenme amaçları, saklanma süreleri ve haklarınız hakkında bilgilendirme metnidir...',
                    onOnay: (onay) => setState(() {
                      _aydinlatmaOkundu = onay;
                      _aydinlatmaMetni = onay;
                    }),
                  );
                },
              ),

              _buildYasalSatir(
                baslik: 'Rıza metni',
                isZorunlu: true,
                value: _rizaMetni,
                onTap: () {
                  _metniOkuVeOnayla(
                    baslik: 'Açık Rıza Metni',
                    icerik: 'Yapay zeka tahlil analizi ve seslendirme servislerinin çalışabilmesi için anonimleştirilmiş sağlık verilerinizin güvenli API modelleri ile işlenmesine açık rıza gösteriyorsunuz...',
                    onOnay: (onay) => setState(() {
                      _rizaOkundu = onay;
                      _rizaMetni = onay;
                    }),
                  );
                },
              ),

              const SizedBox(height: 32),

              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _kayitButonuAktifMi ? const Color(0xFF111424) : Colors.grey.shade300,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                    elevation: _kayitButonuAktifMi ? 2 : 0,
                  ),
                  onPressed: _kayitButonuAktifMi
                      ? () async {
                          await _formKey.currentState?.profiliKaydet();
                          final prefs = await SharedPreferences.getInstance();
                          await prefs.setBool('is_logged_in', true);

                          if (mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Profil bilgileriniz başarıyla kaydedildi!')),
                            );
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(builder: (context) => const AnaEkranYonlendirici()),
                            );
                          }
                        }
                      : null,
                  child: Text(
                    'Sonraki',
                    style: TextStyle(
                      color: _kayitButonuAktifMi ? Colors.white : Colors.grey.shade600,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildYasalSatir({
    required String baslik,
    required bool isZorunlu,
    required bool value,
    required VoidCallback onTap,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 4),
      padding: const EdgeInsets.symmetric(vertical: 6),
      decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Colors.grey.shade300))),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: GestureDetector(
              onTap: onTap,
              child: RichText(
                text: TextSpan(
                  style: const TextStyle(fontSize: 14, color: Colors.black87),
                  children: [
                    if (isZorunlu)
                      const TextSpan(text: '* ', style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
                    const TextSpan(text: 'Okudum ve kabul ediyorum '),
                    TextSpan(text: baslik, style: const TextStyle(fontWeight: FontWeight.bold, decoration: TextDecoration.underline)),
                  ],
                ),
              ),
            ),
          ),
          Switch(
            value: value,
            activeColor: const Color(0xFF00cc88),
            onChanged: (bool newValue) {
              onTap();
            },
          ),
        ],
      ),
    );
  }
}
class ProfilKayitForm extends StatefulWidget {
  const ProfilKayitForm({Key? key}) : super(key: key);

  @override
  State<ProfilKayitForm> createState() => _ProfilKayitFormState();
}

class _ProfilKayitFormState extends State<ProfilKayitForm> {
  final _adController = TextEditingController();
  final _soyadController = TextEditingController();
  final _yasController = TextEditingController();
  String _cinsiyet = 'Bay';
  String _diyabetTuru = 'Tip 2 Diyabet';
  String? _fotoYolu;

  @override
  void initState() {
    super.initState();
    _mevcutBilgileriYukle();
  }

  Future<void> _mevcutBilgileriYukle() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _adController.text = prefs.getString('kullanici_ad') ?? '';
      _soyadController.text = prefs.getString('kullanici_soyad') ?? '';
      _yasController.text = prefs.getString('kullanici_yas') ?? '';
      _cinsiyet = prefs.getString('kullanici_cinsiyet') ?? 'Bay';
      _diyabetTuru = prefs.getString('kullanici_diyabet_turu') ?? 'Tip 2 Diyabet';
      _fotoYolu = prefs.getString('kullanici_foto_yolu');
    });
  }

  Future<void> _fotoSec() async {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (context) {
        return SafeArea(
          child: Wrap(
            children: [
              ListTile(
                leading: const Icon(Icons.photo_camera),
                title: const Text('Kameradan Çek'),
                onTap: () async {
                  Navigator.pop(context);
                  await _fotografiAl(ImageSource.camera);
                },
              ),
              ListTile(
                leading: const Icon(Icons.photo_library),
                title: const Text('Galeriden Seç'),
                onTap: () async {
                  Navigator.pop(context);
                  await _fotografiAl(ImageSource.gallery);
                },
              ),
              if (_fotoYolu != null)
                ListTile(
                  leading: const Icon(Icons.delete_outline, color: Colors.red),
                  title: const Text('Fotoğrafı Kaldır', style: TextStyle(color: Colors.red)),
                  onTap: () async {
                    Navigator.pop(context);
                    final prefs = await SharedPreferences.getInstance();
                    await prefs.remove('kullanici_foto_yolu');
                    setState(() => _fotoYolu = null);
                  },
                ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _fotografiAl(ImageSource kaynak) async {
    try {
      final XFile? secilen = await ImagePicker().pickImage(source: kaynak, maxWidth: 800, imageQuality: 85);
      if (secilen != null) {
        setState(() => _fotoYolu = secilen.path);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Fotoğraf seçilirken bir sorun oluştu.')));
      }
    }
  }

  Future<void> profiliKaydet() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('kullanici_ad', _adController.text.trim());
    await prefs.setString('kullanici_soyad', _soyadController.text.trim());
    await prefs.setString('kullanici_yas', _yasController.text.trim());
    await prefs.setString('kullanici_cinsiyet', _cinsiyet);
    await prefs.setString('kullanici_diyabet_turu', _diyabetTuru);
    if (_fotoYolu != null) {
      await prefs.setString('kullanici_foto_yolu', _fotoYolu!);
    }
  }

  @override
  void dispose() {
    _adController.dispose();
    _soyadController.dispose();
    _yasController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Kişisel Bilgiler', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Color(0xFF111424))),
        const SizedBox(height: 16),
        Center(
          child: GestureDetector(
            onTap: _fotoSec,
            child: Stack(
              children: [
                CircleAvatar(
                  radius: 50,
                  backgroundColor: Colors.teal.shade50,
                  backgroundImage: _fotoYolu != null ? FileImage(File(_fotoYolu!)) : null,
                  child: _fotoYolu == null ? const Icon(Icons.person, size: 50, color: Colors.teal) : null,
                ),
                Positioned(
                  bottom: 0,
                  right: 0,
                  child: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: const BoxDecoration(color: Colors.teal, shape: BoxShape.circle),
                    child: const Icon(Icons.camera_alt, size: 18, color: Colors.white),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 20),
        TextField(
          controller: _adController,
          decoration: InputDecoration(labelText: 'Adınız', border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)), prefixIcon: const Icon(Icons.person)),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _soyadController,
          decoration: InputDecoration(labelText: 'Soyadınız', border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)), prefixIcon: const Icon(Icons.person_outline)),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _yasController,
          keyboardType: TextInputType.number,
          decoration: InputDecoration(labelText: 'Yaşınız', border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)), prefixIcon: const Icon(Icons.cake)),
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: _cinsiyet,
          decoration: InputDecoration(labelText: 'Cinsiyet', border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)), prefixIcon: const Icon(Icons.wc)),
          items: const [DropdownMenuItem(value: 'Bay', child: Text('Bay')), DropdownMenuItem(value: 'Bayan', child: Text('Bayan'))],
          onChanged: (val) {
            if (val != null) setState(() => _cinsiyet = val);
          },
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: _diyabetTuru,
          decoration: InputDecoration(labelText: 'Diyabet Türü', border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)), prefixIcon: const Icon(Icons.bloodtype)),
          items: const [
            DropdownMenuItem(value: 'Tip 1 Diyabet', child: Text('Tip 1 Diyabet')),
            DropdownMenuItem(value: 'Tip 2 Diyabet', child: Text('Tip 2 Diyabet')),
            DropdownMenuItem(value: 'Gizli Şeker (Prediyabet)', child: Text('Gizli Şeker (Prediyabet)')),
            DropdownMenuItem(value: 'Gebelik Diyabeti', child: Text('Gebelik Diyabeti')),
            DropdownMenuItem(value: 'Diyabet Hastası Değilim', child: Text('Diyabet Hastası Değilim')),
          ],
          onChanged: (val) {
            if (val != null) setState(() => _diyabetTuru = val);
          },
        ),
      ],
    );
  }
}
