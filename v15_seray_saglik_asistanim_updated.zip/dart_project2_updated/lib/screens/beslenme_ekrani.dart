import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../services/veritabani_yardimcisi.dart';
import '../services/api_service.dart';
import '../widgets/ust_menu.dart';

class BeslenmeEkrani extends StatefulWidget {
  const BeslenmeEkrani({Key? key}) : super(key: key);
  @override
  _BeslenmeEkraniState createState() => _BeslenmeEkraniState();
}

class _BeslenmeEkraniState extends State<BeslenmeEkrani> {
  List<Map<String, dynamic>> _kayitlar = [];
  List<Map<String, dynamic>> _sekerOlcumleri = [];

  @override
  void initState() {
    super.initState();
    _kayitlariYukle();
  }

  Future<void> _kayitlariYukle() async {
    final veriler = await VeritabaniYardimcisi().beslenmeKayitlariniGetir();
    final sekerler = await VeritabaniYardimcisi().sekerleriGetir();
    if (mounted) {
      setState(() {
        _kayitlar = veriler;
        _sekerOlcumleri = sekerler;
      });
    }
  }

  String _tarihiBicimlendir(String? isoTarih) {
    if (isoTarih == null || isoTarih.isEmpty) return '';
    final t = DateTime.tryParse(isoTarih);
    if (t == null) return isoTarih;
    String iki(int n) => n.toString().padLeft(2, '0');
    return '${iki(t.day)}.${iki(t.month)}.${t.year} ${iki(t.hour)}:${iki(t.minute)}';
  }

  // Yemekten önce (4 saat içinde) yapılmış en yakın şeker ölçümü
  Map<String, dynamic>? _yemekOncesiSekeri(String? yemekTarihIso) {
    final yemekTarihi = DateTime.tryParse(yemekTarihIso ?? '');
    if (yemekTarihi == null || _sekerOlcumleri.isEmpty) return null;
    Map<String, dynamic>? enYakin;
    Duration? enKisaFark;
    for (final olcum in _sekerOlcumleri) {
      final olcumTarihi = DateTime.tryParse(olcum['tarih']?.toString() ?? '');
      if (olcumTarihi == null) continue;
      final fark = yemekTarihi.difference(olcumTarihi);
      if (fark.inMinutes >= 0 && fark.inHours <= 4) {
        if (enKisaFark == null || fark < enKisaFark) {
          enKisaFark = fark;
          enYakin = olcum;
        }
      }
    }
    return enYakin;
  }

  // Yemekten sonra (4 saat içinde) yapılmış en yakın şeker ölçümü
  Map<String, dynamic>? _yemekSonrasiSekeri(String? yemekTarihIso) {
    final yemekTarihi = DateTime.tryParse(yemekTarihIso ?? '');
    if (yemekTarihi == null || _sekerOlcumleri.isEmpty) return null;
    Map<String, dynamic>? enYakin;
    Duration? enKisaFark;
    for (final olcum in _sekerOlcumleri) {
      final olcumTarihi = DateTime.tryParse(olcum['tarih']?.toString() ?? '');
      if (olcumTarihi == null) continue;
      final fark = olcumTarihi.difference(yemekTarihi);
      if (fark.inMinutes >= 0 && fark.inHours <= 4) {
        if (enKisaFark == null || fark < enKisaFark) {
          enKisaFark = fark;
          enYakin = olcum;
        }
      }
    }
    return enYakin;
  }

  Future<void> _yemekEkleFormunuAc() async {
    final adController = TextEditingController();
    final kaloriController = TextEditingController();
    DateTime secilenTarihSaat = DateTime.now();
    File? secilenFoto;
    bool aiKaloriHesaplaniyor = false;
    String aiKaloriSonucu = '';

    await showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('Yemek Ekle'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Fotoğraf seçici
                GestureDetector(
                  onTap: () async {
                    final kaynak = await showModalBottomSheet<ImageSource>(
                      context: context,
                      builder: (context) => SafeArea(
                        child: Wrap(children: [
                          ListTile(
                            leading: const Icon(Icons.camera_alt),
                            title: const Text('Fotoğraf Çek'),
                            onTap: () => Navigator.pop(context, ImageSource.camera),
                          ),
                          ListTile(
                            leading: const Icon(Icons.photo_library),
                            title: const Text('Galeriden Seç'),
                            onTap: () => Navigator.pop(context, ImageSource.gallery),
                          ),
                        ]),
                      ),
                    );
                    if (kaynak == null) return;
                    final XFile? secilen = await ImagePicker()
                        .pickImage(source: kaynak, maxWidth: 1000, imageQuality: 85);
                    if (secilen != null) {
                      setDialogState(() {
                        secilenFoto = File(secilen.path);
                        aiKaloriSonucu = '';
                      });
                    }
                  },
                  child: Container(
                    height: 120,
                    decoration: BoxDecoration(
                      color: Colors.grey.shade100,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.grey.shade300),
                    ),
                    child: secilenFoto != null
                        ? ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: Image.file(secilenFoto!, fit: BoxFit.cover,
                                width: double.infinity))
                        : const Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.camera_alt, color: Colors.grey, size: 32),
                                SizedBox(height: 4),
                                Text('Fotoğraf Ekle', style: TextStyle(color: Colors.grey)),
                              ],
                            ),
                          ),
                  ),
                ),
                // Yapay zeka kalori tahmini butonu
                if (secilenFoto != null) ...[
                  const SizedBox(height: 8),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.orange.shade700,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      ),
                      onPressed: aiKaloriHesaplaniyor
                          ? null
                          : () async {
                              setDialogState(() => aiKaloriHesaplaniyor = true);
                              final sonuc = await ApiService.fotograftanKaloriTahminEt(secilenFoto!);
                              // Kalori rakamını otomatik doldur
                              final kaloriEsles = RegExp(r'(\d+)\s*kcal').firstMatch(sonuc);
                              if (kaloriEsles != null) {
                                kaloriController.text = kaloriEsles.group(1) ?? '';
                              }
                              // Yemek adını otomatik doldur
                              final yemekEsles = RegExp(r'Yemek:\s*(.+)').firstMatch(sonuc);
                              if (yemekEsles != null && adController.text.isEmpty) {
                                adController.text = yemekEsles.group(1)?.trim() ?? '';
                              }
                              setDialogState(() {
                                aiKaloriSonucu = sonuc;
                                aiKaloriHesaplaniyor = false;
                              });
                            },
                      icon: aiKaloriHesaplaniyor
                          ? const SizedBox(width: 14, height: 14,
                              child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                          : const Icon(Icons.auto_awesome, size: 16),
                      label: Text(aiKaloriHesaplaniyor ? 'Analiz ediliyor...' : '🤖 AI ile Kalori Tahmin Et'),
                    ),
                  ),
                  // AI sonucu göster
                  if (aiKaloriSonucu.isNotEmpty)
                    Container(
                      margin: const EdgeInsets.only(top: 6),
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.orange.shade50,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.orange.shade200),
                      ),
                      child: Text(aiKaloriSonucu,
                          style: const TextStyle(fontSize: 12, height: 1.4)),
                    ),
                ],
                const SizedBox(height: 12),
                TextField(
                  controller: adController,
                  decoration: const InputDecoration(
                    labelText: 'Yemek Adı',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.restaurant),
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: kaloriController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Kalori (kcal)',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.local_fire_department),
                    hintText: 'Örn: 450',
                  ),
                ),
                const SizedBox(height: 10),
                // Tarih seçici
                InkWell(
                  onTap: () async {
                    final tarih = await showDatePicker(
                      context: context,
                      initialDate: secilenTarihSaat,
                      firstDate: DateTime(2020),
                      lastDate: DateTime.now(),
                    );
                    if (tarih == null) return;
                    final saat = await showTimePicker(
                      context: context,
                      initialTime: TimeOfDay.fromDateTime(secilenTarihSaat),
                    );
                    if (saat == null) return;
                    setDialogState(() {
                      secilenTarihSaat = DateTime(tarih.year, tarih.month, tarih.day, saat.hour, saat.minute);
                    });
                  },
                  child: InputDecorator(
                    decoration: const InputDecoration(
                      labelText: 'Tarih & Saat',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.access_time),
                    ),
                    child: Text(
                      '${secilenTarihSaat.day.toString().padLeft(2, '0')}.${secilenTarihSaat.month.toString().padLeft(2, '0')}.${secilenTarihSaat.year}  ${secilenTarihSaat.hour.toString().padLeft(2, '0')}:${secilenTarihSaat.minute.toString().padLeft(2, '0')}',
                      style: const TextStyle(fontSize: 14),
                    ),
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('İptal')),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.teal, foregroundColor: Colors.white),
              onPressed: () async {
                if (adController.text.trim().isEmpty) return;
                await VeritabaniYardimcisi().beslenmeEkle({
                  'yemek_adi': adController.text.trim(),
                  'kalori': kaloriController.text.trim(),
                  'resim_yolu': secilenFoto?.path ?? '',
                  'tarih': secilenTarihSaat.toIso8601String(),
                });
                Navigator.pop(context);
                await _kayitlariYukle();
              },
              child: const Text('Kaydet'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Bugünkü toplam kalori
    final bugun = DateTime.now();
    int bugunToplam = 0;
    for (final k in _kayitlar) {
      final t = DateTime.tryParse(k['tarih']?.toString() ?? '');
      if (t != null && t.year == bugun.year && t.month == bugun.month && t.day == bugun.day) {
        bugunToplam += int.tryParse(k['kalori']?.toString() ?? '0') ?? 0;
      }
    }

    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(
        backgroundColor: Colors.grey.shade50,
        foregroundColor: Colors.teal,
        elevation: 0,
        title: const Text('Beslenme Takibi', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF111424))),
        actions: const [UstMenu()],
      ),
      body: Column(
        children: [
          // Bugünkü toplam kalori
          if (bugunToplam > 0)
            Container(
              margin: const EdgeInsets.fromLTRB(16, 8, 16, 0),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              decoration: BoxDecoration(
                color: Colors.orange.shade50,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.orange.shade200),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.local_fire_department, color: Colors.orange.shade700, size: 20),
                  const SizedBox(width: 6),
                  Text('Bugün: $bugunToplam kcal',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.orange.shade800,
                        fontSize: 15,
                      )),
                ],
              ),
            ),
          // Liste
          Expanded(
            child: _kayitlar.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.restaurant_menu, size: 64, color: Colors.teal.shade200),
                        const SizedBox(height: 12),
                        const Text('Henüz yemek kaydı yok.',
                            style: TextStyle(color: Colors.grey, fontSize: 16)),
                        const SizedBox(height: 6),
                        const Text('Aşağıdaki butona basarak başlayın.',
                            style: TextStyle(color: Colors.grey, fontSize: 12)),
                      ],
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: _kayitlar.length,
                    itemBuilder: (context, index) {
                      final kayit = _kayitlar[index];
                      final oncesiSeker = _yemekOncesiSekeri(kayit['tarih']?.toString());
                      final sonrasiSeker = _yemekSonrasiSekeri(kayit['tarih']?.toString());
                      final resimYolu = kayit['resim_yolu']?.toString() ?? '';
                      final kalori = kayit['kalori']?.toString() ?? '';

                      return Card(
                        margin: const EdgeInsets.symmetric(vertical: 5),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Fotoğraf
                              if (resimYolu.isNotEmpty && File(resimYolu).existsSync())
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child: Image.file(File(resimYolu),
                                      width: 70, height: 70, fit: BoxFit.cover),
                                )
                              else
                                Container(
                                  width: 70, height: 70,
                                  decoration: BoxDecoration(
                                    color: Colors.orange.shade50,
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: Icon(Icons.restaurant, color: Colors.orange.shade300, size: 32),
                                ),
                              const SizedBox(width: 12),
                              // Bilgiler
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(kayit['yemek_adi']?.toString() ?? '',
                                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                                    Text(_tarihiBicimlendir(kayit['tarih']?.toString()),
                                        style: TextStyle(fontSize: 11, color: Colors.grey.shade500)),
                                    if (kalori.isNotEmpty && kalori != '0')
                                      Padding(
                                        padding: const EdgeInsets.only(top: 2),
                                        child: Row(
                                          children: [
                                            Icon(Icons.local_fire_department,
                                                size: 13, color: Colors.orange.shade600),
                                            const SizedBox(width: 2),
                                            Text('$kalori kcal',
                                                style: TextStyle(
                                                  fontSize: 12,
                                                  color: Colors.orange.shade700,
                                                  fontWeight: FontWeight.w600,
                                                )),
                                          ],
                                        ),
                                      ),
                                    // Öncesi/Sonrası şeker
                                    if (oncesiSeker != null || sonrasiSeker != null)
                                      Padding(
                                        padding: const EdgeInsets.only(top: 6),
                                        child: Container(
                                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                                          decoration: BoxDecoration(
                                            color: Colors.red.shade50,
                                            borderRadius: BorderRadius.circular(8),
                                          ),
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              if (oncesiSeker != null)
                                                Text(
                                                  '🩸 Önce: ${oncesiSeker['deger']} mg/dL',
                                                  style: const TextStyle(fontSize: 11, color: Colors.red),
                                                ),
                                              if (sonrasiSeker != null)
                                                Text(
                                                  '🩸 Sonra: ${sonrasiSeker['deger']} mg/dL',
                                                  style: TextStyle(
                                                    fontSize: 11,
                                                    color: Colors.red.shade700,
                                                    fontWeight: FontWeight.bold,
                                                  ),
                                                ),
                                            ],
                                          ),
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                              // Sil butonu
                              IconButton(
                                icon: const Icon(Icons.delete_outline, color: Colors.red, size: 20),
                                onPressed: () async {
                                  await VeritabaniYardimcisi()
                                      .beslenmeSil(kayit['id'] as int);
                                  await _kayitlariYukle();
                                },
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
        onPressed: _yemekEkleFormunuAc,
        icon: const Icon(Icons.add),
        label: const Text('Yemek Ekle'),
      ),
    );
  }
}
