import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import '../services/veritabani_yardimcisi.dart';

class TansiyonEkleEkrani extends StatefulWidget {
  const TansiyonEkleEkrani({Key? key}) : super(key: key);

  @override
  State<TansiyonEkleEkrani> createState() => _TansiyonEkleEkraniState();
}

class _TansiyonEkleEkraniState extends State<TansiyonEkleEkrani> {
  final FlutterTts _flutterTts = FlutterTts();
  bool _sesCaliniyor = false;
  bool _yukleniyor = true;

  List<Map<String, dynamic>> _olcumler = [];

  @override
  void initState() {
    super.initState();
    _olcumleriYukle();
  }

  Future<void> _olcumleriYukle() async {
    final liste = await VeritabaniYardimcisi().tansiyonlariGetir();
    if (!mounted) return;
    setState(() {
      _olcumler = liste;
      _yukleniyor = false;
    });
  }

  String _tarihiBicimlendir(String? isoTarih) {
    if (isoTarih == null) return '';
    final t = DateTime.tryParse(isoTarih);
    if (t == null) return isoTarih;
    String iki(int n) => n.toString().padLeft(2, '0');
    return '${iki(t.day)}.${iki(t.month)}.${t.year}';
  }

  // Tansiyon değerini 4 seviyeye ayırır: Çok Düşük, Normal, Yüksek, Çok Yüksek
  String _tansiyonDurumu(int buyuk, int kucuk) {
    if (buyuk >= 180 || kucuk >= 120) return 'Çok Yüksek';
    if (buyuk < 90 || kucuk < 60) return 'Çok Düşük';
    if (buyuk >= 140 || kucuk >= 90) return 'Yüksek';
    return 'Normal';
  }

  Color _tansiyonRengi(String durum) {
    switch (durum) {
      case 'Çok Yüksek':
      case 'Çok Düşük':
        return Colors.red.shade900;
      case 'Yüksek':
        return Colors.orange.shade800;
      default:
        return Colors.green.shade800;
    }
  }

  Color _tansiyonArkaPlanRengi(String durum) {
    switch (durum) {
      case 'Çok Yüksek':
      case 'Çok Düşük':
        return Colors.red.shade50;
      case 'Yüksek':
        return Colors.orange.shade50;
      default:
        return Colors.green.shade50;
    }
  }

  bool _acilMi(String durum) => durum == 'Çok Yüksek' || durum == 'Çok Düşük';

  void _yeniOlcumEkle() {
    final buyukController = TextEditingController();
    final kucukController = TextEditingController();
    final nabizController = TextEditingController();
    String birim = 'mmHg';

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Padding(
              padding: EdgeInsets.only(
                left: 24,
                right: 24,
                top: 24,
                bottom: MediaQuery.of(context).viewInsets.bottom + 24,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Yeni Tansiyon Ölçümü',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    value: birim,
                    decoration: InputDecoration(
                      labelText: 'Cihazınızın Birimi',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                      prefixIcon: const Icon(Icons.straighten),
                    ),
                    items: const [
                      DropdownMenuItem(value: 'mmHg', child: Text('mmHg (örn. 120/80)')),
                      DropdownMenuItem(value: 'kPa', child: Text('kPa (örn. 15.9/7.0)')),
                    ],
                    onChanged: (val) {
                      if (val != null) setModalState(() => birim = val);
                    },
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: buyukController,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    autofocus: true,
                    decoration: InputDecoration(
                      labelText: birim == 'kPa' ? 'Büyük Tansiyon (kPa)' : 'Büyük Tansiyon (Sistolik)',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                      prefixIcon: const Icon(Icons.favorite),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: kucukController,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: InputDecoration(
                      labelText: birim == 'kPa' ? 'Küçük Tansiyon (kPa)' : 'Küçük Tansiyon (Diastolik)',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                      prefixIcon: const Icon(Icons.favorite_border),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: nabizController,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: 'Nabız (isteğe bağlı)',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                      prefixIcon: const Icon(Icons.monitor_heart_outlined),
                    ),
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.teal.shade700,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      onPressed: () async {
                        final buyukGiris = double.tryParse(buyukController.text.trim().replaceAll(',', '.'));
                        final kucukGiris = double.tryParse(kucukController.text.trim().replaceAll(',', '.'));
                        final nabiz = int.tryParse(nabizController.text.trim());

                        if (buyukGiris == null || kucukGiris == null) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Lütfen büyük ve küçük tansiyon değerlerini girin.')),
                          );
                          return;
                        }

                        // Tıbbi standart mmHg'dir; kPa girildiyse çeviriyoruz (1 kPa = 7.50062 mmHg)
                        const kPaToMmHg = 7.50062;
                        double buyukMmHg = birim == 'kPa' ? buyukGiris * kPaToMmHg : buyukGiris;
                        double kucukMmHg = birim == 'kPa' ? kucukGiris * kPaToMmHg : kucukGiris;

                        // Halk arasında tansiyon "12/8" gibi söylenir (gerçek değer 120/80'dir).
                        // mmHg seçiliyken gerçekçi olamayacak kadar düşük bir değer girilmişse
                        // (ör. 12, 8, 9.5) bunu x10 yaparak gerçek mmHg değerine çeviriyoruz.
                        if (birim == 'mmHg' && buyukMmHg < 30 && kucukMmHg < 30) {
                          buyukMmHg *= 10;
                          kucukMmHg *= 10;
                        }

                        final buyuk = buyukMmHg.round();
                        final kucuk = kucukMmHg.round();

                        await VeritabaniYardimcisi().tansiyonEkle({
                          'buyuk': buyuk,
                          'kucuk': kucuk,
                          'nabiz': nabiz,
                          'tarih': DateTime.now().toIso8601String(),
                        });

                        if (context.mounted) Navigator.pop(context);
                        await _olcumleriYukle();
                      },
                      child: const Text(
                        'Kaydet',
                        style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Future<void> _olcumSil(int id) async {
    await VeritabaniYardimcisi().tansiyonSil(id);
    await _olcumleriYukle();
  }

  // 🔊 TANSİYON DEĞERLERİNİ ANALİZ EDİP SESLİ OKUYAN FONKSİYON
  Future<void> _tansiyonAnaliziniSeslendir() async {
    if (_sesCaliniyor) {
      await _flutterTts.stop();
      setState(() => _sesCaliniyor = false);
      return;
    }

    if (_olcumler.isEmpty) {
      await _flutterTts.speak("Henüz kaydedilmiş bir tansiyon ölçümünüz bulunmamaktadır.");
      return;
    }

    final sonOlcum = _olcumler.first;
    int buyuk = sonOlcum['buyuk'] as int;
    int kucuk = sonOlcum['kucuk'] as int;
    final durum = _tansiyonDurumu(buyuk, kucuk);

    String durumMetni = "Son ölçümünüze göre büyük tansiyonunuz $buyuk, küçük tansiyonunuz $kucuk değerindedir. ";

    switch (durum) {
      case 'Çok Yüksek':
        durumMetni += "Bu değerler normalin çok üzerinde ve acil bir durum olabilir. Lütfen en kısa sürede bir doktora veya acil servise başvurunuz.";
        break;
      case 'Çok Düşük':
        durumMetni += "Bu değerler normalin çok altında. Baş dönmesi veya halsizlik hissediyorsanız lütfen en kısa sürede bir doktora veya acil servise başvurunuz.";
        break;
      case 'Yüksek':
        durumMetni += "Tansiyon değerleriniz normal sınırların üzerinde seyretmektedir. Lütfen dinlenip tekrar ölçüm yapınız, yüksek seyir devam ederse doktorunuza danışınız.";
        break;
      default:
        durumMetni += "Tansiyon seyriniz tamamen ideal ve normal sınırlardadır. Sağlıklı günler dileriz.";
    }

    setState(() => _sesCaliniyor = true);
    await _flutterTts.setLanguage("tr-TR");
    await _flutterTts.setPitch(1.0);
    await _flutterTts.speak(durumMetni);

    _flutterTts.setCompletionHandler(() {
      if (mounted) setState(() => _sesCaliniyor = false);
    });
  }

  @override
  void dispose() {
    _flutterTts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Tansiyon Takibi', style: TextStyle(color: Color(0xFF111424), fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Color(0xFF111424)),
        actions: [
          IconButton(
            icon: Icon(
              _sesCaliniyor ? Icons.stop_circle : Icons.volume_up,
              color: Colors.blue,
              size: 28,
            ),
            onPressed: _tansiyonAnaliziniSeslendir,
          ),
          const SizedBox(width: 12),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _yeniOlcumEkle,
        backgroundColor: Colors.teal.shade700,
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text('Ölçüm Ekle', style: TextStyle(color: Colors.white)),
      ),
      body: _yukleniyor
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Ölçüm Geçmişiniz', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  Expanded(
                    child: _olcumler.isEmpty
                        ? const Center(
                            child: Text(
                              'Henüz kaydedilmiş bir ölçüm bulunmuyor.\nSağ alttaki + butonuyla ekleyebilirsiniz.',
                              textAlign: TextAlign.center,
                              style: TextStyle(color: Colors.grey),
                            ),
                          )
                        : ListView.builder(
                            itemCount: _olcumler.length,
                            itemBuilder: (context, index) {
                              final olcum = _olcumler[index];
                              final buyuk = olcum['buyuk'] as int;
                              final kucuk = olcum['kucuk'] as int;
                              final durum = _tansiyonDurumu(buyuk, kucuk);
                              final acilMi = _acilMi(durum);

                              return Card(
                                margin: const EdgeInsets.symmetric(vertical: 6),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  side: acilMi ? BorderSide(color: Colors.red.shade400, width: 1.5) : BorderSide.none,
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 4),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      ListTile(
                                        leading: Icon(
                                          Icons.favorite,
                                          color: _tansiyonRengi(durum),
                                          size: 28,
                                        ),
                                        title: Text(
                                          '$buyuk / $kucuk mmHg',
                                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                                        ),
                                        subtitle: Text(_tarihiBicimlendir(olcum['tarih']?.toString())),
                                        trailing: Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            IconButton(
                                              icon: const Icon(Icons.volume_up, color: Colors.teal),
                                              onPressed: () {
                                                final tarihMetni = _tarihiBicimlendir(olcum['tarih']?.toString());
                                                _flutterTts.speak(
                                                  '$tarihMetni tarihli ölçüm: büyük tansiyon $buyuk, küçük tansiyon $kucuk. Durum: $durum.',
                                                );
                                              },
                                            ),
                                            IconButton(
                                              icon: const Icon(Icons.delete_outline, color: Colors.grey),
                                              onPressed: () => _olcumSil(olcum['id'] as int),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                                        child: Align(
                                          alignment: Alignment.centerLeft,
                                          child: Container(
                                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                            decoration: BoxDecoration(
                                              color: _tansiyonArkaPlanRengi(durum),
                                              borderRadius: BorderRadius.circular(8),
                                            ),
                                            child: Text(
                                              durum,
                                              style: TextStyle(color: _tansiyonRengi(durum), fontWeight: FontWeight.bold),
                                            ),
                                          ),
                                        ),
                                      ),
                                      if (acilMi)
                                        Padding(
                                          padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                                          child: Row(
                                            children: [
                                              Icon(Icons.warning_amber_rounded, color: Colors.red.shade700, size: 18),
                                              const SizedBox(width: 6),
                                              Expanded(
                                                child: Text(
                                                  'Bu değerler acil olabilir. En kısa sürede bir doktora veya acil servise başvurun.',
                                                  style: TextStyle(color: Colors.red.shade700, fontSize: 12, fontWeight: FontWeight.bold),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                  ),
                ],
              ),
            ),
    );
  }
}
