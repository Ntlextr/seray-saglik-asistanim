import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import '../services/api_service.dart';

class SerayAsistanEkrani extends StatefulWidget {
  const SerayAsistanEkrani({Key? key}) : super(key: key);
  @override
  State<SerayAsistanEkrani> createState() => _SerayAsistanEkraniState();
}

class _SerayAsistanEkraniState extends State<SerayAsistanEkrani> {
  final TextEditingController _mesajController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final FlutterTts _tts = FlutterTts();

  // Her mesaj: {'rol': 'kullanici' | 'seray', 'metin': '...'}
  final List<Map<String, String>> _mesajlar = [];
  bool _yanitBekleniyor = false;
  bool _ttsCalisiyor = false;
  int? _ttsIndex; // Hangi mesajın TTS'i çalıyor

  final List<String> _hizliSorular = [
    'Kan şekeri yüksekliği neden olur?',
    'Tansiyon düşürmenin yolları nelerdir?',
    'Diyabetliler ne yememeli?',
    'İnsülin nedir, ne işe yarar?',
    'Kolesterol düşürmek için ne yapmalıyım?',
    'Su içmenin faydaları nelerdir?',
  ];

  @override
  void initState() {
    super.initState();
    _tts.setLanguage('tr-TR');
    _tts.setSpeechRate(0.42);
    _tts.setOnCompletionHandler(() {
      if (mounted) setState(() { _ttsCalisiyor = false; _ttsIndex = null; });
    });
    // Karşılama mesajı
    _mesajlar.add({
      'rol': 'seray',
      'metin': 'Merhaba! Ben Seray Sağlık Asistanınızım 🌿\n\n'
          'Sağlık konularında merak ettiklerinizi sorabilirsiniz. '
          'Teşhis koymam veya ilaç önermem mümkün değil, ancak genel sağlık bilgisi ve destek konusunda yanınızdayım.\n\n'
          'Size nasıl yardımcı olabilirim?',
    });
  }

  @override
  void dispose() {
    _mesajController.dispose();
    _scrollController.dispose();
    _tts.stop();
    super.dispose();
  }

  Future<void> _mesajGonder(String metin) async {
    if (metin.trim().isEmpty) return;
    final temizMetin = metin.trim();
    _mesajController.clear();

    setState(() {
      _mesajlar.add({'rol': 'kullanici', 'metin': temizMetin});
      _yanitBekleniyor = true;
    });
    _sayfaSonunaKaydir();

    // Geçmiş sohbeti hazırla (karşılama hariç)
    final gecmis = _mesajlar
        .skip(1) // Karşılama mesajını atla
        .where((m) => m['metin'] != temizMetin) // Yeni mesajı dahil etme (API zaten ekleyecek)
        .toList();

    final yanit = await ApiService.serayileSohbet(
      kullaniciMesaji: temizMetin,
      sohbetGecmisi: gecmis,
    );

    setState(() {
      _mesajlar.add({'rol': 'seray', 'metin': yanit});
      _yanitBekleniyor = false;
    });
    _sayfaSonunaKaydir();
  }

  void _sayfaSonunaKaydir() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _ttsSeslendir(int index, String metin) async {
    if (_ttsCalisiyor && _ttsIndex == index) {
      await _tts.stop();
      setState(() { _ttsCalisiyor = false; _ttsIndex = null; });
      return;
    }
    await _tts.stop();
    String temiz = metin
        .replaceAll(RegExp(r'\([^)]*\)'), '')
        .replaceAll(RegExp(r'[*#_~`]'), '')
        .replaceAll(RegExp(r'^\s*[-•]\s*', multiLine: true), '')
        .replaceAll('\n\n', '. ')
        .replaceAll('\n', ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
    setState(() { _ttsCalisiyor = true; _ttsIndex = index; });
    await _tts.speak(temiz);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(
        title: Row(
          children: [
            CircleAvatar(
              radius: 16,
              backgroundColor: Colors.teal.shade100,
              child: const Icon(Icons.health_and_safety, color: Colors.teal, size: 18),
            ),
            const SizedBox(width: 8),
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Seray', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                Text('Sağlık Asistanınız', style: TextStyle(fontSize: 11, fontWeight: FontWeight.normal)),
              ],
            ),
          ],
        ),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_sweep_outlined),
            tooltip: 'Sohbeti Temizle',
            onPressed: () {
              setState(() {
                _mesajlar.clear();
                _mesajlar.add({
                  'rol': 'seray',
                  'metin': 'Sohbet temizlendi. Yeni bir konuyu sormaktan çekinmeyin! 🌿',
                });
              });
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // UYARI BANTI
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            color: Colors.amber.shade50,
            child: Row(
              children: [
                Icon(Icons.info_outline, size: 16, color: Colors.amber.shade800),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    'Seray bilgi amaçlıdır. Teşhis koymaz, ilaç önermez.',
                    style: TextStyle(fontSize: 11, color: Colors.amber.shade900),
                  ),
                ),
              ],
            ),
          ),
          // MESAJLAR
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.all(12),
              itemCount: _mesajlar.length + (_yanitBekleniyor ? 1 : 0),
              itemBuilder: (context, index) {
                if (index == _mesajlar.length && _yanitBekleniyor) {
                  return _yaziyorGostergesi();
                }
                final mesaj = _mesajlar[index];
                final kullanicimi = mesaj['rol'] == 'kullanici';
                return _mesajBaloncugu(
                  index: index,
                  metin: mesaj['metin'] ?? '',
                  kullanicimi: kullanicimi,
                );
              },
            ),
          ),
          // HIZLI SORULAR
          if (_mesajlar.length <= 1)
            SizedBox(
              height: 44,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                itemCount: _hizliSorular.length,
                itemBuilder: (context, index) => Padding(
                  padding: const EdgeInsets.only(right: 6),
                  child: ActionChip(
                    label: Text(_hizliSorular[index], style: const TextStyle(fontSize: 11)),
                    backgroundColor: Colors.teal.shade50,
                    side: BorderSide(color: Colors.teal.shade200),
                    onPressed: () => _mesajGonder(_hizliSorular[index]),
                  ),
                ),
              ),
            ),
          // MESAJ GİRİŞ ALANI
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 4, offset: const Offset(0, -1))],
            ),
            padding: EdgeInsets.only(
              left: 12, right: 8, top: 8,
              bottom: MediaQuery.of(context).viewInsets.bottom + 8,
            ),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _mesajController,
                    maxLines: 3,
                    minLines: 1,
                    textInputAction: TextInputAction.newline,
                    decoration: InputDecoration(
                      hintText: 'Sorunuzu yazın...',
                      hintStyle: const TextStyle(fontSize: 14),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(22),
                        borderSide: BorderSide(color: Colors.grey.shade300),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(22),
                        borderSide: const BorderSide(color: Colors.teal),
                      ),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                      isDense: true,
                    ),
                  ),
                ),
                const SizedBox(width: 6),
                Material(
                  color: Colors.teal,
                  borderRadius: BorderRadius.circular(22),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(22),
                    onTap: _yanitBekleniyor ? null : () => _mesajGonder(_mesajController.text),
                    child: const Padding(
                      padding: EdgeInsets.all(10),
                      child: Icon(Icons.send_rounded, color: Colors.white, size: 22),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _mesajBaloncugu({required int index, required String metin, required bool kullanicimi}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: kullanicimi ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (!kullanicimi) ...[
            CircleAvatar(
              radius: 14,
              backgroundColor: Colors.teal.shade100,
              child: const Icon(Icons.health_and_safety, color: Colors.teal, size: 14),
            ),
            const SizedBox(width: 6),
          ],
          Flexible(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: kullanicimi ? Colors.teal : Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(16),
                  topRight: const Radius.circular(16),
                  bottomLeft: kullanicimi ? const Radius.circular(16) : Radius.zero,
                  bottomRight: kullanicimi ? Radius.zero : const Radius.circular(16),
                ),
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 3, offset: const Offset(0, 1))],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    metin,
                    style: TextStyle(
                      color: kullanicimi ? Colors.white : Colors.black87,
                      fontSize: 14,
                      height: 1.4,
                    ),
                  ),
                  if (!kullanicimi) ...[
                    const SizedBox(height: 4),
                    GestureDetector(
                      onTap: () => _ttsSeslendir(index, metin),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            (_ttsCalisiyor && _ttsIndex == index)
                                ? Icons.stop_circle_outlined
                                : Icons.volume_up_outlined,
                            size: 14,
                            color: Colors.teal.shade400,
                          ),
                          const SizedBox(width: 3),
                          Text(
                            (_ttsCalisiyor && _ttsIndex == index) ? 'Durdur' : 'Sesli Dinle',
                            style: TextStyle(fontSize: 11, color: Colors.teal.shade400),
                          ),
                        ],
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
          if (kullanicimi) const SizedBox(width: 6),
        ],
      ),
    );
  }

  Widget _yaziyorGostergesi() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          CircleAvatar(
            radius: 14,
            backgroundColor: Colors.teal.shade100,
            child: const Icon(Icons.health_and_safety, color: Colors.teal, size: 14),
          ),
          const SizedBox(width: 6),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(16), topRight: Radius.circular(16),
                bottomRight: Radius.circular(16),
              ),
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 3)],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                _noktaCizici(0),
                _noktaCizici(150),
                _noktaCizici(300),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _noktaCizici(int gecikmems) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.0, end: 1.0),
      duration: Duration(milliseconds: 600 + gecikmems),
      builder: (context, value, _) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 3),
          child: Container(
            width: 7, height: 7,
            decoration: BoxDecoration(
              color: Colors.teal.withOpacity(0.4 + 0.6 * value),
              shape: BoxShape.circle,
            ),
          ),
        );
      },
    );
  }
}
