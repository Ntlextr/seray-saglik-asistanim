import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/bildirim_servisi.dart';

class AyarlarEkrani extends StatefulWidget {
  const AyarlarEkrani({Key? key}) : super(key: key);
  @override
  State<AyarlarEkrani> createState() => _AyarlarEkraniState();
}

class _AyarlarEkraniState extends State<AyarlarEkrani> {
  final TextEditingController _apiKeyController = TextEditingController();
  bool _apiKeyGizle = true;
  bool _apiKeyKaydedildi = false;

  @override
  void initState() {
    super.initState();
    _apiKeyiYukle();
  }

  @override
  void dispose() {
    _apiKeyController.dispose();
    super.dispose();
  }

  Future<void> _apiKeyiYukle() async {
    final prefs = await SharedPreferences.getInstance();
    final kayitliKey = prefs.getString('gemini_api_key') ?? '';
    setState(() => _apiKeyController.text = kayitliKey);
  }

  Future<void> _apiKeyiKaydet() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('gemini_api_key', _apiKeyController.text.trim());
    setState(() => _apiKeyKaydedildi = true);
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) setState(() => _apiKeyKaydedildi = false);
    });
  }

  static const String kvkkMetni = '''
KİŞİSEL VERİLERİN KORUNMASI AYDINLATMA METNİ

Seray Sağlık Asistanım ("Uygulama"), 6698 sayılı Kişisel Verilerin Korunması Kanunu kapsamında kullanıcılarının kişisel verilerinin güvenliğine önem vermektedir.

1. Toplanan Veriler
Uygulama; ad-soyad, yaş, diyabet durumu gibi profil bilgilerinizi ile girdiğiniz tansiyon, kan şekeri, ilaç ve e-Nabız tahlil sonuçlarınızı içeren sağlık verilerinizi işler.

2. Verilerin Saklanma Yeri
Tüm verileriniz yalnızca kendi cihazınızda (yerel veritabanında) saklanır. Uygulama, verilerinizi hiçbir sunucuya otomatik olarak göndermez.

3. Yapay Zeka Analizi
e-Nabız tahlillerinizi analiz ettirmek istediğinizde, yüklediğiniz belgenin metni yalnızca o anki yorumu oluşturmak amacıyla yapay zeka servis sağlayıcısına (Google Gemini) iletilir. Bu içerik uygulama tarafından ayrıca saklanmaz.

4. Yedekleme ve Paylaşım
"Yedekle" veya "Günlük Sonuçları Paylaş" özelliklerini kullandığınızda, oluşturulan dosya yalnızca sizin seçtiğiniz uygulama veya kişiyle paylaşılır. Bu paylaşımın sorumluluğu kullanıcıya aittir.

5. Haklarınız
KVKK'nın 11. maddesi uyarınca; verilerinizin işlenip işlenmediğini öğrenme, düzeltilmesini veya silinmesini isteme haklarına sahipsiniz.

6. İletişim
Sorularınız için Seray Teknoloji ile iletişime geçebilirsiniz.
''';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Ayarlar'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // ======== YAPAY ZEKA API ANAHTARI ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.key, color: Colors.teal),
                      const SizedBox(width: 8),
                      const Text('Gemini API Anahtarı',
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Yapay zeka özelliklerini (tahlil analizi, AI asistan, kalori tahmini) kullanabilmek için Google AI Studio\'dan ücretsiz API anahtarı almanız gerekir.',
                    style: TextStyle(fontSize: 12, color: Colors.grey, height: 1.4),
                  ),
                  const SizedBox(height: 4),
                  GestureDetector(
                    onTap: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('aistudio.google.com adresinden ücretsiz API anahtarı alabilirsiniz.')),
                      );
                    },
                    child: const Text(
                      '→ aistudio.google.com (Ücretsiz)',
                      style: TextStyle(fontSize: 12, color: Colors.teal, decoration: TextDecoration.underline),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _apiKeyController,
                    obscureText: _apiKeyGizle,
                    decoration: InputDecoration(
                      labelText: 'API Anahtarı',
                      hintText: 'AIza...',
                      border: const OutlineInputBorder(),
                      prefixIcon: const Icon(Icons.vpn_key),
                      suffixIcon: IconButton(
                        icon: Icon(_apiKeyGizle ? Icons.visibility : Icons.visibility_off),
                        onPressed: () => setState(() => _apiKeyGizle = !_apiKeyGizle),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _apiKeyKaydedildi ? Colors.green : Colors.teal,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      ),
                      onPressed: _apiKeyiKaydet,
                      icon: Icon(_apiKeyKaydedildi ? Icons.check : Icons.save),
                      label: Text(_apiKeyKaydedildi ? 'Kaydedildi!' : 'API Anahtarını Kaydet'),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),

          // ======== İLAÇ HATIRLATICI AYARLARI ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: Column(
              children: [
                const Padding(
                  padding: EdgeInsets.fromLTRB(16, 12, 16, 4),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text('İlaç Hatırlatmalarının Çalışması İçin',
                        style: TextStyle(fontWeight: FontWeight.bold)),
                  ),
                ),
                ListTile(
                  leading: const Icon(Icons.battery_charging_full, color: Colors.teal),
                  title: const Text('Pil Optimizasyonunu Kapat'),
                  subtitle: const Text(
                    'Telefon uygulamayı arka planda kapatmasın diye açılması gerekir',
                    style: TextStyle(fontSize: 12),
                  ),
                  onTap: () => BildirimServisi.pilOptimizasyonuGorMezdenGel(),
                ),
                ListTile(
                  leading: const Icon(Icons.alarm_on, color: Colors.teal),
                  title: const Text('Kesin Alarm İznini Kontrol Et'),
                  subtitle: const Text(
                    'Android 12+ cihazlarda kesin alarm için gereklidir',
                    style: TextStyle(fontSize: 12),
                  ),
                  onTap: () async {
                    await BildirimServisi.kesinAlarmIzniniIste();
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Alarm izni kontrol edildi.')),
                      );
                    }
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),

          // ======== UYGULAMA HAKKINDA ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: ListTile(
              leading: const Icon(Icons.info_outline, color: Colors.teal),
              title: const Text('Uygulama Hakkında'),
              subtitle: FutureBuilder<PackageInfo>(
                future: PackageInfo.fromPlatform(),
                builder: (context, snapshot) => Text(
                  snapshot.hasData
                      ? 'Seray Sağlık Asistanım v${snapshot.data!.version}'
                      : 'Seray Sağlık Asistanım',
                  style: const TextStyle(fontSize: 12),
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),

          // ======== KVKK ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: ExpansionTile(
              leading: const Icon(Icons.privacy_tip_outlined, color: Colors.teal),
              title: const Text('KVKK Aydınlatma Metni'),
              children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(kvkkMetni,
                      style: const TextStyle(fontSize: 13, height: 1.4, color: Colors.black87)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
