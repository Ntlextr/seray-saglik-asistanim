import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:syncfusion_flutter_pdf/syncfusion_flutter_pdf.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/api_service.dart';
import '../services/veritabani_yardimcisi.dart';
import '../services/pdf_rapor_servisi.dart';
import '../widgets/ust_menu.dart';

// --- Tahlil bilgi kütüphanesi ---
const Map<String, Map<String, String>> _tahlilBilgileri = {
  'glukoz': {
    'ne': 'Kan Şekeri (Glukoz)',
    'nedenir': 'Kandaki şeker miktarını ölçer.',
    'neden': 'Diyabet ve insülin direncini değerlendirmek için kullanılır.',
    'dikkat': 'Açlık şekeri 100 mg/dL altında normal kabul edilir.',
  },
  'hba1c': {
    'ne': 'Glikozillenmiş Hemoglobin',
    'nedenir': 'Son 3 aylık ortalama kan şekerini gösterir.',
    'neden': 'Diyabet kontrolünü uzun dönemde değerlendirmek için kullanılır.',
    'dikkat': '%6.5 üzeri diyabet lehine değerlendirilir.',
  },
  'alt': {
    'ne': 'Alanin Aminotransferaz (ALT)',
    'nedenir': 'Karaciğer hücrelerinde bulunan bir enzimdir.',
    'neden': 'Karaciğer hasarını değerlendirmek için kullanılır.',
    'dikkat': 'Yüksekliği karaciğer hastalığına işaret edebilir.',
  },
  'ast': {
    'ne': 'Aspartat Aminotransferaz (AST)',
    'nedenir': 'Karaciğer, kalp ve kas hücrelerinde bulunan enzim.',
    'neden': 'Karaciğer ve kalp sağlığını değerlendirmek için.',
    'dikkat': 'ALT ile birlikte değerlendirilir.',
  },
  'kreatinin': {
    'ne': 'Kreatinin',
    'nedenir': 'Kasların enerji kullanımı sonucu oluşan atık madde.',
    'neden': 'Böbrek fonksiyonunu değerlendirmek için.',
    'dikkat': 'Yüksekliği böbrek yetmezliğine işaret edebilir.',
  },
  'kolesterol': {
    'ne': 'Total Kolesterol',
    'nedenir': 'Kandaki toplam kolesterol miktarı.',
    'neden': 'Kalp damar hastalığı riskini belirlemek için.',
    'dikkat': '200 mg/dL altı normal, 240 üzeri yüksek risk sayılır.',
  },
  'trigliserid': {
    'ne': 'Trigliserid',
    'nedenir': 'Kanda bulunan yağ türü.',
    'neden': 'Kalp damar hastalığı ve metabolik sendrom riski için.',
    'dikkat': '150 mg/dL altı normal kabul edilir.',
  },
  'hdl': {
    'ne': 'HDL (İyi Kolesterol)',
    'nedenir': 'Damarlardan kolesterolü temizleyen faydalı yağ.',
    'neden': 'Kalp koruyucu etkisi nedeniyle yüksek olması iyidir.',
    'dikkat': 'Erkeklerde 40, kadınlarda 50 mg/dL üzeri olması istenir.',
  },
  'ldl': {
    'ne': 'LDL (Kötü Kolesterol)',
    'nedenir': 'Damarlarda birikim yapabilen zararlı kolesterol.',
    'neden': 'Damar tıkanıklığı riskini belirlemek için.',
    'dikkat': '100 mg/dL altında tutulması hedeflenir.',
  },
  'tsh': {
    'ne': 'Tiroid Uyarıcı Hormon (TSH)',
    'nedenir': 'Tiroid bezinin çalışmasını düzenleyen hormon.',
    'neden': 'Tiroid hastalıklarını tanımak için.',
    'dikkat': 'Düşükse aşırı aktif, yüksekse az aktif tiroid düşünülür.',
  },
  'b12': {
    'ne': 'Vitamin B12',
    'nedenir': 'Sinir sistemi ve kan hücreleri için gerekli vitamin.',
    'neden': 'Anemi ve sinir hasarı riskini değerlendirmek için.',
    'dikkat': '200 pg/mL altı eksiklik sayılır.',
  },
  'd vitamini': {
    'ne': 'D Vitamini',
    'nedenir': 'Kemik sağlığı ve bağışıklık sistemi için hayati vitamin.',
    'neden': 'Kemik erimesi ve bağışıklık zayıflığı riskini belirlemek.',
    'dikkat': '30 ng/mL altı eksiklik, 20 altı ciddi eksiklik kabul edilir.',
  },
  'demir': {
    'ne': 'Serum Demiri',
    'nedenir': 'Kanda taşınan demir miktarı.',
    'neden': 'Demir eksikliği anemisini değerlendirmek için.',
    'dikkat': 'Düşükse anemi, yüksekse demir birikimi düşünülür.',
  },
  'ferritin': {
    'ne': 'Ferritin',
    'nedenir': 'Vücudun demir deposunu gösteren protein.',
    'neden': 'Demir depolarını değerlendirmek için.',
    'dikkat': 'Kanda demir düşmeden önce ferritin düşer.',
  },
  'hemoglobin': {
    'ne': 'Hemoglobin (Hgb)',
    'nedenir': 'Kırmızı kan hücrelerindeki oksijen taşıyıcı protein.',
    'neden': 'Anemi tanısı için temel göstergedir.',
    'dikkat': 'Kadınlarda 12, erkeklerde 13 g/dL altı anemi sayılır.',
  },
  'ürik': {
    'ne': 'Ürik Asit',
    'nedenir': 'Protein metabolizması sonucu oluşan atık madde.',
    'neden': 'Gut hastalığı ve böbrek taşı riskini değerlendirmek için.',
    'dikkat': 'Erkeklerde 7, kadınlarda 6 mg/dL üzeri yüksek kabul edilir.',
  },
};

Map<String, String> _tahlilBilgisiGetir(String tahlilAdi) {
  final anahtar = tahlilAdi.toLowerCase();
  for (final entry in _tahlilBilgileri.entries) {
    if (anahtar.contains(entry.key)) return entry.value;
  }
  return {
    'ne': tahlilAdi,
    'nedenir': 'Laboratuvar tahlil parametresi.',
    'neden': 'Genel sağlık değerlendirmesinde kullanılır.',
    'dikkat': 'Referans aralığı dışındaki değerler için doktorunuza danışın.',
  };
}

bool _refDisinda(String deger, String ref) {
  if (ref.isEmpty || ref == '-') return false;
  final sayi = double.tryParse(
      deger.replaceAll(',', '.').replaceAll(RegExp(r'[^0-9.]'), ''));
  if (sayi == null) return false;
  final parcalar = ref.split(RegExp(r'[-–]'));
  if (parcalar.length < 2) return false;
  final min = double.tryParse(
      parcalar[0].trim().replaceAll(',', '.').replaceAll(RegExp(r'[^0-9.]'), ''));
  final maks = double.tryParse(
      parcalar[1].trim().replaceAll(',', '.').replaceAll(RegExp(r'[^0-9.]'), ''));
  if (min == null || maks == null) return false;
  return sayi < min || sayi > maks;
}

String _dogalKonusmaMetni(String metin) {
  String t = metin;
  t = t.replaceAll(RegExp(r'\([^)]*\)'), '');
  t = t.replaceAll(RegExp(r'#{1,6}\s'), '');
  t = t.replaceAll(RegExp(r'\*{1,2}([^*\n]+)\*{1,2}'), r'$1');
  t = t.replaceAll(RegExp(r'_{1,2}([^_\n]+)_{1,2}'), r'$1');
  t = t.replaceAll(RegExp(r'^\s*[-•*]\s*', multiLine: true), '');
  t = t.replaceAll(RegExp(r'https?://\S+'), '');
  t = t.replaceAll('\n\n', '. ').replaceAll('\n', ' ');
  t = t.replaceAll(RegExp(r'\s{2,}'), ' ');
  t = t.replaceAll('...', '.').replaceAll('..', '.');
  return t.trim();
}

class YapayZekaEkrani extends StatefulWidget {
  const YapayZekaEkrani({Key? key}) : super(key: key);
  @override
  State<YapayZekaEkrani> createState() => _YapayZekaEkraniState();
}

class _YapayZekaEkraniState extends State<YapayZekaEkrani> {
  // Tablo verisi: tahlil_adi → {tarih: deger, ..., '_ref': referans}
  Map<String, Map<String, String>> _tabloVerisi = {};
  List<String> _tarihSutunlari = []; // Yeniden eskiye

  String? _acikTahlil; // Bilgi kartı açık olan tahlil

  bool _karsilastirmaAcik = false;
  String _karsilastirmaMetni = '';
  bool _karsilastirmaYukleniyor = false;

  bool _aiYorumAcik = false;
  String _aiYorumu = '';
  bool _aiYorumYukleniyor = false;

  final FlutterTts _tts = FlutterTts();
  bool _ttsCalisiyor = false;

  bool _pdfYukleniyor = false;
  String _durumMesaji = '';

  @override
  void initState() {
    super.initState();
    _tts.setLanguage('tr-TR');
    _tts.setSpeechRate(0.42);
    _tts.setOnCompletionHandler(
        () { if (mounted) setState(() => _ttsCalisiyor = false); });
    _veritabaniniyukle();
  }

  @override
  void dispose() {
    _tts.stop();
    super.dispose();
  }

  Future<void> _veritabaniniyukle() async {
    final tumTahliller = await VeritabaniYardimcisi().tumTahlilleriGetir();
    _tabloVerisiOlustur(tumTahliller);
  }

  void _tabloVerisiOlustur(List<Map<String, dynamic>> tahliller) {
    final Map<String, Map<String, String>> yeniTablo = {};
    final Set<String> tarihler = {};
    for (final t in tahliller) {
      final ad = t['tahlil_adi'].toString();
      final tarih = t['tarih'].toString();
      final deger = t['sonuc'].toString();
      final ref = t['referans_degeri'].toString();
      tarihler.add(tarih);
      yeniTablo[ad] ??= {};
      yeniTablo[ad]![tarih] = deger;
      yeniTablo[ad]!['_ref'] = ref;
    }
    final siraliTarihler = tarihler.toList()..sort((a, b) => b.compareTo(a));
    setState(() {
      _tabloVerisi = yeniTablo;
      _tarihSutunlari = siraliTarihler;
    });
  }

  Future<void> _pdfYukle() async {
    final sonuc = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf', 'txt'],
    );
    if (sonuc == null || sonuc.files.single.path == null) return;

    setState(() { _pdfYukleniyor = true; _durumMesaji = 'PDF okunuyor...'; });

    try {
      final dosya = File(sonuc.files.single.path!);
      String metin = '';

      if (sonuc.files.single.extension?.toLowerCase() == 'pdf') {
        final baytlar = await dosya.readAsBytes();
        final pdfBelgesi = PdfDocument(inputBytes: baytlar);
        final sb = StringBuffer();
        for (int i = 0; i < pdfBelgesi.pages.count; i++) {
          sb.write(PdfTextExtractor(pdfBelgesi)
              .extractText(startPageIndex: i, endPageIndex: i));
          sb.write('\n');
        }
        pdfBelgesi.dispose();
        metin = sb.toString();
      } else {
        metin = await dosya.readAsString();
      }

      if (metin.trim().isEmpty) {
        setState(() { _durumMesaji = 'PDF\'den metin çıkarılamadı.'; _pdfYukleniyor = false; });
        return;
      }

      setState(() => _durumMesaji = 'Yapay zeka tahlilleri analiz ediyor...');

      final List<Map<String, String>> tahliller =
          await ApiService.tahlilVerileriniJsonOlarakCikar(metin);

      if (tahliller.isEmpty) {
        setState(() { _durumMesaji = 'Tahlil verisi bulunamadı. API anahtarınızı Ayarlar\'dan kontrol edin.'; _pdfYukleniyor = false; });
        return;
      }

      final simdi = DateTime.now();
      final tarih =
          '${simdi.day.toString().padLeft(2, '0')}.${simdi.month.toString().padLeft(2, '0')}.${simdi.year}';

      for (final t in tahliller) {
        await VeritabaniYardimcisi().tahlilEkle({
          'tarih': tarih,
          'tahlil_adi': t['tahlil_adi'],
          'sonuc': t['sonuc'],
          'referans_degeri': t['referans_araligi'] ?? '-',
        });
      }

      setState(() {
        _durumMesaji = '✅ ${tahliller.length} tahlil başarıyla yüklendi! ($tarih)';
        _pdfYukleniyor = false;
        _karsilastirmaAcik = false;
        _karsilastirmaMetni = '';
        _aiYorumu = '';
        _aiYorumAcik = false;
      });
      await _veritabaniniyukle();
    } catch (e) {
      setState(() { _durumMesaji = 'Hata: $e'; _pdfYukleniyor = false; });
    }
  }

  Future<void> _karsilastirmaYap() async {
    if (_tarihSutunlari.length < 2) return;
    setState(() { _karsilastirmaYukleniyor = true; _karsilastirmaAcik = true; });

    final yeniTarih = _tarihSutunlari[0];
    final eskiTarih = _tarihSutunlari[1];
    final Map<String, String> yeniDegerler = {};
    final Map<String, String> eskiDegerler = {};
    _tabloVerisi.forEach((ad, tarihDegerler) {
      if (tarihDegerler.containsKey(yeniTarih)) yeniDegerler[ad] = tarihDegerler[yeniTarih]!;
      if (tarihDegerler.containsKey(eskiTarih)) eskiDegerler[ad] = tarihDegerler[eskiTarih]!;
    });

    final analiz = await ApiService.karsilastirmaAnalizEt(
      yeniTarih: yeniTarih,
      yeniDegerler: yeniDegerler,
      eskiTarih: eskiTarih,
      eskiDegerler: eskiDegerler,
    );
    setState(() { _karsilastirmaMetni = analiz; _karsilastirmaYukleniyor = false; });
  }

  Future<void> _genelAiYorumYap() async {
    if (_tabloVerisi.isEmpty) return;
    setState(() { _aiYorumYukleniyor = true; _aiYorumAcik = true; });
    final sb = StringBuffer();
    _tabloVerisi.forEach((ad, tarihDegerler) {
      final ref = tarihDegerler['_ref'] ?? '-';
      tarihDegerler.forEach((tarih, deger) {
        if (tarih != '_ref') sb.writeln('$ad ($tarih): $deger [Ref: $ref]');
      });
    });
    final yorum = await ApiService.tahlilMetniniAnalizEt(sb.toString());
    setState(() { _aiYorumu = yorum; _aiYorumYukleniyor = false; });
  }

  Future<void> _ttsBaslat(String metin) async {
    if (_ttsCalisiyor) {
      await _tts.stop();
      setState(() => _ttsCalisiyor = false);
      return;
    }
    setState(() => _ttsCalisiyor = true);
    await _tts.speak(_dogalKonusmaMetni(metin));
  }

  String _tarihKisa(String tarih) {
    if (tarih.contains('.') || tarih.contains('/')) return tarih;
    final t = DateTime.tryParse(tarih);
    if (t == null) return tarih;
    return '${t.day.toString().padLeft(2, '0')}.${t.month.toString().padLeft(2, '0')}.${t.year}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(
        title: const Text('e-Nabız Tahlil Analizi'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
        actions: const [UstMenu()],
      ),
      body: Column(
        children: [
          _pdfYuklemeAlani(),
          if (_durumMesaji.isNotEmpty)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              color: (_durumMesaji.contains('Hata') || _durumMesaji.contains('bulunamadı'))
                  ? Colors.red.shade50 : Colors.teal.shade50,
              child: Text(_durumMesaji,
                  style: TextStyle(
                    fontSize: 13,
                    color: (_durumMesaji.contains('Hata') || _durumMesaji.contains('bulunamadı'))
                        ? Colors.red.shade700 : Colors.teal.shade700,
                  )),
            ),
          if (_tabloVerisi.isNotEmpty) _aksiyonButonlari(),
          if (_karsilastirmaAcik) _karsilastirmaPaneli(),
          if (_aiYorumAcik) _aiYorumPaneli(),
          Expanded(
            child: _tabloVerisi.isEmpty ? _bostaDurumu() : _tahlilTablosu(),
          ),
        ],
      ),
    );
  }

  Widget _pdfYuklemeAlani() {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.all(12),
      child: Row(
        children: [
          Expanded(
            child: ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.teal,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              onPressed: _pdfYukleniyor ? null : _pdfYukle,
              icon: _pdfYukleniyor
                  ? const SizedBox(width: 18, height: 18,
                      child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                  : const Icon(Icons.upload_file),
              label: Text(_pdfYukleniyor ? 'Yükleniyor...' : 'e-Nabız PDF Yükle'),
            ),
          ),
          if (_tabloVerisi.isNotEmpty) ...[
            const SizedBox(width: 8),
            IconButton(
              tooltip: 'PDF Raporu Paylaş',
              icon: const Icon(Icons.picture_as_pdf, color: Colors.teal),
              onPressed: () async {
                final prefs = await SharedPreferences.getInstance();
                final ad = '${prefs.getString('kullanici_ad') ?? ''} ${prefs.getString('kullanici_soyad') ?? ''}'.trim();
                await PdfRaporServisi.enabizRaporuOlusturVePaylas(
                  tabloVerisi: _tabloVerisi,
                  tarihSutunlari: _tarihSutunlari,
                  kullaniciAdi: ad,
                );
              },
            ),
          ],
        ],
      ),
    );
  }

  Widget _aksiyonButonlari() {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.fromLTRB(12, 0, 12, 10),
      child: Wrap(
        spacing: 8,
        children: [
          if (_tarihSutunlari.length >= 2)
            OutlinedButton.icon(
              onPressed: _karsilastirmaYukleniyor ? null : _karsilastirmaYap,
              icon: const Icon(Icons.compare_arrows, size: 18),
              label: const Text('Karşılaştır'),
              style: OutlinedButton.styleFrom(foregroundColor: Colors.teal),
            ),
          OutlinedButton.icon(
            onPressed: _aiYorumYukleniyor ? null : _genelAiYorumYap,
            icon: const Icon(Icons.auto_awesome, size: 18),
            label: const Text('AI Değerlendirme'),
            style: OutlinedButton.styleFrom(
                foregroundColor: Colors.orange.shade700,
                side: BorderSide(color: Colors.orange.shade300)),
          ),
        ],
      ),
    );
  }

  Widget _karsilastirmaPaneli() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.blue.shade50,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.blue.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ListTile(
            dense: true,
            leading: const Icon(Icons.compare_arrows, color: Colors.blue),
            title: Text(
              _tarihSutunlari.length >= 2
                  ? 'Karşılaştırma: ${_tarihSutunlari[1]} → ${_tarihSutunlari[0]}'
                  : 'Karşılaştırma',
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (_karsilastirmaMetni.isNotEmpty)
                  IconButton(
                    icon: Icon(
                      _ttsCalisiyor ? Icons.stop_circle_outlined : Icons.volume_up_outlined,
                      color: _ttsCalisiyor ? Colors.red : Colors.teal,
                    ),
                    onPressed: () => _ttsBaslat(_karsilastirmaMetni),
                    tooltip: 'Sesli Dinle',
                  ),
                IconButton(
                  icon: const Icon(Icons.close, size: 18),
                  onPressed: () => setState(() => _karsilastirmaAcik = false),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: _karsilastirmaYukleniyor
                ? const Center(child: Padding(padding: EdgeInsets.all(16), child: CircularProgressIndicator()))
                : Text(_karsilastirmaMetni, style: const TextStyle(fontSize: 13, height: 1.5)),
          ),
        ],
      ),
    );
  }

  Widget _aiYorumPaneli() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.orange.shade50,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.orange.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ListTile(
            dense: true,
            leading: Icon(Icons.auto_awesome, color: Colors.orange.shade700),
            title: const Text('Yapay Zeka Değerlendirmesi',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (_aiYorumu.isNotEmpty)
                  IconButton(
                    icon: Icon(
                      _ttsCalisiyor ? Icons.stop_circle_outlined : Icons.volume_up_outlined,
                      color: _ttsCalisiyor ? Colors.red : Colors.teal,
                    ),
                    onPressed: () => _ttsBaslat(_aiYorumu),
                    tooltip: 'Sesli Dinle',
                  ),
                IconButton(
                  icon: const Icon(Icons.close, size: 18),
                  onPressed: () => setState(() => _aiYorumAcik = false),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: _aiYorumYukleniyor
                ? const Center(child: Padding(padding: EdgeInsets.all(16), child: CircularProgressIndicator()))
                : Text(_aiYorumu, style: const TextStyle(fontSize: 13, height: 1.5)),
          ),
        ],
      ),
    );
  }

  Widget _bostaDurumu() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.biotech_outlined, size: 72, color: Colors.teal.shade200),
            const SizedBox(height: 16),
            const Text('Henüz tahlil yüklenmedi',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.grey)),
            const SizedBox(height: 8),
            const Text(
              'e-Nabız\'dan indirdiğiniz PDF dosyasını yükleyin.\nYapay zeka tahlillerinizi okuyup tabloya işleyecek.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey, height: 1.5),
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.amber.shade50,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.amber.shade200),
              ),
              child: const Text(
                '⚙️ İlk kullanımda Ayarlar menüsünden Gemini API anahtarınızı girmeyi unutmayın.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 12, color: Colors.brown),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _tahlilTablosu() {
    const double ilkSutunGenislik = 170.0;
    const double degerSutunGenislik = 100.0;

    return SingleChildScrollView(
      scrollDirection: Axis.vertical,
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // BAŞLIK SATIRI
            Container(
              color: Colors.teal,
              child: Row(
                children: [
                  Container(
                    width: ilkSutunGenislik,
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                    child: const Text('Tahlil Adı / Ref. Değeri',
                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)),
                  ),
                  ..._tarihSutunlari.map((tarih) => Container(
                        width: degerSutunGenislik,
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 10),
                        decoration: BoxDecoration(
                          border: Border(left: BorderSide(color: Colors.teal.shade300, width: 0.5)),
                        ),
                        child: Text(_tarihKisa(tarih),
                            textAlign: TextAlign.center,
                            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 11)),
                      )),
                ],
              ),
            ),
            // VERİ SATIRLARI
            ..._tabloVerisi.entries.toList().asMap().entries.map((entry) {
              final index = entry.key;
              final tahlilAdi = entry.value.key;
              final tarihDegerler = entry.value.value;
              final ref = tarihDegerler['_ref'] ?? '-';
              final acik = _acikTahlil == tahlilAdi;
              final bilgi = _tahlilBilgisiGetir(tahlilAdi);
              final satirArkaplan = index.isEven ? Colors.white : Colors.grey.shade50;

              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Ana satır
                  InkWell(
                    onTap: () => setState(() => _acikTahlil = acik ? null : tahlilAdi),
                    child: Container(
                      color: satirArkaplan,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          // Tahlil adı + Ref sütunu
                          Container(
                            width: ilkSutunGenislik,
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                            decoration: BoxDecoration(
                              border: Border(
                                right: BorderSide(color: Colors.grey.shade200),
                                bottom: BorderSide(color: Colors.grey.shade100),
                              ),
                            ),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(tahlilAdi,
                                          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                                      if (ref != '-' && ref.isNotEmpty)
                                        Text('Ref: $ref',
                                            style: TextStyle(fontSize: 10, color: Colors.grey.shade600)),
                                    ],
                                  ),
                                ),
                                Icon(
                                  acik ? Icons.keyboard_arrow_up : Icons.info_outline,
                                  size: 14,
                                  color: Colors.teal.shade300,
                                ),
                              ],
                            ),
                          ),
                          // Değer hücreleri
                          ..._tarihSutunlari.map((tarih) {
                            final deger = tarihDegerler[tarih] ?? '-';
                            final disinda = deger != '-' && _refDisinda(deger, ref);
                            return Container(
                              width: degerSutunGenislik,
                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 8),
                              decoration: BoxDecoration(
                                color: disinda ? Colors.red.shade50 : null,
                                border: Border(
                                  left: BorderSide(color: Colors.grey.shade200, width: 0.5),
                                  bottom: BorderSide(color: Colors.grey.shade100),
                                ),
                              ),
                              child: Text(
                                deger,
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: disinda ? FontWeight.bold : FontWeight.normal,
                                  fontStyle: disinda ? FontStyle.italic : FontStyle.normal,
                                  color: disinda
                                      ? Colors.red.shade700
                                      : (deger == '-' ? Colors.grey.shade400 : Colors.black87),
                                ),
                              ),
                            );
                          }),
                        ],
                      ),
                    ),
                  ),
                  // BİLGİ KARTI (satıra tıklayınca açılır, popup değil)
                  if (acik)
                    Container(
                      width: ilkSutunGenislik + (_tarihSutunlari.length * degerSutunGenislik),
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: Colors.teal.shade50,
                        border: Border(
                          top: BorderSide(color: Colors.teal.shade100),
                          bottom: BorderSide(color: Colors.teal.shade200),
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            bilgi['ne'] ?? tahlilAdi,
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                              color: Colors.teal.shade800,
                            ),
                          ),
                          const Divider(height: 12),
                          _bilgiSatiri('📌 Ne İşe Yarar', bilgi['nedenir'] ?? ''),
                          const SizedBox(height: 5),
                          _bilgiSatiri('🔬 Neden Bakılır', bilgi['neden'] ?? ''),
                          const SizedBox(height: 5),
                          _bilgiSatiri('⚠️ Dikkat', bilgi['dikkat'] ?? ''),
                          if (ref != '-' && ref.isNotEmpty) ...[
                            const SizedBox(height: 5),
                            _bilgiSatiri('📊 Referans Aralığı', ref),
                          ],
                        ],
                      ),
                    ),
                ],
              );
            }),
          ],
        ),
      ),
    );
  }

  Widget _bilgiSatiri(String baslik, String metin) {
    return RichText(
      text: TextSpan(
        style: const TextStyle(fontSize: 12, color: Colors.black87, height: 1.4),
        children: [
          TextSpan(text: '$baslik: ', style: const TextStyle(fontWeight: FontWeight.w600)),
          TextSpan(text: metin),
        ],
      ),
    );
  }
}
