import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:file_picker/file_picker.dart';
import 'profil_kayit_ekrani.dart';
import '../services/veritabani_yardimcisi.dart';

class ProfilSayfasi extends StatefulWidget {
  const ProfilSayfasi({Key? key}) : super(key: key);
  @override
  _ProfilSayfasiState createState() => _ProfilSayfasiState();
}

class _ProfilSayfasiState extends State<ProfilSayfasi> {
  String _ad = "..."; String _soyad = "...";

  @override
  void initState() { super.initState(); _yukle(); }
  _yukle() async { final p = await SharedPreferences.getInstance(); setState(() { _ad = p.getString('user_ad') ?? ""; _soyad = p.getString('user_soyad') ?? ""; }); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 30),
            Center(child: Image.asset('assets/images/app_logo.png', height: 80, width: 80)),
            const SizedBox(height: 16),
            Center(child: Text('$_ad $_soyad', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
            const SizedBox(height: 32),
            ElevatedButton(onPressed: () => VeritabaniYardimcisi().veritabaniYedekleHafizaya(), child: const Text('Verileri WhatsApp\'a Yedekle')),
            const SizedBox(height: 12),
            OutlinedButton(
              onPressed: () async {
                FilePickerResult? r = await FilePicker.platform.pickFiles();
                if (r != null) {
                  await VeritabaniYardimcisi().yedegiGeriYukle(r.files.single.path!);
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Yedek WhatsApp\'tan Başarıyla Yüklendi!')));
                }
              },
              child: const Text('Yedek Bul ve Geri Yükle'),
            ),
          ],
        ),
      ),
    );
  }
}
