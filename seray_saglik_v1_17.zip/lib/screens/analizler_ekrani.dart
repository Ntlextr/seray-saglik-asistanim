import 'package:flutter/material.dart';
import '../services/veritabani_yardimcisi.dart';

class AnalizlerEkrani extends StatefulWidget {
  const AnalizlerEkrani({Key? key}) : super(key: key);
  @override
  _AnalizlerEkraniState createState() => _AnalizlerEkraniState();
}

class _AnalizlerEkraniState extends State<AnalizlerEkrani> {
  List<Map<String, dynamic>> _sekerler = [];
  List<Map<String, dynamic>> _tansiyonlar = [];
  bool _yukleniyor = true;

  @override
  void initState() { super.initState(); _verileriYukle(); }

  Future<void> _verileriYukle() async {
    final sekerListesi = await VeritabaniYardimcisi().sekerleriGetir();
    final tansiyonListesi = await VeritabaniYardimcisi().tansiyonlariGetir();
    setState(() { _sekerler = sekerListesi; _tansiyonlar = tansiyonListesi; _yukleniyor = false; });
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: Colors.grey.shade50,
        appBar: AppBar(
          title: const Text('Sağlık Analizleri & İkazlar'),
          backgroundColor: Colors.teal,
          foregroundColor: Colors.white,
          bottom: const TabBar(labelColor: Colors.white, unselectedLabelColor: Colors.white70, tabs: [Tab(text: 'Şeker Seyri'), Tab(text: 'Tansiyon Seyri')]),
        ),
        body: _yukleniyor ? const Center(child: CircularProgressIndicator()) : TabBarView(children: [_sekerSayfasi(), _tansiyonSayfasi()]),
      ),
    );
  }

  Widget _sekerSayfasi() {
    if (_sekerler.isEmpty) return const Center(child: Text('Kayıtlı ölçüm bulunamadı.'));
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _sekerler.length,
      itemBuilder: (context, index) {
        final int deger = int.tryParse(_sekerler[index]['deger'].toString()) ?? 0;
        bool yuksekMi = deger > 140;
        return Card(
          color: yuksekMi ? Colors.red.shade50 : Colors.green.shade50,
          child: ListTile(
            title: Text('$deger mg/dL', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: yuksekMi ? Colors.red.shade900 : Colors.green.shade900)),
            subtitle: Text('Durum: ${_sekerler[index]['durum']}'),
            trailing: IconButton(icon: const Icon(Icons.volume_up), onPressed: () {}),
          ),
        );
      },
    );
  }

  Widget _tansiyonSayfasi() {
    if (_tansiyonlar.isEmpty) return const Center(child: Text('Kayıtlı ölçüm bulunamadı.'));
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _tansiyonlar.length,
      itemBuilder: (context, index) {
        final t = _tansiyonlar[index];
        return Card(child: ListTile(title: Text('${t['buyuk']}/${t['kucuk']} mm Hg'), subtitle: Text('Nabız: ${t['nabiz']} bpm')));
      },
    );
  }
}
