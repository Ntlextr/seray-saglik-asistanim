// lib/models/saglik_verisi.dart
class SaglikVerisi {
  final DateTime tarih;
  final double tansiyonUst;
  final double tansiyonAlt;
  final double seker;
  final double nabiz;
  final String ilacBilgisi;
  final String notlar;

  SaglikVerisi({
    required this.tarih,
    required this.tansiyonUst,
    required this.tansiyonAlt,
    required this.seker,
    required this.nabiz,
    this.ilacBilgisi = "",
    this.notlar = "",
  });

  Map<String, dynamic> toJson() => {
    'tarih': tarih.toIso8601String(),
    'tansiyonUst': tansiyonUst,
    'tansiyonAlt': tansiyonAlt,
    'seker': seker,
    'nabiz': nabiz,
    'ilacBilgisi': ilacBilgisi,
    'notlar': notlar,
  };

  factory SaglikVerisi.fromJson(Map<String, dynamic> json) => SaglikVerisi(
    tarih: DateTime.parse(json['tarih']),
    tansiyonUst: (json['tansiyonUst'] as num).toDouble(),
    tansiyonAlt: (json['tansiyonAlt'] as num).toDouble(),
    seker: (json['seker'] as num).toDouble(),
    nabiz: (json['nabiz'] as num).toDouble(),
    ilacBilgisi: json['ilacBilgisi'] ?? "",
    notlar: json['notlar'] ?? "",
  );
}
