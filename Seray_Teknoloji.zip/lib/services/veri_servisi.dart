import 'dart:convert';
import '../models/saglik_verisi.dart';

class VeriServisi {
  static SaglikVerisi metniVeriyeDonustur(String metin) {
    // Gelen JSON metnini haritaya çevirir
    final Map<String, dynamic> data = jsonDecode(metin);
    
    return SaglikVerisi(
      tarih: DateTime.parse(data['tarih']),
      tansiyonUst: (data['tansiyonUst'] as num).toDouble(),
      tansiyonAlt: (data['tansiyonAlt'] as num).toDouble(),
      seker: (data['seker'] as num).toDouble(),
      nabiz: (data['nabiz'] as num).toDouble(),
      ilacBilgisi: "PDF Analizinden geldi",
      notlar: "Otomatik tarama",
    );
  }
}
