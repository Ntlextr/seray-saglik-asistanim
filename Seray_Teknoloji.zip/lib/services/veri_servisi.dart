// lib/services/veri_servisi.dart
import 'dart:convert';
import 'package:google_generative_ai/google_generative_ai.dart';
import '../models/saglik_verisi.dart';
import 'api_service.dart';

class VeriServisi {
  
  // 1. Gemini'dan veriyi çeken fonksiyon
  static Future<SaglikVerisi> pdfAnalizEtVeVeriyeDonustur(String dosyaIcerigi) async {
    final prompt = '''
      Aşağıdaki tahlil verilerini analiz et ve sadece şu JSON formatında cevap ver, başka hiçbir şey yazma:
      {"tarih": "${DateTime.now().toIso8601String()}", "tansiyonUst": 0, "tansiyonAlt": 0, "seker": 0, "nabiz": 0}
      Tahlil İçeriği: $dosyaIcerigi
    ''';

    final response = await ApiService.model.generateContent([Content.text(prompt)]);
    String aiYaniti = response.text ?? '{"tarih": "${DateTime.now().toIso8601String()}", "tansiyonUst": 0, "tansiyonAlt": 0, "seker": 0, "nabiz": 0}';
    
    // JSON'u temizleyip modele paketliyoruz
    final Map<String, dynamic> data = jsonDecode(aiYaniti.replaceAll('```json', '').replaceAll('```', ''));
    return SaglikVerisi.fromJson(data);
  }

  // 2. Yedekleme için verileri JSON listesine çevirme
  static String verileriJsonYap(List<SaglikVerisi> liste) {
    return jsonEncode(liste.map((e) => e.toJson()).toList());
  }
}
