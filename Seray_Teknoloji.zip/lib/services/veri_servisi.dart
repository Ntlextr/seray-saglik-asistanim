// lib/services/veri_servisi.dart
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/saglik_verisi.dart';

class VeriServisi {
  static Future<void> veriKaydet(SaglikVerisi veri) async {
    final prefs = await SharedPreferences.getInstance();
    List<String> liste = prefs.getStringList('saglik_verileri') ?? [];
    liste.add(jsonEncode(veri.toJson()));
    await prefs.setStringList('saglik_verileri', liste);
  }

  static Future<List<SaglikVerisi>> verileriGetir() async {
    final prefs = await SharedPreferences.getInstance();
    List<String> liste = prefs.getStringList('saglik_verileri') ?? [];
    List<SaglikVerisi> veriler = liste.map((e) => SaglikVerisi.fromJson(jsonDecode(e))).toList();
    veriler.sort((a, b) => b.tarih.compareTo(a.tarih)); // En yeni en üstte
    return veriler;
  }
}
