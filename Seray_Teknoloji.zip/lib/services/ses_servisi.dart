// lib/services/ses_servisi.dart
import 'package:flutter_tts/flutter_tts.dart';

class SesServisi {
  static final FlutterTts _tts = FlutterTts();

  static Future<void> tahlilOku({
    required double seker,
    required double tansiyonUst,
    required double tansiyonAlt,
    required double nabiz,
  }) async {
    // Türkçe dili ayarla
    await _tts.setLanguage("tr-TR");
    // Konuşma hızını ayarla (0.5 yavaş, 1.0 normal)
    await _tts.setSpeechRate(0.5);
    
    String mesaj = "Tahlil sonuçlarınız: Şekeriniz $seker, "
                   "tansiyonunuz ${tansiyonUst.toInt()}a ${tansiyonAlt.toInt()}, "
                   "nabzınız ise $nabiz olarak ölçülmüştür.";
                   
    await _tts.speak(mesaj);
  }
}
