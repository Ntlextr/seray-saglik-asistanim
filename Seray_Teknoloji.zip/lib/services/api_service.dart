// lib/services/api_service.dart
import 'package:google_generative_ai/google_generative_ai.dart';

class ApiService {
  // Buraya kopyaladığın anahtarı yapıştır
  static final model = GenerativeModel(
    model: 'gemini-1.5-flash',
    apiKey: 'AQ.Ab8RN6K6KcNyBXXrl96mw73Dvxzlxu5luwadgEkyHJBvR3OEjg', 
  );
}
