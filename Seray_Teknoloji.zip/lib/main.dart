import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart'; // Sesli okuma için
import 'screens/analizler.dart';
import 'screens/dosya_yonetim.dart';
import 'services/veri_servisi.dart';
import 'models/saglik_verisi.dart';

void main() => runApp(const MaterialApp(home: AnaEkran()));

class AnaEkran extends StatefulWidget {
  const AnaEkran({super.key});

  @override
  State<AnaEkran> createState() => _AnaEkranState();
}

class _AnaEkranState extends State<AnaEkran> {
  int _seciliSayfa = 0;
  final FlutterTts flutterTts = FlutterTts();

  // Son ölçümü sesli oku
  Future<void> sesliOku(String metin) async {
    await flutterTts.setLanguage("tr-TR");
    await flutterTts.speak(metin);
  }

  final List<Widget> _sayfalar = [
    const AnaSayfaIcerik(), // Yeni Hızlı Özet sayfası
    const AnalizlerSekmeSayfasi(),
    const VeriYonetimiSekmeSayfasi(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Seray Sağlık Asistanı")),
      body: _sayfalar[_seciliSayfa],
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        currentIndex: _seciliSayfa,
        onTap: (index) => setState(() => _seciliSayfa = index),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Özet"),
          BottomNavigationBarItem(icon: Icon(Icons.bar_chart), label: "Analizler"),
          BottomNavigationBarItem(icon: Icon(Icons.upload_file), label: "PDF Yükle"),
        ],
      ),
    );
  }
}

// Yeni Ana Sayfa Tasarımı
class AnaSayfaIcerik extends StatelessWidget {
  const AnaSayfaIcerik({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text("Son Ölçüm Durumunuz:", style: TextStyle(fontSize: 18)),
          const SizedBox(height: 20),
          Card(
            margin: const EdgeInsets.all(20),
            child: ListTile(
              leading: const Icon(Icons.favorite, color: Colors.red),
              title: const Text("Şeker: 110 mg/dL"),
              subtitle: const Text("Tarih: Bugün"),
              trailing: IconButton(
                icon: const Icon(Icons.volume_up),
                onPressed: () => print("Sesli okuma tetiklendi!"),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
