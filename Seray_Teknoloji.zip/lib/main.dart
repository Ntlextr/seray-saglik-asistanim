import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'screens/analizler.dart'; // Analizler ekranın
import 'screens/dosya_yonetim.dart'; // PDF Yükle ekranın
import 'screens/ana_panel.dart'; // İlaç yönetimi yaptığımız 76 satırlık dosya

void main() => runApp(const MaterialApp(home: AnaEkran()));

class AnaEkran extends StatefulWidget {
  const AnaEkran({super.key});

  @override
  State<AnaEkran> createState() => _AnaEkranState();
}

class _AnaEkranState extends State<AnaEkran> {
  int _seciliSayfa = 0;
  final FlutterTts flutterTts = FlutterTts();

  @override
  void initState() {
    super.initState();
    flutterTts.setLanguage("tr-TR");
  }

  // Sayfaları tanımlıyoruz
  final List<Widget> _sayfalar = [
    const AnaSaglikPaneli(), // Senin 76 satırlık ilaç yönetimi ve özet panelin
    const AnalizlerSekmeSayfasi(),
    const VeriYonetimiSekmeSayfasi(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _sayfalar[_seciliSayfa],
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        currentIndex: _seciliSayfa,
        onTap: (index) => setState(() => _seciliSayfa = index),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Özet"),
          BottomNavigationBarItem(icon: Icon(Icons.bar_chart), label: "Analizler"),
          BottomNavigationBarItem(icon: Icon(Icons.upload_file), label: "PDF Yükle"),
        ],
      ),
    );
  }
}
