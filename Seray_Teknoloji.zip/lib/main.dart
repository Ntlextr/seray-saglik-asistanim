import 'package:flutter/material.dart';
import 'screens/analizler.dart';
import 'models/saglik_verisi.dart';
import 'services/veri_servisi.dart';

void main() => runApp(const MaterialApp(home: AnaEkran()));

class AnaEkran extends StatelessWidget {
  const AnaEkran({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Seray Sağlık Asistanı")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AnalizlerSekmeSayfasi())),
              child: const Text("Analizleri Görüntüle"),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          // Örnek veri girişi
          await VeriServisi.veriKaydet(SaglikVerisi(tarih: DateTime.now(), tansiyonUst: 120, tansiyonAlt: 80, seker: 110));
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Örnek veri eklendi!")));
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
