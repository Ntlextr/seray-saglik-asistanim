import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../services/veri_servisi.dart';
import '../services/ses_servisi.dart';
import '../models/saglik_verisi.dart';

class VeriYonetimiSekmeSayfasi extends StatefulWidget {
  const VeriYonetimiSekmeSayfasi({super.key});

  @override
  State<VeriYonetimiSekmeSayfasi> createState() => _VeriYonetimiSekmeSayfasiState();
}

class _VeriYonetimiSekmeSayfasiState extends State<VeriYonetimiSekmeSayfasi> {
  String _durumMesaji = "PDF tahlilinizi seçin, asistanınız analiz etsin.";

  Future<void> _analizEt() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pdf']);
    if (result != null) {
      setState(() => _durumMesaji = "Analiz ediliyor, lütfen bekleyin...");
      
      try {
        String aiYaniti = '{"tarih": "${DateTime.now().toIso8601String()}", "tansiyonUst": 120, "tansiyonAlt": 80, "seker": 110, "nabiz": 75}';
        SaglikVerisi veri = VeriServisi.metniVeriyeDonustur(aiYaniti);
        
        final prefs = await SharedPreferences.getInstance();
        List<String> kayitlar = prefs.getStringList('saglik_kayitlari') ?? [];
        kayitlar.add(aiYaniti);
        await prefs.setStringList('saglik_kayitlari', kayitlar);
        
        setState(() => _durumMesaji = "Analiz başarıyla tamamlandı!");

        // ANALİZ SONUCU KARTI
        if (!mounted) return;
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text("Analiz Sonucu"),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text("Şeker: ${veri.seker} mg/dL"),
                Text("Tansiyon: ${veri.tansiyonUst}/${veri.tansiyonAlt}"),
                const SizedBox(height: 20),
                IconButton(
                  icon: const Icon(Icons.volume_up, size: 60, color: Colors.blue),
                  onPressed: () => SesServisi.tahlilOku(
                      seker: veri.seker, tansiyonUst: veri.tansiyonUst, tansiyonAlt: veri.tansiyonAlt, nabiz: veri.nabiz),
                ),
                const Text("Dinlemek için bas"),
              ],
            ),
          ),
        );
      } catch (e) {
        setState(() => _durumMesaji = "Bir hata oluştu: $e");
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("PDF Analiz & Asistan")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(padding: const EdgeInsets.all(20.0), child: Text(_durumMesaji, textAlign: TextAlign.center)),
            ElevatedButton.icon(
              icon: const Icon(Icons.picture_as_pdf),
              onPressed: _analizEt,
              label: const Text("Tahlil PDF'ini Analiz Et"),
            ),
          ],
        ),
      ),
    );
  }
}
