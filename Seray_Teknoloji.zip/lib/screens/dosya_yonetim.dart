// lib/screens/dosya_yonetim.dart
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import '../services/veri_servisi.dart';
import '../services/ses_servisi.dart';
import '../models/saglik_verisi.dart';

class VeriYonetimiSekmeSayfasi extends StatefulWidget {
  const VeriYonetimiSekmeSayfasi({super.key});

  @override
  State<VeriYonetimiSekmeSayfasi> createState() => _VeriYonetimiSekmeSayfasiState();
}

class _VeriYonetimiSekmeSayfasiState extends State<VeriYonetimiSekmeSayfasi> {
  String _durumMesaji = "PDF tahlilinizi seçin, asistanınız analiz etsin.";

  Future<void> _analizEt() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pdf']);
    if (result != null) {
      setState(() => _durumMesaji = "Analiz ediliyor, lütfen bekleyin...");
      
      try {
        // 1. Burada PDF'ten metni çekeceksin (İleride PDF kütüphanesi ile)
        // 2. Gemini'a gönderip veriyi aldık (Basitleştirilmiş temsil)
        String aiYaniti = '{"tarih": "${DateTime.now().toIso8601String()}", "tansiyonUst": 120, "tansiyonAlt": 80, "seker": 110, "nabiz": 75}';
        
        SaglikVerisi veri = VeriServisi.metniVeriyeDonustur(aiYaniti);
        
        // 3. Sesli Oku
        await SesServisi.tahlilOku(seker: veri.seker, tansiyonUst: veri.tansiyonUst, tansiyonAlt: veri.tansiyonAlt, nabiz: veri.nabiz);
        
        setState(() => _durumMesaji = "Analiz başarıyla tamamlandı ve sesli okundu!");
      } catch (e) {
        setState(() => _durumMesaji = "Bir hata oluştu, tekrar deneyin.");
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("PDF Analiz & Asistan")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(padding: const EdgeInsets.all(20.0), child: Text(_durumMesaji, textAlign: TextAlign.center)),
            ElevatedButton.icon(
              icon: const Icon(Icons.picture_as_pdf),
              onPressed: _analizEt,
              label: const Text("Tahlil PDF'ini Analiz Et"),
            ),
          ],
        ),
      ),
    );
  }
}
