import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../models/saglik_verisi.dart';

class AnalizlerSekmeSayfasi extends StatefulWidget {
  const AnalizlerSekmeSayfasi({super.key});

  @override
  State<AnalizlerSekmeSayfasi> createState() => _AnalizlerSekmeSayfasiState();
}

class _AnalizlerSekmeSayfasiState extends State<AnalizlerSekmeSayfasi> {
  List<SaglikVerisi> _kayitlar = [];

  @override
  void initState() {
    super.initState();
    _gecmisiYukle();
  }

  Future<void> _gecmisiYukle() async {
    final prefs = await SharedPreferences.getInstance();
    // Kaydedilen JSON listesini çek
    String? jsonVeri = prefs.getString('saglik_kayitlari');
    if (jsonVeri != null) {
      List<dynamic> liste = jsonDecode(jsonVeri);
      setState(() {
        _kayitlar = liste.map((item) => SaglikVerisi.fromJson(item)).toList();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Sağlık Analizleri")),
      body: _kayitlar.isEmpty
          ? const Center(child: Text("Henüz kayıtlı bir analiz yok."))
          : ListView.builder(
              itemCount: _kayitlar.length,
              itemBuilder: (context, index) {
                final veri = _kayitlar[index];
                return ListTile(
                  leading: const Icon(Icons.favorite, color: Colors.red),
                  title: Text("Tansiyon: ${veri.tansiyonUst}/${veri.tansiyonAlt}"),
                  subtitle: Text("Şeker: ${veri.seker} mg/dL - Tarih: ${veri.tarih.day}/${veri.tarih.month}"),
                );
              },
            ),
    );
  }
}
