import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../models/saglik_verisi.dart';

class AnalizlerSayfasi extends StatefulWidget {
  const AnalizlerSayfasi({super.key});

  @override
  State<AnalizlerSayfasi> createState() => _AnalizlerSayfasiState();
}

class _AnalizlerSayfasiState extends State<AnalizlerSayfasi> {
  List<SaglikVerisi> _kayitlar = [];
  bool _yukleniyor = true;

  @override
  void initState() {
    super.initState();
    _verileriCek();
  }

  Future<void> _verileriCek() async {
    final prefs = await SharedPreferences.getInstance();
    // 1. ADIM: Kayıtlı verileri al
    List<String>? hamVeri = prefs.getStringList('saglik_kayitlari');
    
    if (hamVeri != null) {
      setState(() {
        // 2. ADIM: Her bir veriyi JSON'dan SaglikVerisi nesnesine dönüştür
        _kayitlar = hamVeri.map((s) => SaglikVerisi.fromJson(jsonDecode(s))).toList();
        _yukleniyor = false;
      });
    } else {
      setState(() => _yukleniyor = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Sağlık Analizleri")),
      body: _yukleniyor 
        ? const Center(child: CircularProgressIndicator())
        : _kayitlar.isEmpty 
          ? const Center(child: Text("Henüz kayıtlı bir analiz yok."))
          : ListView.builder(
              itemCount: _kayitlar.length,
              itemBuilder: (context, index) {
                final veri = _kayitlar[index];
                return Card(
                  margin: const EdgeInsets.all(8.0),
                  child: ListTile(
                    title: Text("Tarih: ${veri.tarih.toString().substring(0, 16)}"),
                    subtitle: Text("Şeker: ${veri.seker} | Tansiyon: ${veri.tansiyonUst}/${veri.tansiyonAlt}"),
                    leading: const Icon(Icons.analytics, color: Colors.blue),
                  ),
                );
              },
            ),
    );
  }
}
