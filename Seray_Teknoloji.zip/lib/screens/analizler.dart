// lib/screens/analizler.dart
import 'package:flutter/material.dart';
import '../services/veri_servisi.dart';
import '../models/saglik_verisi.dart';

class AnalizlerSekmeSayfasi extends StatelessWidget {
  const AnalizlerSekmeSayfasi({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Akıllı Analizler")),
      body: FutureBuilder<List<SaglikVerisi>>(
        future: VeriServisi.verileriGetir(),
        builder: (context, snapshot) {
          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text("Henüz veri yok abim."));
          }
          var veriler = snapshot.data!;
          
          return ListView.builder(
            itemCount: veriler.length,
            itemBuilder: (context, index) {
              var mevcut = veriler[index];
              String farkMetni = "İlk kayıt";
              
              if (index < veriler.length - 1) {
                var onceki = veriler[index + 1];
                double fark = mevcut.seker - onceki.seker;
                farkMetni = fark > 0 
                    ? "Öncekinden ${fark.toStringAsFixed(1)} birim yüksek." 
                    : "Öncekinden ${fark.abs().toStringAsFixed(1)} birim düşük.";
              }

              return Card(
                margin: const EdgeInsets.all(8),
                child: ListTile(
                  title: Text("Şeker: ${mevcut.seker} mg/dL"),
                  subtitle: Text("Tarih: ${mevcut.tarih.day}/${mevcut.tarih.month} - $farkMetni"),
                  leading: const Icon(Icons.analytics, color: Colors.teal),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
