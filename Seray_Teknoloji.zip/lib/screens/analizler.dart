// lib/screens/analizler.dart
import 'package:flutter/material.dart';
import '../models/saglik_verisi.dart'; // Model dosyanı bağladık

class AnalizlerSekmeSayfasi extends StatelessWidget {
  const AnalizlerSekmeSayfasi({super.key});

  @override
  Widget build(BuildContext context) {
    // İleride buraya kayıtlı verilerin listesini çekeceğiz
    return Scaffold(
      appBar: AppBar(title: const Text("Sağlık Analizleri")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text("Sağlık Geçmişiniz", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            // Buraya zamanla verilerin listesini veya grafiklerini dizeceğiz
            const ListTile(
              leading: Icon(Icons.favorite, color: Colors.red),
              title: Text("Tansiyon & Nabız"),
              subtitle: Text("Henüz veri girişi yapılmamış."),
            ),
          ],
        ),
      ),
    );
  }
}
