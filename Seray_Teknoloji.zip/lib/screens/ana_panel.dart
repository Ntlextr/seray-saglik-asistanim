// lib/screens/ana_panel.dart
import 'package:flutter/material.dart';
import '../services/database_servisi.dart'; // Veriler buraya gidiyor

class AnaSaglikPaneli extends StatelessWidget {
  const AnaSaglikPaneli({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Seray Sağlık Yönetimi")),
      body: Column(
        children: [
          // 1. İlaç Hatırlatıcı Bölümü (Checkbox'lı Liste)
          Expanded(child: _ilacListesi()),
          
          // 2. Aksiyon Butonları
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () => _raporHazirla(), // Dr. Raporunu PDF yapacak
                  child: const Text("Dr. Raporu Hazırla"),
                ),
                ElevatedButton(
                  onPressed: () => _gunlukVeriEkle(), // Tansiyon/Şeker girişi
                  child: const Text("Veri Girişi"),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _ilacListesi() {
    return ListView(children: const [
      ListTile(title: Text("İnsülin (Sabah)"), trailing: Icon(Icons.check_box_outline_blank)),
      ListTile(title: Text("Tansiyon İlacı (Akşam)"), trailing: Icon(Icons.check_box_outline_blank)),
    ]);
  }

  void _raporHazirla() {
    // Burada tüm Database'i çekip PDF'e dökeceğiz
    print("PDF Raporu hazırlanıyor...");
  }

  void _gunlukVeriEkle() {
    // Burada tansiyon, şeker ve nabız için küçük bir pencere açılacak
    print("Günlük veri giriş ekranı...");
  }
}
