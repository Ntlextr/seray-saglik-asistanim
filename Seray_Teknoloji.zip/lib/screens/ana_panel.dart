import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AnaSaglikPaneli extends StatefulWidget {
  const AnaSaglikPaneli({super.key});

  @override
  State<AnaSaglikPaneli> createState() => _AnaSaglikPaneliState();
}

class _AnaSaglikPaneliState extends State<AnaSaglikPaneli> {
  List<String> _ilaclar = [];
  final TextEditingController _ilacController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _ilaclariYukle();
  }

  // Hafızadan ilaçları çek
  Future<void> _ilaclariYukle() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _ilaclar = prefs.getStringList('ilaclar') ?? [];
    });
  }

  // Yeni ilaç ekle ve kaydet
  Future<void> _ilacEkle(String ilac) async {
    if (ilac.isEmpty) return;
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _ilaclar.add(ilac);
      _ilacController.clear();
    });
    await prefs.setStringList('ilaclar', _ilaclar);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Seray Sağlık Yönetimi")),
      body: Column(
        children: [
          // İlaç ekleme alanı
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(child: TextField(controller: _ilacController, decoration: const InputDecoration(labelText: "Yeni İlaç Adı"))),
                IconButton(icon: const Icon(Icons.add), onPressed: () => _ilacEkle(_ilacController.text)),
              ],
            ),
          ),
          // İlaç listesi
          Expanded(
            child: ListView.builder(
              itemCount: _ilaclar.length,
              itemBuilder: (context, index) => ListTile(
                title: Text(_ilaclar[index]),
                trailing: IconButton(icon: const Icon(Icons.delete, color: Colors.red), onPressed: () => _ilacSil(index)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _ilacSil(int index) async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _ilaclar.removeAt(index);
    });
    await prefs.setStringList('ilaclar', _ilaclar);
  }
}
