// lib/screens/dosya_yonetim.dart
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';

class VeriYonetimiSekmeSayfasi extends StatefulWidget {
  const VeriYonetimiSekmeSayfasi({super.key});

  @override
  State<VeriYonetimiSekmeSayfasi> createState() => _VeriYonetimiSekmeSayfasiState();
}

class _VeriYonetimiSekmeSayfasiState extends State<VeriYonetimiSekmeSayfasi> {
  String _dosyaAdi = "Henüz dosya seçilmedi";

  Future<void> _dosyaSec() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
    );

    if (result != null) {
      setState(() {
        _dosyaAdi = result.files.single.name;
      });
      // Burada ileride PDF'i okuyup değerleri çıkaracağız
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Dosya Yönetimi")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(_dosyaAdi, style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _dosyaSec,
              child: const Text("PDF Seç"),
            ),
          ],
        ),
      ),
    );
  }
}
