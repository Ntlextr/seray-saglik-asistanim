import 'dart:async';
import '../theme/renkler.dart';
import 'package:flutter/material.dart';
import '../services/bildirim_servisi.dart';
import '../services/ses_servisi.dart';
import '../services/veritabani_yardimcisi.dart';

// Alarm saatinde açılan tam ekran uyarı. Telefon kilitli ya da kilitsiz,
// kullanıcı başka bir şey yapıyor olsa bile bu ekran öne çıkar. "İçtim"
// ya da "Atladım"a basılana kadar hem bildirim sesi hem de sesli okuma
// (TTS) tekrar eder. ÖNEMLİ: bildirimId, ilacın veritabanındaki id'siyle
// AYNIDIR (ilacHatirlaticisiKur bunu böyle kuruyor) — bu yüzden doz
// geçmişine kaydederken doğrudan bu id kullanılabiliyor.
class AlarmEkrani extends StatefulWidget {
  final int bildirimId;
  // YENİ: ekranda o an GERÇEKTEN çalan/görünen sistem bildiriminin kimliği.
  // Normal günlük alarmda bildirimId ile AYNIDIR. Ertele'den gelen
  // bildirimlerde FARKLIDIR (erteleId = ilaç id + 500000) — çünkü Ertele
  // artık günlük alarmın id'sini bozmamak için ayrı bir kimlikte çalışıyor.
  // İçtim/Atladım/Ertele butonları bildirimi SUSTURMAK için mutlaka bunu
  // kullanmalı, bildirimId'yi değil (yoksa yanlış/var olmayan bir kimlik
  // iptal edilir, gerçekte çalan bildirim susmadan tepside kalır).
  final int sistemBildirimId;
  final String ilacAdi;
  // ÖNEMLİ: Kullanıcı istedi — bildirim/TTS metni türe göre değişsin
  // ("ilacınızı" / "insülininizi"). 'Hap' veya 'İnsülin' değeri alır,
  // tanınmayan/boş değerde güvenli varsayılan olarak 'Hap' davranışı uygulanır.
  final String ilacTuru;
  const AlarmEkrani({Key? key, required this.bildirimId, int? sistemBildirimId, required this.ilacAdi, this.ilacTuru = 'Hap'})
      : sistemBildirimId = sistemBildirimId ?? bildirimId,
        super(key: key);

  @override
  State<AlarmEkrani> createState() => _AlarmEkraniState();

  // ÖNEMLİ: Kullanıcı istedi — üstteki bildirimden "Ertele"/"Kapat"
  // tuşuna basılınca, EĞER bu ekran zaten açıksa (fullScreenIntent onu
  // otomatik açmış olabilir), bildirim aksiyonu bu ekranı da senkron
  // şekilde kapatabilsin diye şu an ekranda açık olan TEK örneğe (varsa)
  // dışarıdan erişim sağlanıyor.
  static _AlarmEkraniState? _aktifOrnek;
  static bool get aktifMi => _aktifOrnek != null && (_aktifOrnek?.mounted ?? false);
  static Future<void> disaridanKapat() async {
    final ornek = _aktifOrnek;
    if (ornek != null && ornek.mounted) {
      await ornek._sessizceKapat();
    }
  }  // --- disaridanKapat() sonu ---
}

class _AlarmEkraniState extends State<AlarmEkrani> {
  Timer? _tekrarZamanlayici;
  bool _islemYapiliyor = false;

  @override
  void initState() {
    super.initState();
    AlarmEkrani._aktifOrnek = this;
    _sesliOkumayaBasla();
  }

  Future<void> _sesliOkumayaBasla() async {
    _tekrarSoyle();
    // Her 6 saniyede bir tekrar seslendir; kullanıcı İçtim/Atladım'a basana kadar sürer.
    _tekrarZamanlayici = Timer.periodic(const Duration(seconds: 6), (_) => _tekrarSoyle());
  }

  // Tür bazlı doğru kelimeyi üretir: İnsülin → "insülininizi", diğer her şey
  // (Hap/İlaç ve tanımsız değerler) → "ilacınızı".
  String get _kelime => widget.ilacTuru == 'İnsülin' ? 'insülininizi' : 'ilacınızı';

  Future<void> _tekrarSoyle() async {
    await SesServisi.konus('${widget.ilacAdi} ${_kelime} alma vaktiniz geldi');
  }

  // Bildirimden ("Kapat" tuşuna basınca) çağrılır — DB'ye kaydetmeden,
  // sadece sesi/ekranı kapatır (kullanıcı zaten bildirimden karar vermiş
  // sayılır, çift kayıt oluşmasın diye burada içildi/atlandı SORULMAZ,
  // sadece ekran/ses durdurulur).
  Future<void> _sessizceKapat() async {
    _tekrarZamanlayici?.cancel();
    await SesServisi.durdur();
    if (mounted) Navigator.of(context).pop();
  }  // --- _sessizceKapat() sonu ---

  // İÇTİM/ATLADIM — kullanıcı isteğiyle eklendi: "Kapat" yerine artık her
  // doz için AÇIKÇA bir durum kaydediliyor, ilaç bazında uyum/adherence
  // analizi mümkün oluyor.
  Future<void> _durumKaydetVeKapat(String durum) async {
    if (_islemYapiliyor) return;
    setState(() => _islemYapiliyor = true);
    _tekrarZamanlayici?.cancel();
    await SesServisi.durdur();
    // ÖNEMLİ DÜZELTME (yeni bug — kullanıcı bildirdi): bildirim
    // "ongoing:true / autoCancel:false / FLAG_INSISTENT" ile kurulu
    // (bilinçli olarak — kaydırarak kapatılamasın diye). Önceki oturumda
    // buradaki BildirimServisi.iptalEt() çağrısı TAMAMEN kaldırılmıştı
    // (3q bug'ını çözmek için — cancel() aynı id'nin YARIN için zaten
    // yeniden kurulmuş olan alarmını da siliyordu). Ama bu, ekrandaki
    // sesi durdursa bile SİSTEM bildirimini/sesini hiç kapatmıyordu —
    // kullanıcı bildirim çekmecesini elle açıp silmek zorunda kalıyordu.
    // DOĞRU ÇÖZÜM: bildirimi iptal ET (sesi/tepsiyi hemen kapatır) AMA
    // hemen ardından aynı ilacı, veritabanındaki kayıtlı saatiyle GÜNLÜK
    // TEKRAR olarak YENİDEN kur — böylece hem bildirim susuyor hem de
    // yarınki alarm garantiye alınmış oluyor (native'in kendiliğinden
    // yeniden kurup kurmadığına bağımlı kalınmıyor).
    await BildirimServisi.iptalEt(widget.sistemBildirimId);
    try {
      final ilacKaydi = await VeritabaniYardimcisi().ilacBul(widget.bildirimId);
      final saatMetni = ilacKaydi?['saat']?.toString();
      if (saatMetni != null && saatMetni.contains(':')) {
        final parcalar = saatMetni.split(':');
        final saat = TimeOfDay(hour: int.parse(parcalar[0]), minute: int.parse(parcalar[1]));
        await BildirimServisi.ilacHatirlaticisiKur(
          id: widget.bildirimId,
          ilacAdi: widget.ilacAdi,
          saat: saat,
          tip: widget.ilacTuru,
        );
      }
    } catch (_) {
      // İlaç kaydı bulunamadıysa (silinmiş olabilir) sessizce geç —
      // zaten hatırlatılacak bir ilaç kalmamış demektir.
    }
    try {
      await VeritabaniYardimcisi().ilacGecmisineKaydet(
        ilacId: widget.bildirimId,
        ilacAdi: widget.ilacAdi,
        durum: durum,
      );
    } catch (_) {
      // Kayıt başarısız olsa bile kullanıcıyı ekranda bekletmeyelim.
    }
    if (mounted) Navigator.of(context).pop();
  }  // --- _durumKaydetVeKapat() sonu ---

  // ÖNEMLİ: Bildirimdeki Ertele butonu MIUI'de çalışmadığı için kaldırıldı
  // (bkz. bildirim_servisi.dart) — kullanıcı isteğiyle bu tam ekrana taşındı.
  Future<void> _ertele() async {
    if (_islemYapiliyor) return;
    setState(() => _islemYapiliyor = true);
    _tekrarZamanlayici?.cancel();
    await SesServisi.durdur();
    // ÖNEMLİ DÜZELTME (aynı kök sorun İçtim/Atladım'daki gibi): önce
    // mevcut (şu an çalan) bildirimi iptal ediyoruz ki ses/bildirim
    // hemen sussun. Sonra günlük alarmı DB'deki kayıtlı saatiyle bu id
    // için yeniden kuruyoruz (Ertele'nin kendisi ayrı, çakışmayan bir
    // id'ye 10 dakikalık TEK SEFERLİK hatırlatma kuracak — bkz.
    // bildirim_servisi.dart) — böylece "Ertele" günlük tekrarı bozmuyor.
    await BildirimServisi.iptalEt(widget.sistemBildirimId);
    try {
      final ilacKaydi = await VeritabaniYardimcisi().ilacBul(widget.bildirimId);
      final saatMetni = ilacKaydi?['saat']?.toString();
      if (saatMetni != null && saatMetni.contains(':')) {
        final parcalar = saatMetni.split(':');
        final saat = TimeOfDay(hour: int.parse(parcalar[0]), minute: int.parse(parcalar[1]));
        await BildirimServisi.ilacHatirlaticisiKur(
          id: widget.bildirimId,
          ilacAdi: widget.ilacAdi,
          saat: saat,
          tip: widget.ilacTuru,
        );
      }
    } catch (_) {
      // İlaç kaydı bulunamadıysa sessizce geç.
    }
    // ÖNEMLİ: Ertele'nin kendisi HER ZAMAN orijinal ilaç id'sini (widget.
    // bildirimId) kullanmalı, sistem id'sini DEĞİL — ertele() zaten kendi
    // içinde id+500000 hesaplıyor; sistemBildirimId'yi buraya versek
    // (ör. ikinci kez ertelenirse) kayma birikirdi.
    await BildirimServisi.ertele(id: widget.bildirimId, ilacAdi: widget.ilacAdi, tur: widget.ilacTuru);
    if (mounted) Navigator.of(context).pop();
  }  // --- _ertele() sonu ---

  @override
  void dispose() {
    if (AlarmEkrani._aktifOrnek == this) AlarmEkrani._aktifOrnek = null;
    _tekrarZamanlayici?.cancel();
    SesServisi.durdur();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false, // geri tuşuyla kapatılamasın, sadece butonlarla
      child: Scaffold(
        backgroundColor: AppRenkleri.aktif.shade700,
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.medication, color: Colors.white, size: 96),
                const SizedBox(height: 24),
                Text(widget.ilacTuru == 'İnsülin' ? 'İnsülin Zamanı' : 'İlaç Zamanı', style: const TextStyle(color: Colors.white70, fontSize: 22)),
                const SizedBox(height: 8),
                Text(
                  widget.ilacAdi,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white, fontSize: 44, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 12),
                const Text('Bu ilacı aldınız mı?', style: TextStyle(color: Colors.white70, fontSize: 16)),
                const SizedBox(height: 40),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    style: FilledButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: AppRenkleri.aktif.shade700,
                      padding: const EdgeInsets.symmetric(vertical: 20),
                      textStyle: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                    ),
                    onPressed: _islemYapiliyor ? null : () => _durumKaydetVeKapat('icildi'),
                    icon: const Icon(Icons.check_circle),
                    label: const Text('İÇTİM'),
                  ),
                ),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.white,
                      side: const BorderSide(color: Colors.white70, width: 1.5),
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      textStyle: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
                    ),
                    onPressed: _islemYapiliyor ? null : () => _durumKaydetVeKapat('atlandi'),
                    icon: const Icon(Icons.close),
                    label: const Text('ATLADIM'),
                  ),
                ),
                const SizedBox(height: 10),
                TextButton.icon(
                  onPressed: _islemYapiliyor ? null : _ertele,
                  style: TextButton.styleFrom(foregroundColor: Colors.white70),
                  icon: const Icon(Icons.snooze),
                  label: const Text('Ertele (10 dk)', style: TextStyle(fontSize: 15)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
