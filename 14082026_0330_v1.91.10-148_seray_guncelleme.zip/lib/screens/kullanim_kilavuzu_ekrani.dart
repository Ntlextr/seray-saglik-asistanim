import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../theme/renkler.dart';

// ÖNEMLİ DÜZELTME: Kılavuz artık koda gömülü SABİT bir liste değil —
// Ayarlar'daki KVKK/Hakkında ile AYNI Cloudflare Worker'ın (/icerik)
// "kilavuz" alanından çekiliyor. Bu sayede bir bölümü değiştirmek veya
// yeni bölüm eklemek için artık yeni bir APK basmana gerek yok, sadece
// worker.js'i güncelleyip Deploy'a basman yeterli. İnternet yoksa veya
// worker'a ulaşılamazsa, aşağıdaki _yerelYedek listesi (worker'a ilk
// eklendiği andaki içerikle birebir aynı) gösterilir — kullanıcı hiçbir
// zaman boş ekranla karşılaşmaz.
class KullanimKilavuzuEkrani extends StatefulWidget {
  const KullanimKilavuzuEkrani({Key? key}) : super(key: key);

  static const List<Map<String, String>> _yerelYedek = [
    {
      'baslik': '🏠 Ana Sayfa',
      'metin': 'Ana sayfada en son girdiğiniz şeker ve tansiyon ölçümünüzü görürsünüz. "Şeker Ekle" ve "Tansiyon Ekle" butonlarıyla yeni ölçüm kaydedebilirsiniz.'
    },
    {
      'baslik': '📊 Analizler',
      'metin': 'Şeker, Tansiyon, Su, Kilo ve Adım geçmişinizi burada tarih/saatiyle görürsünüz. Referans değerlerin dışındaki ölçümler kırmızı renkte gösterilir. Hoparlör ikonuna basarak ölçümü sesli dinleyebilirsiniz.'
    },
    {
      'baslik': '❤️ Nabız Ölçümü',
      'metin': 'Tansiyon ekleme ekranındaki nabız alanına dokununca, parmağınızı arka kameranın ve flaşın üzerine kapatarak nabzınızı ölçebilirsiniz. Ayarlar\'dan "Basit (Hızlı)" veya "Gelişmiş (FFT — daha isabetli)" yöntemini seçebilirsiniz. Ölçüm sonunda BPM\'in yanında kaba bir Stres/Enerji göstergesi de görürsünüz — bu tıbbi bir ölçüm değildir, sadece kalp atışlarınızın düzenliliğinden çıkarılan bir fikirdir.'
    },
    {
      'baslik': '📄 e-Nabız Tahlil Okuma Merkezi',
      'metin': 'e-Nabız\'dan indirdiğiniz PDF dosyasını yükleyin — yapay zeka tahlilinizi okuyup tabloya işler. Sonuçlar artık kategoriye göre gruplu (Kan Sayımı, Biyokimya, İdrar Tahlili vb.) ve tarihe göre doğru sırayla gösterilir. Bir tahlil adına dokununca açıklaması açılır ve hoparlör ikonuyla sesli dinlenebilir. Her tarih sütununun üstündeki ✨ ikonuyla sadece o tarihe ait sonuçların yorumunu, "AI Değerlendirme" butonuyla da tüm geçmişinizin genel bir değerlendirmesini alabilirsiniz — ikisi de sesli dinlenebilir.'
    },
    {
      'baslik': '💊 İlaçlarım',
      'metin': '"İlaç Ekle" ile ilacınızı, dozunu ve hatırlatma saatini girin. Belirlediğiniz saatte telefonunuz sesli olarak uyarır. Kalem ikonuyla düzenleyebilir, çöp kutusuyla silebilirsiniz.'
    },
    {
      'baslik': '🤖 Seray AI Sağlık Asistanı',
      'metin': 'Sağlık konularında merak ettiklerinizi Seray\'a sorabilirsiniz. Artık girdiğiniz kan şekeri/tansiyon geçmişinizin yanı sıra yüklediğiniz TÜM e-Nabız tahlil sonuçlarını da bilir — "kolesterolüm nasıl" gibi sorulara gerçek verilerinizle cevap verebilir. Mesaj kutusunun yanındaki mikrofon ikonuna basıp konuşarak da soru sorabilirsiniz, yazmanıza gerek yok.'
    },
    {
      'baslik': '👤 Profil',
      'metin': 'Adınızı, yaşınızı, diyabet durumunuzu ve fotoğrafınızı buradan güncelleyebilirsiniz. "Çıkış Yap" uygulamayı kapatır; verileriniz cihazınızda saklı kalır.'
    },
    {
      'baslik': '☰ Üst Menü',
      'metin': 'Her ekranın sağ üstündeki menüden: günlük ölçüm sonuçlarınızı PDF olarak paylaşabilir, verilerinizi yedekleyip geri yükleyebilir, ayarlara ve bu kılavuza her an ulaşabilirsiniz.'
    },
  ];

  @override
  State<KullanimKilavuzuEkrani> createState() => _KullanimKilavuzuEkraniState();
}  // --- KullanimKilavuzuEkrani sonu ---

class _KullanimKilavuzuEkraniState extends State<KullanimKilavuzuEkrani> {
  List<Map<String, String>> _bolumler = KullanimKilavuzuEkrani._yerelYedek;
  bool _yukleniyor = true;

  @override
  void initState() {
    super.initState();
    _icerigiCloudflaredanCek();
  }  // --- initState() sonu ---

  Future<void> _icerigiCloudflaredanCek() async {
    try {
      final response = await http
          .get(Uri.parse('https://empty-union-ce11.serdarcirak.workers.dev/icerik'))
          .timeout(const Duration(seconds: 8));
      if (response.statusCode == 200) {
        final data = jsonDecode(utf8.decode(response.bodyBytes));
        final liste = data['kilavuz'];
        if (liste is List && liste.isNotEmpty) {
          final donusturulmus = liste
              .map<Map<String, String>>((b) => {
                    'baslik': (b['baslik'] ?? '').toString(),
                    'metin': (b['metin'] ?? '').toString(),
                  })
              .toList();
          if (mounted) setState(() => _bolumler = donusturulmus);
        }
      }
    } catch (_) {
      // İnternet yoksa veya worker'a ulaşılamazsa yerel yedek zaten
      // gösteriliyor — kullanıcı hiçbir hata görmez.
    }
    if (mounted) setState(() => _yukleniyor = false);
  }  // --- _icerigiCloudflaredanCek() sonu ---

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Kullanma Kılavuzu'),
        backgroundColor: AppRenkleri.aktif,
        foregroundColor: Colors.white,
        actions: [
          if (_yukleniyor)
            const Padding(
              padding: EdgeInsets.only(right: 16),
              child: Center(
                child: SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                ),
              ),
            ),
        ],
      ),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: _bolumler.length,
        separatorBuilder: (context, index) => const SizedBox(height: 12),
        itemBuilder: (context, index) {
          final b = _bolumler[index];
          return Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(b['baslik']!, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text(b['metin']!, style: const TextStyle(fontSize: 14, height: 1.4)),
                ],
              ),
            ),
          );
        },
      ),
    );
  }  // --- build() sonu ---
}  // --- _KullanimKilavuzuEkraniState sonu ---
