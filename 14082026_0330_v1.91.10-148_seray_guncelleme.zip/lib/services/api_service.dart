import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'veritabani_yardimcisi.dart';
import 'profil_yoneticisi.dart';
import 'uygulama_bilgi_metni.dart';

class ApiService {
  // Kullanıcı hiçbir key girmiyor. Tüm istekler Cloudflare Worker'a gidiyor,
  // Worker da OpenAI API'ye güvenli şekilde iletiyor.
  static const String _apiUrl =
      'https://empty-union-ce11.serdarcirak.workers.dev';
  // Ucuz/hızlı görevler (JSON çıkarma) için nano; daha akıcı ve doğru
  // Türkçe cümleler kuran sohbet/görsel yorum için mini kullanıyoruz.
  static const String _hizliModel = 'gpt-5-nano';
  static const String _kaliteliModel = 'gpt-5-mini';
  static const Duration _zamanAsimi = Duration(seconds: 75);

  // --- GÜVENLİK: PAYLAŞILAN GİZLİ ANAHTAR ---
  // Worker artık bu anahtarı bilmeyen istekleri reddediyor (bkz. worker.js).
  // BU DEĞER, Cloudflare panelinde Worker'ın Settings > Variables kısmına
  // eklediğin "SERAY_APP_SECRET" ile BİREBİR AYNI OLMALI. Değiştirmek
  // istersen ikisini birlikte değiştir, yoksa uygulama "Yetkisiz istek"
  // hatası almaya başlar.
  static const String _appSecret = 'Yn2zTv72M5R2BfKhkx8vnZRb9pZnNMfeU-jgbGLdoI8';

  static Future<String> _metinCevabiCikar(http.Response response) {
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final metin = data['choices']?[0]?['message']?['content'];
      // Önceden sadece 'null' durumu yakalanıyordu; AI boş bir string ("")
      // döndürdüğünde bu sessizce geçiyor ve daha sonra "Ham cevap: " diye
      // hiçbir şey göstermeyen anlamsız bir hataya dönüşüyordu. Artık boş
      // string de aynı şekilde açıkça işaretleniyor.
      if (metin == null || metin.toString().trim().isEmpty) {
        return Future.value('Yanıt oluşturulamadı: AI boş bir cevap döndürdü '
            '(girdi metni çok uzun/karmaşık olabilir ya da servis geçici '
            'bir sorun yaşıyor olabilir, lütfen tekrar deneyin).');
      }
      return Future.value(metin.toString());
    }
    return Future.value(
        'API Hatası (Kod ${response.statusCode}): ${response.body}');
  }  // --- _metinCevabiCikar() sonu ---

  // Bilinen tüm "bu bir AI cevabı değil, hata mesajı" biçimlerini tek yerden
  // kontrol eder. Diğer ekranlar da (örn. Analizler'deki sekme yorumları)
  // bunu kullanarak hatalı cevapları önbelleğe kalıcı olarak kaydetmekten
  // kaçınabilir.
  static bool cevapHataMi(String cevap) {
    return cevap.startsWith('API Hatası') ||
        cevap.startsWith('Bağlantı sırasında') ||
        cevap.startsWith('Bağlantı çok yavaş') ||
        cevap.startsWith('Yanıt oluşturulamadı');
  }  // --- cevapHataMi() sonu ---

  // --- TAHLIL METNİ ANALİZİ ---
  static Future<String> tahlilMetniniAnalizEt(String metin, {String? kullaniciAdi}) async {
    final hitapCumlesi = (kullaniciAdi != null && kullaniciAdi.trim().isNotEmpty)
        ? ' Kullanıcının adı "$kullaniciAdi" — ona doğal bir şekilde ismiyle hitap ederek konuş (örn. "$kullaniciAdi Bey/Hanım, ...").'
        : '';
    final sistemPrompt =
        'Sen kıdemli, şefkatli ve çok dikkatli bir sağlık asistanısın. '
        'Verilen e-Nabız tahlil sonuçlarını teknik terimlere boğmadan, anlaşılır, '
        'sakinleştirici ve empatik bir dille analiz et. Sınır değerlerin dışındaki '
        'sonuçları açıkça belirt ve doktora başvurulması gereken durumlar için '
        'nazikçe yönlendirme yap. Asla teşhis koyma, ilaç önerme.$hitapCumlesi';

    return await _mesajGonder(
      model: _kaliteliModel,
      mesajlar: [
        {'role': 'system', 'content': sistemPrompt},
        {'role': 'user', 'content': 'Tahlil Metni:\n$metin'},
      ],
    );
  }

  // Sabit tahlil-bilgisi sözlüğünde (yapay_zeka_ekrani.dart) OLMAYAN bir
  // tahlil için, "ne işe yarar / neden bakılır / dikkat" bilgisini AI'dan
  // üretir. Sonuç çağıran tarafta kalıcı olarak önbelleğe alınır, bir daha
  // aynı tahlil için tekrar sorulmaz.
  static Future<Map<String, String>> tahlilAciklamasiUret(String tahlilAdi) async {
    const sistemPrompt =
        'Sen bir laboratuvar tahlilleri uzmanısın. Sana verilen tahlil adı için '
        'kısa, sade, hasta dilinde bir açıklama üreteceksin. SADECE şu formatta, '
        'başka hiçbir açıklama olmadan, saf bir JSON nesnesi döndür: '
        '{"ne": "tahlilin tam/açık adı", "nedenir": "1 cümlede ne olduğu", '
        '"neden": "1 cümlede neden bakıldığı", "dikkat": "1 cümlede genel bilgi, '
        'kesin sayısal eşik verme, kişisel referans aralığına göre değerlendirilmesi '
        'gerektiğini belirt"}.';

    final cevap = await _mesajGonder(
      model: _hizliModel, // Kısa/basit bir açıklama, hızlı ve ucuz model yeterli.
      mesajlar: [
        {'role': 'system', 'content': sistemPrompt},
        {'role': 'user', 'content': 'Tahlil adı: $tahlilAdi'},
      ],
      responseFormat: const {'type': 'json_object'},
    );

    if (cevapHataMi(cevap)) {
      throw Exception(cevap);
    }
    try {
      final temiz = cevap.replaceAll('```json', '').replaceAll('```', '').trim();
      final ayristirilan = jsonDecode(temiz) as Map<String, dynamic>;
      return {
        'ne': (ayristirilan['ne'] ?? tahlilAdi).toString(),
        'nedenir': (ayristirilan['nedenir'] ?? '').toString(),
        'neden': (ayristirilan['neden'] ?? '').toString(),
        'dikkat': (ayristirilan['dikkat'] ?? '').toString(),
      };
    } catch (e) {
      throw Exception('Açıklama ayrıştırılamadı: $cevap');
    }
  }

  // Kullanıcı isteğiyle eklendi: tahlil sonucu referans dışındaysa (yüksek
  // ya da düşük), bu YÖNE ÖZEL olası nedenleri anlatır — genel "Dikkat"
  // metninden farklı olarak, "neden yüksek çıkmış olabilir" sorusuna
  // odaklanır. Tahlil adı + yön ("yuksek"/"dusuk") bazında önbelleğe
  // alınır, bir daha sorulmaz.
  static Future<String> tahlilYonNedeniUret(String tahlilAdi, String yon) async {
    final yonMetni = yon == 'yuksek' ? 'YÜKSEK' : 'DÜŞÜK';
    final sistemPrompt =
        'Sen bir laboratuvar tahlilleri uzmanısın. Sana verilen tahlil için, '
        'sonucun neden $yonMetni çıkmış OLABİLECEĞİNİ, hasta dilinde, 2-4 '
        'maddelik KISA bir liste hâlinde anlatacaksın (en yaygın/genel '
        'nedenler — diyet, sıvı alımı, ilaç kullanımı, egzersiz, enfeksiyon, '
        'kronik hastalıklar gibi kategoriler olabilir, hastaya özel teşhis '
        'KOYMA). Kesinlikle "sizde şu hastalık var" gibi teşhis cümlesi '
        'kurma, sadece "şu nedenlerle yükselebilir/düşebilir" tarzında genel '
        'bilgi ver ve kesin tanı için doktora danışılması gerektiğini '
        'belirt. SADECE şu formatta, başka hiçbir açıklama olmadan, saf bir '
        'JSON nesnesi döndür: {"nedenler": "kısa maddeler, her biri yeni '
        'satırda \'• \' ile başlasın"}.';

    final cevap = await _mesajGonder(
      model: _hizliModel,
      mesajlar: [
        {'role': 'system', 'content': sistemPrompt},
        {'role': 'user', 'content': 'Tahlil adı: $tahlilAdi — sonuç $yonMetni çıktı.'},
      ],
      responseFormat: const {'type': 'json_object'},
    );

    if (cevapHataMi(cevap)) {
      throw Exception(cevap);
    }
    try {
      final temiz = cevap.replaceAll('```json', '').replaceAll('```', '').trim();
      final ayristirilan = jsonDecode(temiz) as Map<String, dynamic>;
      return (ayristirilan['nedenler'] ?? '').toString();
    } catch (e) {
      throw Exception('Nedenler ayrıştırılamadı: $cevap');
    }
  }  // --- tahlilYonNedeniUret() sonu ---


  // sözlük OLMADIĞI için AI'dan "ne için kullanılır" bilgisi üretir. Doz/
  // teşhis/tedavi tavsiyesi KESİNLİKLE vermez — sadece genel, hasta dilinde
  // bir tanıtım bilgisi. Çağıran taraf (ilac_ekrani.dart) sonucu kalıcı
  // önbelleğe alır, aynı ilaç için bir daha sorulmaz.
  static Future<Map<String, String>> ilacBilgisiUret(String ilacAdi) async {
    const sistemPrompt =
        'Sen genel ilaç bilgilendirmesi yapan bir eczacı asistanısın. Sana '
        'verilen (Türkiye\'de satılan) bir ilacın TİCARİ adı için kısa, sade, '
        'hasta dilinde GENEL bilgi vereceksin. Kesinlikle doz önerme, "şu kadar '
        'al" deme, teşhis koyma veya tedavi tavsiyesi verme — sadece ilacın ne '
        'için / hangi durumlarda kullanıldığını genel hatlarıyla anlat. Eğer '
        'ilacı tanımıyorsan veya emin değilsen bunu açıkça belirt, uydurma '
        'bilgi verme. SADECE şu formatta, başka hiçbir açıklama olmadan, saf '
        'bir JSON nesnesi döndür: {"kategori": "1-2 kelimelik kısa etiket — '
        'örn: Tansiyon, Kalp, Prostat, Şeker, Kolesterol, Ağrı Kesici, '
        'Antibiyotik, Mide, Alerji, Tiroid, Diğer — bilinmiyorsa Diğer", '
        '"etkenMadde": "bilinen etken madde adı ya da bilinmiyorsa boş metin", '
        '"neIcin": "1-2 cümlede hangi durumlarda/ ne için kullanılır", '
        '"dikkat": "1 cümlede genel uyarı — örn. doktor/eczacıya danışılması '
        'gerektiği, bu bilginin doz/tedavi tavsiyesi olmadığı"}.';

    final cevap = await _mesajGonder(
      model: _hizliModel,
      mesajlar: [
        {'role': 'system', 'content': sistemPrompt},
        {'role': 'user', 'content': 'İlaç adı: $ilacAdi'},
      ],
      responseFormat: const {'type': 'json_object'},
    );

    if (cevapHataMi(cevap)) {
      throw Exception(cevap);
    }
    try {
      final temiz = cevap.replaceAll('```json', '').replaceAll('```', '').trim();
      final ayristirilan = jsonDecode(temiz) as Map<String, dynamic>;
      return {
        'kategori': (ayristirilan['kategori'] ?? '').toString(),
        'etkenMadde': (ayristirilan['etkenMadde'] ?? '').toString(),
        'neIcin': (ayristirilan['neIcin'] ?? '').toString(),
        'dikkat': (ayristirilan['dikkat'] ?? '').toString(),
      };
    } catch (e) {
      throw Exception('İlaç bilgisi ayrıştırılamadı: $cevap');
    }
  }  // --- ilacBilgisiUret() sonu ---

  // --- İKİ TAHLIL ARASINDAKİ KARŞILAŞTIRMA ANALİZİ ---
  static Future<String> karsilastirmaAnalizEt({
    required String yeniTarih,
    required Map<String, String> yeniDegerler,
    required String eskiTarih,
    required Map<String, String> eskiDegerler,
  }) async {
    final StringBuffer sb = StringBuffer();
    sb.writeln('$yeniTarih tarihli yeni sonuçlar:');
    yeniDegerler.forEach((ad, deger) => sb.writeln('- $ad: $deger'));
    sb.writeln('\n$eskiTarih tarihli önceki sonuçlar:');
    eskiDegerler.forEach((ad, deger) => sb.writeln('- $ad: $deger'));

    const sistemPrompt = 'Sen deneyimli bir sağlık asistanısın. İki farklı '
        'tarihe ait laboratuvar tahlil sonuçlarını karşılaştır: belirgin '
        'iyileşme gösteren değerleri belirt, kötüleşen veya dikkat gerektiren '
        'değerleri vurgula, değişmeyenler hakkında kısa bilgi ver. Samimi, '
        'sakinleştirici bir dille yaz. Teşhis koyma, ilaç önerme.';

    return await _mesajGonder(
      model: _kaliteliModel,
      mesajlar: [
        {'role': 'system', 'content': sistemPrompt},
        {'role': 'user', 'content': sb.toString()},
      ],
    );
  }  // --- karsilastirmaAnalizEt() sonu ---

  // --- PDF METNİNDEN YAPILANDIRILMIŞ TAHLIL VERİLERİ ---
  static Future<Map<String, dynamic>> tahlilVerileriniJsonOlarakCikar(
      String metin) async {
    const sistemPrompt =
        'Aşağıda bir e-Nabız tahlil sonuçları metni yer almaktadır. Bu metin '
        'bir PDF\'ten otomatik çıkarıldığı için satırlar/sütunlar karışmış veya '
        'sıra bozulmuş olabilir — buna rağmen elinden geleni yap. '
        '1) Metnin içinde bu tahlilin ait olduğu TARİHİ bul (rapor/numune/tahlil '
        'tarihi — genelde belgenin başında veya sonunda GG.AA.YYYY ya da benzer '
        'bir biçimde geçer). Bulamazsan null bırak. '
        '2) Metindeki HER BİR laboratuvar tahlilini tespit et, her birine şu '
        'sabit kategorilerden birini ata: "Kan Sayımı", "Biyokimya", "İdrar Tahlili", '
        '"Hormon", "Karaciğer/Böbrek", "Lipid (Kolesterol)", "Diğer". '
        '3) ÇOK ÖNEMLİ — TAHLİL ADI NORMALİZASYONU: e-Nabız PDF\'leri aynı testi '
        'farklı tarihlerde/kaynaklarda FARKLI isimlerle yazabilir (örn. bir PDF\'te '
        '"AST", başka birinde "ASPARTAT AMİNOTRANSFERAZ"; bir yerde "Glukoz (AKŞ)", '
        'başka yerde "GLUKOZ (SERUM/PLAZMA)"; bazen kategori adı öne eklenmiş olur, '
        'örn. "TAM KAN SAYIMI - EO#" — bu aslında sadece "EO#"dir). SEN bunları '
        'standart, KISA, herkesçe bilinen TIBBİ KISALTMA/İSME normalize et (örn. '
        'AST, ALT, HDL, LDL, Glukoz, Kreatinin, Kolesterol, Trigliserid, Sodyum, '
        'Potasyum, Kalsiyum gibi) — kategori önekini ("TAM KAN SAYIMI -", "TAM İDRAR '
        'ANALİZİ -" gibi) ASLA tahlil_adi\'nin içine katma, sadece "kategori" alanına '
        'yaz. Aynı testin farklı görünen isimlerini HER ZAMAN aynı normalize isme çevir '
        'ki zaman içindeki gidişatı tek satırda takip edilebilsin. '
        'SADECE şu formatta, başka hiçbir açıklama veya markdown işareti '
        'olmadan, saf bir JSON nesnesi döndür: '
        '{"tarih": "GG.AA.YYYY veya null", "tahliller": [{"tahlil_adi": "...", "sonuc": "...", "referans_araligi": "...", "kategori": "..."}]}. '
        'Referans aralığı yoksa "-" yaz. Gerçekten hiç tahlil bulamazsan {"tarih": null, "tahliller": []} döndür.';

    final cevap = await _mesajGonder(
      // Not: Bu ayrıştırma daha önce hızlı ama zayıf modelle (nano) yapılıyordu
      // ve karmaşık/bozuk PDF metinlerinde neredeyse hep boş sonuç veriyordu.
      // Sohbet ekranındaki gibi kaliteli modele geçirildi.
      model: _kaliteliModel,
      mesajlar: [
        {'role': 'system', 'content': sistemPrompt},
        {'role': 'user', 'content': 'Tahlil Metni:\n$metin'},
      ],
      responseFormat: const {'type': 'json_object'},
    );

    if (cevapHataMi(cevap)) {
      throw Exception(cevap);
    }

    try {
      String temiz = cevap.replaceAll('```json', '').replaceAll('```', '').trim();
      final dynamic ayristirilan = jsonDecode(temiz);
      final List<dynamic> liste = ayristirilan is List
          ? ayristirilan
          : (ayristirilan['tahliller'] as List<dynamic>? ?? []);
      final String? pdfTarihi = ayristirilan is Map ? ayristirilan['tarih']?.toString() : null;
      final tahliller = liste
          .map<Map<String, String>>((satir) => {
                'tahlil_adi': (satir['tahlil_adi'] ?? '').toString(),
                'sonuc': (satir['sonuc'] ?? '').toString(),
                'referans_araligi': (satir['referans_araligi'] ?? '-').toString(),
                'kategori': (satir['kategori'] ?? 'Diğer').toString(),
              })
          .where((s) => s['tahlil_adi']!.isNotEmpty && s['sonuc']!.isNotEmpty)
          .toList();
      return {'tarih': pdfTarihi, 'tahliller': tahliller};
    } catch (e) {
      // Önceden burada hata sessizce yutulup boş liste dönüyordu — AI'nın
      // gerçekten "tahlil yok" mu dediğini, yoksa cevabının bozuk JSON mu
      // geldiğini asla göremiyorduk. Artık gerçek cevabı taşıyoruz ki
      // ekranda görünsün ve kör uçmayalım.
      throw Exception('AI cevabı JSON olarak ayrıştırılamadı. Ham cevap: '
          '${cevap.length > 300 ? cevap.substring(0, 300) : cevap}');
    }
  }

  // --- RAPOR ANALİZİ (radyoloji/patoloji/konsültasyon vb. YAZILI raporlar) ---
  // Tahlil (sayısal/tablo) sonuçlarından FARKLI olarak, bu fonksiyon
  // rapor FOTOĞRAFINI (röntgen/MR raporu, doktor notu, konsültasyon
  // yazısı vb.) okuyup hem kısa bir BAŞLIK/konu hem de hasta diliyle bir
  // yorum üretir — kullanıcının Gemini/ChatGPT'ye elle okutup yorumlattığı
  // işi uygulama içinde yapar.
  static Future<Map<String, String>> raporFotografiniAnalizEt(File fotografDosyasi) async {
    final baytlar = await fotografDosyasi.readAsBytes();
    final base64Gorsel = base64Encode(baytlar);

    final sistemPrompt =
        'Sana bir tıbbi rapor görseli (radyoloji, patoloji, konsültasyon, '
        'ameliyat notu vb. YAZILI/anlatı tarzı bir rapor — sayısal tahlil '
        'tablosu DEĞİL) verilecek. Görevin: '
        '1) Raporun KONUSUNU kısa bir başlıkla özetle (örn. "Akciğer '
        'Röntgeni", "Karın MR Sonucu", "Kardiyoloji Konsültasyonu"). '
        '2) Rapor tarihini bulabilirsen GG.AA.YYYY biçiminde ver, '
        'bulamazsan null bırak. '
        '3) Raporu hasta diliyle, sakin ve anlaşılır şekilde özetle — '
        'önemli bulguları, varsa dikkat edilmesi gereken noktaları '
        'vurgula. TEŞHİS KOYMA, İLAÇ/TEDAVİ ÖNERME — sadece raporda '
        'YAZANI açıkla, gerekiyorsa doktora danışılmasını hatırlat. '
        'SADECE şu formatta saf bir JSON nesnesi döndür, başka hiçbir '
        'açıklama ekleme: {"baslik": "...", "tarih": "GG.AA.YYYY veya '
        'null", "yorum": "..."}';

    final cevap = await _mesajGonder(
      model: _kaliteliModel,
      mesajlar: [
        {
          'role': 'user',
          'content': [
            {'type': 'text', 'text': sistemPrompt},
            {
              'type': 'image_url',
              'image_url': {'url': 'data:image/jpeg;base64,$base64Gorsel'}
            }
          ]
        }
      ],
      responseFormat: const {'type': 'json_object'},
    );

    if (cevapHataMi(cevap)) {
      throw Exception(cevap);
    }
    try {
      final temiz = cevap.replaceAll('```json', '').replaceAll('```', '').trim();
      final ayristirilan = jsonDecode(temiz) as Map<String, dynamic>;
      return {
        'baslik': (ayristirilan['baslik'] ?? 'Rapor').toString(),
        'tarih': (ayristirilan['tarih'] ?? '').toString(),
        'yorum': (ayristirilan['yorum'] ?? '').toString(),
      };
    } catch (e) {
      throw Exception('Rapor analizi ayrıştırılamadı. Ham cevap: '
          '${cevap.length > 300 ? cevap.substring(0, 300) : cevap}');
    }
  }  // --- raporFotografiniAnalizEt() sonu ---

  // PDF'ten çıkarılan METİN üzerinden rapor analizi — raporFotografiniAnalizEt
  // ile AYNI JSON şeklini üretir, sadece görsel yerine metin okur (PDF
  // olarak yüklenen raporlar için).
  static Future<Map<String, String>> raporMetniniAnalizEt(String metin) async {
    final sistemPrompt =
        'Sana bir tıbbi rapor metni (radyoloji, patoloji, konsültasyon, '
        'ameliyat notu vb. YAZILI/anlatı tarzı bir rapor — PDF\'ten '
        'otomatik çıkarıldığı için satırlar karışmış olabilir) verilecek. '
        'Görevin: '
        '1) Raporun KONUSUNU kısa bir başlıkla özetle. '
        '2) Rapor tarihini bulabilirsen GG.AA.YYYY biçiminde ver, '
        'bulamazsan null bırak. '
        '3) Raporu hasta diliyle, sakin ve anlaşılır şekilde özetle — '
        'önemli bulguları vurgula. TEŞHİS KOYMA, İLAÇ/TEDAVİ ÖNERME. '
        'SADECE şu formatta saf bir JSON nesnesi döndür: {"baslik": "...", '
        '"tarih": "GG.AA.YYYY veya null", "yorum": "..."}\n\nRapor metni:\n$metin';

    final cevap = await _mesajGonder(
      model: _kaliteliModel,
      mesajlar: [
        {'role': 'user', 'content': sistemPrompt},
      ],
      responseFormat: const {'type': 'json_object'},
    );

    if (cevapHataMi(cevap)) {
      throw Exception(cevap);
    }
    try {
      final temiz = cevap.replaceAll('```json', '').replaceAll('```', '').trim();
      final ayristirilan = jsonDecode(temiz) as Map<String, dynamic>;
      return {
        'baslik': (ayristirilan['baslik'] ?? 'Rapor').toString(),
        'tarih': (ayristirilan['tarih'] ?? '').toString(),
        'yorum': (ayristirilan['yorum'] ?? '').toString(),
      };
    } catch (e) {
      throw Exception('Rapor analizi ayrıştırılamadı. Ham cevap: '
          '${cevap.length > 300 ? cevap.substring(0, 300) : cevap}');
    }
  }  // --- raporMetniniAnalizEt() sonu ---

  // --- YEMEK FOTOĞRAFINDAN KALORİ TAHMİNİ (OpenAI Vision) ---
  static Future<String> fotograftanKaloriTahminEt(File fotografDosyasi) async {
    try {
      final baytlar = await fotografDosyasi.readAsBytes();
      final base64Gorsel = base64Encode(baytlar);

      return await _mesajGonder(
        model: _kaliteliModel,
        mesajlar: [
          {
            'role': 'user',
            'content': [
              {
                'type': 'text',
                'text':
                    'Bu fotoğraftaki yemek(ler)i veya yiyece(k)i DİKKATLİCE '
                    'incele. ÖNEMLİ: masada/tabakta BİRDEN FAZLA ayrı yemek '
                    'çeşidi olabilir (örn. çorba + salata + ana yemek gibi) — '
                    'bunları TEK bir yemek gibi birleştirme, her birini AYRI '
                    'bir öğe olarak say. Sadece garnitür/sos gibi ana yemeğin '
                    'parçası olan şeyleri o yemeğin içine dahil et, ayrı öğe '
                    'yapma. Her öğe için: tüm malzemeleri, pişirme yöntemini '
                    '(kalori miktarını belirgin şekilde değiştirir) ve '
                    'porsiyon büyüklüğünü (tabağın/kabın boyutuyla kıyasla) '
                    'dikkate al. Emin olamadığın bir malzeme varsa en olası '
                    'tahminini yap, belirlenemedi deme. Türkçe yanıt ver. '
                    'TAM olarak şu formatta yanıt ver (kaç öğe varsa o kadar '
                    '"ÖĞE" bloğu yaz, TEK yemek olsa bile 1 öğe olarak aynı '
                    'formatta yaz):\nÖĞE_SAYISI: [rakam]\n\n'
                    'ÖĞE 1: [yemek adı, gördüğün ana malzemeler dahil]\n'
                    'Kalori: [rakam] kcal\nProtein: [rakam] g\n'
                    'Karbonhidrat: [rakam] g\nYağ: [rakam] g\n\n'
                    '(varsa ÖĞE 2, ÖĞE 3... aynı formatta devam)\n\n'
                    'TOPLAM:\nKalori: [tüm öğelerin toplamı] kcal\n'
                    'Protein: [tüm öğelerin toplamı] g\n'
                    'Karbonhidrat: [tüm öğelerin toplamı] g\n'
                    'Yağ: [tüm öğelerin toplamı] g\n\n'
                    'Açıklama: [kısa besin değeri bilgisi]'
              },
              {
                'type': 'image_url',
                'image_url': {'url': 'data:image/jpeg;base64,$base64Gorsel'}
              }
            ]
          }
        ],
      );
    } catch (e) {
      return 'Fotoğraf analizi sırasında hata oluştu: $e';
    }
  }  // --- fotograftanKaloriTahminEt() sonu ---

  // İlaç kutusu/şişesi fotoğrafından ilaç adını (ve varsa dozajını) okur.
  // Format, ilac_ekrani.dart'ın regex ile ayrıştırabilmesi için sabit
  // tutulmalı: "İlaç Adı: ...", "Dozaj: ...".
  static Future<String> ilacKutusundanTani(File fotografDosyasi) async {
    try {
      final baytlar = await fotografDosyasi.readAsBytes();
      final base64Gorsel = base64Encode(baytlar);

      return await _mesajGonder(
        model: _kaliteliModel,
        mesajlar: [
          {
            'role': 'user',
            'content': [
              {
                'type': 'text',
                'text':
                    'Bu fotoğraftaki ilaç kutusunu/şişesini incele. Kutu '
                    'üzerindeki YAZILI ilaç adını ve dozajını oku. TAM '
                    'olarak şu formatta yanıt ver (okunamıyorsa "Okunamadı" '
                    'yaz):\n'
                    'İlaç Adı: [kutuda yazan TAM ad + dozaj birlikte, örn: '
                    'Arlec 25 mg — kutuda dozaj yazıyorsa isme MUTLAKA ekle]'
              },
              {
                'type': 'image_url',
                'image_url': {'url': 'data:image/jpeg;base64,$base64Gorsel'}
              }
            ]
          }
        ],
      );
    } catch (e) {
      return 'İlaç Adı: Okunamadı\nDozaj: -';
    }
  }  // --- ilacKutusundanTani() sonu ---

  // --- KULLANICININ PROFİL VE SON ÖLÇÜMLERİNİ ÖZETLEYEN BAĞLAM METNİ ---
  // Seray'ın "beni tanımıyorsun" sorununu çözmek için: sohbete başlamadan
  // önce kullanıcının profilini ve son ölçümlerini toplayıp sistem promptuna
  // ekliyoruz. Böylece Seray, günlük gidişat hakkında da yorum yapabiliyor.
  static Future<String> _kullaniciBaglamiOlustur() async {
    try {
      return await _kullaniciBaglamiOlusturIc().timeout(
        const Duration(seconds: 6),
        onTimeout: () => '', // Veritabanı yavaşsa/takılırsa boş bağlamla devam et, sohbeti KİLİTLEME
      );
    } catch (_) {
      return '';
    }
  }  // --- _kullaniciBaglamiOlustur() sonu ---

  static Future<String> _kullaniciBaglamiOlusturIc() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      // ÖNEMLİ: Ad/yaş/boy/hedef kilo/diyabet artık HER PROFİL için AYRI
      // saklanıyor (profil_kayit_ekrani.dart, profil_sayfasi.dart,
      // analizler_ekrani.dart ile aynı anahtar üretme mantığı) — bu yüzden
      // burada da aynı şekilde AKTİF PROFİLE göre doğru anahtarları
      // okuyoruz. "Annem" profilindeyken artık gerçekten Annem'in kendi
      // bilgileri (girilmişse) gösterilir, Serdar'ınkiler değil.
      final py = ProfilYoneticisi();
      final ad = (await py.aktifProfil()).ad;
      final yas = prefs.getString(await py.profilAnahtari('kullanici_yas')) ?? prefs.getString('user_yas') ?? '';
      final boy = prefs.getString(await py.profilAnahtari('kullanici_boy')) ?? '';
      final hedefKilo = prefs.getDouble(await py.profilAnahtari('hedef_kilo'));
      final diyabet = prefs.getString(await py.profilAnahtari('kullanici_diyabet_turu')) ?? '';

      final sekerler = await VeritabaniYardimcisi().sekerleriGetir();
      final tansiyonlar = await VeritabaniYardimcisi().tansiyonlariGetir();
      final tumTahliller = await VeritabaniYardimcisi().tumTahlilleriGetir();
      final suKayitlari = await VeritabaniYardimcisi().suKayitlariniGetir();
      final kiloKayitlari = await VeritabaniYardimcisi().kiloKayitlariniGetir();
      final beslenmeKayitlari = await VeritabaniYardimcisi().beslenmeKayitlariniGetir();

      final sb = StringBuffer();
      sb.writeln('--- KULLANICI BİLGİLERİ (yalnızca sana bilgi amaçlı verildi, kullanıcıya bu başlığı okuma) ---');
      if (ad.isNotEmpty) sb.writeln('Ad: $ad');
      if (yas.isNotEmpty) sb.writeln('Yaş: $yas');
      if (boy.isNotEmpty) sb.writeln('Boy: $boy cm');
      if (hedefKilo != null) sb.writeln('Hedef kilo: ${hedefKilo.toStringAsFixed(1)} kg');
      if (diyabet.isNotEmpty && diyabet != 'Yok') sb.writeln('Diyabet durumu: $diyabet');

      if (sekerler.isNotEmpty) {
        sb.writeln('Son kan şekeri ölçümleri (en yeniden eskiye):');
        for (final s in sekerler.take(8)) {
          sb.writeln('- ${s['deger']} mg/dL (${s['durum']}, ${s['tarih']})');
        }
      }
      if (tansiyonlar.isNotEmpty) {
        sb.writeln('Son tansiyon ölçümleri (en yeniden eskiye):');
        for (final t in tansiyonlar.take(8)) {
          sb.writeln('- ${t['buyuk']}/${t['kucuk']} mmHg (${t['tarih']})');
        }
      }
      // ÖNEMLİ: önceden Seray'a e-Nabız tahlil sonuçları hiç verilmiyordu,
      // kullanıcı "tahlillerimde ne var" gibi bir şey sorunca cevap veremiyordu.
      // Artık yüklenmiş TÜM e-Nabız tahlilleri de bağlama ekleniyor.
      if (tumTahliller.isNotEmpty) {
        sb.writeln('Kullanıcının e-Nabız\'dan yüklediği laboratuvar tahlil sonuçları:');
        for (final t in tumTahliller.take(60)) {
          sb.writeln('- ${t['tahlil_adi']}: ${t['sonuc']} (Ref: ${t['referans_degeri']}, ${t['tarih']})');
        }
      }
      if (suKayitlari.isNotEmpty) {
        final sonSu = suKayitlari.first;
        sb.writeln('En son su tüketimi kaydı: ${sonSu['miktar_ml']} ml (${sonSu['tarih']})');
      }
      if (kiloKayitlari.isNotEmpty) {
        final sonKilo = kiloKayitlari.first;
        sb.writeln('En son kilo kaydı: ${sonKilo['kilo']} kg (${sonKilo['tarih']})');
      }
      // ÖNEMLİ: Beslenme (yemek) kayıtları önceden bağlama HİÇ eklenmiyordu —
      // kullanıcı "ne yedim / yemeklerim" diye sorunca Seray'ın elinde veri
      // olmadığı için "yetkim yok" gibi yanlış anlaşılan bir cevap veriyordu.
      // Aslında sorun yetki değil, veri hiç gönderilmiyordu — artık gönderiliyor.
      if (beslenmeKayitlari.isNotEmpty) {
        sb.writeln('Kullanıcının kaydettiği yemek/beslenme kayıtları (en yeniden eskiye):');
        for (final b in beslenmeKayitlari.take(20)) {
          sb.writeln('- ${b['yemek_adi']}: ${b['kalori']} kcal (${b['tarih']})');
        }
      }
      sb.writeln(
          'Kullanıcı sana kendi verilerini sorarsa (örn. "son şekerim ne kadardı", '
          '"tahlillerimde bir sorun var mı", "kolesterolüm ne durumda", "ne yedim", '
          '"yemek kayıtlarım neler"), yukarıdaki gerçek verileri kullanarak cevap ver — '
          'bu veriler sana zaten yetkiyle verildi, "yetkim yok / erişimim yok" gibi bir '
          'şey ASLA söyleme; eğer sorduğu konuda veri yoksa sadece "bu konuda henüz '
          'kayıtlı bir verin yok" de. Gidişatta (art arda yüksek/düşük ölçümler gibi) '
          'endişe verici bir örüntü görürsen, nazikçe belirt ve doktora danışmasını öner. '
          'Ama asla teşhis koyma. '
          'Vücut kitle endeksi (VKİ), ideal kilo ya da günlük kalori ihtiyacı sorulursa: '
          'boy ve en son kilo bilgisi yukarıda verilmişse bunları kullanarak KENDİN hesapla '
          '(VKİ = kilo / boy_metre²; günlük kalori ihtiyacı için yaş/cinsiyet biliniyorsa '
          'basit bir Harris-Benedict/Mifflin tahmini yap) — kullanıcıyı tekrar "boyunuz/'
          'kilonuz nedir" diye sormayla oyalama, zaten profilinde/kilo kayıtlarında var. '
          'Boy bilgisi YOKSA, nazikçe Profil ekranından "Boy (cm)" alanını doldurmasını söyle. '
          'Günlük protein ihtiyacı sorulursa: genel sağlıklı yetişkin için kilogram başına '
          'yaklaşık 0,8-1 g, 65 yaş üstü ya da aktif/kas koruması önemli kişilerde 1-1,2 g/kg '
          'aralığı yaygın genel bir referanstır (bu KESİN bir tıbbi reçete değil, genel bilgi '
          'olduğunu belirt). Yukarıda "Hedef kilo" verilmişse, hesaplamayı MEVCUT kilo yerine '
          'HEDEF kiloya göre yap (kişi o hedefe ulaştığında alması gereken miktarı soruyor '
          'olabilir) — hangi kiloyu baz aldığını cevabında açıkça belirt. Hedef kilo yoksa en '
          'son kayıtlı kiloyu kullan. Böbrek hastalığı gibi protein kısıtlaması gerektiren bir '
          'durum belirtilmemişse bu hesaplamayı yap; kişi böbrek sorunu belirtirse hesap yerine '
          'doktoruna danışmasını söyle. '
          'Kilo ile yediği yemekler arasında bir ilişki sorarsa (örn. "kilom neden artıyor"), '
          'yukarıdaki kilo kayıtları ile beslenme kayıtlarının tarihlerini karşılaştırarak '
          'yorum yap — ama kesin bilimsel bir neden-sonuç iddiası yerine, gördüğün genel '
          'eğilimi nazikçe belirt.');
      return sb.toString();
    } catch (_) {
      return '';
    }
  }  // --- _kullaniciBaglamiOlusturIc() sonu ---

  // --- SERAY YAPAY ZEKA SAĞLIK DANIŞMANI ---
  // gorsel verilirse (ataç ile eklenen fotoğraf), mesaj metin+resim olarak
  // gönderilir — Seray fotoğrafı da görüp yorumlayabilir (örn. yemek, tahlil
  // kağıdı, ilaç kutusu fotoğrafı).
  static Future<String> serayileSohbet({
    required String kullaniciMesaji,
    required List<Map<String, String>> sohbetGecmisi,
    File? gorsel,
  }) async {
    final baglam = await _kullaniciBaglamiOlustur();
    final sistemPrompt = '''
Senin adın Seray. Türkçe konuşan, şefkatli ve sabırlı bir sağlık bilinci asistanısın. Şeker, tansiyon gibi takip ettiğin konular her yaştan insanı ilgilendirebilir — sadece yaşlılara özgü konuşma, HERKESE aynı sıcak ve saygılı üslupla hitap et.

ÖNEMLİ — KENDİNİ TANITMA KURALI: Cevaplarına ASLA "Ben Seray..." diyerek başlama — bu SADECE ilk karşılama mesajında bir kere yapıldı, sohbetin geri kalanında bunu TEKRARLAMA. Sıradan bir cevap veriyormuş gibi doğrudan konuya gir (örn. doğrudan bilgiyle veya kısa bir onay ifadesiyle başla). Kendinden üçüncü kişi gibi ("Sen...") bahsetme ve sistem talimatındaki cümleleri olduğu gibi tekrarlama — kendi cümlelerinle, doğal ve akıcı konuş.

TEMEL KURALLAR:
- Asla teşhis koyma
- Asla ilaç önerme veya doz değiştirme
- Kullanıcının verilerinde gerçekten endişe verici bir örüntü fark ettiğinde doktora danışmasını öner — bunu HER mesajda tekrar etme, sadece gerektiğinde ve doğal bir şekilde söyle
- Anlaşılır, sade, DÜZGÜN VE DOĞRU DİLBİLGİSİNE SAHİP Türkçe kullan
- Sıcak, empatik ve sakinleştirici bir dil kullan
- Kullanıcının adını, yaşını veya sağlık geçmişini kendi isteği olmadan HER mesajda tekrar tekrar söyleme — bu bilgi sana arka planda referans için verildi, sohbeti doğal tut

$baglam
''';

    final List<Map<String, dynamic>> mesajlar = [
      {'role': 'system', 'content': sistemPrompt},
    ];
    for (final mesaj in sohbetGecmisi) {
      mesajlar.add({
        'role': mesaj['rol'] == 'kullanici' ? 'user' : 'assistant',
        'content': mesaj['metin'] ?? '',
      });
    }

    if (gorsel != null) {
      final baytlar = await gorsel.readAsBytes();
      final base64Gorsel = base64Encode(baytlar);
      mesajlar.add({
        'role': 'user',
        'content': [
          {'type': 'text', 'text': kullaniciMesaji.trim().isEmpty ? 'Bu fotoğrafı yorumla.' : kullaniciMesaji},
          {
            'type': 'image_url',
            'image_url': {'url': 'data:image/jpeg;base64,$base64Gorsel'}
          }
        ],
      });
    } else {
      mesajlar.add({'role': 'user', 'content': kullaniciMesaji});
    }

    return await _mesajGonder(model: _kaliteliModel, mesajlar: mesajlar);
  }  // --- serayileSohbet() sonu ---

  // --- YARDIM ASİSTANI (uygulama kullanımı Soru-Cevap) ---
  // Seray AI'dan (sağlık sohbeti) tamamen ayrı, kendi sistem promptuna
  // sahip: kullanıcının sağlık verilerine erişmez, sadece uygulamaBilgiMetni
  // referansıyla "bu buton ne işe yarar", "su hedefimi nasıl değiştiririm"
  // gibi soruları yanıtlar.
  static Future<String> uygulamaYardimSohbeti({
    required String kullaniciMesaji,
    required List<Map<String, String>> sohbetGecmisi,
  }) async {
    final sistemPrompt = '''
Sen Seray Sağlık Asistanım uygulamasının Yardım Asistanısın. Türkçe, kısa
ve net konuş. SADECE uygulamanın nasıl kullanılacağı hakkında soruları
yanıtla. Aşağıdaki bilgi, uygulamanın gerçek ekran/buton adlarını içerir,
bunları birebir kullan:

$uygulamaBilgiMetni
''';

    final List<Map<String, dynamic>> mesajlar = [
      {'role': 'system', 'content': sistemPrompt},
    ];
    for (final mesaj in sohbetGecmisi) {
      mesajlar.add({
        'role': mesaj['rol'] == 'kullanici' ? 'user' : 'assistant',
        'content': mesaj['metin'] ?? '',
      });
    }
    mesajlar.add({'role': 'user', 'content': kullaniciMesaji});

    return await _mesajGonder(model: _hizliModel, mesajlar: mesajlar);
  }  // --- uygulamaYardimSohbeti() sonu ---

  // --- SEKME BAŞINA DİNAMİK GİDİŞAT YORUMU (Şeker/Tansiyon/Su/Kilo/Adım) ---
  // Kısa (2-3 cümle), sekmenin üstünde gösterilecek bir yorum üretir.
  // Ucuz/hızlı model kullanılır çünkü bu, sık tetiklenebilecek küçük bir görev.
  static Future<String> gidisatYorumuOlustur({
    required String metrikAdi,
    required String veriOzeti,
  }) async {
    final sistemPrompt =
        'Sen kısa ve öz konuşan bir sağlık asistanısın. Kullanıcının $metrikAdi '
        'ölçüm geçmişine bakarak SADECE 2-3 cümlelik, sıcak ve yapıcı bir '
        'gidişat yorumu yap. Sayıları tekrar tekrar sıralama, genel eğilimi '
        '(iyi gidiyor / dikkat gerekiyor / stabil vb.) yorumla ve gerekirse '
        'kısa bir öneri ekle. Teşhis koyma, ilaç önerme. Markdown kullanma.';

    return await _mesajGonder(
      model: _hizliModel,
      mesajlar: [
        {'role': 'system', 'content': sistemPrompt},
        {'role': 'user', 'content': veriOzeti},
      ],
    );
  }  // --- gidisatYorumuOlustur() sonu ---

  // --- HAFTALIK ÖRÜNTÜ/İÇGÖRÜ ÖZETİ (Şeker + Beslenme birlikte) ---
  // Ayrı ayrı grafiklerde görünmeyen bağlantıları (örn. "X yemekten sonra
  // şekerin genelde yükseliyor") yakalamak için şeker ölçümleri ile aynı
  // haftadaki yemek kayıtlarını birlikte AI'ya veriyoruz.
  static Future<String> haftalikIcgoruOlustur(String veriOzeti) async {
    const sistemPrompt =
        'Sen deneyimli bir diyabet/beslenme asistanısın. Kullanıcının son 7 '
        'günlük kan şekeri ölçümleri İLE aynı dönemdeki yemek kayıtlarını '
        'birlikte inceleyeceksin. Amacın: ayrı ayrı bakınca fark edilmeyen '
        'bir ÖRÜNTÜ var mı bulmak (örn. "akşam yediğin X yemeğinden birkaç '
        'saat sonra şekerin genelde yükseliyor" gibi). SADECE 3-4 cümlelik, '
        'somut ve yapıcı bir özet yaz. Yeterli veri yoksa ya da net bir '
        'örüntü göremiyorsan bunu dürüstçe söyle, uydurma bağlantı kurma. '
        'Teşhis koyma, ilaç/diyet reçetesi verme — sadece dikkat çeken '
        'örüntüyü işaret et ve gerekirse doktor/diyetisyene danışmayı öner. '
        'Markdown kullanma.';

    return await _mesajGonder(
      model: _kaliteliModel,
      mesajlar: [
        {'role': 'system', 'content': sistemPrompt},
        {'role': 'user', 'content': veriOzeti},
      ],
    );
  }  // --- haftalikIcgoruOlustur() sonu ---

  // --- ORTAK MESAJ GÖNDERME ---
  static Future<String> _mesajGonder({
    required List<Map<String, dynamic>> mesajlar,
    String model = _hizliModel,
    Map<String, String>? responseFormat,
  }) async {
    try {
      final url = Uri.parse('$_apiUrl?model=$model');
      final response = await http
          .post(
            url,
            headers: {
              'Content-Type': 'application/json',
              // --- GÜVENLİK: Worker'daki paylaşılan gizli anahtar kontrolü ---
              // Bu anahtar Worker'daki SERAY_APP_SECRET ile birebir aynı
              // olmalı. Eşleşmezse Worker isteği reddeder (401).
              'X-Seray-Key': _appSecret,
            },
            body: jsonEncode({
              'messages': mesajlar,
              if (responseFormat != null) 'response_format': responseFormat,
            }),
          )
          .timeout(_zamanAsimi);

      return await _metinCevabiCikar(response);
    } on TimeoutException {
      return 'Bağlantı çok yavaş kaldı ve işlem zaman aşımına uğradı. '
          'Lütfen internet bağlantınızı kontrol edip tekrar deneyin.';
    } catch (e) {
      return 'Bağlantı sırasında bir sorun oluştu: $e';
    }
  }  // --- _mesajGonder() sonu ---
}
