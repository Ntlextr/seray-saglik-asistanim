import 'dart:convert';
import '../models/saglik_verisi.dart';

class VeriServisi {
  static SaglikVerisi metniVeriyeDonustur(String metin) {
    try {
      final Map<String, dynamic> data = jsonDecode(metin);
      
      return SaglikVerisi(
        tarih: DateTime.parse(data['tarih'] ?? DateTime.now().toIso8601String()),
        tansiyonUst: (data['tansiyonUst'] as num).toDouble(),
        tansiyonAlt: (data['tansiyonAlt'] as num).toDouble(),
        seker: (data['seker'] as num).toDouble(),
        nabiz: (data['nabiz'] as num).toDouble(),
        ilacBilgisi: "PDF Analizinden geldi",
        notlar: "Otomatik",
      );
    } catch (e) {
      // Hata durumunda boş veri döndür
      return SaglikVerisi(
        tarih: DateTime.now(),
        tansiyonUst: 0,
        tansiyonAlt: 0,
        seker: 0,
        nabiz: 0,
        ilacBilgisi: "Hata",
        notlar: "Veri okunamadı",
      );
    }
  }
}
