import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/saglik_verisi.dart';

class DatabaseServisi {
  static const String _key = 'saglik_kayitlari';

  static Future<void> veriKaydet(SaglikVerisi yeniVeri) async {
    final prefs = await SharedPreferences.getInstance();
    List<SaglikVerisi> liste = await verileriGetir();
    liste.add(yeniVeri);
    await prefs.setString(_key, jsonEncode(liste.map((e) => e.toJson()).toList()));
  }

  static Future<List<SaglikVerisi>> verileriGetir() async {
    final prefs = await SharedPreferences.getInstance();
    String? jsonString = prefs.getString(_key);
    if (jsonString == null) return [];
    return (jsonDecode(jsonString) as List).map((e) => SaglikVerisi.fromJson(e)).toList();
  }

  // Dr. Raporu için veriyi metin formatında döker
  static Future<String> raporHazirla() async {
    List<SaglikVerisi> liste = await verileriGetir();
    String rapor = "SAĞLIK TAKİP RAPORU\n------------------\n";
    for (var v in liste) {
      rapor += "${v.tarih.toString().substring(0,10)} | Şeker: ${v.seker} | Tansiyon: ${v.tansiyonUst}/${v.tansiyonAlt} | Nabız: ${v.nabiz} | İlaç: ${v.ilacBilgisi}\n";
    }
    return rapor;
  }
}
