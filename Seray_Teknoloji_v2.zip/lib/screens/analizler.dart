import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../models/saglik_verisi.dart';

class AnalizlerSayfasi extends StatefulWidget {
  const AnalizlerSayfasi({super.key});

  @override
  State<AnalizlerSayfasi> createState() => _AnalizlerSayfasiState();
}

class _AnalizlerSayfasiState extends State<AnalizlerSayfasi> {
  List<SaglikVerisi> _kayitlar = [];
  bool _yukleniyor = true;

  @override
  void initState() {
    super.initState();
    _verileriCek();
  }

  Future<void> _verileriCek() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      List<String>? hamVeri = prefs.getStringList('saglik_kayitlari');
      
      if (hamVeri != null) {
        setState(() {
          _kayitlar = hamVeri.map((s) => SaglikVerisi.fromJson(jsonDecode(s))).toList();
          _yukleniyor = false;
        });
      } else {
        setState(() => _yukleniyor = false);
      }
    } catch (e) {
      setState(() => _yukleniyor = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Sağlık Analizleri")),
      body: _yukleniyor 
        ? const Center(child: CircularProgressIndicator())
        : _kayitlar.isEmpty 
          ? const Center(child: Text("Henüz kayıtlı bir analiz yok."))
          : ListView.builder(
              itemCount: _kayitlar.length,
              itemBuilder: (context, index) {
                // Son ekleneni en başa getirmek için indeks ters çevrildi
                final veri = _kayitlar[_kayitlar.length - 1 - index];
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  child: ListTile(
                    leading: const Icon(Icons.analytics, color: Colors.blue),
                    title: Text("Tarih: ${veri.tarih.toString().substring(0, 16)}"),
                    subtitle: Text("Şeker: ${veri.seker} | Tansiyon: ${veri.tansiyonUst}/${veri.tansiyonAlt}"),
                  ),
                );
              },
            ),
    );
  }
}
