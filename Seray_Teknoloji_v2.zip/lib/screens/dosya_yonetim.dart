import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart';
import '../services/veri_servisi.dart';
import '../services/ses_servisi.dart';
import '../services/api_service.dart';
import '../models/saglik_verisi.dart';

class VeriYonetimiSekmeSayfasi extends StatefulWidget {
  const VeriYonetimiSekmeSayfasi({super.key});

  @override
  State<VeriYonetimiSekmeSayfasi> createState() =>
      _VeriYonetimiSekmeSayfasiState();
}

class _VeriYonetimiSekmeSayfasiState extends State<VeriYonetimiSekmeSayfasi> {
  String _durumMesaji = "PDF tahlilinizi seçin, asistanınız analiz etsin.";
  bool _yukleniyor = false;

  Future<void> _analizEt() async {
    final result = await FilePicker.platform
        .pickFiles(type: FileType.custom, allowedExtensions: ['pdf']);
    if (result == null || result.files.single.path == null) return;

    setState(() {
      _yukleniyor = true;
      _durumMesaji = "PDF okunuyor, lütfen bekleyin...";
    });

    try {
      // 1) PDF dosyasından ham metni çıkar
      final dosya = File(result.files.single.path!);
      final bytes = await dosya.readAsBytes();
      final pdfDoc = PdfDocument(inputBytes: bytes);
      final pdfMetni = PdfTextExtractor(pdfDoc).extractText();
      pdfDoc.dispose();

      if (pdfMetni.trim().isEmpty) {
        throw Exception(
            "PDF içinden metin okunamadı. Taranmış (resim) bir PDF olabilir.");
      }

      if (mounted) {
        setState(() => _durumMesaji = "Gemini analiz ediyor...");
      }

      // 2) Çıkarılan metni Gemini'ye gönder, JSON cevabı al
      final aiYaniti = await ApiService.tahlilMetniniAnalizEt(pdfMetni);

      // 3) JSON cevabını modele çevir
      final SaglikVerisi veri = VeriServisi.metniVeriyeDonustur(aiYaniti);

      // 4) Kaydet
      final prefs = await SharedPreferences.getInstance();
      final kayitlar = prefs.getStringList('saglik_kayitlari') ?? [];
      kayitlar.add(aiYaniti);
      await prefs.setStringList('saglik_kayitlari', kayitlar);

      if (!mounted) return;
      setState(() {
        _yukleniyor = false;
        _durumMesaji = "Analiz başarıyla tamamlandı!";
      });

      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text("Analiz Sonucu"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text("Şeker: ${veri.seker} mg/dL"),
              Text("Tansiyon: ${veri.tansiyonUst}/${veri.tansiyonAlt}"),
              Text("Nabız: ${veri.nabiz}"),
              const SizedBox(height: 20),
              IconButton(
                icon: const Icon(Icons.volume_up, size: 60, color: Colors.blue),
                onPressed: () => SesServisi.tahlilOku(
                  seker: veri.seker,
                  tansiyonUst: veri.tansiyonUst,
                  tansiyonAlt: veri.tansiyonAlt,
                  nabiz: veri.nabiz,
                ),
              ),
              const Text("Dinlemek için bas"),
            ],
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _yukleniyor = false;
        _durumMesaji = "Bir hata oluştu: $e";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("PDF Analiz & Asistan")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Text(_durumMesaji, textAlign: TextAlign.center),
            ),
            if (_yukleniyor)
              const CircularProgressIndicator()
            else
              ElevatedButton.icon(
                icon: const Icon(Icons.picture_as_pdf),
                onPressed: _analizEt,
                label: const Text("Tahlil PDF'ini Analiz Et"),
              ),
          ],
        ),
      ),
    );
  }
}
