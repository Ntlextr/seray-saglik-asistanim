class SaglikVerisi {
  final DateTime tarih;
  final double seker;
  final double tansiyonUst;
  final double tansiyonAlt;
  final double nabiz;
  final String ilacBilgisi; 
  final String notlar;      

  SaglikVerisi({
    required this.tarih,
    required this.seker,
    required this.tansiyonUst,
    required this.tansiyonAlt,
    required this.nabiz,
    this.ilacBilgisi = "",
    this.notlar = "",
  });

  Map<String, dynamic> toJson() => {
    'tarih': tarih.toIso8601String(),
    'seker': seker,
    'tansiyonUst': tansiyonUst,
    'tansiyonAlt': tansiyonAlt,
    'nabiz': nabiz,
    'ilacBilgisi': ilacBilgisi,
    'notlar': notlar,
  };

  factory SaglikVerisi.fromJson(Map<String, dynamic> json) => SaglikVerisi(
    tarih: DateTime.parse(json['tarih']),
    seker: (json['seker'] as num).toDouble(),
    tansiyonUst: (json['tansiyonUst'] as num).toDouble(),
    tansiyonAlt: (json['tansiyonAlt'] as num).toDouble(),
    nabiz: (json['nabiz'] as num).toDouble(),
    ilacBilgisi: json['ilacBilgisi'] ?? "",
    notlar: json['notlar'] ?? "",
  );
}
