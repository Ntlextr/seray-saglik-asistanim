import 'package:flutter/material.dart';
import '../theme/renkler.dart';
import '../theme/sablon.dart';
import '../services/veritabani_yardimcisi.dart';
import '../services/bildirim_servisi.dart';
import '../services/adim_servisi.dart';
import '../services/widget_servisi.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../widgets/ust_menu.dart';

class SuKiloEkrani extends StatefulWidget {
  const SuKiloEkrani({Key? key}) : super(key: key);
  @override
  State<SuKiloEkrani> createState() => _SuKiloEkraniState();
}

class _SuKiloEkraniState extends State<SuKiloEkrani>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  // Su takibi
  int _bugunSuMl = 0;
  List<Map<String, dynamic>> _suKayitlari = [];
  // ÖNCEDEN sabit 2000 mL idi. Artık VeritabaniYardimcisi().suHedefiMlGetir()
  // ile en son kiloya göre (kilo x 30ml, diyetisyen formülü) otomatik
  // hesaplanıyor — kullanıcı isterse elle de değiştirebiliyor.
  int _gunlukHedefMl = 2000;
  bool _suHedefiManuelMi = false;

  // Kilo takibi
  List<Map<String, dynamic>> _kiloKayitlari = [];

  // Su hatırlatma bildirimleri (sabit saatli: 10-13-16-19-21) — varsayılan
  // AÇIK, SharedPreferences'ta saklanıyor.
  bool _suHatirlatmaAktif = true;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _verileriYukle();
    _suHatirlatmaTercihiniYukle();
  }

  Future<void> _suHatirlatmaTercihiniYukle() async {
    final tercihler = await SharedPreferences.getInstance();
    final aktif = tercihler.getBool('su_hatirlatma_aktif') ?? true;
    if (mounted) setState(() => _suHatirlatmaAktif = aktif);
    if (aktif) {
      BildirimServisi.suHatirlaticilariniKur();
    }
  }  // --- _suHatirlatmaTercihiniYukle() sonu ---

  Future<void> _suHatirlatmaTercihiniDegistir(bool yeniDeger) async {
    setState(() => _suHatirlatmaAktif = yeniDeger);
    final tercihler = await SharedPreferences.getInstance();
    await tercihler.setBool('su_hatirlatma_aktif', yeniDeger);
    if (yeniDeger) {
      await BildirimServisi.suHatirlaticilariniKur();
    } else {
      await BildirimServisi.suHatirlaticilariniIptalEt();
    }
  }  // --- _suHatirlatmaTercihiniDegistir() sonu ---

  // Su hedefini elle düzenleme — kaydedince bir daha kiloya göre otomatik
  // hesaba dönmez ("Otomatiğe Dön" ile geri alınabilir).
  Future<void> _suHedefiDuzenle() async {
    final controller = TextEditingController(text: (_gunlukHedefMl / 1000).toStringAsFixed(1));
    final secim = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Günlük Su Hedefi'),
        content: TextField(
          controller: controller,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(suffixText: 'Litre', border: OutlineInputBorder()),
          autofocus: true,
        ),
        actions: [
          if (_suHedefiManuelMi)
            TextButton(onPressed: () => Navigator.pop(context, 'otomatik'), child: const Text('Otomatiğe Dön')),
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Vazgeç')),
          TextButton(onPressed: () => Navigator.pop(context, 'kaydet'), child: const Text('Kaydet')),
        ],
      ),
    );
    if (secim == null) return;
    final tercihler = await SharedPreferences.getInstance();
    if (secim == 'otomatik') {
      await tercihler.remove('su_hedefi_ml_manuel');
    } else if (secim == 'kaydet') {
      final litre = double.tryParse(controller.text.replaceAll(',', '.'));
      if (litre == null || litre <= 0) return;
      await tercihler.setInt('su_hedefi_ml_manuel', (litre * 1000).round());
    }
    await _verileriYukle();
  }  // --- _suHedefiDuzenle() sonu ---

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _verileriYukle() async {
    final su = await VeritabaniYardimcisi().bugunToplamSuGetir();
    final suKayit = await VeritabaniYardimcisi().suKayitlariniGetir();
    final kilo = await VeritabaniYardimcisi().kiloKayitlariniGetir();
    final suHedefi = await VeritabaniYardimcisi().suHedefiMlGetir();
    final tercihler = await SharedPreferences.getInstance();
    if (mounted) {
      setState(() {
        _bugunSuMl = su;
        _suKayitlari = suKayit;
        _kiloKayitlari = kilo;
        _gunlukHedefMl = suHedefi;
        _suHedefiManuelMi = tercihler.getInt('su_hedefi_ml_manuel') != null;
      });
    }
    // ÖNEMLİ: Önceden widget SADECE Özet ekranı açıkken güncelleniyordu —
    // burada (Su & Kilo ekranında) su eklense bile widget haberdar olmuyordu.
    // Artık su verisi her değiştiğinde widget'a da anında haber veriliyor.
    final adim = await AdimServisi.bugunkuAdimGetir();
    WidgetServisi.guncelle(adim: adim, suMl: su);
  }

  String _tarihiBicimlendir(String? isoTarih) {
    if (isoTarih == null) return '';
    final t = DateTime.tryParse(isoTarih);
    if (t == null) return isoTarih;
    String iki(int n) => n.toString().padLeft(2, '0');
    return '${iki(t.day)}.${iki(t.month)}.${t.year} ${iki(t.hour)}:${iki(t.minute)}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(
        title: FittedBox(
          fit: BoxFit.scaleDown,
          alignment: Alignment.centerLeft,
          child: const Text('Su & Kilo Takibi', maxLines: 1),
        ),
        backgroundColor: AppRenkleri.aktif,
        foregroundColor: Colors.white,
        actions: const [UstMenu()],
        bottom: TabBar(
          controller: _tabController,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white70,
          indicatorColor: Colors.white,
          tabs: const [
            Tab(icon: Icon(Icons.water_drop), text: 'Su Takibi'),
            Tab(icon: Icon(Icons.monitor_weight), text: 'Kilo Takibi'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _suTabibiWidget(),
          _kiloTakibiWidget(),
        ],
      ),
    );
  }

  // ===================== SU TAKİBİ =====================
  Widget _suTabibiWidget() {
    final yuzde = (_bugunSuMl / _gunlukHedefMl).clamp(0.0, 1.0);
    final bardakSayisi = (_bugunSuMl / 250).floor(); // 1 bardak = 250 ml
    final kalanMl = (_gunlukHedefMl - _bugunSuMl).clamp(0, _gunlukHedefMl);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          // Günlük özet kartı
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Text(
                    'Bugün İçtiğiniz Su',
                    style: TextStyle(color: Colors.grey.shade600, fontSize: 13),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _bugunSuMl >= 1000
                        ? '${(_bugunSuMl / 1000).toStringAsFixed(1)} L'
                        : '$_bugunSuMl mL',
                    style: TextStyle(fontSize: 40, fontWeight: FontWeight.bold, color: AppRenkleri.aktif),
                  ),
                  GestureDetector(
                    onTap: _suHedefiDuzenle,
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          '$bardakSayisi bardak  •  Hedef: ${_gunlukHedefMl ~/ 1000} L${_suHedefiManuelMi ? '' : ' (kiloya göre)'}',
                          style: TextStyle(color: Colors.grey.shade500, fontSize: 12),
                        ),
                        const SizedBox(width: 4),
                        Icon(Icons.edit, size: 13, color: Colors.grey.shade400),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  // İlerleme çubuğu
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: LinearProgressIndicator(
                      value: yuzde,
                      minHeight: 14,
                      backgroundColor: Colors.blue.shade100,
                      valueColor: AlwaysStoppedAnimation<Color>(
                        yuzde >= 1.0 ? Colors.green : Colors.blue.shade400,
                      ),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    yuzde >= 1.0
                        ? '🎉 Günlük hedefe ulaştınız!'
                        : 'Hedefe $kalanMl mL kaldı (${(yuzde * 100).toInt()}%)',
                    style: TextStyle(
                      fontSize: 12,
                      color: yuzde >= 1.0 ? Colors.green : Colors.grey.shade600,
                      fontWeight: yuzde >= 1.0 ? FontWeight.bold : FontWeight.normal,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          // Hızlı ekleme butonları
          const Text('Hızlı Ekle', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          const SizedBox(height: 10),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            alignment: WrapAlignment.center,
            children: [
              _suEkleButonu('1 Bardak\n250 mL', 250, Icons.local_drink),
              _suEkleButonu('Büyük Bardak\n350 mL', 350, Icons.local_cafe),
              _suEkleButonu('Küçük Şişe\n500 mL', 500, Icons.water),
              _suEkleButonu('Büyük Şişe\n1000 mL', 1000, Icons.water_outlined),
            ],
          ),
          const SizedBox(height: 16),
          // Özel miktar girişi
          OutlinedButton.icon(
            icon: const Icon(Icons.edit, size: 16),
            label: const Text('Özel Miktar Gir'),
            style: OutlinedButton.styleFrom(foregroundColor: AppRenkleri.aktif),
            onPressed: _ozelMiktarGir,
          ),
          const SizedBox(height: 20),
          // Su hatırlatma bildirimleri açma/kapama — sabit saatlerde
          // (10-13-16-19-21) günlük tekrarlayan bildirim kurar/iptal eder.
          Card(
            color: Colors.blue.shade50,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: SwitchListTile(
              value: _suHatirlatmaAktif,
              onChanged: _suHatirlatmaTercihiniDegistir,
              activeColor: Colors.blue,
              secondary: const Icon(Icons.notifications_active_outlined, color: Colors.blue),
              title: const Text('Su İçme Hatırlatmaları', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
              subtitle: const Text('Günde 5 kez (10-13-16-19-21) hatırlatma bildirimi', style: TextStyle(fontSize: 11)),
            ),
          ),
          const SizedBox(height: 20),
          // Bugünkü kayıtlar
          if (_suKayitlari.isNotEmpty) ...[
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Bugünkü Kayıtlar', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                TextButton(
                  onPressed: () async {
                    final onay = await showDialog<bool>(
                      context: context,
                      builder: (ctx) => AlertDialog(
                        title: const Text('Tüm Su Kayıtlarını Sil'),
                        content: const Text('Bugünkü su kayıtlarınızı silmek istiyor musunuz?'),
                        actions: [
                          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('İptal')),
                          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Sil', style: TextStyle(color: Colors.red))),
                        ],
                      ),
                    );
                    if (onay == true) {
                      for (final k in _suKayitlari) {
                        await VeritabaniYardimcisi().suKaydiSil(k['id'] as int);
                      }
                      await _verileriYukle();
                    }
                  },
                  child: const Text('Temizle', style: TextStyle(color: Colors.red, fontSize: 12)),
                ),
              ],
            ),
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: _suKayitlari.length,
              itemBuilder: (context, index) {
                final kayit = _suKayitlari[index];
                final miktarMl = kayit['miktar_ml'] as int;
                return ListTile(
                  dense: true,
                  leading: const Icon(Icons.water_drop, color: Colors.blue, size: 20),
                  title: Text(
                    miktarMl >= 1000
                        ? '${(miktarMl / 1000).toStringAsFixed(1)} L'
                        : '$miktarMl mL',
                    style: const TextStyle(fontSize: 14),
                  ),
                  subtitle: Text(_tarihiBicimlendir(kayit['tarih']?.toString()),
                      style: const TextStyle(fontSize: 11)),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline, size: 18, color: Colors.grey),
                    onPressed: () async {
                      await VeritabaniYardimcisi().suKaydiSil(kayit['id'] as int);
                      await _verileriYukle();
                    },
                  ),
                );
              },
            ),
          ],
        ],
      ),
    );
  }

  Widget _suEkleButonu(String etiket, int miktarMl, IconData ikon) {
    return InkWell(
      onTap: () async {
        await VeritabaniYardimcisi().suEkle(miktarMl);
        await _verileriYukle();
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('$miktarMl mL eklendi ✓'), duration: const Duration(seconds: 1)),
          );
        }
      },
      borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
      child: Container(
        width: 140,
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
        decoration: BoxDecoration(
          color: Colors.blue.shade50,
          borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
          border: Border.all(color: Colors.blue.shade200),
        ),
        child: Column(
          children: [
            Icon(ikon, color: Colors.blue.shade600, size: 28),
            const SizedBox(height: 6),
            Text(etiket, textAlign: TextAlign.center,
                style: TextStyle(fontSize: 12, color: Colors.blue.shade800, fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }

  void _ozelMiktarGir() {
    final controller = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Özel Miktar'),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(
            labelText: 'Miktar (mL)',
            hintText: 'Örn: 400',
            suffixText: 'mL',
          ),
          autofocus: true,
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('İptal')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppRenkleri.aktif, foregroundColor: Colors.white),
            onPressed: () async {
              final miktar = int.tryParse(controller.text.trim());
              if (miktar != null && miktar > 0) {
                Navigator.pop(context);
                await VeritabaniYardimcisi().suEkle(miktar);
                await _verileriYukle();
              }
            },
            child: const Text('Ekle'),
          ),
        ],
      ),
    );
  }

  // ===================== KİLO TAKİBİ =====================
  Widget _kiloTakibiWidget() {
    final double? sonKilo = _kiloKayitlari.isNotEmpty
        ? (_kiloKayitlari.first['kilo'] as num).toDouble()
        : null;
    final double? oncekiKilo = _kiloKayitlari.length >= 2
        ? (_kiloKayitlari[1]['kilo'] as num).toDouble()
        : null;

    double? fark;
    if (sonKilo != null && oncekiKilo != null) {
      fark = sonKilo - oncekiKilo;
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Son kilo kartı
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Text('Son Ölçülen Kilo', style: TextStyle(color: Colors.grey.shade600, fontSize: 13)),
                  const SizedBox(height: 8),
                  sonKilo != null
                      ? Text('${sonKilo.toStringAsFixed(1)} kg',
                          style: TextStyle(fontSize: 40, fontWeight: FontWeight.bold, color: AppRenkleri.aktif))
                      : const Text('Henüz kayıt yok', style: TextStyle(fontSize: 18, color: Colors.grey)),
                  if (fark != null) ...[
                    const SizedBox(height: 6),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          fark > 0 ? Icons.arrow_upward : (fark < 0 ? Icons.arrow_downward : Icons.remove),
                          color: fark > 0 ? Colors.orange : (fark < 0 ? Colors.green : Colors.grey),
                          size: 16,
                        ),
                        Text(
                          ' ${fark.abs().toStringAsFixed(1)} kg (önceki ölçüme göre)',
                          style: TextStyle(
                            fontSize: 12,
                            color: fark > 0 ? Colors.orange : (fark < 0 ? Colors.green : Colors.grey),
                          ),
                        ),
                      ],
                    ),
                  ],
                  if (_kiloKayitlari.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 4),
                      child: Text(
                        _tarihiBicimlendir(_kiloKayitlari.first['tarih']?.toString()),
                        style: TextStyle(fontSize: 11, color: Colors.grey.shade500),
                      ),
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          // Kilo ekle butonu
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppRenkleri.aktif,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            ),
            onPressed: _kiloEkle,
            icon: const Icon(Icons.add),
            label: const Text('Kilo Ölçümü Ekle'),
          ),
          const SizedBox(height: 20),
          // Grafik (son 10 kayıt)
          if (_kiloKayitlari.length >= 2) ...[
            const Text('Kilo Seyri', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
            const SizedBox(height: 10),
            _kiloGrafigi(),
            const SizedBox(height: 16),
          ],
          // Geçmiş listesi
          if (_kiloKayitlari.isNotEmpty) ...[
            const Text('Geçmiş Ölçümler', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
            const SizedBox(height: 8),
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: _kiloKayitlari.length,
              itemBuilder: (context, index) {
                final kayit = _kiloKayitlari[index];
                final kilo = (kayit['kilo'] as num).toDouble();
                return Card(
                  margin: const EdgeInsets.symmetric(vertical: 3),
                  child: ListTile(
                    dense: true,
                    leading: CircleAvatar(
                      radius: 18,
                      backgroundColor: AppRenkleri.aktif.shade50,
                      child: Icon(Icons.monitor_weight, color: AppRenkleri.aktif, size: 18),
                    ),
                    title: Text('${kilo.toStringAsFixed(1)} kg',
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text(_tarihiBicimlendir(kayit['tarih']?.toString()),
                        style: const TextStyle(fontSize: 11)),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline, size: 18, color: Colors.grey),
                      onPressed: () async {
                        await VeritabaniYardimcisi().kiloKaydiSil(kayit['id'] as int);
                        await _verileriYukle();
                      },
                    ),
                  ),
                );
              },
            ),
          ],
        ],
      ),
    );
  }

  Widget _kiloGrafigi() {
    // Son 10 kaydı al, eskiden yeniye çevir
    final kayitlar = _kiloKayitlari.take(10).toList().reversed.toList();
    final kilolar = kayitlar.map((k) => (k['kilo'] as num).toDouble()).toList();
    final minKilo = kilolar.reduce((a, b) => a < b ? a : b) - 1;
    final maxKilo = kilolar.reduce((a, b) => a > b ? a : b) + 1;
    final aralik = (maxKilo - minKilo).clamp(1.0, double.infinity);

    return Container(
      height: 130,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
        border: Border.all(color: Colors.grey.shade200),
      ),
      padding: const EdgeInsets.all(12),
      child: CustomPaint(
        painter: _KiloGrafikCizici(
          kilolar: kilolar,
          minKilo: minKilo,
          maxKilo: maxKilo,
          aralik: aralik,
        ),
      ),
    );
  }

  void _kiloEkle() {
    final controller = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Kilo Ekle'),
        content: TextField(
          controller: controller,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(
            labelText: 'Kilonuz',
            hintText: 'Örn: 75.5',
            suffixText: 'kg',
          ),
          autofocus: true,
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('İptal')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppRenkleri.aktif, foregroundColor: Colors.white),
            onPressed: () async {
              final kilo = double.tryParse(controller.text.trim().replaceAll(',', '.'));
              if (kilo != null && kilo > 0) {
                Navigator.pop(context);
                await VeritabaniYardimcisi().kiloEkle(kilo);
                await _verileriYukle();
              }
            },
            child: const Text('Kaydet'),
          ),
        ],
      ),
    );
  }
}

class _KiloGrafikCizici extends CustomPainter {
  final List<double> kilolar;
  final double minKilo;
  final double maxKilo;
  final double aralik;

  _KiloGrafikCizici({
    required this.kilolar,
    required this.minKilo,
    required this.maxKilo,
    required this.aralik,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (kilolar.length < 2) return;

    final boya = Paint()
      ..color = AppRenkleri.aktif
      ..strokeWidth = 2.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final noktaBoya = Paint()..color = AppRenkleri.aktif..style = PaintingStyle.fill;
    final dolguBoya = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [AppRenkleri.aktif.withOpacity(0.3), AppRenkleri.aktif.withOpacity(0.02)],
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height))
      ..style = PaintingStyle.fill;

    final adim = size.width / (kilolar.length - 1);

    // Noktaları hesapla
    final noktalar = kilolar.asMap().entries.map((e) {
      final x = e.key * adim;
      final y = size.height - ((e.value - minKilo) / aralik) * size.height;
      return Offset(x, y.clamp(4.0, size.height - 4.0));
    }).toList();

    // Dolgu
    final dolguYol = Path()..moveTo(noktalar.first.dx, size.height);
    for (final n in noktalar) dolguYol.lineTo(n.dx, n.dy);
    dolguYol.lineTo(noktalar.last.dx, size.height);
    dolguYol.close();
    canvas.drawPath(dolguYol, dolguBoya);

    // Çizgi
    final yol = Path()..moveTo(noktalar.first.dx, noktalar.first.dy);
    for (int i = 1; i < noktalar.length; i++) yol.lineTo(noktalar[i].dx, noktalar[i].dy);
    canvas.drawPath(yol, boya);

    // Noktalar
    for (final n in noktalar) canvas.drawCircle(n, 4, noktaBoya);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
