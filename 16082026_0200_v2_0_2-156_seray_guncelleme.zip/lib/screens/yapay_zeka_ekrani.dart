import 'dart:io';
import 'dart:convert';
import '../theme/renkler.dart';
import '../theme/sablon.dart';
import 'package:flutter/material.dart';
import '../services/profil_yoneticisi.dart';
import 'package:file_picker/file_picker.dart';
import 'package:read_pdf_text/read_pdf_text.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/api_service.dart';
import '../services/veritabani_yardimcisi.dart';
import '../services/pdf_rapor_servisi.dart';
import '../services/ses_servisi.dart';
import '../widgets/ust_menu.dart';

// --- Tahlil bilgi kütüphanesi ---
const Map<String, Map<String, String>> _tahlilBilgileri = {
  'glukoz': {
    'ne': 'Kan Şekeri (Glukoz)',
    'nedenir': 'Kandaki şeker miktarını ölçer.',
    'neden': 'Diyabet ve insülin direncini değerlendirmek için kullanılır.',
    'dikkat': 'Açlık şekeri 100 mg/dL altında normal kabul edilir.',
  },
  'hba1c': {
    'ne': 'Glikozillenmiş Hemoglobin',
    'nedenir': 'Son 3 aylık ortalama kan şekerini gösterir.',
    'neden': 'Diyabet kontrolünü uzun dönemde değerlendirmek için kullanılır.',
    'dikkat': '%6.5 üzeri diyabet lehine değerlendirilir.',
  },
  'alt': {
    'ne': 'Alanin Aminotransferaz (ALT)',
    'nedenir': 'Karaciğer hücrelerinde bulunan bir enzimdir.',
    'neden': 'Karaciğer hasarını değerlendirmek için kullanılır.',
    'dikkat': 'Yüksekliği karaciğer hastalığına işaret edebilir.',
  },
  'ast': {
    'ne': 'Aspartat Aminotransferaz (AST)',
    'nedenir': 'Karaciğer, kalp ve kas hücrelerinde bulunan enzim.',
    'neden': 'Karaciğer ve kalp sağlığını değerlendirmek için.',
    'dikkat': 'ALT ile birlikte değerlendirilir.',
  },
  'kreatinin': {
    'ne': 'Kreatinin',
    'nedenir': 'Kasların enerji kullanımı sonucu oluşan atık madde.',
    'neden': 'Böbrek fonksiyonunu değerlendirmek için.',
    'dikkat': 'Yüksekliği böbrek yetmezliğine işaret edebilir.',
  },
  'kolesterol': {
    'ne': 'Total Kolesterol',
    'nedenir': 'Kandaki toplam kolesterol miktarı.',
    'neden': 'Kalp damar hastalığı riskini belirlemek için.',
    'dikkat': '200 mg/dL altı normal, 240 üzeri yüksek risk sayılır.',
  },
  'trigliserid': {
    'ne': 'Trigliserid',
    'nedenir': 'Kanda bulunan yağ türü.',
    'neden': 'Kalp damar hastalığı ve metabolik sendrom riski için.',
    'dikkat': '150 mg/dL altı normal kabul edilir.',
  },
  'hdl': {
    'ne': 'HDL (İyi Kolesterol)',
    'nedenir': 'Damarlardan kolesterolü temizleyen faydalı yağ.',
    'neden': 'Kalp koruyucu etkisi nedeniyle yüksek olması iyidir.',
    'dikkat': 'Erkeklerde 40, kadınlarda 50 mg/dL üzeri olması istenir.',
  },
  'ldl': {
    'ne': 'LDL (Kötü Kolesterol)',
    'nedenir': 'Damarlarda birikim yapabilen zararlı kolesterol.',
    'neden': 'Damar tıkanıklığı riskini belirlemek için.',
    'dikkat': '100 mg/dL altında tutulması hedeflenir.',
  },
  'tsh': {
    'ne': 'Tiroid Uyarıcı Hormon (TSH)',
    'nedenir': 'Tiroid bezinin çalışmasını düzenleyen hormon.',
    'neden': 'Tiroid hastalıklarını tanımak için.',
    'dikkat': 'Düşükse aşırı aktif, yüksekse az aktif tiroid düşünülür.',
  },
  'b12': {
    'ne': 'Vitamin B12',
    'nedenir': 'Sinir sistemi ve kan hücreleri için gerekli vitamin.',
    'neden': 'Anemi ve sinir hasarı riskini değerlendirmek için.',
    'dikkat': '200 pg/mL altı eksiklik sayılır.',
  },
  'd vitamini': {
    'ne': 'D Vitamini',
    'nedenir': 'Kemik sağlığı ve bağışıklık sistemi için hayati vitamin.',
    'neden': 'Kemik erimesi ve bağışıklık zayıflığı riskini belirlemek.',
    'dikkat': '30 ng/mL altı eksiklik, 20 altı ciddi eksiklik kabul edilir.',
  },
  'demir': {
    'ne': 'Serum Demiri',
    'nedenir': 'Kanda taşınan demir miktarı.',
    'neden': 'Demir eksikliği anemisini değerlendirmek için.',
    'dikkat': 'Düşükse anemi, yüksekse demir birikimi düşünülür.',
  },
  'ferritin': {
    'ne': 'Ferritin',
    'nedenir': 'Vücudun demir deposunu gösteren protein.',
    'neden': 'Demir depolarını değerlendirmek için.',
    'dikkat': 'Kanda demir düşmeden önce ferritin düşer.',
  },
  'hemoglobin': {
    'ne': 'Hemoglobin (Hgb)',
    'nedenir': 'Kırmızı kan hücrelerindeki oksijen taşıyıcı protein.',
    'neden': 'Anemi tanısı için temel göstergedir.',
    'dikkat': 'Kadınlarda 12, erkeklerde 13 g/dL altı anemi sayılır.',
  },
  'ürik': {
    'ne': 'Ürik Asit',
    'nedenir': 'Protein metabolizması sonucu oluşan atık madde.',
    'neden': 'Gut hastalığı ve böbrek taşı riskini değerlendirmek için.',
    'dikkat': 'Erkeklerde 7, kadınlarda 6 mg/dL üzeri yüksek kabul edilir.',
  },
};

// Sadece sabit sözlükte arar; bulamazsa null döner (genel yedek metni
// artık burada üretilmiyor — onu çağıran taraf, AI'dan gerçek bir açıklama
// getirmeyi deneyecek).
Map<String, String>? _tahlilBilgisiGetir(String tahlilAdi) {
  final anahtar = tahlilAdi.toLowerCase();
  for (final entry in _tahlilBilgileri.entries) {
    if (anahtar.contains(entry.key)) return entry.value;
  }
  return null;
}bool _refDisinda(String deger, String ref) {
  if (ref.isEmpty || ref == '-') return false;
  // ÖNEMLİ DÜZELTME: önceden tüm rakam/nokta DIŞINDAKİ karakterler (harf,
  // boşluk, işaret) siliniyordu — bu, "217 x10^9/L" gibi birim içeren
  // değerlerde birimin İÇİNDEKİ rakamları (x10^9'daki 1, 0, 9) da sayının
  // sonuna ekleyip "217" değerini "217109" gibi devasa bir sayıya
  // çeviriyordu, bu da PLT/RBC/WBC gibi normal sonuçları yanlışlıkla
  // "Ref Dışı" gösteriyordu. Artık SADECE metnin en BAŞINDAKİ sayıyı
  // (ilk boşluk/harfe kadar) okuyoruz — birim ne olursa olsun etkilenmez.
  final ilkSayiEslesme = RegExp(r'^-?[0-9]+([.,][0-9]+)?').firstMatch(deger.trim());
  if (ilkSayiEslesme == null) return false;
  final sayi = double.tryParse(ilkSayiEslesme.group(0)!.replaceAll(',', '.'));
  if (sayi == null) return false;
  final parcalar = ref.split(RegExp(r'[-–]'));
  if (parcalar.length < 2) return false;
  final min = double.tryParse(
      parcalar[0].trim().replaceAll(',', '.').replaceAll(RegExp(r'[^0-9.]'), ''));
  final maks = double.tryParse(
      parcalar[1].trim().replaceAll(',', '.').replaceAll(RegExp(r'[^0-9.]'), ''));
  if (min == null || maks == null) return false;
  return sayi < min || sayi > maks;
}

// Değer referans dışındaysa, YÖNÜNÜ (yüksek mi düşük mü) döner — hiçbiri
// değilse ya da hesaplanamıyorsa null. Kullanıcı isteğiyle eklendi: tahlil
// detayında sadece "referans dışı" demek yerine, artık YÜKSEK ya da DÜŞÜK
// olmasının olası nedenlerini ayrı ayrı gösterebiliyoruz.
String? _refDisiYonu(String deger, String ref) {
  if (ref.isEmpty || ref == '-') return null;
  final ilkSayiEslesme = RegExp(r'^-?[0-9]+([.,][0-9]+)?').firstMatch(deger.trim());
  if (ilkSayiEslesme == null) return null;
  final sayi = double.tryParse(ilkSayiEslesme.group(0)!.replaceAll(',', '.'));
  if (sayi == null) return null;
  final parcalar = ref.split(RegExp(r'[-–]'));
  if (parcalar.length < 2) return null;
  final min = double.tryParse(
      parcalar[0].trim().replaceAll(',', '.').replaceAll(RegExp(r'[^0-9.]'), ''));
  final maks = double.tryParse(
      parcalar[1].trim().replaceAll(',', '.').replaceAll(RegExp(r'[^0-9.]'), ''));
  if (min == null || maks == null) return null;
  if (sayi > maks) return 'yuksek';
  if (sayi < min) return 'dusuk';
  return null;
}  // --- _refDisiYonu() sonu ---

String _dogalKonusmaMetni(String metin) {
  String t = metin;
  t = t.replaceAll(RegExp(r'\([^)]*\)'), '');
  t = t.replaceAll(RegExp(r'#{1,6}\s'), '');
  t = t.replaceAll(RegExp(r'\*{1,2}([^*\n]+)\*{1,2}'), r'$1');
  t = t.replaceAll(RegExp(r'_{1,2}([^_\n]+)_{1,2}'), r'$1');
  t = t.replaceAll(RegExp(r'^\s*[-•*]\s*', multiLine: true), '');
  t = t.replaceAll(RegExp(r'https?://\S+'), '');
  t = t.replaceAll('\n\n', '. ').replaceAll('\n', ' ');
  t = t.replaceAll(RegExp(r'\s{2,}'), ' ');
  t = t.replaceAll('...', '.').replaceAll('..', '.');
  return t.trim();
}

class YapayZekaEkrani extends StatefulWidget {
  const YapayZekaEkrani({Key? key}) : super(key: key);
  @override
  State<YapayZekaEkrani> createState() => _YapayZekaEkraniState();
}

class _YapayZekaEkraniState extends State<YapayZekaEkrani> {
  // Tablo verisi: tahlil_adi → {tarih: deger, ..., '_ref': referans, '_kategori': kategori}
  Map<String, Map<String, String>> _tabloVerisi = {};
  List<String> _tarihSutunlari = []; // Yeniden eskiye, GERÇEK tarihe göre sıralı
  // Kategoriye göre gruplu görünüm için: kategori → o kategorideki tahlil adları
  List<MapEntry<String, List<String>>> _kategoriGruplari = [];

  // Tahlil detayı artık ayrı bir Dialog penceresinde açılıyor (bkz.
  // _tahlilDetayGoster) — bu yüzden hangi satırın "açık" olduğunu tutan
  // eski state alanına artık gerek yok.
  // Tabloyu "Tümü / Ref Dışı / Normal" olarak filtrelemek için.
  String _gorunumFiltresi = 'tumu'; // tumu | refDisi | normal
  // Sabit sözlükte olmayan tahliller için AI'dan üretilip kalıcı olarak
  // (SharedPreferences'a) kaydedilen açıklamalar — bir daha sorulmaz.
  final Map<String, Map<String, String>> _aiTahlilAciklamalari = {};
  final Set<String> _aciklamaYukleniyor = {};
  // Yüksek/düşük nedenleri için ayrı önbellek — anahtar "tahlilAdi|yon".
  final Map<String, String> _yonNedenleri = {};
  final Set<String> _yonNedeniYukleniyor = {};

  // Önce sabit sözlüğe bakar; orada yoksa AI'dan üretilmiş (ve önbelleğe
  // alınmış) açıklamayı döner. O da yoksa AI'yı arka planda tetikleyip
  // "hazırlanıyor" mesajı gösterir; sonuç gelince ekran kendiliğinden güncellenir.
  Map<String, String> _tahlilBilgisiGetirCanli(String tahlilAdi) {
    final sabit = _tahlilBilgisiGetir(tahlilAdi);
    if (sabit != null) return sabit;

    final onbellek = _aiTahlilAciklamalari[tahlilAdi];
    if (onbellek != null) return onbellek;

    if (!_aciklamaYukleniyor.contains(tahlilAdi)) {
      _aciklamaYukleniyor.add(tahlilAdi);
      _tahlilAciklamasiYukle(tahlilAdi);
    }
    return {
      'ne': tahlilAdi,
      'nedenir': 'Açıklama hazırlanıyor...',
      'neden': '',
      'dikkat': '',
    };
  }

  Future<void> _tahlilAciklamasiYukle(String tahlilAdi) async {
    final prefs = await SharedPreferences.getInstance();
    final anahtar = 'tahlil_aciklama_${tahlilAdi.toLowerCase()}';
    final kayitliJson = prefs.getString(anahtar);
    if (kayitliJson != null) {
      try {
        final bilgi = Map<String, String>.from(jsonDecode(kayitliJson));
        if (mounted) {
          setState(() {
            _aiTahlilAciklamalari[tahlilAdi] = bilgi;
            _aciklamaYukleniyor.remove(tahlilAdi);
          });
        }
        return;
      } catch (_) {
        // Bozuk kayıt varsa yeniden üretilecek, aşağı devam.
      }
    }
    try {
      final bilgi = await ApiService.tahlilAciklamasiUret(tahlilAdi);
      await prefs.setString(anahtar, jsonEncode(bilgi));
      if (mounted) {
        setState(() {
          _aiTahlilAciklamalari[tahlilAdi] = bilgi;
          _aciklamaYukleniyor.remove(tahlilAdi);
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _aiTahlilAciklamalari[tahlilAdi] = {
            'ne': tahlilAdi,
            'nedenir': 'Açıklama şu an alınamadı, tekrar dokunup deneyin.',
            'neden': '',
            'dikkat': '',
          };
          _aciklamaYukleniyor.remove(tahlilAdi);
        });
      }
    }
  }  // --- _tahlilAciklamasiYukle() sonu ---

  // Yüksek/düşük nedenini önce SharedPreferences önbelleğinden, yoksa
  // AI'dan getirir. Sonuç geldiğinde ekran kendiliğinden güncellenir.
  String _yonNedeniGetirCanli(String tahlilAdi, String yon) {
    final anahtar = '$tahlilAdi|$yon';
    final onbellek = _yonNedenleri[anahtar];
    if (onbellek != null) return onbellek;

    if (!_yonNedeniYukleniyor.contains(anahtar)) {
      _yonNedeniYukleniyor.add(anahtar);
      _yonNedeniYukle(tahlilAdi, yon, anahtar);
    }
    return 'Olası nedenler hazırlanıyor...';
  }  // --- _yonNedeniGetirCanli() sonu ---

  Future<void> _yonNedeniYukle(String tahlilAdi, String yon, String anahtar) async {
    final prefs = await SharedPreferences.getInstance();
    final prefsAnahtari = 'tahlil_yon_nedeni_${anahtar.toLowerCase()}';
    final kayitli = prefs.getString(prefsAnahtari);
    if (kayitli != null) {
      if (mounted) {
        setState(() {
          _yonNedenleri[anahtar] = kayitli;
          _yonNedeniYukleniyor.remove(anahtar);
        });
      }
      return;
    }
    try {
      final nedenler = await ApiService.tahlilYonNedeniUret(tahlilAdi, yon);
      await prefs.setString(prefsAnahtari, nedenler);
      if (mounted) {
        setState(() {
          _yonNedenleri[anahtar] = nedenler;
          _yonNedeniYukleniyor.remove(anahtar);
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _yonNedenleri[anahtar] = 'Şu an alınamadı, tekrar dokunup deneyin.';
          _yonNedeniYukleniyor.remove(anahtar);
        });
      }
    }
  }  // --- _yonNedeniYukle() sonu ---

  // ÖNEMLİ: Tahlil detayı artık satırın İÇİNDE (yatay kaydırılabilir tablo
  // alanında sıkışıp sağa doğru taşan) bir panel değil, AYRI BİR PENCERE
  // (Dialog) olarak açılıyor — kullanıcı bunu istedi. Dialog, sayfanın geri
  // kalanından bağımsız bir "route" olduğu için üstteki setState() tabanlı
  // önbellek mantığı onu otomatik güncellemiyor; bu yüzden burada AYNI
  // SharedPreferences önbellek anahtarlarını kullanan, ama FutureBuilder
  // ile uyumlu, sonucu DÖNEN (side-effect'siz) iki küçük yardımcı var.
  Future<Map<String, String>> _tahlilBilgisiFuture(String tahlilAdi) async {
    final sabit = _tahlilBilgisiGetir(tahlilAdi);
    if (sabit != null) return sabit;
    final prefs = await SharedPreferences.getInstance();
    final anahtar = 'tahlil_aciklama_${tahlilAdi.toLowerCase()}';
    final kayitliJson = prefs.getString(anahtar);
    if (kayitliJson != null) {
      try {
        return Map<String, String>.from(jsonDecode(kayitliJson));
      } catch (_) {
        // Bozuk kayıt varsa yeniden üretilecek, aşağı devam.
      }
    }
    try {
      final bilgi = await ApiService.tahlilAciklamasiUret(tahlilAdi);
      await prefs.setString(anahtar, jsonEncode(bilgi));
      return bilgi;
    } catch (e) {
      return {'ne': tahlilAdi, 'nedenir': 'Açıklama şu an alınamadı, tekrar deneyin.', 'neden': '', 'dikkat': ''};
    }
  }  // --- _tahlilBilgisiFuture() sonu ---

  Future<String> _yonNedeniFuture(String tahlilAdi, String yon) async {
    final anahtar = '$tahlilAdi|$yon';
    final prefs = await SharedPreferences.getInstance();
    final prefsAnahtari = 'tahlil_yon_nedeni_${anahtar.toLowerCase()}';
    final kayitli = prefs.getString(prefsAnahtari);
    if (kayitli != null) return kayitli;
    try {
      final nedenler = await ApiService.tahlilYonNedeniUret(tahlilAdi, yon);
      await prefs.setString(prefsAnahtari, nedenler);
      return nedenler;
    } catch (e) {
      return 'Şu an alınamadı, tekrar deneyin.';
    }
  }  // --- _yonNedeniFuture() sonu ---

  // Tahlil detayını AYRI BİR PENCERE (Dialog) olarak açar — üst bantta
  // başlık + hoparlör (sesli dinle) + yazdır/paylaş + X (kapat) var,
  // içerik telefon genişliğine SIĞACAK şekilde dikey kaydırılıyor.
  void _tahlilDetayGoster({required String tahlilAdi, required String ref, required String? yon}) {
    showDialog(
      context: context,
      builder: (dialogContext) => Dialog(
        insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 40),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: ConstrainedBox(
          constraints: BoxConstraints(maxHeight: MediaQuery.of(dialogContext).size.height * 0.75),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // ÜST BANT: başlık + hoparlör + yazdır/paylaş + kapat
              Container(
                decoration: BoxDecoration(
                  color: AppRenkleri.aktif,
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
                ),
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
                child: Row(
                  children: [
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        tahlilAdi,
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.volume_up, color: Colors.white),
                      tooltip: 'Sesli Dinle',
                      onPressed: () async {
                        final b = await _tahlilBilgisiFuture(tahlilAdi);
                        final okunacak = [
                          b['ne'] ?? tahlilAdi,
                          if ((b['nedenir'] ?? '').isNotEmpty) 'Ne işe yarar: ${b['nedenir']}',
                          if ((b['neden'] ?? '').isNotEmpty) 'Neden bakılır: ${b['neden']}',
                          if ((b['dikkat'] ?? '').isNotEmpty) 'Dikkat: ${b['dikkat']}',
                          // ÖNEMLİ DÜZELTME: Kullanıcı fark etti — sesli
                          // okuma "Dikkat"te duruyordu, sonradan eklenen
                          // Referans Aralığı ve yüksek/düşük nedeni hiç
                          // okunmuyordu. İkisi de artık ekleniyor.
                          if (ref != '-' && ref.isNotEmpty) 'Referans aralığı: $ref',
                          if (yon != null) (yon == 'yuksek' ? 'Yüksek çıkmasının olası nedenleri: ' : 'Düşük çıkmasının olası nedenleri: ') + await _yonNedeniFuture(tahlilAdi, yon),
                        ].join('. ');
                        SesServisi.konus(okunacak);
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.share_outlined, color: Colors.white),
                      tooltip: 'Paylaş',
                      onPressed: () async {
                        final ad = await _kullaniciAdiniGetir();
                        final b = await _tahlilBilgisiFuture(tahlilAdi);
                        final parcalar = [
                          if ((b['nedenir'] ?? '').isNotEmpty) 'Ne İşe Yarar: ${b['nedenir']}',
                          if ((b['neden'] ?? '').isNotEmpty) 'Neden Bakılır: ${b['neden']}',
                          if ((b['dikkat'] ?? '').isNotEmpty) 'Dikkat: ${b['dikkat']}',
                          if (ref != '-' && ref.isNotEmpty) 'Referans Aralığı: $ref',
                        ];
                        if (yon != null) {
                          final yonMetni = await _yonNedeniFuture(tahlilAdi, yon);
                          parcalar.add((yon == 'yuksek' ? 'Yüksek Çıkmasının Olası Nedenleri: ' : 'Düşük Çıkmasının Olası Nedenleri: ') + yonMetni);
                        }
                        try {
                          await PdfRaporServisi.analizRaporuOlusturVePaylas(
                            kullaniciAdi: ad,
                            baslik: tahlilAdi,
                            analizMetni: parcalar.join('\n\n'),
                          );
                        } catch (_) {
                          // Sessizce geç — kullanıcı tekrar deneyebilir.
                        }
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.print_outlined, color: Colors.white),
                      tooltip: 'Yazdır',
                      onPressed: () async {
                        final ad = await _kullaniciAdiniGetir();
                        final b = await _tahlilBilgisiFuture(tahlilAdi);
                        final parcalar = [
                          if ((b['nedenir'] ?? '').isNotEmpty) 'Ne İşe Yarar: ${b['nedenir']}',
                          if ((b['neden'] ?? '').isNotEmpty) 'Neden Bakılır: ${b['neden']}',
                          if ((b['dikkat'] ?? '').isNotEmpty) 'Dikkat: ${b['dikkat']}',
                          if (ref != '-' && ref.isNotEmpty) 'Referans Aralığı: $ref',
                        ];
                        if (yon != null) {
                          final yonMetni = await _yonNedeniFuture(tahlilAdi, yon);
                          parcalar.add((yon == 'yuksek' ? 'Yüksek Çıkmasının Olası Nedenleri: ' : 'Düşük Çıkmasının Olası Nedenleri: ') + yonMetni);
                        }
                        try {
                          await PdfRaporServisi.analizRaporuYazdir(
                            kullaniciAdi: ad,
                            baslik: tahlilAdi,
                            analizMetni: parcalar.join('\n\n'),
                          );
                        } catch (_) {
                          // Sessizce geç — kullanıcı tekrar deneyebilir.
                        }
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.close, color: Colors.white),
                      tooltip: 'Kapat',
                      onPressed: () => Navigator.pop(dialogContext),
                    ),
                  ],
                ),
              ),
              // İÇERİK: telefon genişliğine sığan, dikey kaydırılan panel.
              Flexible(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(14),
                  child: FutureBuilder<Map<String, String>>(
                    future: _tahlilBilgisiFuture(tahlilAdi),
                    builder: (context, snapshot) {
                      final bilgi = snapshot.data ?? {'ne': tahlilAdi, 'nedenir': 'Yükleniyor...', 'neden': '', 'dikkat': ''};
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _bilgiSatiri('📌 Ne İşe Yarar', bilgi['nedenir'] ?? ''),
                          const SizedBox(height: 5),
                          _bilgiSatiri('🔬 Neden Bakılır', bilgi['neden'] ?? ''),
                          const SizedBox(height: 5),
                          _bilgiSatiri('⚠️ Dikkat', bilgi['dikkat'] ?? ''),
                          if (ref != '-' && ref.isNotEmpty) ...[
                            const SizedBox(height: 5),
                            _bilgiSatiri('📊 Referans Aralığı', ref),
                          ],
                          if (yon != null) ...[
                            const SizedBox(height: 5),
                            FutureBuilder<String>(
                              future: _yonNedeniFuture(tahlilAdi, yon),
                              builder: (context, yonSnapshot) {
                                return _bilgiSatiri(
                                  yon == 'yuksek' ? '📈 Yüksek Çıkmasının Olası Nedenleri' : '📉 Düşük Çıkmasının Olası Nedenleri',
                                  yonSnapshot.data ?? 'Olası nedenler hazırlanıyor...',
                                );
                              },
                            ),
                          ],
                        ],
                      );
                    },
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }  // --- _tahlilDetayGoster() sonu ---

  bool _karsilastirmaAcik = false;
  String _karsilastirmaMetni = '';
  bool _karsilastirmaYukleniyor = false;

  bool _aiYorumAcik = false;
  String _aiYorumu = '';
  bool _aiYorumYukleniyor = false;
  String _aiYorumBasligi = 'Genel Değerlendirme';

  bool _ttsCalisiyor = false;

  bool _pdfYukleniyor = false;
  String _durumMesaji = '';

  @override
  void initState() {
    super.initState();
    _veritabaniniyukle();
  }  // --- initState() sonu ---

  @override
  void dispose() {
    SesServisi.durdur();
    super.dispose();
  }  // --- dispose() sonu ---

  Future<void> _veritabaniniyukle() async {
    final tumTahliller = await VeritabaniYardimcisi().tumTahlilleriGetir();
    _tabloVerisiOlustur(tumTahliller);
  }  // --- _veritabaniniyukle() sonu ---

  // "GG.AA.YYYY" biçimindeki bir tarih metnini gerçek DateTime'a çevirir.
  // Önceden tarihler düz metin (string) olarak karşılaştırılıyordu — bu,
  // "02.08.2026" ile "15.04.2025" gibi tarihleri kronolojik değil alfabetik
  // sıralıyordu (0 < 1 olduğu için 02.08 hep önce geliyordu). Artık gerçek
  // tarihe göre sıralanıyor.
  DateTime? _tarihiAyristir(String tarih) {
    final parcalar = tarih.split('.');
    if (parcalar.length != 3) return null;
    final gun = int.tryParse(parcalar[0]);
    final ay = int.tryParse(parcalar[1]);
    final yil = int.tryParse(parcalar[2]);
    if (gun == null || ay == null || yil == null) return null;
    return DateTime(yil, ay, gun);
  }

  // ÖNEMLİ (kök sorun düzeltmesi): e-Nabız PDF'leri aynı testi farklı
  // isimlerle yazabiliyor ("TAM KAN SAYIMI - EO#" vs "EO#", "ASPARTAT
  // AMİNOTRANSFERAZ" vs "AST" gibi) — bu da aynı testin zaman içindeki
  // gidişatının tek satırda birleşmek yerine ayrı ayrı satırlara bölünmesine
  // (ve PDF'in onlarca sayfaya şişmesine) yol açıyordu. AI'ya artık
  // normalize etmesini söylüyoruz (bkz. api_service.dart), ama burada AYRICA
  // deterministik, kesin bilinen bir güvenlik ağı uyguluyoruz — böylece
  // ESKİDEN kaydedilmiş veriler de (yeniden PDF yüklemeden) düzelir, çünkü
  // bu fonksiyon tablo her oluşturulduğunda çalışır.
  String _tahlilAdiniNormallestir(String ham) {
    var ad = ham.trim();

    // 1) Kategori önekini kaldır — artık sadece 2 sabit kalıp değil, "TAM
    // ... -" ile başlayan HERHANGİ bir önek yakalanıyor (parantezli ek
    // açıklamalar dahil, örn. "TAM İDRAR ANALİZİ (STRİP+MİKROSKOPİ) (GAİTA) - X").
    final onekDeseni = RegExp(r'^TAM\s+[A-ZÇĞİÖŞÜa-zçğıöşü/()+.\s]*-\s*', caseSensitive: false);
    ad = ad.replaceFirst(onekDeseni, '').trim();

    // 2) Sonu ".." ile kesilmiş (PDF'ten kırpılmış) isimleri temizle,
    // örn. "Granüler Silendir (G.." → "Granüler Silendir".
    if (ad.endsWith('..')) {
      ad = ad.substring(0, ad.length - 2).trim();
      final acikParantez = ad.lastIndexOf('(');
      if (acikParantez != -1 && !ad.substring(acikParantez).contains(')')) {
        ad = ad.substring(0, acikParantez).trim();
      }
    }

    // 3) Kesin bilinen eş anlamlılar. Anahtar küçük harfli hâlin BAŞINDA
    // aranıyor (startsWith) — böylece "(SERUM/PLAZMA)", "(SERUM/PL..",
    // "(İDRAR)" gibi farklı ek varyasyonlarının hepsi tek isme toplanır.
    // Genişletildi: gerçek verideki onlarca tekrar eden çift eklendi
    // (Kolesterol, HDL/LDL, Trigliserid, Ürobilinojen, Renk, pH, Protein,
    // Keton, Bilirubin (idrar), Nitrit, Dansite, Epitel, Mum Silendir, Klor).
    // Genuinely FARKLI testler (örn. Sodyum/serum vs 24 saatlik idrar
    // Sodyumu, Lökosit/Eritrosit'in strip vs mikroskopi yöntemleri) BİLEREK
    // ayrı bırakıldı — yanlış birleştirme riski, tekrar riskinden daha kötü.
    final esAnlamlilar = <String, String>{
      'aspartat aminotransferaz': 'AST',
      'alanin aminotransferaz': 'ALT',
      'kreatinin': 'Kreatinin',
      'glukoz (akş': 'Glukoz (AKŞ)',
      'glukoz (serum': 'Glukoz (AKŞ)',
      'total kolesterol': 'Kolesterol',
      'kolesterol (serum': 'Kolesterol',
      'hdl kolesterol': 'HDL Kolesterol',
      'hdl': 'HDL Kolesterol',
      'ldl kolesterol': 'LDL Kolesterol',
      'ldl': 'LDL Kolesterol',
      'trigliserid': 'Trigliserid',
      'sodyum (serum': 'Sodyum',
      'sodyum (plazma': 'Sodyum',
      'potasyum (serum': 'Potasyum',
      'potasyum (plazma': 'Potasyum',
      'kalsiyum (serum': 'Kalsiyum',
      'kalsiyum (plazma': 'Kalsiyum',
      'ürobilinojen': 'Ürobilinojen (İdrar)',
      'urobilinojen': 'Ürobilinojen (İdrar)',
      'renk (idrar': 'Renk (İdrar)',
      'renk': 'Renk (İdrar)',
      'ph (idrar': 'pH (İdrar)',
      'protein (idrar': 'Protein (İdrar)',
      'keton (idrar': 'Keton (İdrar)',
      'keton': 'Keton (İdrar)',
      'görünüm': 'Görünüm (İdrar)',
      'gorunum': 'Görünüm (İdrar)',
      'bilirubin (idrar': 'Bilirubin (İdrar)',
      'direct bilirubin': 'Direkt Bilirubin',
      'direkt bilirubin': 'Direkt Bilirubin',
      'indirect bilirubin': 'İndirekt Bilirubin',
      'indirekt bilirubin': 'İndirekt Bilirubin',
      'total bilirubin': 'Total Bilirubin',
      'nitrit (idrar': 'Nitrit (İdrar)',
      'nitrit': 'Nitrit (İdrar)',
      'dansite': 'Dansite (İdrar)',
      'epitel(sec': 'Epitel (SEC)',
      'epitel (sec': 'Epitel (SEC)',
      'epitel (nec': 'Epitel (NEC)',
      'mum silendier': 'Mum Silendir (WAXY)',
      'mum silendir': 'Mum Silendir (WAXY)',
      'klorür': 'Klor',
      // İngilizce/Türkçe karışık gelen PDF'lerde aynı testin iki farklı
      // isimle (biri İngilizce, biri Türkçe) ayrı satır olarak görünmesini
      // önlemek için eklendi.
      'magnesium': 'Magnezyum',
      'potassium': 'Potasyum',
      'sodium': 'Sodyum',
      'calcium': 'Kalsiyum',
      'chloride': 'Klor',
      'chlorine': 'Klor',
      'glucose': 'Glukoz (AKŞ)',
      'cholesterol': 'Kolesterol',
      'creatinine': 'Kreatinin',
      'triglyceride': 'Trigliserid',
    };
    final kucukHali = ad.toLowerCase();
    for (final entry in esAnlamlilar.entries) {
      if (kucukHali == entry.key || kucukHali.startsWith(entry.key)) {
        return entry.value;
      }
    }

    return ad;
  }  // --- _tahlilAdiniNormallestir() sonu ---

  void _tabloVerisiOlustur(List<Map<String, dynamic>> tahliller) {
    final Map<String, Map<String, String>> yeniTablo = {};
    final Set<String> tarihler = {};
    // Kategori sırası sabit ve anlamlı olsun diye önceden tanımlı bir sıra kullanıyoruz.
    const kategoriSirasi = ['Kan Sayımı', 'Biyokimya', 'Lipid (Kolesterol)', 'Hormon', 'Karaciğer/Böbrek', 'İdrar Tahlili', 'Diğer'];
    final Map<String, List<String>> kategoriMap = {for (final k in kategoriSirasi) k: []};

    for (final t in tahliller) {
      final ad = _tahlilAdiniNormallestir(t['tahlil_adi'].toString());
      final tarih = t['tarih'].toString();
      final deger = t['sonuc'].toString();
      final ref = t['referans_degeri'].toString();
      final kategori = (t['kategori']?.toString().isNotEmpty ?? false) ? t['kategori'].toString() : 'Diğer';
      tarihler.add(tarih);
      final yeniMi = !yeniTablo.containsKey(ad);
      yeniTablo[ad] ??= {};
      yeniTablo[ad]![tarih] = deger;
      yeniTablo[ad]!['_ref'] = ref;
      yeniTablo[ad]!['_kategori'] = kategori;
      if (yeniMi) {
        (kategoriMap[kategori] ?? kategoriMap['Diğer']!).add(ad);
      }
    }

    // Gerçek tarihe göre (yeniden eskiye) sırala — metin sıralaması DEĞİL.
    final siraliTarihler = tarihler.toList()
      ..sort((a, b) {
        final ta = _tarihiAyristir(a);
        final tb = _tarihiAyristir(b);
        if (ta == null || tb == null) return b.compareTo(a); // ayrıştırılamazsa eski davranışa düş
        return tb.compareTo(ta);
      });

    // Her tahlil adını kendi kategori grubu içinde alfabetik sırala, boş kategorileri at.
    final kategoriGruplari = <MapEntry<String, List<String>>>[];
    for (final kategori in kategoriSirasi) {
      final adlar = kategoriMap[kategori] ?? [];
      if (adlar.isEmpty) continue;
      adlar.sort();
      kategoriGruplari.add(MapEntry(kategori, adlar));
    }

    setState(() {
      _tabloVerisi = yeniTablo;
      _tarihSutunlari = siraliTarihler;
      _kategoriGruplari = kategoriGruplari;
    });
  }  // --- _tabloVerisiOlustur() sonu ---

  Future<void> _pdfYukle() async {
    final sonuc = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf', 'txt'],
    );
    if (sonuc == null || sonuc.files.single.path == null) return;

    setState(() { _pdfYukleniyor = true; _durumMesaji = 'PDF okunuyor...'; });

    try {
      final dosya = File(sonuc.files.single.path!);
      String metin = '';

      if (sonuc.files.single.extension?.toLowerCase() == 'pdf') {
        metin = await ReadPdfText.getPDFtext(dosya.path);
      } else {
        metin = await dosya.readAsString();
      }

      if (metin.trim().isEmpty) {
        setState(() { _durumMesaji = 'PDF\'den metin çıkarılamadı.'; _pdfYukleniyor = false; });
        return;
      }

      setState(() => _durumMesaji = 'Yapay zeka tahlilleri analiz ediyor...');

      final aiSonuc = await ApiService.tahlilVerileriniJsonOlarakCikar(metin);
      final List<Map<String, String>> tahliller =
          (aiSonuc['tahliller'] as List).cast<Map<String, String>>();

      if (tahliller.isEmpty) {
        setState(() {
          _durumMesaji = 'Bu PDF içinde tanınabilir bir laboratuvar tahlili bulunamadı '
              '(PDF\'den ${metin.trim().length} karakter metin okunabildi). '
              'Farklı bir e-Nabız PDF\'i deneyin.';
          _pdfYukleniyor = false;
        });
        return;
      }

      // PDF içindeki GERÇEK tahlil tarihini kullan — önceden burada her
      // zaman "bugünün" (yükleme anının) tarihi kullanılıyordu, bu yüzden
      // farklı tarihli birden fazla PDF yüklendiğinde hepsi aynı "bugün"
      // sütununda üst üste biniyordu. AI tarihi bulamazsa (null/geçersiz),
      // son çare olarak yine bugüne düşüyoruz.
      final simdi = DateTime.now();
      final bugunTarihi =
          '${simdi.day.toString().padLeft(2, '0')}.${simdi.month.toString().padLeft(2, '0')}.${simdi.year}';
      final aiTarihi = aiSonuc['tarih']?.toString();
      final gecerliTarihMi = aiTarihi != null &&
          aiTarihi != 'null' &&
          RegExp(r'^\d{1,2}\.\d{1,2}\.\d{4}$').hasMatch(aiTarihi);
      final tarih = gecerliTarihMi ? aiTarihi! : bugunTarihi;

      for (final t in tahliller) {
        await VeritabaniYardimcisi().tahlilEkle({
          'tarih': tarih,
          'tahlil_adi': t['tahlil_adi'],
          'sonuc': t['sonuc'],
          'referans_degeri': t['referans_araligi'] ?? '-',
          'kategori': t['kategori'] ?? 'Diğer',
        });
      }

      setState(() {
        _durumMesaji = '✅ ${tahliller.length} tahlil başarıyla yüklendi! ($tarih)'
            '${gecerliTarihMi ? '' : ' — PDF\'te tarih bulunamadığı için bugünün tarihi kullanıldı.'}';
        _pdfYukleniyor = false;
        _karsilastirmaAcik = false;
        _karsilastirmaMetni = '';
        _aiYorumu = '';
        _aiYorumAcik = false;
      });
      await _veritabaniniyukle();
    } catch (e) {
      // ÖNEMLİ: "PlatformException... Something went wrong while parsing!"
      // hatası, PDF okuma kütüphanesinin ŞİFRE KORUMALI ya da bozuk PDF'leri
      // okuyamamasından kaynaklanıyor — e-Nabız'ın bazı PDF çıktıları
      // TC kimlik no/doğum tarihi ile şifrelenmiş oluyor. Ham teknik hata
      // yerine kullanıcıya olası sebebi ve çözümü anlatan bir mesaj gösteriyoruz.
      final hataMetni = e.toString();
      if (hataMetni.contains('parsing') || hataMetni.contains('PlatformException')) {
        setState(() {
          _durumMesaji = 'Bu PDF okunamadı — muhtemelen ŞİFRE KORUMALI ya da bozuk bir dosya.\n\n'
              'Çözüm: PDF\'i telefonunuzda/bilgisayarınızda bir PDF görüntüleyiciyle açıp, '
              'şifresini girip "Yazdır → PDF olarak kaydet" yaparak şifresiz yeni bir kopya '
              'oluşturun, sonra o kopyayı buradan yükleyin.';
          _pdfYukleniyor = false;
        });
      } else {
        setState(() { _durumMesaji = 'Hata: $e'; _pdfYukleniyor = false; });
      }
    }
  }  // --- _pdfYukle() sonu ---

  Future<void> _karsilastirmaYap() async {
    if (_tarihSutunlari.length < 2) return;
    setState(() { _karsilastirmaYukleniyor = true; _karsilastirmaAcik = true; });

    final yeniTarih = _tarihSutunlari[0];
    final eskiTarih = _tarihSutunlari[1];
    final Map<String, String> yeniDegerler = {};
    final Map<String, String> eskiDegerler = {};
    _tabloVerisi.forEach((ad, tarihDegerler) {
      if (tarihDegerler.containsKey(yeniTarih)) yeniDegerler[ad] = tarihDegerler[yeniTarih]!;
      if (tarihDegerler.containsKey(eskiTarih)) eskiDegerler[ad] = tarihDegerler[eskiTarih]!;
    });

    final analiz = await ApiService.karsilastirmaAnalizEt(
      yeniTarih: yeniTarih,
      yeniDegerler: yeniDegerler,
      eskiTarih: eskiTarih,
      eskiDegerler: eskiDegerler,
    );
    setState(() { _karsilastirmaMetni = analiz; _karsilastirmaYukleniyor = false; });
  }  // --- _karsilastirmaYap() sonu ---

  // ÖNEMLİ DÜZELTME: Önceden ham (global) kullanici_ad/kullanici_soyad
  // okunuyordu — "Annem" profilindeyken bile PDF çıktısında/sayfa
  // başlığında hâlâ ASIL kullanıcının adı görünüyordu. Artık AKTİF
  // PROFİLİN gerçek adı kullanılıyor (ProfilYoneticisi'nin sakladığı,
  // Profil Kaydı'nda girilen isimle senkron tutulan tek kaynak).
  Future<String> _kullaniciAdiniGetir() async {
    return (await ProfilYoneticisi().aktifProfil()).ad;
  }  // --- _kullaniciAdiniGetir() sonu ---

  Future<void> _genelAiYorumYap() async {
    if (_tabloVerisi.isEmpty) return;
    // ÖNEMLİ DÜZELTME: Önceden "Genel AI Analizi" ismine rağmen SADECE
    // referans dışı (anormal) sonuçları analiz ediyordu — isim yanıltıcıydı.
    // Artık gerçekten TÜM sonuçları AI'ye gönderiyor; referans dışı olanlar
    // metinde ayrıca işaretleniyor ki AI onlara odaklansın ama normal
    // sonuçları da göz ardı etmesin.
    setState(() { _aiYorumYukleniyor = true; _aiYorumAcik = true; _aiYorumBasligi = 'Genel AI Analizi (Tüm Sonuçlar)'; });

    final sb = StringBuffer();
    _tabloVerisi.forEach((ad, tarihDegerler) {
      final ref = tarihDegerler['_ref'] ?? '-';
      tarihDegerler.forEach((tarih, deger) {
        if (tarih == '_ref' || tarih == '_kategori') return;
        final refDisiMi = _refDisinda(deger, ref);
        sb.writeln('$ad ($tarih): $deger [Ref: $ref]${refDisiMi ? ' — REFERANS DIŞI' : ''}');
      });
    });

    if (sb.isEmpty) {
      setState(() {
        _aiYorumu = 'Henüz yüklenmiş bir tahlil sonucu bulunamadı.';
        _aiYorumYukleniyor = false;
      });
      return;
    }

    // Aynı sonuç kümesi için AI'ye tekrar tekrar sormamak adına önbelleğe
    // alıyoruz — veri değişmediyse kayıtlı analiz gösterilir.
    final imza = sb.toString().hashCode.toString();
    final prefs = await SharedPreferences.getInstance();
    final onbellekImza = prefs.getString('tahlil_yorum_imza_genel_v2');
    final onbellekYorum = prefs.getString('tahlil_yorum_metin_genel_v2');
    if (onbellekImza == imza && onbellekYorum != null) {
      setState(() { _aiYorumu = onbellekYorum; _aiYorumYukleniyor = false; });
      return;
    }

    final ad = await _kullaniciAdiniGetir();
    final yorum = await ApiService.tahlilMetniniAnalizEt(sb.toString(), kullaniciAdi: ad);
    await prefs.setString('tahlil_yorum_imza_genel_v2', imza);
    await prefs.setString('tahlil_yorum_metin_genel_v2', yorum);
    setState(() { _aiYorumu = yorum; _aiYorumYukleniyor = false; });
  }  // --- _genelAiYorumYap() sonu ---

  // Tarih sütunu başlığındaki ✨ ikonuna basınca o tarihe ait TÜM
  // sonuçları analiz eder — genel değerlendirmeden ayrı, daha odaklı bir
  // görünüm. ÖNEMLİ DÜZELTME: eskiden burada sadece Referans Dışı
  // değerler toplanıyordu (kullanıcı fark etti) — artık o tarihteki TÜM
  // sonuçlar gönderiliyor, AI hem normal hem anormal değerleri
  // değerlendirebiliyor.
  Future<void> _tarihIcinAnalizYap(String tarih) async {
    if (_tabloVerisi.isEmpty) return;
    setState(() { _aiYorumYukleniyor = true; _aiYorumAcik = true; _aiYorumBasligi = '${_tarihKisa(tarih)} Analizi'; });

    final sb = StringBuffer();
    _tabloVerisi.forEach((ad, tarihDegerler) {
      final deger = tarihDegerler[tarih];
      if (deger == null) return;
      final ref = tarihDegerler['_ref'] ?? '-';
      final disindaMi = _refDisinda(deger, ref);
      sb.writeln('$ad: $deger [Ref: $ref]${disindaMi ? ' — REFERANS DIŞI' : ''}');
    });

    if (sb.isEmpty) {
      setState(() {
        _aiYorumu = 'Bu tarihe ait sonuç bulunamadı.';
        _aiYorumYukleniyor = false;
      });
      return;
    }

    final imza = sb.toString().hashCode.toString();
    final prefs = await SharedPreferences.getInstance();
    final onbellekAnahtari = 'tahlil_yorum_tum_$tarih';
    final onbellekImza = prefs.getString('${onbellekAnahtari}_imza');
    final onbellekYorum = prefs.getString(onbellekAnahtari);
    if (onbellekImza == imza && onbellekYorum != null) {
      setState(() { _aiYorumu = onbellekYorum; _aiYorumYukleniyor = false; });
      return;
    }

    final ad = await _kullaniciAdiniGetir();
    final yorum = await ApiService.tahlilMetniniAnalizEt(sb.toString(), kullaniciAdi: ad);
    await prefs.setString('${onbellekAnahtari}_imza', imza);
    await prefs.setString(onbellekAnahtari, yorum);
    setState(() { _aiYorumu = yorum; _aiYorumYukleniyor = false; });
  }  // --- _tarihIcinAnalizYap() sonu ---

  Future<void> _ttsBaslat(String metin) async {
    if (_ttsCalisiyor) {
      await SesServisi.durdur();
      setState(() => _ttsCalisiyor = false);
      return;
    }
    setState(() => _ttsCalisiyor = true);
    await SesServisi.konus(_dogalKonusmaMetni(metin), onTamamlandi: () {
      if (mounted) setState(() => _ttsCalisiyor = false);
    });
  }  // --- _ttsBaslat() sonu ---

  // Ekranda kısa gösterim için GG.AA.YY (2 haneli yıl) — önceden tarih
  // zaten "GG.AA.YYYY" formatındaysa hiç dokunmadan 4 haneli olarak
  // gösteriliyordu, şimdi her zaman kısaltılıyor.
  String _tarihKisa(String tarih) {
    DateTime? t;
    if (tarih.contains('.')) {
      final parcalar = tarih.split('.');
      if (parcalar.length == 3) {
        final gun = int.tryParse(parcalar[0]);
        final ay = int.tryParse(parcalar[1]);
        final yil = int.tryParse(parcalar[2]);
        if (gun != null && ay != null && yil != null) t = DateTime(yil, ay, gun);
      }
    } else {
      t = DateTime.tryParse(tarih);
    }
    if (t == null) return tarih;
    final yilKisa = (t.year % 100).toString().padLeft(2, '0');
    return '${t.day.toString().padLeft(2, '0')}.${t.month.toString().padLeft(2, '0')}.$yilKisa';
  }  // --- _tarihKisa() sonu ---

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(
        title: FittedBox(
          fit: BoxFit.scaleDown,
          alignment: Alignment.centerLeft,
          child: const Text('e-Nabız Tahlil Analizi', maxLines: 1),
        ),
        backgroundColor: AppRenkleri.aktif,
        foregroundColor: Colors.white,
        actions: const [UstMenu()],
      ),
      body: Column(
        children: [
          _pdfYuklemeAlani(),
          if (_durumMesaji.isNotEmpty)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              color: (_durumMesaji.contains('Hata') || _durumMesaji.contains('bulunamadı'))
                  ? Colors.red.shade50 : AppRenkleri.aktif.shade50,
              child: Text(_durumMesaji,
                  style: TextStyle(
                    fontSize: 13,
                    color: (_durumMesaji.contains('Hata') || _durumMesaji.contains('bulunamadı'))
                        ? Colors.red.shade700 : AppRenkleri.aktif.shade700,
                  )),
            ),
          if (_tabloVerisi.isNotEmpty) _aksiyonButonlari(),
          if (_karsilastirmaAcik) _karsilastirmaPaneli(),
          if (_aiYorumAcik) _aiYorumPaneli(),
          Expanded(
            child: _tabloVerisi.isEmpty ? _bostaDurumu() : _tahlilTablosu(),
          ),
        ],
      ),
    );
  }  // --- build() sonu ---

  Widget _pdfYuklemeAlani() {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.all(12),
      child: Row(
        children: [
          Expanded(
            child: ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: AppRenkleri.aktif,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              onPressed: _pdfYukleniyor ? null : _pdfYukle,
              icon: _pdfYukleniyor
                  ? const SizedBox(width: 18, height: 18,
                      child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                  : const Icon(Icons.upload_file),
              label: Text(_pdfYukleniyor ? 'Yükleniyor...' : 'e-Nabız PDF Yükle'),
            ),
          ),
          if (_tabloVerisi.isNotEmpty) ...[
            const SizedBox(width: 8),
            IconButton(
              tooltip: 'PDF Raporu Paylaş',
              icon: Icon(Icons.picture_as_pdf, color: AppRenkleri.aktif),
              onPressed: () async {
                final ad = await _kullaniciAdiniGetir();

                // Mevcut tarihlerden yılları çıkarıp kullanıcıya seçim sunuyoruz.
                final yillar = _tarihSutunlari
                    .map((t) => int.tryParse(t.split('.').last))
                    .whereType<int>()
                    .toSet()
                    .toList()
                  ..sort((a, b) => b.compareTo(a));

                int? secilenYil;
                if (yillar.length > 1 && mounted) {
                  secilenYil = await showDialog<int?>(
                    context: context,
                    builder: (context) => SimpleDialog(
                      title: const Text('Hangi yılı PDF olarak dışa aktaralım?'),
                      children: [
                        SimpleDialogOption(
                          onPressed: () => Navigator.pop(context, null),
                          child: const Text('Tüm Yıllar'),
                        ),
                        ...yillar.map((yil) => SimpleDialogOption(
                              onPressed: () => Navigator.pop(context, yil),
                              child: Text('$yil'),
                            )),
                      ],
                    ),
                  );
                }

                await PdfRaporServisi.enabizRaporuOlusturVePaylas(
                  tabloVerisi: _tabloVerisi,
                  tarihSutunlari: _tarihSutunlari,
                  kullaniciAdi: ad,
                  secilenYil: secilenYil,
                );
              },
            ),
          ],
        ],
      ),
    );
  }  // --- _pdfYuklemeAlani() sonu ---

  // Ref Dışı / Normal filtre butonları için ortak görünüm — seçiliyken
  // dolu (teal), değilken çerçeveli (aynı teal ton) — Karşılaştır ve Genel
  // AI Analizi butonlarıyla aynı aileden, tek bir tutarlı görünüm.
  Widget _filtreButonu({required String etiket, required bool secili, required VoidCallback onTap}) {
    if (secili) {
      return ElevatedButton.icon(
        onPressed: onTap,
        icon: const Icon(Icons.check, size: 16, color: Colors.white),
        label: Text(etiket),
        style: ElevatedButton.styleFrom(backgroundColor: AppRenkleri.aktif, foregroundColor: Colors.white),
      );
    }
    return OutlinedButton(
      onPressed: onTap,
      style: OutlinedButton.styleFrom(foregroundColor: AppRenkleri.aktif, side: BorderSide(color: AppRenkleri.aktif.shade300)),
      child: Text(etiket),
    );
  }  // --- _filtreButonu() sonu ---

  Widget _aksiyonButonlari() {
    // ÖNEMLİ DÜZELTME: Önceden 4 buton (Karşılaştır/Genel AI Analizi/Ref
    // Dışı/Normal) hepsi farklı widget türü + farklı renkteydi (teal
    // outline, turuncu outline, kırmızı chip, yeşil chip) — "her biri
    // başka biri tasarlamış gibi" görünüyordu. Artık HEPSİ aynı
    // OutlinedButton ailesinden, aynı teal marka rengiyle; sadece
    // seçili filtre (Ref Dışı/Normal) dolu (filled) hale geçerek
    // "aktif" olduğunu gösteriyor — renk paleti tek.
    final butonKenarligi = BorderSide(color: AppRenkleri.aktif.shade300);
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.fromLTRB(12, 0, 12, 10),
      child: Wrap(
        spacing: 8,
        children: [
          if (_tarihSutunlari.length >= 2)
            OutlinedButton.icon(
              onPressed: _karsilastirmaYukleniyor ? null : _karsilastirmaYap,
              icon: const Icon(Icons.compare_arrows, size: 18),
              label: const Text('Karşılaştır'),
              style: OutlinedButton.styleFrom(foregroundColor: AppRenkleri.aktif, side: butonKenarligi),
            ),
          OutlinedButton.icon(
            onPressed: _aiYorumYukleniyor ? null : _genelAiYorumYap,
            icon: const Icon(Icons.auto_awesome, size: 18),
            label: const Text('Genel AI Analizi'),
            style: OutlinedButton.styleFrom(foregroundColor: AppRenkleri.aktif, side: butonKenarligi),
          ),
          // "Tümü / Ref Dışı / Normal" görünüm filtresi — tabloyu sadece
          // anormal ya da sadece normal sonuçları gösterecek şekilde daraltır.
          _filtreButonu(
            etiket: 'Ref Dışı',
            secili: _gorunumFiltresi == 'refDisi',
            onTap: () => setState(() => _gorunumFiltresi = _gorunumFiltresi == 'refDisi' ? 'tumu' : 'refDisi'),
          ),
          _filtreButonu(
            etiket: 'Normal',
            secili: _gorunumFiltresi == 'normal',
            onTap: () => setState(() => _gorunumFiltresi = _gorunumFiltresi == 'normal' ? 'tumu' : 'normal'),
          ),
          // Ref Dışı / Normal filtresi aktifken, SADECE o filtreye giren
          // satırları PDF olarak çıktı almak için yazıcı ikonu.
          if (_gorunumFiltresi != 'tumu')
            IconButton(
              tooltip: '${_gorunumFiltresi == 'refDisi' ? 'Ref Dışı' : 'Normal'} Sonuçları Yazdır / Paylaş',
              icon: Icon(Icons.print, color: AppRenkleri.aktif),
              onPressed: () async {
                try {
                  final ad = await _kullaniciAdiniGetir();
                  final filtreliVeri = <String, Map<String, String>>{};
                  for (final grup in _filtreliKategoriGruplari()) {
                    for (final tahlilAdi in grup.value) {
                      filtreliVeri[tahlilAdi] = _tabloVerisi[tahlilAdi]!;
                    }
                  }
                  await PdfRaporServisi.enabizRaporuOlusturVePaylas(
                    tabloVerisi: filtreliVeri,
                    tarihSutunlari: _tarihSutunlari,
                    kullaniciAdi: ad,
                    filtreEtiketi: _gorunumFiltresi == 'refDisi' ? 'Ref Dışı Sonuçlar' : 'Normal Sonuçlar',
                  );
                } catch (e) {
                  if (context.mounted) {
                    showDialog(
                      context: context,
                      builder: (dialogContext) => AlertDialog(
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                        title: const Text('PDF Oluşturulamadı'),
                        content: SelectableText(e.toString()),
                        actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Kapat'))],
                      ),
                    );
                  }
                }
              },
            ),
        ],
      ),
    );
  }  // --- _aksiyonButonlari() sonu ---

  Widget _karsilastirmaPaneli() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.blue.shade50,
        borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
        border: Border.all(color: Colors.blue.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ListTile(
            dense: true,
            leading: const Icon(Icons.compare_arrows, color: Colors.blue),
            title: Text(
              _tarihSutunlari.length >= 2
                  ? 'Karşılaştırma: ${_tarihSutunlari[1]} → ${_tarihSutunlari[0]}'
                  : 'Karşılaştırma',
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (_karsilastirmaMetni.isNotEmpty)
                  IconButton(
                    icon: Icon(
                      _ttsCalisiyor ? Icons.stop_circle_outlined : Icons.volume_up_outlined,
                      color: _ttsCalisiyor ? Colors.red : AppRenkleri.aktif,
                      size: 28,
                    ),
                    onPressed: () => _ttsBaslat(_karsilastirmaMetni),
                    tooltip: 'Sesli Dinle',
                  ),
                if (_karsilastirmaMetni.isNotEmpty)
                  IconButton(
                    icon: Icon(Icons.share_outlined, color: AppRenkleri.aktif),
                    tooltip: 'Paylaş',
                    onPressed: () async {
                      try {
                        final ad = await _kullaniciAdiniGetir();
                        final baslik = _tarihSutunlari.length >= 2
                            ? 'Karşılaştırma: ${_tarihSutunlari[1]} - ${_tarihSutunlari[0]}'
                            : 'Karşılaştırma';
                        await PdfRaporServisi.analizRaporuOlusturVePaylas(
                          kullaniciAdi: ad,
                          baslik: baslik,
                          analizMetni: _karsilastirmaMetni,
                        );
                      } catch (e) {
                        if (context.mounted) {
                          showDialog(
                            context: context,
                            builder: (dialogContext) => AlertDialog(
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                              title: const Text('PDF Oluşturulamadı'),
                              content: SelectableText(e.toString()),
                              actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Kapat'))],
                            ),
                          );
                        }
                      }
                    },
                  ),
                if (_karsilastirmaMetni.isNotEmpty)
                  IconButton(
                    icon: Icon(Icons.print_outlined, color: AppRenkleri.aktif),
                    tooltip: 'Yazdır',
                    onPressed: () async {
                      try {
                        final ad = await _kullaniciAdiniGetir();
                        final baslik = _tarihSutunlari.length >= 2
                            ? 'Karşılaştırma: ${_tarihSutunlari[1]} - ${_tarihSutunlari[0]}'
                            : 'Karşılaştırma';
                        await PdfRaporServisi.analizRaporuYazdir(
                          kullaniciAdi: ad,
                          baslik: baslik,
                          analizMetni: _karsilastirmaMetni,
                        );
                      } catch (e) {
                        if (context.mounted) {
                          showDialog(
                            context: context,
                            builder: (dialogContext) => AlertDialog(
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                              title: const Text('PDF Oluşturulamadı'),
                              content: SelectableText(e.toString()),
                              actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Kapat'))],
                            ),
                          );
                        }
                      }
                    },
                  ),
                IconButton(
                  icon: const Icon(Icons.close, size: 18),
                  onPressed: () => setState(() => _karsilastirmaAcik = false),
                ),
              ],
            ),
          ),
          ConstrainedBox(
            constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.4),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: _karsilastirmaYukleniyor
                  ? const Center(child: Padding(padding: EdgeInsets.all(16), child: CircularProgressIndicator()))
                  : Scrollbar(
                      thumbVisibility: true,
                      child: SingleChildScrollView(
                        child: SelectableText(_karsilastirmaMetni, style: const TextStyle(fontSize: 13, height: 1.5)),
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }  // --- _karsilastirmaPaneli() sonu ---

  Widget _aiYorumPaneli() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.orange.shade50,
        borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
        border: Border.all(color: Colors.orange.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ListTile(
            dense: true,
            leading: Icon(Icons.auto_awesome, color: Colors.orange.shade700),
            title: Text(_aiYorumBasligi,
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (_aiYorumu.isNotEmpty)
                  IconButton(
                    icon: Icon(
                      _ttsCalisiyor ? Icons.stop_circle_outlined : Icons.volume_up_outlined,
                      color: _ttsCalisiyor ? Colors.red : AppRenkleri.aktif,
                      size: 28,
                    ),
                    onPressed: () => _ttsBaslat(_aiYorumu),
                    tooltip: 'Sesli Dinle',
                  ),
                if (_aiYorumu.isNotEmpty)
                  IconButton(
                    icon: Icon(Icons.share_outlined, color: AppRenkleri.aktif),
                    tooltip: 'Paylaş',
                    onPressed: () async {
                      try {
                        final ad = await _kullaniciAdiniGetir();
                        await PdfRaporServisi.analizRaporuOlusturVePaylas(
                          kullaniciAdi: ad,
                          baslik: _aiYorumBasligi,
                          analizMetni: _aiYorumu,
                        );
                      } catch (e) {
                        if (context.mounted) {
                          showDialog(
                            context: context,
                            builder: (dialogContext) => AlertDialog(
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                              title: const Text('PDF Oluşturulamadı'),
                              content: SelectableText(e.toString()),
                              actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Kapat'))],
                            ),
                          );
                        }
                      }
                    },
                  ),
                if (_aiYorumu.isNotEmpty)
                  IconButton(
                    icon: Icon(Icons.print_outlined, color: AppRenkleri.aktif),
                    tooltip: 'Yazdır',
                    onPressed: () async {
                      try {
                        final ad = await _kullaniciAdiniGetir();
                        await PdfRaporServisi.analizRaporuYazdir(
                          kullaniciAdi: ad,
                          baslik: _aiYorumBasligi,
                          analizMetni: _aiYorumu,
                        );
                      } catch (e) {
                        if (context.mounted) {
                          showDialog(
                            context: context,
                            builder: (dialogContext) => AlertDialog(
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                              title: const Text('PDF Oluşturulamadı'),
                              content: SelectableText(e.toString()),
                              actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Kapat'))],
                            ),
                          );
                        }
                      }
                    },
                  ),
                IconButton(
                  icon: const Icon(Icons.close, size: 18),
                  onPressed: () => setState(() => _aiYorumAcik = false),
                ),
              ],
            ),
          ),
          // ÖNEMLİ: önceden bu metin sınırsız yükseklikte büyüyordu ve uzun
          // değerlendirmelerde ekranın altına taşıp görünmez oluyordu, hiçbir
          // şekilde kaydırılamıyordu. Artık panel en fazla ekranın ~%40'ı
          // kadar yer kaplıyor, taşan kısım kendi içinde dikey kaydırılabiliyor.
          ConstrainedBox(
            constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.4),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: _aiYorumYukleniyor
                  ? const Center(child: Padding(padding: EdgeInsets.all(16), child: CircularProgressIndicator()))
                  : Scrollbar(
                      thumbVisibility: true,
                      child: SingleChildScrollView(
                        child: SelectableText(_aiYorumu, style: const TextStyle(fontSize: 13, height: 1.5)),
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }  // --- _aiYorumPaneli() sonu ---

  Widget _bostaDurumu() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.biotech_outlined, size: 72, color: AppRenkleri.aktif.shade200),
            const SizedBox(height: 16),
            const Text('Henüz tahlil yüklenmedi',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.grey)),
            const SizedBox(height: 8),
            const Text(
              'e-Nabız\'dan indirdiğiniz PDF dosyasını yükleyin.\nYapay zeka tahlillerinizi okuyup tabloya işleyecek.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey, height: 1.5),
            ),
          ],
        ),
      ),
    );
  }  // --- _bostaDurumu() sonu ---

  // "Ref Dışı" filtresinde: en az bir tarihte referans dışı değeri olan
  // tahliller gösterilir. "Normal" filtresinde: hiçbir tarihte referans
  // dışı değeri OLMAYAN (ve en az bir gerçek değeri olan) tahliller gösterilir.
  // "Tümü"nde hiçbir şey elenmez.
  List<MapEntry<String, List<String>>> _filtreliKategoriGruplari() {
    if (_gorunumFiltresi == 'tumu') return _kategoriGruplari;

    final sonuc = <MapEntry<String, List<String>>>[];
    for (final grup in _kategoriGruplari) {
      final filtreliAdlar = grup.value.where((tahlilAdi) {
        final tarihDegerler = _tabloVerisi[tahlilAdi] ?? {};
        final ref = tarihDegerler['_ref'] ?? '-';
        bool hicDegerVar = false;
        bool refDisiVarMi = false;
        tarihDegerler.forEach((tarih, deger) {
          if (tarih == '_ref' || tarih == '_kategori' || deger == '-') return;
          hicDegerVar = true;
          if (_refDisinda(deger, ref)) refDisiVarMi = true;
        });
        if (!hicDegerVar) return false;
        return _gorunumFiltresi == 'refDisi' ? refDisiVarMi : !refDisiVarMi;
      }).toList();
      if (filtreliAdlar.isNotEmpty) {
        sonuc.add(MapEntry(grup.key, filtreliAdlar));
      }
    }
    return sonuc;
  }  // --- _filtreliKategoriGruplari() sonu ---

  Widget _tahlilTablosu() {
    // ÖNEMLİ DEĞİŞİKLİK: Önceki sürüm sütunları ekrana SIĞDIRMAYA çalışıyordu
    // (LayoutBuilder ile genişlik hesaplayıp daraltıyordu) — bu da çok tarih
    // olunca yazıları okunamaz hale getiriyordu. Artık sütunlar SABİT ve
    // okunaklı genişlikte; ekrana sığmazsa tablo YANA KAYDIRILABİLİYOR
    // (sıkıştırma yok). Tüm tarihler gösteriliyor, "en güncel 4" sınırı kalktı.
    const double ilkSutunGenislik = 170.0;
    const double degerSutunGenislik = 110.0;
    final gosterilecekTarihler = _tarihSutunlari;

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // BAŞLIK SATIRI
              Container(
                color: AppRenkleri.aktif,
                child: Row(
                  children: [
                    Container(
                      width: ilkSutunGenislik,
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                      child: const Text('Tahlil Adı / Ref. Değeri',
                          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)),
                    ),
                    ...gosterilecekTarihler.map((tarih) => Container(
                          width: degerSutunGenislik,
                          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 10),
                          decoration: BoxDecoration(
                            border: Border(left: BorderSide(color: AppRenkleri.aktif.shade300, width: 0.5)),
                          ),
                          child: Column(
                            children: [
                              Text(_tarihKisa(tarih),
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
                              const SizedBox(height: 3),
                              InkWell(
                                onTap: () => _tarihIcinAnalizYap(tarih),
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                                  decoration: BoxDecoration(
                                    color: Colors.white.withOpacity(0.2),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      const Icon(Icons.auto_awesome, size: 13, color: Colors.white),
                                      const SizedBox(width: 3),
                                      const Text('Analiz', style: TextStyle(fontSize: 11, color: Colors.white, fontWeight: FontWeight.w600)),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        )),
                  ],
                ),
              ),
              // KATEGORİYE GÖRE GRUPLU VERİ SATIRLARI
              ..._filtreliKategoriGruplari().expand((grup) {
                final kategoriAdi = grup.key;
                final tahlilAdlari = grup.value;
                return [
                  // Kategori başlığı — daha büyük ve uygulamanın ana tema
                  // rengiyle (shade800 yerine direkt aktif renk) vurgulandı.
                  Container(
                    width: double.infinity,
                    color: AppRenkleri.aktif.shade50,
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    child: Text(kategoriAdi,
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppRenkleri.aktif)),
                  ),
                  ...tahlilAdlari.asMap().entries.map((entry) {
                    final index = entry.key;
                    final tahlilAdi = entry.value;
                    final tarihDegerler = _tabloVerisi[tahlilAdi] ?? {};
                    final ref = tarihDegerler['_ref'] ?? '-';
                    final satirArkaplan = index.isEven ? Colors.white : Colors.grey.shade50;
                    // Kullanıcı isteğiyle: en son tarihteki değere göre
                    // "yüksek mi düşük mü referans dışı" hesaplanır — pencere
                    // açılınca nedenini gösteririz. Artık pencere bir Dialog
                    // olduğu için bu HER SATIRDA (tıklanmasa bile) hesaplanır
                    // (ucuz bir string/sayı işlemi, AI çağrısı DEĞİL).
                    final enSonTarih = gosterilecekTarihler.isNotEmpty ? gosterilecekTarihler.first : null;
                    final enSonDeger = enSonTarih != null ? (tarihDegerler[enSonTarih] ?? '-') : '-';
                    final yon = enSonDeger != '-' ? _refDisiYonu(enSonDeger, ref) : null;

                    return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Ana satır
                  InkWell(
                    // ÖNEMLİ DÜZELTME: Kullanıcı fark etti — bilgi paneli
                    // satırın İÇİNDE (yatay kaydırılabilir tablo alanında)
                    // açılınca sağa doğru taşıp okunamıyordu. Artık ayrı bir
                    // PENCERE (Dialog) olarak, telefon genişliğine göre açılıyor.
                    onTap: () => _tahlilDetayGoster(tahlilAdi: tahlilAdi, ref: ref, yon: yon),
                    child: Container(
                      color: satirArkaplan,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          // Tahlil adı + Ref sütunu
                          Container(
                            width: ilkSutunGenislik,
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                            decoration: BoxDecoration(
                              border: Border(
                                right: BorderSide(color: Colors.grey.shade200),
                                bottom: BorderSide(color: Colors.grey.shade100),
                              ),
                            ),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(tahlilAdi,
                                          maxLines: 2, overflow: TextOverflow.ellipsis,
                                          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                                      if (ref != '-' && ref.isNotEmpty)
                                        Text('Ref: $ref',
                                            style: TextStyle(fontSize: 10, color: Colors.grey.shade600)),
                                    ],
                                  ),
                                ),
                                Icon(
                                  Icons.info_outline,
                                  size: 14,
                                  color: AppRenkleri.aktif.shade300,
                                ),
                              ],
                            ),
                          ),
                          // Değer hücreleri
                          ...gosterilecekTarihler.map((tarih) {
                            final deger = tarihDegerler[tarih] ?? '-';
                            final disinda = deger != '-' && _refDisinda(deger, ref);
                            return Container(
                              width: degerSutunGenislik,
                              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
                              decoration: BoxDecoration(
                                // ÖNEMLİ DÜZELTME: Kullanıcı iki kez fark etti —
                                // önce shade50 sonra shade100 bile "hiç belli
                                // olmuyor" dedi. Bu sefer belirgin bir sıçrama
                                // yapıp shade300'e çıkarıldı, yazı rengi de
                                // shade900'e koyulaştırıldı (kontrast için).
                                color: disinda ? Colors.red.shade300 : null,
                                border: Border(
                                  left: BorderSide(color: Colors.grey.shade200, width: 0.5),
                                  bottom: BorderSide(color: Colors.grey.shade100),
                                ),
                              ),
                              child: Text(
                                deger,
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: disinda ? FontWeight.bold : FontWeight.normal,
                                  fontStyle: disinda ? FontStyle.italic : FontStyle.normal,
                                  color: disinda
                                      ? Colors.red.shade900
                                      : (deger == '-' ? Colors.grey.shade400 : Colors.black87),
                                ),
                              ),
                            );
                          }),
                        ],
                      ),
                    ),
                  ),
                ],
              );
                  }),
                ];
              }),
            ],
          ),
        ),
      );
  }  // --- _tahlilTablosu() sonu ---

  Widget _bilgiSatiri(String baslik, String metin) {
    return RichText(
      text: TextSpan(
        style: const TextStyle(fontSize: 12, color: Colors.black87, height: 1.4),
        children: [
          TextSpan(text: '$baslik: ', style: const TextStyle(fontWeight: FontWeight.w600)),
          TextSpan(text: metin),
        ],
      ),
    );
  }  // --- _bilgiSatiri() sonu ---
}
