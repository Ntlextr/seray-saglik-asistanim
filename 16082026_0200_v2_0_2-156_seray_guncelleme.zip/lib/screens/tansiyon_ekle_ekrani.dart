import 'package:flutter/material.dart';
import '../theme/renkler.dart';
import '../theme/sablon.dart';
import '../services/veritabani_yardimcisi.dart';
import '../services/ses_servisi.dart';
import 'nabiz_olcum_ekrani.dart';
import '../services/acil_durum_servisi.dart';
import '../services/profil_yoneticisi.dart';
import 'package:shared_preferences/shared_preferences.dart';

class TansiyonEkleEkrani extends StatefulWidget {
  const TansiyonEkleEkrani({Key? key}) : super(key: key);

  @override
  State<TansiyonEkleEkrani> createState() => _TansiyonEkleEkraniState();
}

class _TansiyonEkleEkraniState extends State<TansiyonEkleEkrani> {
  bool _sesCaliniyor = false;
  bool _yukleniyor = true;
  String _acilKisiAdi = '';

  List<Map<String, dynamic>> _olcumler = [];

  @override
  void initState() {
    super.initState();
    _olcumleriYukle();
    _acilKisiAdiniYukle();
  }

  Future<void> _acilKisiAdiniYukle() async {
    final prefs = await SharedPreferences.getInstance();
    final py = ProfilYoneticisi();
    final ad = prefs.getString(await py.profilAnahtari('acil_kisi_ad')) ?? '';
    if (!mounted) return;
    setState(() => _acilKisiAdi = ad);
  }  // --- _acilKisiAdiniYukle() sonu ---

  Future<void> _olcumleriYukle() async {
    final liste = await VeritabaniYardimcisi().tansiyonlariGetir();
    if (!mounted) return;
    setState(() {
      _olcumler = liste;
      _yukleniyor = false;
    });
  }

  String _tarihiBicimlendir(String? isoTarih) {
    if (isoTarih == null) return '';
    final t = DateTime.tryParse(isoTarih);
    if (t == null) return isoTarih;
    String iki(int n) => n.toString().padLeft(2, '0');
    return '${iki(t.day)}.${iki(t.month)}.${t.year}';
  }

  // Tansiyon değerini 4 seviyeye ayırır: Çok Düşük, Normal, Yüksek, Çok Yüksek
  String _tansiyonDurumu(int buyuk, int kucuk) {
    if (buyuk >= 180 || kucuk >= 120) return 'Çok Yüksek';
    if (buyuk < 90 || kucuk < 60) return 'Çok Düşük';
    if (buyuk >= 140 || kucuk >= 90) return 'Yüksek';
    return 'Normal';
  }

  Color _tansiyonRengi(String durum) {
    switch (durum) {
      case 'Çok Yüksek':
      case 'Çok Düşük':
        return Colors.red.shade900;
      case 'Yüksek':
        return Colors.orange.shade800;
      default:
        return Colors.green.shade800;
    }
  }

  Color _tansiyonArkaPlanRengi(String durum) {
    switch (durum) {
      case 'Çok Yüksek':
      case 'Çok Düşük':
        return Colors.red.shade50;
      case 'Yüksek':
        return Colors.orange.shade50;
      default:
        return Colors.green.shade50;
    }
  }

  bool _acilMi(String durum) => durum == 'Çok Yüksek' || durum == 'Çok Düşük';

  void _yeniOlcumEkle() {
    final buyukController = TextEditingController();
    final kucukController = TextEditingController();
    final nabizController = TextEditingController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Padding(
              padding: EdgeInsets.only(
                left: 24,
                right: 24,
                top: 24,
                bottom: MediaQuery.of(context).viewInsets.bottom + 24,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Yeni Tansiyon Ölçümü',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 12),
                  // ÖNEMLİ DÜZELTME: kPa/mmHg birim seçici KALDIRILDI —
                  // kullanıcı kPa seçip mmHg'ye dönüştürülmüş bir değer
                  // (örn. 14/7 kPa → 105/53 mmHg) görünce kafası
                  // karışıyordu ("neden 14/7 yazmadı da başka bir şey
                  // gösterdi" diye). Cihazların BÜYÜK ÇOĞUNLUĞU zaten mmHg
                  // gösteriyor — form artık SABİT mmHg, basit ve net.
                  TextField(
                    controller: buyukController,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    autofocus: true,
                    decoration: InputDecoration(
                      labelText: 'Büyük Tansiyon (Sistolik)',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
                      prefixIcon: const Icon(Icons.favorite),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: kucukController,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: InputDecoration(
                      labelText: 'Küçük Tansiyon (Diastolik)',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
                      prefixIcon: const Icon(Icons.favorite_border),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: nabizController,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: 'Nabız (isteğe bağlı)',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
                      prefixIcon: const Icon(Icons.monitor_heart_outlined),
                      suffixIcon: IconButton(
                        icon: const Icon(Icons.camera_alt, color: Colors.red),
                        tooltip: 'Kameradan Ölç',
                        onPressed: () async {
                          final bpm = await Navigator.push<int>(
                            context,
                            MaterialPageRoute(builder: (context) => const NabizOlcumEkrani()),
                          );
                          if (bpm != null) {
                            setModalState(() => nabizController.text = bpm.toString());
                          }
                        },
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppRenkleri.aktif.shade700,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
                      ),
                      onPressed: () async {
                        final buyukGiris = double.tryParse(buyukController.text.trim().replaceAll(',', '.'));
                        final kucukGiris = double.tryParse(kucukController.text.trim().replaceAll(',', '.'));
                        final nabiz = int.tryParse(nabizController.text.trim());

                        if (buyukGiris == null || kucukGiris == null) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Lütfen büyük ve küçük tansiyon değerlerini girin.')),
                          );
                          return;
                        }

                        double buyukMmHg = buyukGiris;
                        double kucukMmHg = kucukGiris;

                        // Halk arasında tansiyon "12/8" gibi söylenir (gerçek değer 120/80'dir).
                        // Gerçekçi olamayacak kadar düşük bir değer girilmişse (ör. 12, 8, 9.5)
                        // bunu x10 yaparak gerçek mmHg değerine çeviriyoruz.
                        if (buyukMmHg < 30 && kucukMmHg < 30) {
                          buyukMmHg *= 10;
                          kucukMmHg *= 10;
                        }

                        // ÖNEMLİ DÜZELTME: x10 kuralı bile geçerli bir aralığa
                        // getiremiyorsa (örn. "14/7" gibi hâlâ imkansız bir
                        // değerse — x10 sonrası 140/70 mantıklı ama "3/2" gibi
                        // bir giriş x10'dan sonra bile 30/20 kalıp anlamsız
                        // olabilir), otomatik "düzeltmeye" GÜVENMİYORUZ —
                        // kullanıcıyı gerçek değeri girmeye yönlendiren bir
                        // uyarı gösterip KAYDETMİYORUZ. Sessizce yanlış bir
                        // sayı kaydetmek, "Çok Düşük" gibi yanlış acil durum
                        // uyarıları tetikleyebiliyordu.
                        if (buyukMmHg < 40 || kucukMmHg < 30 || buyukMmHg > 300 || kucukMmHg > 200) {
                          showDialog(
                            context: context,
                            builder: (d) => AlertDialog(
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                              title: const Text('Değer Gerçekçi Görünmüyor'),
                              content: const Text(
                                'Girdiğiniz değer normal bir tansiyon ölçümüne benzemiyor. '
                                'Lütfen cihazınızda gördüğünüz tam sayıyı girin — örneğin '
                                '"140/70" gibi (12/8 değil, 140/70).',
                              ),
                              actions: [TextButton(onPressed: () => Navigator.pop(d), child: const Text('Tamam'))],
                            ),
                          );
                          return;
                        }

                        final buyuk = buyukMmHg.round();
                        final kucuk = kucukMmHg.round();

                        final yeniId = await VeritabaniYardimcisi().tansiyonEkle({
                          'buyuk': buyuk,
                          'kucuk': kucuk,
                          'nabiz': nabiz,
                          'tarih': DateTime.now().toIso8601String(),
                        });
                        if (context.mounted) Navigator.pop(context);
                        await _olcumleriYukle();
                        final tansiyonDurumu = _tansiyonDurumu(buyuk, kucuk);
                        if (_acilMi(tansiyonDurumu) && mounted) {
                          await AcilDurumServisi.tehlikeliOlcumBildir(
                            this.context,
                            olcumOzeti: 'Tansiyon $buyuk/$kucuk mmHg ($tansiyonDurumu) olarak kaydedildi.',
                            onGonderildi: () async {
                              await VeritabaniYardimcisi().tansiyonSmsGonderildiIsaretle(yeniId);
                              if (mounted) await _olcumleriYukle();
                            },
                          );
                        }
                      },
                      child: const Text(
                        'Kaydet',
                        style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Future<void> _olcumSil(int id) async {
    await VeritabaniYardimcisi().tansiyonSil(id);
    await _olcumleriYukle();
  }

  // 🔊 TANSİYON DEĞERLERİNİ ANALİZ EDİP SESLİ OKUYAN FONKSİYON
  Future<void> _tansiyonAnaliziniSeslendir() async {
    if (_sesCaliniyor) {
      await SesServisi.durdur();
      setState(() => _sesCaliniyor = false);
      return;
    }

    if (_olcumler.isEmpty) {
      await SesServisi.konus("Henüz kaydedilmiş bir tansiyon ölçümünüz bulunmamaktadır.");
      return;
    }

    final sonOlcum = _olcumler.first;
    int buyuk = sonOlcum['buyuk'] as int;
    int kucuk = sonOlcum['kucuk'] as int;
    final durum = _tansiyonDurumu(buyuk, kucuk);

    String durumMetni = "Son ölçümünüze göre büyük tansiyonunuz $buyuk, küçük tansiyonunuz $kucuk değerindedir. ";

    switch (durum) {
      case 'Çok Yüksek':
        durumMetni += "Bu değerler normalin çok üzerinde ve acil bir durum olabilir. Lütfen en kısa sürede bir doktora veya acil servise başvurunuz.";
        break;
      case 'Çok Düşük':
        durumMetni += "Bu değerler normalin çok altında. Baş dönmesi veya halsizlik hissediyorsanız lütfen en kısa sürede bir doktora veya acil servise başvurunuz.";
        break;
      case 'Yüksek':
        durumMetni += "Tansiyon değerleriniz normal sınırların üzerinde seyretmektedir. Lütfen dinlenip tekrar ölçüm yapınız, yüksek seyir devam ederse doktorunuza danışınız.";
        break;
      default:
        durumMetni += "Tansiyon seyriniz tamamen ideal ve normal sınırlardadır. Sağlıklı günler dileriz.";
    }

    setState(() => _sesCaliniyor = true);
    await SesServisi.konus(durumMetni, onTamamlandi: () {
      if (mounted) setState(() => _sesCaliniyor = false);
    });
  }

  @override
  void dispose() {
    SesServisi.durdur();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Tansiyon Takibi', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: AppRenkleri.aktif,
        foregroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(
            icon: Icon(
              _sesCaliniyor ? Icons.stop_circle : Icons.volume_up,
              color: Colors.blue,
              size: 34,
            ),
            onPressed: _tansiyonAnaliziniSeslendir,
          ),
          const SizedBox(width: 12),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _yeniOlcumEkle,
        backgroundColor: AppRenkleri.aktif.shade700,
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text('Ölçüm Ekle', style: TextStyle(color: Colors.white)),
      ),
      body: _yukleniyor
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Ölçüm Geçmişiniz', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  Expanded(
                    child: _olcumler.isEmpty
                        ? const Center(
                            child: Text(
                              'Henüz kaydedilmiş bir ölçüm bulunmuyor.\nSağ alttaki + butonuyla ekleyebilirsiniz.',
                              textAlign: TextAlign.center,
                              style: TextStyle(color: Colors.grey),
                            ),
                          )
                        : ListView.builder(
                            padding: const EdgeInsets.only(bottom: 88),
                            itemCount: _olcumler.length,
                            itemBuilder: (context, index) {
                              final olcum = _olcumler[index];
                              final buyuk = olcum['buyuk'] as int;
                              final kucuk = olcum['kucuk'] as int;
                              final durum = _tansiyonDurumu(buyuk, kucuk);
                              final acilMi = _acilMi(durum);
                              final smsGonderildi = (olcum['sms_gonderildi'] as int? ?? 0) == 1;

                              return Card(
                                margin: const EdgeInsets.symmetric(vertical: 6),
                                color: acilMi ? Colors.red.shade50 : null,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
                                  side: acilMi ? BorderSide(color: Colors.red.shade400, width: 1.5) : BorderSide.none,
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Row(
                                        children: [
                                          Icon(Icons.favorite, color: _tansiyonRengi(durum), size: 20),
                                          const SizedBox(width: 6),
                                          Flexible(
                                            child: Text(
                                              '$buyuk / $kucuk mmHg',
                                              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                                              overflow: TextOverflow.ellipsis,
                                              maxLines: 1,
                                            ),
                                          ),
                                          const SizedBox(width: 6),
                                          Container(
                                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                            decoration: BoxDecoration(color: _tansiyonArkaPlanRengi(durum), borderRadius: BorderRadius.circular(8)),
                                            child: Text(durum, style: TextStyle(color: _tansiyonRengi(durum), fontWeight: FontWeight.bold, fontSize: 11), overflow: TextOverflow.ellipsis, maxLines: 1),
                                          ),
                                          IconButton(
                                            icon: Icon(Icons.volume_up, color: AppRenkleri.aktif, size: 20),
                                            padding: EdgeInsets.zero,
                                            constraints: const BoxConstraints(),
                                            onPressed: () {
                                              final tarihMetni = _tarihiBicimlendir(olcum['tarih']?.toString());
                                              SesServisi.konus('$tarihMetni tarihli ölçüm: büyük tansiyon $buyuk, küçük tansiyon $kucuk. Durum: $durum.');
                                            },
                                          ),
                                          IconButton(
                                            icon: const Icon(Icons.delete_outline, color: Colors.grey, size: 20),
                                            padding: EdgeInsets.zero,
                                            constraints: const BoxConstraints(),
                                            onPressed: () => _olcumSil(olcum['id'] as int),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 2),
                                      Text(
                                        _tarihiBicimlendir(olcum['tarih']?.toString()),
                                        style: TextStyle(fontSize: 12, color: Colors.grey.shade700),
                                      ),
                                      if (acilMi)
                                        Padding(
                                          padding: const EdgeInsets.only(top: 6),
                                          child: Row(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Icon(Icons.warning_amber_rounded, color: Colors.red.shade700, size: 16),
                                              const SizedBox(width: 6),
                                              Expanded(
                                                child: Text.rich(
                                                  TextSpan(
                                                    children: [
                                                      const TextSpan(text: 'Acil olabilir. En kısa sürede doktora/acil servise başvurun. '),
                                                      if (smsGonderildi && _acilKisiAdi.isNotEmpty)
                                                        TextSpan(
                                                          text: '$_acilKisiAdi kişisine SMS gönderildi.',
                                                          style: const TextStyle(fontStyle: FontStyle.italic),
                                                        ),
                                                    ],
                                                  ),
                                                  style: TextStyle(color: Colors.red.shade700, fontSize: 11, fontWeight: FontWeight.bold, height: 1.3),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                  ),
                ],
              ),
            ),
    );
  }
}
