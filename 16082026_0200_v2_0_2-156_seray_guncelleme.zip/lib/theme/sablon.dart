import 'package:flutter/material.dart';

// Uygulamanın görsel ŞABLON sistemi. Renk sisteminden (AppRenkleri, aynı
// klasördeki renkler.dart) TAMAMEN bağımsız — ikisi birlikte, üst üste
// çalışır: renk paleti "hangi ton", şablon ise "hangi his" (köşeler,
// yoğunluk, üst menü şekli) sorusuna cevap verir. main.dart, uygulama
// açılırken (runApp'tan ÖNCE) kayıtlı tercihi okuyup sablonAdi değerini
// ayarlar; Ayarlar ekranından değiştirilebilir.
//
// ÖNEMLİ TASARIM KARARI: "Klasik" şablonun tüm değerleri, mevcut kodda
// zaten sabit yazılı olan değerlerle (örn. BorderRadius.circular(12),
// standart AppBar, standart yoğunluk) BİREBİR AYNI ya da null (Flutter'ın
// kendi varsayılanı). Yani bu sistem hiç eklenmemiş gibi davranır ta ki
// kullanıcı Ayarlar'dan bilinçli olarak "Modern Yuvarlak"ı seçene kadar —
// mevcut düzen hiçbir şekilde bozulmaz.
class AppSablon {
  static String sablonAdi = 'klasik'; // klasik | modern_yuvarlak

  static bool get modernMi => sablonAdi == 'modern_yuvarlak';

  // Kart / kutu / buton köşe yarıçapı.
  static double get kartYaricapi => modernMi ? 22.0 : 12.0;

  // ÜST MENÜ ŞEKLİ: 26 ekranın hiçbiri kendi AppBar şeklini tanımlamıyor,
  // bu yüzden burada tek bir yerde belirlenen şekil TÜM ekranlara otomatik
  // yansıyor. Klasik'te null (Flutter'ın standart, düz köşeli AppBar'ı,
  // mevcut görünümle birebir aynı). Modern'de alt kenarları yuvarlatılmış
  // bir "kart gibi" üst menü.
  static ShapeBorder? get appBarSekli => modernMi
      ? const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(bottomLeft: Radius.circular(26), bottomRight: Radius.circular(26)),
        )
      : null;

  // GENEL YOĞUNLUK: Modern'de Material bileşenlerinin (liste satırları,
  // butonlar, form alanları) varsayılan iç boşluğu biraz artırılıyor —
  // "daha ferah" his. Klasik'te standart (mevcutla birebir aynı).
  static VisualDensity get yogunluk => modernMi ? VisualDensity.comfortable : VisualDensity.standard;

  // KART GÖLGESİ: Modern'de kartlar gölgesiz/düz (elevation 0) — daha
  // "flat" modern bir görünüm. Klasik'te Flutter'ın standart gölgesi
  // (mevcutla birebir aynı, null = tema override etmiyor).
  static double? get kartGolgesi => modernMi ? 0.0 : null;

  static String get adi => modernMi ? 'Modern Yuvarlak' : 'Klasik';
  static String get aciklama => modernMi
      ? 'Yuvarlak köşeler, düz üst menü, ferah ve gölgesiz kartlar'
      : 'Mevcut, bilinen görünüm';
}

