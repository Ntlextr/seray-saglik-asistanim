import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'seker_ekle_ekrani.dart';
import 'tansiyon_ekle_ekrani.dart';
import 'yapay_zeka_ekrani.dart';
import '../services/veritabani_yardimcisi.dart';

class AnaSayfa extends StatefulWidget {
  const AnaSayfa({Key? key}) : super(key: key);

  @override
  _AnaSayfaState createState() => _AnaSayfaState();
}

class _AnaSayfaState extends State<AnaSayfa> {
  String _kullaniciAdi = "...";
  List<Map<String, dynamic>> _sonSekerler = [];
  List<Map<String, dynamic>> _sonTansiyonlar = [];
  bool _yukleniyor = true;

  @override
  void initState() {
    super.initState();
    _verileriTazele();
  }

  Future<void> _verileriTazele() async {
    final prefs = await SharedPreferences.getInstance();
    final sekerler = await VeritabaniYardimcisi().sekerleriGetir();
    final tansiyonlar = await VeritabaniYardimcisi().tansiyonlariGetir();
    
    setState(() {
      _kullaniciAdi = prefs.getString('user_ad') ?? "Kullanıcı";
      _sonSekerler = sekerler;
      _sonTansiyonlar = tansiyonlar;
      _yukleniyor = false;
    });
  }

  String _saateGoreSelamla() {
    final saat = DateTime.now().hour;
    if (saat >= 6 && saat < 12) return 'Günaydın';
    if (saat >= 12 && saat < 18) return 'İyi Günler';
    if (saat >= 18 && saat < 22) return 'İyi Akşamlar';
    return 'İyi Geceler';
  }

  IconData _saateGoreIkon() {
    final saat = DateTime.now().hour;
    if (saat >= 6 && saat < 18) return Icons.wb_sunny;
    return Icons.brightness_3;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      body: SafeArea(
        child: _yukleniyor 
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _verileriTazele,
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Card(
                      elevation: 0,
                      color: Colors.teal.shade50,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      child: Padding(
                        padding: const EdgeInsets.all(20.0),
                        child: Row(
                          children: [
                            Icon(_saateGoreIkon(), size: 40, color: Colors.orange.shade700),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('${_saateGoreSelamla()},', style: const TextStyle(fontSize: 16, color: Colors.black54)),
                                  Text('$_kullaniciAdi Bey', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.teal)),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 24),
                    const Text('Hızlı İşlemler', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: _hizliErisimButonu(
                            ikon: Icons.bloodtype,
                            renk: Colors.red.shade600,
                            baslik: 'Şeker Ekle',
                            onTap: () async {
                              final basarili = await Navigator.push(context, MaterialPageRoute(builder: (context) => const SekerEkleEkrani()));
                              if (basarili == true) _verileriTazele();
                            },
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: _hizliErisimButonu(
                            ikon: Icons.favorite,
                            renk: Colors.teal.shade600,
                            baslik: 'Tansiyon Ekle',
                            onTap: () async {
                              final basarili = await Navigator.push(context, MaterialPageRoute(builder: (context) => const TansiyonEkleEkrani()));
                              if (basarili == true) _verileriTazele();
                            },
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton.icon(
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => const YapayZekaEkrani()));
                      },
                      icon: const Icon(Icons.android, size: 28),
                      label: const Text('YAPAY ZEKA SAĞLIK ASİSTANI', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.teal.shade700,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      ),
                    ),
                    const SizedBox(height: 24),
                    const Text('Son Şeker Ölçümleri', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    _sonSekerler.isEmpty 
                      ? const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('Kayıtlı şeker ölçümü yok.', style: TextStyle(fontSize: 16))))
                      : Column(children: _sonSekerler.take(3).map((s) => Card(
                          margin: const EdgeInsets.only(bottom: 8),
                          child: ListTile(
                            leading: Icon(Icons.bloodtype, color: Colors.red.shade600, size: 30),
                            title: Text('${s['deger']} mg/dL', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                            trailing: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                              decoration: BoxDecoration(color: Colors.red.shade50, borderRadius: BorderRadius.circular(12)),
                              child: Text(s['durum'].toString(), style: TextStyle(color: Colors.red.shade700, fontWeight: FontWeight.bold, fontSize: 16)),
                            ),
                          ),
                        )).toList()),
                    const SizedBox(height: 16),
                    const Text('Son Tansiyon Ölçümleri', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    _sonTansiyonlar.isEmpty 
                      ? const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('Kayıtlı tansiyon ölçümü yok.', style: TextStyle(fontSize: 16))))
                      : Column(children: _sonTansiyonlar.take(3).map((t) => Card(
                          margin: const EdgeInsets.only(bottom: 8),
                          child: ListTile(
                            leading: const Icon(Icons.favorite, color: Colors.teal, size: 30),
                            title: Text('${t['buyuk']} / ${t['kucuk']}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                            subtitle: Text('Nabız: ${t['nabiz']} bpm', style: const TextStyle(fontSize: 15)),
                          ),
                        )).toList()),
                  ],
                ),
              ),
            ),
      ),
    );
  }

  Widget _hizliErisimButonu({required IconData ikon, required Color renk, required String baslik, required VoidCallback onTap}) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 24),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.grey.shade200),
        ),
        child: Column(
          children: [
            Icon(ikon, size: 40, color: renk),
            const SizedBox(height: 12),
            Text(baslik, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}
