

3 site
Açık kaynaklı yapay zeka kodlama asistanları arasında en iyi performans gösterenler genellikle VS Code gibi IDE'lere entegre çalışan ajanlardır. İhtiyaçlarınıza en uygun olanı bulmak için öne çıkan açık kaynaklı araçlar şunlardır: 

Manus
 +1
Cline: Tamamen açık kaynaklı ve modelden bağımsız bir VS Code uzantısıdır. Kendi API anahtarınızı (OpenAI, Anthropic vb.) bağlayarak doğrudan bilgisayarınızdaki dosya sistemi üzerinde kod yazar ve testleri çalıştırır. 

Manus
OpenCode: Terminal ve masaüstü arayüzlerinde çalışan çok yönlü bir ajandır. Yerel modeller dahil 75'ten fazla LLM (Büyük Dil Modeli) sağlayıcısını destekler. 

OpenCode
Aider: Doğrudan terminal üzerinden kod tabanınızla (repository) konuşan popüler bir araçtır. Claude veya GPT gibi güçlü modellerin API'lerini kullanarak karmaşık projeleri yönetmenizi sağlar. 

AIMultiple
Eğer açık kaynaklı bir yapay zeka ile kodlama yapmaya başlamak istiyorsanız bana şunları söyleyebilir misiniz?
Tercih ettiğiniz programlama dili nedir?
Kendi bilgisayarınızda (yerel sunucuda) çalıştırabileceğiniz yerel modelleri (Local LLM) mi tercih edersiniz, yoksa harici API kullanmak sizin için uygun mu?





Mobil yazılım geliştirme için en popüler iki açık kaynaklı alternatif Flutter (Dart) ve React Native (JavaScript/TypeScript) teknolojileridir. Projenizin ihtiyaçlarına göre doğru seçimi yapmak için temel farklar şunlardır:
Performans ve Arayüz
Flutter (Dart): Kendi çizim motorunu (Impeller/Skia) kullanır. Arayüzü doğrudan ekrana çizer. Bu sayede tüm cihazlarda mükemmel, akıcı ve yüksek performanslı animasyonlar sunar.
React Native: Cihazın kendi orijinal (native) bileşenlerini köprüler yardımıyla çağırır. Aşırı yoğun animasyonlarda köprü gecikmesi yaşanabilir ancak standart uygulamalarda yerel (native) hissi daha yüksektir.
Geliştirme Hızı ve Ekosistem
Flutter (Dart): Tek bir kod tabanından hem iOS hem Android için birebir aynı tasarımı üretir. Hazır widget kütüphanesi çok geniştir. Tasarım süreçleri çok hızlı ilerler.
React Native: Web geliştirme (React) dünyasına çok yakındır. JavaScript ekosistemindeki milyonlarca kütüphaneden faydalanır. Web geliştiricileri çok hızlı uyum sağlar.
Yapay Zeka Desteği
Flutter (Dart): Büyük dil modelleri (LLM) Dart dilinde kaliteli kod üretebilir. Ancak popüler web dillerine kıyasla internetteki kaynak veri havuzu daha dar olduğundan yapay zeka bazen karmaşık mimarilerde hata yapabilir.
React Native: JavaScript dünyası devasa bir veri havuzuna sahiptir. Yapay zeka araçları (Cline, Aider vb.) JavaScript ve TypeScript ile neredeyse kusursuz ve alternatifsiz kod üretir.
Geliştirmek istediğiniz mobil uygulama için en doğru seçimi yapabilmemiz adına bana şunları söyleyebilir misiniz?
Daha önce web geliştirme (JS/React) geçmişiniz var mı?
Yapacağınız uygulama bol animasyonlu/görsel ağırlıklı bir proje mi yoksa veri odaklı standart bir uygulama mı?





Harika ve çok net hazırlanmış bir proje planı. Seray Sağlık Asistanım uygulamasının temel iskeletini, Material 3 tasarım diline, yaş dostu (büyük fontlar/kartlar) felsefesine ve verdiğiniz genişletilebilir modüler yapı kuralına uygun olarak Sürüm 1 (Temel MVP) seviyesinde ayağa kaldırıyoruz.
İlerleyen aşamalarda AI, PDF ve Grafikleri kolayca bağlayabilmeniz için kodun mimarisini tamamen esnek ve modüler bıraktım.
📱 Sürüm 1: Temel MVP Kodu
Aşağıdaki kodu doğrudan main.dart dosyanıza yapıştırıp çalıştırabilirsiniz. shared_preferences kullanarak yerel veri kaydetme mekanizmasının altyapısını ve zamana göre dinamik selamlama (Günaydın, İyi Akşamlar vb.) fonksiyonunu ekledim:
dart
import 'package:flutter/material.dart';

void main() {
  runApp(const SeraySaglikUygulamasi());
}

class SeraySaglikUygulamasi extends StatelessWidget {
  const SeraySaglikUygulamasi({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Seray Sağlık Asistanım',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.teal,
          brightness: Brightness.light,
        ),
        // Yaş dostu büyük ve okunaklı yazı tipi ayarları
        textTheme: const TextTheme(
          headlineMedium: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.black87),
          titleLarge: TextStyle(fontSize: 22, fontWeight: FontWeight.w600),
          bodyLarge: TextStyle(fontSize: 18, color: Colors.black87),
          bodyMedium: TextStyle(fontSize: 16),
        ),
      ),
      home: const AnaEkran(),
    );
  }
}

// --- ANA NAVİGASYON VE FRAMEWORK ---
class AnaEkran extends StatefulWidget {
  const AnaEkran({super.key});
  @override
  State<AnaEkran> createState() => _AnaEkranState();
}

class _AnaEkranState extends State<AnaEkran> {
  int _seciliSayfa = 0;
  final String _kullaniciAdi = "Serdar Bey";

  // Modüler yapı: Sayfalar listesi
  late final List<Widget> _sayfalar;

  @override
  void initState() {
    super.initState();
    _sayfalar = [
      AnaSayfaPaneli(kullaniciAdi: _kullaniciAdi),
      const AnalizlerSayfasi(),
      const AyarlarSayfasi(),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("❤️ Seray Sağlık Asistanım", style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      // Sol Menü (Drawer) - Proje gereksinimi
      drawer: NavigationDrawer(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(28, 32, 16, 10),
            child: Text("Menü", style: Theme.of(context).textTheme.titleLarge),
          ),
          NavigationDrawerDestination(
            icon: const Icon(Icons.person),
            label: Text("Profil ($_kullaniciAdi)", style: const TextStyle(fontSize: 16)),
          ),
          const NavigationDrawerDestination(
            icon: const Icon(Icons.description),
            label: Text("e-Nabız PDF Yükle", style: TextStyle(fontSize: 16)),
          ),
          const NavigationDrawerDestination(
            icon: const Icon(Icons.cloud_upload),
            label: Text("Google Drive Yedekle", style: TextStyle(fontSize: 16)),
          ),
        ],
      ),
      body: _sayfalar[_seciliSayfa],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _seciliSayfa,
        onDestinationSelected: (index) => setState(() => _seciliSayfa = index),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home, size: 30), label: "Ana Sayfa"),
          NavigationDestination(icon: Icon(Icons.bar_chart, size: 30), label: "Analizler"),
          NavigationDestination(icon: Icon(Icons.settings, size: 30), label: "Ayarlar"),
        ],
      ),
    );
  }
}

// --- 1. ANA SAYFA PANELİ ---
class AnaSayfaPaneli extends StatelessWidget {
  final String kullaniciAdi;
  const AnaSayfaPaneli({super.key, required this.kullaniciAdi});

  // Saate göre dinamik selamlama fonksiyonu
  String _saateGoreSelamla() {
    final saat = DateTime.now().hour;
    if (saat >= 5 && saat < 12) return "Günaydın ☀️";
    if (saat >= 12 && saat < 17) return "İyi Günler 🌤️";
    if (saat >= 17 && saat < 22) return "İyi Akşamlar 🌆";
    return "İyi Geceler 🌙";
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // Hoş Geldiniz Karşılama Kartı (Büyük ve Okunaklı)
        Card(
          elevation: 4,
          color: Theme.of(context).colorScheme.primaryContainer,
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _saateGoreSelamla(),
                  style: TextStyle(fontSize: 18, color: Theme.of(context).colorScheme.onPrimaryContainer),
                ),
                const SizedBox(height: 5),
                Text(
                  "Hoş Geldiniz, $kullaniciAdi",
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.onPrimaryContainer),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 20),

        // Doktor Bilgilendirme Kartı (Şeker, Tansiyon, Nabız için boş şablon)
        Card(
          elevation: 2,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: const [
                Icon(Icons.health_and_safety, color: Colors.red, size: 40),
                SizedBox(width: 15),
                Expanded(
                  child: Text(
                    "Doktor Bilgilendirme: Son ölçümleriniz stabil görünüyor. Lütfen günlük takibi aksatmayınız.",
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 20),

        // Hızlı İşlem Butonları (Yaş dostu büyük dokunma alanları)
        Row(
          children: [
            Expanded(
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 15)),
                onPressed: () {},
                icon: const Icon(Icons.bloodtype, color: Colors.red),
                label: const Text("Tansiyon\nEkle", textAlign: TextAlign.center, style: TextStyle(fontSize: 16)),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 15)),
                onPressed: () {},
                icon: const Icon(Icons.water_drop, color: Colors.blue),
                label: const Text("Kan Şekeri\nEkle", textAlign: TextAlign.center, style: TextStyle(fontSize: 16)),
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),

        // Sağlık Verileri Takip Listesi Özetleri
        Text("Bugünkü Takip Öğeleri", style: Theme.of(context).textTheme.headlineMedium),
        const SizedBox(height: 10),
        _saglikTakipSatiri(context, Icons.medication, "İlaç Takibi", "Akşam dozu bekleniyor (Hazırlık aşamasında)", Colors.purple),
        _saglikTakipSatiri(context, Icons.local_drink, "Su Takibi", "1.5 Litre içildi / Hedef 2.5 L", Colors.blue),
        _saglikTakipSatiri(context, Icons.monitor_weight, "Kilo Takibi", "Son ölçüm: 78 kg", Colors.teal),
        _saglikTakipSatiri(context, Icons.calendar_month, "Doktor Randevuları", "Kardiyoloji - 20 Temmuz", Colors.orange),
      ],
    );
  }

  Widget _saglikTakipSatiri(BuildContext context, IconData icon, String baslik, String altBaslik, Color renk) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: ListTile(
        leading: CircleAvatar(backgroundColor: renk.withOpacity(0.2), child: Icon(icon, color: renk)),
        title: Text(baslik, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        subtitle: Text(altBaslik, style: const TextStyle(fontSize: 14)),
        trailing: const Icon(Icons.arrow_forward_ios, size: 16),
        onTap: () {},
      ),
    );
  }
}

// --- 2. ANALİZLER VE YAPAY ZEKA SAYFASI ---
class AnalizlerSayfasi extends StatelessWidget {
  const AnalizlerSayfasi({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text("Sağlık Analizleri & Yapay Zeka", style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 15),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(20),
              child: Text(
                "📊 Grafik Alanı\nTansiyon ve Şeker geçmiş grafikleriniz bir sonraki güncellemede burada listelenecektir.",
                style: TextStyle(fontSize: 16, height: 1.5),
              ),
            ),
          ),
          const SizedBox(height: 15),
          Card(
            color: Colors.purple.value == 0 ? Colors.white : Colors.purple.withOpacity(0.05),
            shape: RoundedRectangleBorder(side: BorderSide(color: Colors.purple.withOpacity(0.3)), borderRadius: BorderRadius.circular(12)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: const [
                      Icon(Icons.smart_toy, color: Colors.purple, size: 30),
                      SizedBox(width: 10),
                      Text("Yapay Zeka Sağlık Asistanı", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.purple)),
                    ],
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    "🤖 'Merhaba Serdar Bey, tahlil sonuçlarınızı veya günlük ölçüm trendlerinizi yorumlamam için bir sonraki sürümde aktif olacağım.'",
                    style: TextStyle(fontSize: 16, fontStyle: FontStyle.italic),
                  ),
                  const SizedBox(height: 15),
                  const Text(
                    "⚠️ Yasal Uyarı: Yapay zeka yorumları sadece bilgilendirme amaçlıdır, doktor teşhisi yerine geçmez.",
Kodu dikkatli kullanın.
style: TextStyle(fontSize: 12, color: Colors.redAccent, fontWeight: FontWeight.w600),
),
],
),
),
),
],
),
);
}
}
// --- 3. AYARLAR SAYFASI ---
class AyarlarSayfasi extends StatelessWidget {
const AyarlarSayfasi({super.key});
@override
Widget build(BuildContext context) {
return Scaffold(
body: ListView(
children: [
const SizedBox(height: 10),
ListTile(
leading: const Icon(Icons.person, size: 28),
title: const Text("Profil Bilgileri", style: TextStyle(fontSize: 18)),
subtitle: const Text("Fotoğraf ve kişisel sağlık sınırları"),
onTap: () {},
),
const Divider(),
ListTile(
leading: const Icon(Icons.cloud_sync, size: 28),
title: const Text("Google Drive Yedekleme", style: TextStyle(fontSize: 18)),
subtitle: const Text("Verilerinizi buluta yedekleyin veya geri yükleyin"),
onTap: () {},
),
const Divider(),
ListTile(
leading: const Icon(Icons.gavel, size: 28),
title: const Text("KVKK & Gizlilik Sözleşmesi", style: TextStyle(fontSize: 18)),
subtitle: const Text("Yerel veri koruma ve yasal metinler"),
onTap: () {},
),
const Divider(),
const AboutListTile(
icon: Icon(Icons.info, size: 28),
applicationName: "Seray Sağlık Asistanım",
applicationVersion: "v1.0.0 (MVP)",
applicationLegalese: "© 2026 Seray Sağlık. Tüm hakları saklıdır.",
child: Text("Uygulama Hakkında", style: TextStyle(fontSize: 18)),
),
],
),
);
}
}




Soru sorun


AI Modu'nun yanıtı hazır
Soru sorun 