package com.seraysaglikasistani

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
