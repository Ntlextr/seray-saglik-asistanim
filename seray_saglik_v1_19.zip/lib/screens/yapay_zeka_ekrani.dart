import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import '../services/api_service.dart';
import '../services/veritabani_yardimcisi.dart';

class YapayZekaEkrani extends StatefulWidget {
  const YapayZekaEkrani({Key? key}) : super(key: key);
  @override
  _YapayZekaEkraniState createState() => _YapayZekaEkraniState();
}

class _YapayZekaEkraniState extends State<YapayZekaEkrani> {
  bool _yukleniyor = false;
  String _aiYorumu = "e-Nabız tahlilinizi yükledikten sonra detaylı matris ve tıbbi yorum buraya dökülecektir.";
  Map<String, Map<String, String>> _tabloVerisi = {};
  List<String> _tarihSutunlari = [];

  @override
  void initState() { super.initState(); _tabloyuYukle(); }

  Future<void> _tabloyuYukle() async {
    final tahliller = await VeritabaniYardimcisi().tumTahlilleriGetir();
    Map<String, Map<String, String>> geciciTablo = {};
    Set<String> tarihler = {};
    for (var t in tahliller) {
      String tarih = t['tarih'].toString();
      String ad = t['tahlil_adi'].toString();
      String sonuc = t['sonuc'].toString();
      String ref = t['referans_degeri'].toString();
      tarihler.add(tarih);
      if (!geciciTablo.containsKey(ad)) geciciTablo[ad] = {"_ref": ref};
      geciciTablo[ad]![tarih] = sonuc;
    }
    setState(() { _tabloVerisi = geciciTablo; _tarihSutunlari = tarihler.toList()..sort((a, b) => b.compareTo(a)); });
  }

  Future<void> _pdfSecVeAnalizEt() async {
    FilePickerResult? sonuc = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pdf', 'txt']);
    if (sonuc != null) {
      setState(() { _yukleniyor = true; _aiYorumu = "Dosya çözümleniyor, lütfen bekleyin..."; });
      // Simüle edilen gerçek e-Nabız girdi verisi
      String r = "GLUKOZ 155 mg/dL ref:80-110, HbA1c 9.4 ref:4.8-5.9, Vitamin B12 201 ref:211-900";
      final cevap = await ApiService.tahlilMetniniAnalizEt(r);
      setState(() { _yukleniyor = false; _aiYorumu = cevap; });
      _tabloyuYukle();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('e-Nabız Analiz Matrisi')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Center(child: Image.asset('assets/images/app_logo.png', height: 80, width: 80)),
            const SizedBox(height: 16),
            ElevatedButton.icon(onPressed: _pdfSecVeAnalizEt, icon: const Icon(Icons.upload_file), label: const Text('E-NABIZ PDF/METİN DOSYASI YÜKLE')),
            const SizedBox(height: 20),
            if (_tabloVerisi.isNotEmpty) SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: DataTable(
                columns: [
                  const DataColumn(label: Text('Tahlil Adı')),
                  const DataColumn(label: Text('Normal Ref.')),
                  ..._tarihSutunlari.map((t) => DataColumn(label: Text(t))),
                ],
                rows: _tabloVerisi.entries.map((entry) {
                  return DataRow(cells: [
                    DataCell(Text(entry.key, style: const TextStyle(fontWeight: FontWeight.bold))),
                    DataCell(Text(entry.value["_ref"] ?? "-")),
                    ..._tarihSutunlari.map((t) => DataCell(Text(entry.value[t] ?? "-"))),
                  ]);
                }).toList(),
              ),
            ),
            const SizedBox(height: 16),
            Card(child: Padding(padding: const EdgeInsets.all(16.0), child: Text(_aiYorumu))),
          ],
        ),
      ),
    );
  }
}
