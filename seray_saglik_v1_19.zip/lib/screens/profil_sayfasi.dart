import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:file_picker/file_picker.dart';
import 'profil_kayit_ekrani.dart';
import '../services/veritabani_yardimcisi.dart';

class ProfilSayfasi extends StatefulWidget {
  const ProfilSayfasi({Key? key}) : super(key: key);
  @override
  _ProfilSayfasiState createState() => _ProfilSayfasiState();
}

class _ProfilSayfasiState extends State<ProfilSayfasi> {
  String _ad = "..."; String _soyad = "...";
  int _yas = 0;
  String _diyabetTipi = "Yok";

  @override
  void initState() { super.initState(); _yukle(); }

  _yukle() async {
    final p = await SharedPreferences.getInstance();
    setState(() {
      _ad = p.getString('user_ad') ?? "";
      _soyad = p.getString('user_soyad') ?? "";
      _yas = p.getInt('user_yas') ?? 0;
      _diyabetTipi = p.getString('user_diyabet') ?? "Yok";
    });
  }

  Future<void> _cikisYap() async {
    final onay = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Çıkış Yap'),
        content: const Text('Uygulamadan çıkış yapmak istediğinize emin misiniz? Verileriniz cihazınızda saklı kalmaya devam edecek.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Vazgeç')),
          TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('ÇIKIŞ YAP')),
        ],
      ),
    );
    if (onay != true) return;

    final p = await SharedPreferences.getInstance();
    await p.setBool('is_logged_in', false);

    if (mounted) {
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (context) => const ProfilKayitEkrani()),
        (route) => false,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(color: Colors.teal.shade50, borderRadius: BorderRadius.circular(16)),
                child: Column(
                  children: [
                    const CircleAvatar(radius: 45, backgroundColor: Colors.teal, child: Icon(Icons.person, size: 50, color: Colors.white)),
                    const SizedBox(height: 12),
                    Text('$_ad $_soyad', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
                    const Divider(height: 32),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Kayıtlı Yaş:', style: TextStyle(fontSize: 16)),
                        Text('$_yas', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.teal)),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Diyabet Durumu:', style: TextStyle(fontSize: 16)),
                        Text(_diyabetTipi, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.teal)),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              ElevatedButton(onPressed: () => VeritabaniYardimcisi().veritabaniYedekleHafizaya(), child: const Text('Verileri WhatsApp\'a Yedekle')),
              const SizedBox(height: 12),
              OutlinedButton(
                onPressed: () async {
                  FilePickerResult? r = await FilePicker.platform.pickFiles();
                  if (r != null) {
                    await VeritabaniYardimcisi().yedegiGeriYukle(r.files.single.path!);
                    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Yedek WhatsApp\'tan Başarıyla Yüklendi!')));
                  }
                },
                child: const Text('Yedek Bul ve Geri Yükle'),
              ),
              const SizedBox(height: 32),
              ElevatedButton.icon(
                onPressed: _cikisYap,
                icon: const Icon(Icons.logout),
                label: const Text('ÇIKIŞ YAP'),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.grey.shade700, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 14)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
