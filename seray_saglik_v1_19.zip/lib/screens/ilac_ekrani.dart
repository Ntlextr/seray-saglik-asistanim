import 'package:flutter/material.dart';
import '../services/veritabani_yardimcisi.dart';

class IlacEkrani extends StatefulWidget {
  const IlacEkrani({Key? key}) : super(key: key);
  @override
  _IlacEkraniState createState() => _IlacEkraniState();
}

class _IlacEkraniState extends State<IlacEkrani> {
  List<Map<String, dynamic>> _ilacListesi = [];
  final _adController = TextEditingController();
  final _dozController = TextEditingController();
  TimeOfDay _secilenSaat = const TimeOfDay(hour: 9, minute: 0);

  @override
  void initState() { super.initState(); _ilaclariYukle(); }

  Future<void> _ilaclariYukle() async {
    final veriler = await VeritabaniYardimcisi().ilaclariGetir();
    setState(() => _ilacListesi = veriler);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('İlaçlarım & Alarmlar'), backgroundColor: Colors.teal, foregroundColor: Colors.white),
      body: _ilacListesi.isEmpty
          ? const Center(child: Text('Henüz ilaç eklemediniz.'))
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _ilacListesi.length,
              itemBuilder: (context, index) {
                final ilac = _ilacListesi[index];
                return Card(
                  child: ListTile(
                    leading: const Icon(Icons.medication, color: Colors.teal),
                    title: Text(ilac['ad'].toString(), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                    subtitle: Text('Doz: ${ilac['dozaj']} | Saat: ${ilac['saat']}\n🔔 Hatırlatma Sesi Aktif', style: const TextStyle(color: Colors.orange)),
                    trailing: IconButton(icon: const Icon(Icons.delete, color: Colors.red), onPressed: () async { await VeritabaniYardimcisi().ilacSil(int.parse(ilac['id'].toString())); _ilaclariYukle(); }),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          showDialog(
            context: context,
            builder: (context) => AlertDialog(
              title: const Text('İlaç Ekle'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(controller: _adController, decoration: const InputDecoration(labelText: 'İlaç Adı')),
                  TextField(controller: _dozController, decoration: const InputDecoration(labelText: 'Doz')),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () async {
                    await VeritabaniYardimcisi().ilacEkle({'ad': _adController.text, 'dozaj': _dozController.text, 'saat': _secilenSaat.format(context)});
                    Navigator.pop(context);
                    _ilaclariYukle();
                  },
                  child: const Text('EKLE'),
                )
              ],
            ),
          );
        },
        label: const Text('Hatırlatıcı Kur'),
        icon: const Icon(Icons.add_alarm),
      ),
    );
  }
}
