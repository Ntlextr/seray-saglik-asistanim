import 'package:flutter/material.dart';
import 'theme/renkler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import 'screens/profil_kayit_ekrani.dart';
import 'screens/yedek_bulundu_ekrani.dart';
import 'screens/kritik_izinler_ekrani.dart';
import 'screens/pin_kilit_ekrani.dart';
import 'services/crash_servisi.dart';
import 'screens/ana_sayfa.dart';
import 'screens/ilac_ekrani.dart';
import 'screens/analizler_ekrani.dart';
import 'screens/beslenme_ekrani.dart';
import 'screens/seray_asistan_ekrani.dart';
import 'screens/splash_animasyon_ekrani.dart';
import 'services/bildirim_servisi.dart';
import 'services/istatistik_servisi.dart';
import 'navigasyon_anahtari.dart';

// Bu dosya, Android'in ÖNBELLEK (cache) klasöründe durur — cache klasörü
// Android'in Otomatik Yedekleme'sine (Auto Backup) DAHİL EDİLMEZ, yani
// telefon değişse/uygulama silinip yeniden kurulsa bile ASLA geri gelmez.
// Bu yüzden "bu cihazda uygulama daha önce gerçekten çalıştırıldı mı"
// sorusunun cevabını güvenle verir: dosya YOKSA ama profil verisi VARSA,
// bu verinin Android'in otomatik yedeğinden geldiği (kullanıcının kendi
// az önceki kaydı olmadığı) anlaşılır.
Future<File> _cihazIziDosyasi() async {
  final gecici = await getTemporaryDirectory();
  return File('${gecici.path}/cihaz_calisti.marker');
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await crashRaporlamayiBaslat();
  final prefs = await SharedPreferences.getInstance();
  final bool isLoggedIn = prefs.getBool('is_logged_in') ?? false;
  final bool pinKilidiAktif = prefs.getBool('pin_kilit_aktif') ?? false;

  // ÖNEMLİ: Otomatik Yedekleme (Auto Backup) sessizce geri yükleme yapınca
  // kullanıcı hiç haberi olmadan eski bir profille karşılaşıyordu — "bu
  // profili nereden buldu" şaşkınlığına yol açtı. Artık iz dosyası yoksa
  // (bu cihazda uygulama HİÇ çalıştırılmamış demektir) ama profil verisi
  // VARSA (yedekten geldi demektir), kullanıcıya önce soran bir ekran
  // gösteriyoruz.
  final iziDosyasi = await _cihazIziDosyasi();
  final cihazDahaOnceCalistiMi = await iziDosyasi.exists();
  final yedekOnayiGerekli = isLoggedIn && !cihazDahaOnceCalistiMi;

  // ÖNEMLİ DÜZELTME: "kritik_izinler_gosterildi" ve "widget_banneri_gizli"
  // bayrakları SharedPreferences'ta tutuluyor — yani yedekten (otomatik ya
  // da manuel) geri geldiklerinde "zaten gösterildi/kapatıldı" diye
  // GELİYORLAR. Ama gerçekte kamera/bildirim/pil izinleri VE ana ekrandaki
  // widget, uygulama silinip yeniden kurulunca (yedekten devam edilse bile)
  // her zaman sıfırlanır — bunlar SharedPreferences'ın DIŞINDA, işletim
  // sistemi seviyesinde tutulur. Doğru sinyal "yedekten mi sıfırdan mı"
  // değil, "bu cihazda uygulama GERÇEKTEN daha önce çalıştı mı" (iz
  // dosyası — o da yedeklenmiyor). Cihaz ilk kez çalışıyorsa (silinip
  // yeniden kurulmuş olsa bile), bu iki ekran/banner MUTLAKA tekrar
  // gösterilir; sıradan bir "üstüne güncelleme"de (iz dosyası zaten var)
  // hiçbir şey değişmez, tekrar sormaz.
  if (!cihazDahaOnceCalistiMi) {
    await prefs.setBool('kritik_izinler_gosterildi', false);
    await prefs.setBool('widget_banneri_gizli', false);
  }
  final bool izinlerGosterildi = prefs.getBool('kritik_izinler_gosterildi') ?? false;

  // Tema tercihi: runApp'tan ÖNCE okunuyor ki uygulama ilk kare çizilirken
  // doğru renkte açılsın (sonradan değişirse "yanıp sönme" olmasın).
  // Yeni tema seçimi ('tema_secimi') varsa onu kullan; yoksa eski
  // 'cocuk_temasi' (evet/hayır) tercihinden geriye dönük uyumlu şekilde türet.
  final kayitliTema = prefs.getString('tema_secimi');
  if (kayitliTema != null) {
    AppRenkleri.temaAdi = kayitliTema;
  } else {
    final eskiCocukTercihi = prefs.getBool('cocuk_temasi') ?? false;
    AppRenkleri.temaAdi = eskiCocukTercihi ? 'cocuk' : 'turkuaz';
  }
  AppRenkleri.cocukTemasiAktif = AppRenkleri.temaAdi == 'cocuk';
  final bulunanAd = '${prefs.getString('kullanici_ad') ?? ''} ${prefs.getString('kullanici_soyad') ?? ''}'.trim();
  runApp(SeraySaglikUygulamasi(
    isLoggedIn: isLoggedIn,
    izinlerGosterildi: izinlerGosterildi,
    yedekOnayiGerekli: yedekOnayiGerekli,
    bulunanKullaniciAdi: bulunanAd,
    pinKilidiAktif: pinKilidiAktif,
  ));
  // Uygulama bir ilaç bildirimine dokunularak (kapalıyken) açıldıysa,
  // doğrudan tam ekran alarm sayfasını göster.
  WidgetsBinding.instance.addPostFrameCallback((_) => BildirimServisi.baslangicBildirimineBak());
  // YENİ: kullanıcı istatistik rızası verdiyse (bkz. profil_kayit_ekrani.dart),
  // her açılışta sessizce "son aktif" zaman damgasını güncelle. Rıza
  // verilmediyse veya internet yoksa fonksiyon zaten hiçbir şey yapmadan
  // sessizce geçer — kullanıcıyı asla bekletmez.
  IstatistikServisi.aktiviteBildir();
  // Bu cihazda artık gerçekten çalıştırıldığını işaretle (yeni kurulumda
  // profil ekranını tamamladıktan sonra da ayrıca işaretleniyor, burada
  // İKİ DURUMDA da (yedekli/yedeksiz) baştan işaretlemek zararsız —
  // asıl amaç bir DAHAKİ silme/kurmada bu ekranın tekrar çıkmaması).
  if (cihazDahaOnceCalistiMi == false && !yedekOnayiGerekli) {
    iziDosyasi.writeAsString('1').catchError((_) => iziDosyasi);
  }
}

class SeraySaglikUygulamasi extends StatelessWidget {
  final bool isLoggedIn;
  final bool izinlerGosterildi;
  final bool yedekOnayiGerekli;
  final String bulunanKullaniciAdi;
  final bool pinKilidiAktif;
  const SeraySaglikUygulamasi({
    Key? key,
    required this.isLoggedIn,
    required this.izinlerGosterildi,
    this.yedekOnayiGerekli = false,
    this.bulunanKullaniciAdi = '',
    this.pinKilidiAktif = false,
  }) : super(key: key);

  // Uygulama kilidi (PIN) etkinse, açılışta HER ŞEYDEN ÖNCE bu ekran
  // gösterilir — böylece telefonu eline alan biri profil/ölçüm/yedek
  // ekranlarının hiçbirini PIN girmeden göremez. Başarılı girişten sonra
  // normal akış (_sonrakiEkran) devam eder.
  Widget _baslangicEkrani() {
    if (!isLoggedIn) return const ProfilKayitEkrani();
    if (pinKilidiAktif) {
      return PinKilitEkrani(
        mod: PinKilitModu.dogrula,
        onBasarili: () {
          navigasyonAnahtari.currentState?.pushReplacement(
            MaterialPageRoute(builder: (context) => _sonrakiEkran()),
          );
        },
      );
    }
    return _sonrakiEkran();
  }  // --- _baslangicEkrani() sonu ---

  // PIN kontrolünden SONRA (ya da PIN kapalıysa doğrudan) izlenecek akış —
  // önceden _baslangicEkrani() içindeydi, PIN adımı eklenince ayrıldı.
  Widget _sonrakiEkran() {
    // Yedekten sessizce geri yüklenmiş veri varsa, önce kullanıcıya sor.
    if (yedekOnayiGerekli) {
      return YedekBulunduEkrani(
        kullaniciAdi: bulunanKullaniciAdi.trim().isEmpty ? 'Kayıtlı Kullanıcı' : bulunanKullaniciAdi,
        onDevamEt: () {
          // ÖNEMLİ DÜZELTME: Önceden burada doğrudan AnaEkranYonlendirici'ye
          // gidiliyordu — "cihaz ilk kez çalışıyorsa izin ekranı mutlaka
          // gösterilsin" kontrolü SADECE yedeksiz girişte çalışıyordu,
          // yedekten devam edildiğinde (Evet/Hayır fark etmez) izin ekranı
          // tamamen atlanıyordu. Artık burada da aynı kontrol yapılıyor.
          navigasyonAnahtari.currentState?.pushReplacement(
            MaterialPageRoute(builder: (context) => _izinSonrasiEkran()),
          );
        },
      );
    }
    return _izinSonrasiEkran();
  }  // --- _sonrakiEkran() sonu ---

  // Kayıtlı ama izin ekranını daha önce tamamlamamış (örn. yarıda bırakmış,
  // ya da cihaz gerçekten ilk kez çalışıyor) kullanıcı, ana ekrana geçmeden
  // önce bu ekranı görsün. Hem "yedeksiz giriş" hem "yedekten devam" yolunun
  // İKİSİ de artık bu TEK kontrolden geçiyor.
  Widget _izinSonrasiEkran() {
    if (!izinlerGosterildi) {
      return KritikIzinlerEkrani(
        onTamamlandi: () {
          navigasyonAnahtari.currentState?.pushReplacement(
            MaterialPageRoute(builder: (context) => const AnaEkranYonlendirici()),
          );
        },
      );
    }
    return const AnaEkranYonlendirici();
  }  // --- _izinSonrasiEkran() sonu ---

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: navigasyonAnahtari,
      title: 'Seray Sağlık Asistanım',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: AppRenkleri.aktif, scaffoldBackgroundColor: Colors.white),
      home: SplashAnimasyonEkrani(sonraki: _baslangicEkrani()),
    );
  }
}

class AnaEkranYonlendirici extends StatefulWidget {
  const AnaEkranYonlendirici({Key? key}) : super(key: key);
  @override
  _AnaEkranYonlendiriciState createState() => _AnaEkranYonlendiriciState();
}

class _AnaEkranYonlendiriciState extends State<AnaEkranYonlendirici> {
  int _seciliSekme = 0;
  // Sekme her seçildiğinde bu sayaç artar; sayfalara verilen key değiştiği için
  // Flutter o sayfayı sıfırdan kurar ve veriler (ölçümler, profil vb.) tazelenir.
  int _yenilemeSayaci = 0;

  @override
  Widget build(BuildContext context) {
    // NOT: Profil artık alt menüde değil, her ekranın sağ üstündeki
    // ☰ üst menüsünden erişiliyor (bkz. widgets/ust_menu.dart).
    // Seray AI Asistan artık alt menünün ortasında (3. sıra).
    final List<Widget> sayfalar = [
      AnaSayfa(key: ValueKey('ana_$_yenilemeSayaci')),
      AnalizlerEkrani(key: ValueKey('analiz_$_yenilemeSayaci')),
      SerayAsistanEkrani(key: ValueKey('seray_$_yenilemeSayaci')),
      IlacEkrani(key: ValueKey('ilac_$_yenilemeSayaci')),
      BeslenmeEkrani(key: ValueKey('beslenme_$_yenilemeSayaci')),
    ];
    return Scaffold(
      body: IndexedStack(index: _seciliSekme, children: sayfalar),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _seciliSekme,
        onDestinationSelected: (index) => setState(() {
          _seciliSekme = index;
          _yenilemeSayaci++;
        }),
        destinations: [
          _renkliSekme(Icons.home_outlined, Icons.home, 'Anasayfa', Colors.orange),
          _renkliSekme(Icons.analytics_outlined, Icons.analytics, 'Analizler', Colors.blue),
          _renkliSekme(Icons.health_and_safety_outlined, Icons.health_and_safety, 'Seray AI', Colors.teal),
          _renkliSekme(Icons.medication_outlined, Icons.medication, 'İlaçlarım', Colors.red),
          _renkliSekme(Icons.restaurant_menu_outlined, Icons.restaurant_menu, 'Beslenme', Colors.deepOrange),
        ],
      ),
    );
  }  // --- build() sonu ---

  // Alt menü sekmeleri için, Özet ekranındaki ölçüm kartlarıyla aynı
  // stilde (yumuşak renkli daire arka planlı ikon) bir sekme üretir.
  // ÖNEMLİ: önceden seçili OLMAYAN sekmeler gri/soluk gösteriliyordu — bu
  // "sadece tıkladığım renk değişiyor" izlenimi veriyordu. Artık TÜM
  // sekmeler HER ZAMAN kendi rengiyle renkli; aktif olan ise kalın bir
  // halka (çerçeve) ile ayrıca belirginleştiriliyor.
  NavigationDestination _renkliSekme(IconData disIkon, IconData iciIkon, String etiket, MaterialColor renk) {
    Widget daire(IconData ikon, bool secili) => Container(
          width: 38,
          height: 38,
          decoration: BoxDecoration(
            color: renk.withOpacity(0.18),
            shape: BoxShape.circle,
            border: secili ? Border.all(color: renk.shade700, width: 2.5) : null,
          ),
          child: Icon(ikon, color: renk.shade700, size: 20),
        );
    return NavigationDestination(
      icon: daire(disIkon, false),
      selectedIcon: daire(iciIkon, true),
      label: etiket,
    );
  }  // --- _renkliSekme() sonu ---
}
