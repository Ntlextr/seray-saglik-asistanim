import 'dart:io';
import 'dart:math' show pow, log, ln10;
import '../theme/renkler.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:path_provider/path_provider.dart';
import '../services/veritabani_yardimcisi.dart';
import '../services/api_service.dart';
import '../services/ses_servisi.dart';
import '../services/pdf_rapor_servisi.dart';
import '../services/profil_yoneticisi.dart';
import '../widgets/ust_menu.dart';

// Grafik sol eksenindeki sayıların düzensiz/çirkin aralıklarla (örn.
// birbirine yakın, üst üste görünen değerler) yerine yuvarlak (10/25/50/
// 100/250/500 gibi) aralıklarla gösterilmesini sağlar.
double _guzelAralik(double ham) {
  if (ham <= 0) return 1;
  final buyukluk = pow(10, (log(ham) / ln10).floor()).toDouble();
  final oran = ham / buyukluk;
  double guzelOran;
  if (oran <= 1) {
    guzelOran = 1;
  } else if (oran <= 2) {
    guzelOran = 2;
  } else if (oran <= 2.5) {
    guzelOran = 2.5;
  } else if (oran <= 5) {
    guzelOran = 5;
  } else {
    guzelOran = 10;
  }
  return guzelOran * buyukluk;
}  // --- _guzelAralik() sonu ---

class BeslenmeEkrani extends StatefulWidget {
  const BeslenmeEkrani({Key? key}) : super(key: key);
  @override
  _BeslenmeEkraniState createState() => _BeslenmeEkraniState();
}

class _BeslenmeEkraniState extends State<BeslenmeEkrani> {
  List<Map<String, dynamic>> _kayitlar = [];
  List<Map<String, dynamic>> _sekerOlcumleri = [];
  // Kalori Seyri grafiğinde çizgi↔bar seçimi — diğer ekranlardaki (Şeker/
  // Tansiyon/Su/Adım) toggle ile aynı mantık.
  bool _barGorunumu = false;

  // ÖNEMLİ: ImagePicker'ın verdiği dosya yolu geçici (cache) bir konumdur —
  // sistem bunu istediği zaman silebilir, ayrıca uygulama yedeklenirken bu
  // fotoğraflar dahil edilmiyordu. Artık her fotoğraf, diğer uygulamaların
  // yaptığı gibi kalıcı bir "yemek_fotograflari" klasörüne kopyalanıyor ve
  // veritabanına o kalıcı yolun kaydı yazılıyor.
  Future<File> _fotografiKaliciKlasoreKopyala(File kaynak) async {
    final belgeler = await getApplicationDocumentsDirectory();
    final klasor = Directory('${belgeler.path}/yemek_fotograflari');
    if (!await klasor.exists()) {
      await klasor.create(recursive: true);
    }
    final dosyaAdi = 'yemek_${DateTime.now().millisecondsSinceEpoch}.jpg';
    final hedefYolu = '${klasor.path}/$dosyaAdi';
    return kaynak.copy(hedefYolu);
  }  // --- _fotografiKaliciKlasoreKopyala() sonu ---

  static const List<String> _ogunSecenekleri = [
    'Sabah', 'Ara Öğün', 'Öğle', 'Ara Öğün 2', 'Akşam', 'Ara Öğün 3',
  ];

  @override
  void initState() {
    super.initState();
    _kayitlariYukle();
  }  // --- initState() sonu ---

  Future<void> _kayitlariYukle() async {
    final veriler = await VeritabaniYardimcisi().beslenmeKayitlariniGetir();
    final sekerler = await VeritabaniYardimcisi().sekerleriGetir();
    if (mounted) {
      setState(() {
        _kayitlar = veriler;
        _sekerOlcumleri = sekerler;
      });
    }
  }  // --- _kayitlariYukle() sonu ---

  String _tarihiBicimlendir(String? isoTarih) {
    if (isoTarih == null || isoTarih.isEmpty) return '';
    final t = DateTime.tryParse(isoTarih);
    if (t == null) return isoTarih;
    String iki(int n) => n.toString().padLeft(2, '0');
    return '${iki(t.day)}.${iki(t.month)}.${t.year} ${iki(t.hour)}:${iki(t.minute)}';
  }  // --- _tarihiBicimlendir() sonu ---

  Map<String, dynamic>? _yemekOncesiSekeri(String? yemekTarihIso) {
    final yemekTarihi = DateTime.tryParse(yemekTarihIso ?? '');
    if (yemekTarihi == null || _sekerOlcumleri.isEmpty) return null;
    Map<String, dynamic>? enYakin;
    Duration? enKisaFark;
    for (final olcum in _sekerOlcumleri) {
      final olcumTarihi = DateTime.tryParse(olcum['tarih']?.toString() ?? '');
      if (olcumTarihi == null) continue;
      final fark = yemekTarihi.difference(olcumTarihi);
      if (fark.inMinutes >= 0 && fark.inHours <= 4) {
        if (enKisaFark == null || fark < enKisaFark) {
          enKisaFark = fark;
          enYakin = olcum;
        }
      }
    }
    return enYakin;
  }  // --- _yemekOncesiSekeri() sonu ---

  Map<String, dynamic>? _yemekSonrasiSekeri(String? yemekTarihIso) {
    final yemekTarihi = DateTime.tryParse(yemekTarihIso ?? '');
    if (yemekTarihi == null || _sekerOlcumleri.isEmpty) return null;
    Map<String, dynamic>? enYakin;
    Duration? enKisaFark;
    for (final olcum in _sekerOlcumleri) {
      final olcumTarihi = DateTime.tryParse(olcum['tarih']?.toString() ?? '');
      if (olcumTarihi == null) continue;
      final fark = olcumTarihi.difference(yemekTarihi);
      if (fark.inMinutes >= 0 && fark.inHours <= 4) {
        if (enKisaFark == null || fark < enKisaFark) {
          enKisaFark = fark;
          enYakin = olcum;
        }
      }
    }
    return enYakin;
  }  // --- _yemekSonrasiSekeri() sonu ---

  Future<void> _yemekEkleFormunuAc({Map<String, dynamic>? duzenlenecekKayit}) async {
    final duzenlemeModu = duzenlenecekKayit != null;
    String? secilenOgun;
    final ozelAdController = TextEditingController(text: duzenlenecekKayit?['yemek_adi']?.toString() ?? '');
    final kaloriController = TextEditingController(text: duzenlenecekKayit?['kalori']?.toString() ?? '');
    // ÖNEMLİ: Kullanıcı istedi — kalori gibi tam makro takibi (protein/
    // karbonhidrat/yağ), AI tarafından tahmin edilip kaydedilsin.
    final proteinController = TextEditingController(text: duzenlenecekKayit?['protein']?.toString() ?? '');
    final karbonhidratController = TextEditingController(text: duzenlenecekKayit?['karbonhidrat']?.toString() ?? '');
    final yagController = TextEditingController(text: duzenlenecekKayit?['yag']?.toString() ?? '');
    DateTime secilenTarihSaat = duzenlemeModu
        ? (DateTime.tryParse(duzenlenecekKayit['tarih']?.toString() ?? '') ?? DateTime.now())
        : DateTime.now();
    File? secilenFoto = (duzenlenecekKayit?['resim_yolu']?.toString().isNotEmpty ?? false)
        ? File(duzenlenecekKayit!['resim_yolu'].toString())
        : null;
    bool aiCalisiyor = false;
    String aiAnalizMetni = duzenlenecekKayit?['ai_analiz']?.toString() ?? '';
    String uyariMetni = '';
    // YENİ: masada/tabakta birden fazla yemek varsa AI her birini AYRI
    // öğe olarak döndürüyor (bkz. api_service.dart) — bu liste dolarsa
    // kayıt sırasında TEK satır yerine her öğe kendi satırı olarak
    // kaydedilir (günlük/öğün toplamları otomatik doğru çıkar, çünkü
    // toplamlar zaten tüm satırlar üzerinden hesaplanıyor).
    List<Map<String, String>> aiOgeleri = [];

    await showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: Text(duzenlemeModu ? 'Yemek Düzenle' : 'Yemek Ekle'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Öğün seçim çipleri — önceden tanımlı, tek dokunuşla seçiliyor
                const Text('Öğün', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: _ogunSecenekleri.map((ogun) {
                    final secili = secilenOgun == ogun;
                    return ChoiceChip(
                      label: Text(ogun, style: const TextStyle(fontSize: 12)),
                      selected: secili,
                      selectedColor: AppRenkleri.aktif.shade100,
                      onSelected: (_) => setDialogState(() {
                        secilenOgun = ogun;
                        uyariMetni = '';
                      }),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 8),
                // ÖNEMLİ: Kullanıcı istedi — ana öğünlerde (Sabah/Öğle/
                // Akşam; ara öğünlerde değil) insülin/ilaç ve şeker ölçümü
                // hatırlatması. Kaydı ENGELLEMİYOR, sadece görsel bir
                // hatırlatma — kullanıcı isterse yoksayıp devam edebilir.
                if (!duzenlemeModu && ['Sabah', 'Öğle', 'Akşam'].contains(secilenOgun))
                  Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Colors.blue.shade50,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.blue.shade100),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(Icons.notifications_active_outlined, size: 18, color: Colors.blue.shade700),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'Unutmayın: yemekten önce insülininizi/ilacınızı aldınız mı ve şekerinizi ölçtünüz mü?',
                            style: TextStyle(fontSize: 12, color: Colors.blue.shade900),
                          ),
                        ),
                      ],
                    ),
                  ),
                TextField(
                  controller: ozelAdController,
                  decoration: const InputDecoration(
                    labelText: 'Özel isim (isteğe bağlı, örn: mercimek çorbası)',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.edit_note),
                    isDense: true,
                  ),
                ),
                const SizedBox(height: 14),

                // Fotoğraf seçici
                GestureDetector(
                  onTap: () async {
                    final kaynak = await showModalBottomSheet<ImageSource>(
                      context: context,
                      builder: (context) => SafeArea(
                        child: Wrap(children: [
                          ListTile(
                            leading: const Icon(Icons.camera_alt),
                            title: const Text('Fotoğraf Çek'),
                            onTap: () => Navigator.pop(context, ImageSource.camera),
                          ),
                          ListTile(
                            leading: const Icon(Icons.photo_library),
                            title: const Text('Galeriden Seç'),
                            onTap: () => Navigator.pop(context, ImageSource.gallery),
                          ),
                        ]),
                      ),
                    );
                    if (kaynak == null) return;
                    final XFile? secilen = await ImagePicker()
                        // ÖNEMLİ DÜZELTME: Kullanıcı "AI yemek fotoğraflarını
                        // iyi yorumlayamıyor" dedi — kök sebep muhtemelen bu:
                        // 640px/%65 kalite, malzemeleri/porsiyon büyüklüğünü
                        // ayırt etmek için fazla düşüktü. Rapor Analizi'ndeki
                        // gibi (1400px/%80) yükseltildi.
                        .pickImage(source: kaynak, maxWidth: 1400, imageQuality: 80);
                    if (secilen != null) {
                      final kaliciDosya = await _fotografiKaliciKlasoreKopyala(File(secilen.path));
                      setDialogState(() {
                        secilenFoto = kaliciDosya;
                        aiAnalizMetni = '';
                        uyariMetni = '';
                      });
                    }
                  },
                  child: Container(
                    height: 120,
                    decoration: BoxDecoration(
                      color: Colors.grey.shade100,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.grey.shade300),
                    ),
                    child: secilenFoto != null
                        ? ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: Image.file(secilenFoto!, fit: BoxFit.cover,
                                width: double.infinity))
                        : const Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.camera_alt, color: Colors.grey, size: 32),
                                SizedBox(height: 4),
                                Text('Fotoğraf Ekle (isteğe bağlı)', style: TextStyle(color: Colors.grey)),
                              ],
                            ),
                          ),
                  ),
                ),

                if (secilenFoto != null) ...[
                  const SizedBox(height: 8),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.orange.shade700,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      ),
                      onPressed: aiCalisiyor
                          ? null
                          : () async {
                              setDialogState(() { aiCalisiyor = true; uyariMetni = ''; aiOgeleri = []; });
                              final sonuc = await ApiService.fotograftanKaloriTahminEt(secilenFoto!);
                              // YENİ: önce çoklu-öğe formatını dene (bkz.
                              // api_service.dart'taki güncel prompt — masada
                              // birden fazla yemek varsa her biri ayrı "ÖĞE"
                              // bloğu olarak geliyor).
                              final ogeRegex = RegExp(
                                r'ÖĞE\s+\d+:\s*(.+?)\n'
                                r'Kalori:\s*(\d+)\s*kcal\s*\n'
                                r'Protein:\s*(\d+)\s*g\s*\n'
                                r'Karbonhidrat:\s*(\d+)\s*g\s*\n'
                                r'Yağ:\s*(\d+)\s*g',
                              );
                              final bulunanOgeler = ogeRegex.allMatches(sonuc).map((m) => {
                                'ad': (m.group(1) ?? '').trim(),
                                'kalori': m.group(2) ?? '',
                                'protein': m.group(3) ?? '',
                                'karbonhidrat': m.group(4) ?? '',
                                'yag': m.group(5) ?? '',
                              }).toList();
                              final toplamRegex = RegExp(
                                r'TOPLAM:\s*\n'
                                r'Kalori:\s*(\d+)\s*kcal\s*\n'
                                r'Protein:\s*(\d+)\s*g\s*\n'
                                r'Karbonhidrat:\s*(\d+)\s*g\s*\n'
                                r'Yağ:\s*(\d+)\s*g',
                              );
                              final toplamEsles = toplamRegex.firstMatch(sonuc);
                              if (toplamEsles != null) {
                                // TOPLAM bloğu bulunduysa form alanlarını
                                // toplamla doldur (öğe sayısı ne olursa olsun
                                // formdaki tekil alanlar hep "bu fotoğrafın
                                // toplamı"nı gösterir).
                                kaloriController.text = toplamEsles.group(1) ?? '';
                                proteinController.text = toplamEsles.group(2) ?? '';
                                karbonhidratController.text = toplamEsles.group(3) ?? '';
                                yagController.text = toplamEsles.group(4) ?? '';
                              } else {
                                // ESKİ FORMAT YEDEĞİ: AI beklenen kalıba
                                // uymazsa (nadiren olur), eski tekil regex ile
                                // en azından kalori/makro alanlarını doldur.
                                final kaloriEsles = RegExp(r'(\d+)\s*kcal').firstMatch(sonuc);
                                if (kaloriEsles != null) kaloriController.text = kaloriEsles.group(1) ?? '';
                                final proteinEsles = RegExp(r'Protein:\s*(\d+)').firstMatch(sonuc);
                                if (proteinEsles != null) proteinController.text = proteinEsles.group(1) ?? '';
                                final karbEsles = RegExp(r'Karbonhidrat:\s*(\d+)').firstMatch(sonuc);
                                if (karbEsles != null) karbonhidratController.text = karbEsles.group(1) ?? '';
                                final yagEsles = RegExp(r'Yağ:\s*(\d+)').firstMatch(sonuc);
                                if (yagEsles != null) yagController.text = yagEsles.group(1) ?? '';
                              }
                              setDialogState(() {
                                aiAnalizMetni = sonuc;
                                aiOgeleri = bulunanOgeler;
                                aiCalisiyor = false;
                              });
                            },
                      icon: aiCalisiyor
                          ? const SizedBox(width: 14, height: 14,
                              child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                          : const Icon(Icons.auto_awesome, size: 16),
                      label: Text(aiCalisiyor ? 'Analiz ediliyor...' : '🤖 AI ile Kalori Tahmin Et'),
                    ),
                  ),
                  if (aiAnalizMetni.isNotEmpty)
                    Container(
                      margin: const EdgeInsets.only(top: 6),
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.orange.shade50,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.orange.shade200),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // YENİ: masada birden fazla yemek algılandıysa
                          // (aiOgeleri.length > 1), her öğeyi ayrı ayrı
                          // listele + altta öğün toplamını göster. Tek öğe
                          // ise (veya parse edilemediyse) eski davranış
                          // gibi sadece ham AI metni gösterilir.
                          if (aiOgeleri.length > 1) ...[
                            ...aiOgeleri.map((oge) => Padding(
                                  padding: const EdgeInsets.only(bottom: 4),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      const Text('🍽️ ', style: TextStyle(fontSize: 12)),
                                      Expanded(
                                        child: Text(
                                          '${oge['ad']}  —  ${oge['kalori']} kcal  (P:${oge['protein']}g  K:${oge['karbonhidrat']}g  Y:${oge['yag']}g)',
                                          style: const TextStyle(fontSize: 12, height: 1.4),
                                        ),
                                      ),
                                    ],
                                  ),
                                )),
                            const Divider(height: 14),
                            Text(
                              'Öğün Toplamı: ${kaloriController.text} kcal  (P:${proteinController.text}g  K:${karbonhidratController.text}g  Y:${yagController.text}g)',
                              style: const TextStyle(fontSize: 12, height: 1.4, fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 6),
                          ] else
                            Text(aiAnalizMetni, style: const TextStyle(fontSize: 12, height: 1.4)),
                          const SizedBox(height: 4),
                          // ÖNEMLİ DÜZELTME: Kullanıcı fark etti — bu önizleme
                          // kutusunda (kaydetmeden ÖNCE) Sesli/Print/Paylaş
                          // yoktu; kaydedilmiş yemeğin detay penceresinde
                          // vardı ama burada eksikti. Aynı üçlü buraya da eklendi.
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              IconButton(
                                icon: Icon(Icons.volume_up, size: 20, color: Colors.orange.shade800),
                                tooltip: 'Sesli Dinle',
                                padding: EdgeInsets.zero,
                                constraints: const BoxConstraints(),
                                onPressed: () => SesServisi.konus(aiAnalizMetni),
                              ),
                              const SizedBox(width: 14),
                              IconButton(
                                icon: Icon(Icons.share_outlined, size: 20, color: Colors.orange.shade800),
                                tooltip: 'Paylaş',
                                padding: EdgeInsets.zero,
                                constraints: const BoxConstraints(),
                                onPressed: () async {
                                  final ad = (await ProfilYoneticisi().aktifProfil()).ad;
                                  final baslik = ozelAdController.text.trim().isNotEmpty ? ozelAdController.text.trim() : 'Yemek Kalori Tahmini';
                                  await PdfRaporServisi.analizRaporuOlusturVePaylas(
                                    kullaniciAdi: ad,
                                    baslik: baslik,
                                    analizMetni: aiAnalizMetni,
                                  );
                                },
                              ),
                              const SizedBox(width: 14),
                              IconButton(
                                icon: Icon(Icons.print_outlined, size: 20, color: Colors.orange.shade800),
                                tooltip: 'Yazdır',
                                padding: EdgeInsets.zero,
                                constraints: const BoxConstraints(),
                                onPressed: () async {
                                  final ad = (await ProfilYoneticisi().aktifProfil()).ad;
                                  final baslik = ozelAdController.text.trim().isNotEmpty ? ozelAdController.text.trim() : 'Yemek Kalori Tahmini';
                                  await PdfRaporServisi.analizRaporuYazdir(
                                    kullaniciAdi: ad,
                                    baslik: baslik,
                                    analizMetni: aiAnalizMetni,
                                  );
                                },
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                ],
                const SizedBox(height: 12),
                TextField(
                  controller: kaloriController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Kalori (kcal)',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.local_fire_department),
                    hintText: 'Örn: 450',
                  ),
                ),
                const SizedBox(height: 10),
                // ÖNEMLİ: Kullanıcı istedi — kalori gibi tam makro takibi.
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: proteinController,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(
                          labelText: 'Protein (g)',
                          border: OutlineInputBorder(),
                          isDense: true,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: TextField(
                        controller: karbonhidratController,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(
                          labelText: 'Karb. (g)',
                          border: OutlineInputBorder(),
                          isDense: true,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: TextField(
                        controller: yagController,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(
                          labelText: 'Yağ (g)',
                          border: OutlineInputBorder(),
                          isDense: true,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                InkWell(
                  onTap: () async {
                    final tarih = await showDatePicker(
                      context: context,
                      initialDate: secilenTarihSaat,
                      firstDate: DateTime(2020),
                      lastDate: DateTime.now(),
                    );
                    if (tarih == null) return;
                    final saat = await showTimePicker(
                      context: context,
                      initialTime: TimeOfDay.fromDateTime(secilenTarihSaat),
                    );
                    if (saat == null) return;
                    setDialogState(() {
                      secilenTarihSaat = DateTime(tarih.year, tarih.month, tarih.day, saat.hour, saat.minute);
                    });
                  },
                  child: InputDecorator(
                    decoration: const InputDecoration(
                      labelText: 'Tarih & Saat',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.access_time),
                    ),
                    child: Text(
                      '${secilenTarihSaat.day.toString().padLeft(2, '0')}.${secilenTarihSaat.month.toString().padLeft(2, '0')}.${secilenTarihSaat.year}  ${secilenTarihSaat.hour.toString().padLeft(2, '0')}:${secilenTarihSaat.minute.toString().padLeft(2, '0')}',
                      style: const TextStyle(fontSize: 14),
                    ),
                  ),
                ),
                // UYARI — artık gizli bir SnackBar değil, doğrudan formun içinde,
                // butonların hemen üstünde, kaçırılması imkansız şekilde gösteriliyor.
                if (uyariMetni.isNotEmpty)
                  Container(
                    margin: const EdgeInsets.only(top: 12),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Colors.red.shade50,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.red.shade300),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.error_outline, color: Colors.red.shade700, size: 18),
                        const SizedBox(width: 8),
                        Expanded(child: Text(uyariMetni, style: TextStyle(color: Colors.red.shade700, fontSize: 13))),
                      ],
                    ),
                  ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('İptal')),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: AppRenkleri.aktif, foregroundColor: Colors.white),
              onPressed: () async {
                final ozelAd = ozelAdController.text.trim();
                final yemekAdi = ozelAd.isNotEmpty
                    ? (secilenOgun != null ? '$secilenOgun — $ozelAd' : ozelAd)
                    : secilenOgun;
                if (yemekAdi == null || yemekAdi.isEmpty) {
                  setDialogState(() => uyariMetni = 'Lütfen bir öğün seçin veya özel bir isim yazın.');
                  return;
                }
                // YENİ: masada birden fazla yemek algılandıysa (ve yeni bir
                // kayıt ekleniyorsa — düzenleme modunda karışıklık olmasın
                // diye tek satır davranışı korunuyor), her öğe kendi ayrı
                // satırı olarak kaydediliyor. Böylece günlük/haftalık
                // toplamlar (zaten tüm satırları toplayarak hesaplanıyor)
                // otomatik olarak her öğeyi de içerir, ekstra bir toplam
                // hesaplama kodu gerekmiyor.
                if (!duzenlemeModu && aiOgeleri.length > 1) {
                  for (final oge in aiOgeleri) {
                    final ogeAdi = secilenOgun != null ? '$secilenOgun — ${oge['ad']}' : (oge['ad'] ?? '');
                    await VeritabaniYardimcisi().beslenmeEkle({
                      'yemek_adi': ogeAdi,
                      'kalori': oge['kalori'] ?? '',
                      'protein': oge['protein'] ?? '',
                      'karbonhidrat': oge['karbonhidrat'] ?? '',
                      'yag': oge['yag'] ?? '',
                      'resim_yolu': secilenFoto?.path ?? '',
                      'tarih': secilenTarihSaat.toIso8601String(),
                      'ai_analiz': aiAnalizMetni,
                    });
                  }
                } else {
                  final veri = {
                    'yemek_adi': yemekAdi,
                    'kalori': kaloriController.text.trim(),
                    'protein': proteinController.text.trim(),
                    'karbonhidrat': karbonhidratController.text.trim(),
                    'yag': yagController.text.trim(),
                    'resim_yolu': secilenFoto?.path ?? '',
                    'tarih': secilenTarihSaat.toIso8601String(),
                    'ai_analiz': aiAnalizMetni,
                  };
                  if (duzenlemeModu) {
                    await VeritabaniYardimcisi().beslenmeGuncelle(duzenlenecekKayit['id'] as int, veri);
                  } else {
                    await VeritabaniYardimcisi().beslenmeEkle(veri);
                  }
                }
                if (context.mounted) Navigator.pop(context);
                await _kayitlariYukle();
              },
              child: Text(duzenlemeModu ? 'Güncelle' : 'Kaydet'),
            ),
          ],
        ),
      ),
    );
  }

  // ÖNEMLİ DÜZELTME: Kullanıcı istedi — tıklanınca sadece AI analiz metni
  // değil, hangi öğün/tarih/saat olduğu + sesli dinle + yazdır + paylaş
  // olan TAM bir detay penceresi (tahlil/rapor detay pencereleriyle aynı
  // desen) açılsın.
  void _analiziGoster(Map<String, dynamic> kayit) {
    final yemekAdi = kayit['yemek_adi']?.toString() ?? '';
    final analiz = kayit['ai_analiz']?.toString() ?? '';
    final tarih = _tarihiBicimlendir(kayit['tarih']?.toString());
    final kalori = kayit['kalori']?.toString() ?? '';
    final protein = kayit['protein']?.toString() ?? '';
    final karb = kayit['karbonhidrat']?.toString() ?? '';
    final yag = kayit['yag']?.toString() ?? '';
    final ozetSatirlari = [
      if (tarih.isNotEmpty) 'Tarih/Saat: $tarih',
      if (kalori.isNotEmpty && kalori != '0') 'Kalori: $kalori kcal',
      if (protein.isNotEmpty && protein != '0') 'Protein: $protein g',
      if (karb.isNotEmpty && karb != '0') 'Karbonhidrat: $karb g',
      if (yag.isNotEmpty && yag != '0') 'Yağ: $yag g',
    ];
    final tamMetin = [...ozetSatirlari, if (analiz.isNotEmpty) '', analiz].join('\n');

    showDialog(
      context: context,
      builder: (dialogContext) => Dialog(
        insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 40),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: ConstrainedBox(
          constraints: BoxConstraints(maxHeight: MediaQuery.of(dialogContext).size.height * 0.75),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                decoration: BoxDecoration(
                  color: AppRenkleri.aktif,
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
                ),
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
                child: Row(
                  children: [
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(yemekAdi, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15), maxLines: 2, overflow: TextOverflow.ellipsis),
                    ),
                    IconButton(
                      icon: const Icon(Icons.volume_up, color: Colors.white),
                      tooltip: 'Sesli Dinle',
                      onPressed: () => SesServisi.konus(tamMetin),
                    ),
                    IconButton(
                      icon: const Icon(Icons.share_outlined, color: Colors.white),
                      tooltip: 'Paylaş',
                      onPressed: () async {
                        try {
                          final ad = (await ProfilYoneticisi().aktifProfil()).ad;
                          await PdfRaporServisi.analizRaporuOlusturVePaylas(
                            kullaniciAdi: ad,
                            baslik: yemekAdi,
                            analizMetni: tamMetin,
                          );
                        } catch (_) {}
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.print_outlined, color: Colors.white),
                      tooltip: 'Yazdır',
                      onPressed: () async {
                        try {
                          final ad = (await ProfilYoneticisi().aktifProfil()).ad;
                          await PdfRaporServisi.analizRaporuYazdir(
                            kullaniciAdi: ad,
                            baslik: yemekAdi,
                            analizMetni: tamMetin,
                          );
                        } catch (_) {}
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.close, color: Colors.white),
                      tooltip: 'Kapat',
                      onPressed: () => Navigator.pop(dialogContext),
                    ),
                  ],
                ),
              ),
              Flexible(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      for (final satir in ozetSatirlari)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 4),
                          child: Text(satir, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                        ),
                      if (analiz.isNotEmpty) ...[
                        const Divider(height: 16),
                        SelectableText(analiz, style: const TextStyle(fontSize: 14, height: 1.4)),
                      ],
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }  // --- _analiziGoster() sonu ---

  @override
  Widget build(BuildContext context) {
    final bugun = DateTime.now();
    int bugunToplam = 0;
    // ÖNEMLİ: Kullanıcı istedi — kalori gibi protein/karbonhidrat/yağ da
    // günlük toplam olarak gösterilsin.
    int bugunProtein = 0;
    int bugunKarbonhidrat = 0;
    int bugunYag = 0;
    // Son 7 günün günlük toplam kalorisi (grafik için)
    final Map<String, int> gunlukToplamlar = {};
    for (final k in _kayitlar) {
      final t = DateTime.tryParse(k['tarih']?.toString() ?? '');
      if (t == null) continue;
      final gunAnahtari = '${t.year}-${t.month.toString().padLeft(2, '0')}-${t.day.toString().padLeft(2, '0')}';
      final kal = int.tryParse(k['kalori']?.toString() ?? '0') ?? 0;
      gunlukToplamlar[gunAnahtari] = (gunlukToplamlar[gunAnahtari] ?? 0) + kal;
      if (t.year == bugun.year && t.month == bugun.month && t.day == bugun.day) {
        bugunToplam += kal;
        bugunProtein += int.tryParse(k['protein']?.toString() ?? '0') ?? 0;
        bugunKarbonhidrat += int.tryParse(k['karbonhidrat']?.toString() ?? '0') ?? 0;
        bugunYag += int.tryParse(k['yag']?.toString() ?? '0') ?? 0;
      }
    }
    final sonYediGun = gunlukToplamlar.keys.toList()..sort();
    final grafikGunleri = sonYediGun.length > 7 ? sonYediGun.sublist(sonYediGun.length - 7) : sonYediGun;

    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(
        backgroundColor: AppRenkleri.aktif,
        foregroundColor: Colors.white,
        elevation: 0,
        title: FittedBox(
          fit: BoxFit.scaleDown,
          alignment: Alignment.centerLeft,
          child: const Text('Beslenme Takibi', style: TextStyle(fontWeight: FontWeight.bold), maxLines: 1),
        ),
        actions: [
          // ÖNEMLİ DÜZELTME: Kullanıcı istedi — alttaki "Yemek Ekle" FAB'ı
          // bazı ekranlarda alt menüyle çakışıyordu. Artık üstte, her zaman
          // görünür sabit bir "+" ikonu var; FAB kaldırıldı.
          IconButton(
            icon: const Icon(Icons.add_circle, size: 28),
            tooltip: 'Yemek Ekle',
            onPressed: _yemekEkleFormunuAc,
          ),
          const UstMenu(),
        ],
      ),
      body: Column(
        children: [
          if (bugunToplam > 0)
            Container(
              margin: const EdgeInsets.fromLTRB(16, 8, 16, 0),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              decoration: BoxDecoration(
                color: Colors.orange.shade50,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.orange.shade200),
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.local_fire_department, color: Colors.orange.shade700, size: 20),
                      const SizedBox(width: 6),
                      Text('Bugün: $bugunToplam kcal',
                          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.orange.shade800, fontSize: 15)),
                    ],
                  ),
                  if (bugunProtein > 0 || bugunKarbonhidrat > 0 || bugunYag > 0) ...[
                    const SizedBox(height: 6),
                    Text(
                      'Protein: ${bugunProtein}g   •   Karbonhidrat: ${bugunKarbonhidrat}g   •   Yağ: ${bugunYag}g',
                      style: TextStyle(fontSize: 12, color: Colors.orange.shade700),
                    ),
                  ],
                ],
              ),
            ),
          // GÜNLÜK KALORİ SEYRİ GRAFİĞİ (Şeker/Tansiyon'daki gibi)
          if (grafikGunleri.length >= 2)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(12, 12, 16, 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Kalori Seyri (Son Günler)', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                      const SizedBox(height: 8),
                      Align(
                        alignment: Alignment.centerRight,
                        child: IconButton(
                          icon: Icon(_barGorunumu ? Icons.show_chart : Icons.bar_chart, size: 20, color: Colors.grey.shade600),
                          tooltip: _barGorunumu ? 'Çizgi grafiğe geç' : 'Bar grafiğe geç',
                          onPressed: () => setState(() => _barGorunumu = !_barGorunumu),
                          padding: EdgeInsets.zero,
                          constraints: const BoxConstraints(),
                        ),
                      ),
                      SizedBox(
                        height: 140,
                        child: Builder(
                          builder: (context) {
                            final tumDegerler = [for (final g in grafikGunleri) gunlukToplamlar[g]!.toDouble()];
                            final hamMinY = tumDegerler.isEmpty ? 0.0 : tumDegerler.reduce((a, b) => a < b ? a : b);
                            final hamMaxY = tumDegerler.isEmpty ? 100.0 : tumDegerler.reduce((a, b) => a > b ? a : b);
                            final aralik = _guzelAralik((hamMaxY - hamMinY) / 4);
                            // ÖNEMLİ DÜZELTME: fl_chart eksenin gerçek min/max
                            // veri değeri için AYRICA bir etiket ekliyor —
                            // bizim yuvarlak interval etiketimize yakın çıkıp
                            // üst üste biniyordu. Kullandığımız fl_chart
                            // sürümünde bunu kapatan minIncluded/maxIncluded
                            // parametresi YOK — bu yüzden eksen sınırlarını
                            // baştan interval'in tam katı olacak şekilde
                            // hesaplayıp chart'a AÇIKÇA veriyoruz.
                            final minY = (hamMinY / aralik).floor() * aralik;
                            final maxY = (hamMaxY / aralik).ceil() * aralik;
                            FlTitlesData kaloriBaslikVerisi() => FlTitlesData(
                                  topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                                  rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                                  // ÖNEMLİ DÜZELTME: Önceden sabit aralık YOKTU
                                  // (fl_chart kendi hesaplıyordu) ve alan (36px)
                                  // 3 haneli kalori sayıları için dardı — sayılar
                                  // alt alta bölünüp üst üste biniyordu. Artık
                                  // yuvarlak aralık + daha geniş alan + tek satır.
                                  leftTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: true,
                                      reservedSize: 46,
                                      interval: aralik,
                                      getTitlesWidget: (value, meta) => Text(
                                        value.toInt().toString(),
                                        style: const TextStyle(fontSize: 10),
                                        maxLines: 1,
                                        softWrap: false,
                                        overflow: TextOverflow.visible,
                                      ),
                                    ),
                                  ),
                                  bottomTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: true,
                                      reservedSize: 26,
                                      // ÖNEMLİ DÜZELTME: interval belirtilmediği için
                                      // fl_chart az sayıda gün varken (ör. 3 gün) kesirli
                                      // pozisyonlarda (0, 0.5, 1, 1.5, 2) etiket üretiyordu,
                                      // value.toInt() bunları yuvarlarken aynı tarih iki kez
                                      // görünüyordu (ör. "11.08 11.08 13.08 13.08 14.08").
                                      // interval:1 ile sadece tam sayı (gerçek gün) pozisyonlarında
                                      // etiket üretilmesi garanti ediliyor.
                                      interval: 1,
                                      getTitlesWidget: (value, meta) {
                                        final i = value.toInt();
                                        if (i < 0 || i >= grafikGunleri.length) return const SizedBox.shrink();
                                        final t = DateTime.tryParse(grafikGunleri[i]);
                                        final etiket = t != null ? '${t.day.toString().padLeft(2, '0')}.${t.month.toString().padLeft(2, '0')}' : '';
                                        return Padding(
                                          padding: const EdgeInsets.only(top: 6),
                                          child: Text(etiket, style: const TextStyle(fontSize: 10)),
                                        );
                                      },
                                    ),
                                  ),
                                );
                            if (_barGorunumu) {
                              return BarChart(
                                BarChartData(
                                  minY: minY,
                                  maxY: maxY,
                                  gridData: FlGridData(show: true, drawVerticalLine: false, horizontalInterval: aralik),
                                  titlesData: kaloriBaslikVerisi(),
                                  borderData: FlBorderData(show: false),
                                  barGroups: [
                                    for (int i = 0; i < grafikGunleri.length; i++)
                                      BarChartGroupData(x: i, barRods: [
                                        BarChartRodData(toY: gunlukToplamlar[grafikGunleri[i]]!.toDouble(), color: Colors.orange, width: 16, borderRadius: BorderRadius.circular(4)),
                                      ]),
                                  ],
                                ),
                              );
                            }
                            return LineChart(
                              LineChartData(
                                minY: minY,
                                maxY: maxY,
                                gridData: FlGridData(show: true, drawVerticalLine: false, horizontalInterval: aralik),
                                titlesData: kaloriBaslikVerisi(),
                                borderData: FlBorderData(show: false),
                                lineBarsData: [
                                  LineChartBarData(
                                    spots: [for (int i = 0; i < grafikGunleri.length; i++) FlSpot(i.toDouble(), gunlukToplamlar[grafikGunleri[i]]!.toDouble())],
                                    isCurved: true,
                                    color: Colors.orange,
                                    barWidth: 3,
                                    dotData: const FlDotData(show: true),
                                    belowBarData: BarAreaData(show: true, color: Color(0x1FFF9800)),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          Expanded(
            child: _kayitlar.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.restaurant_menu, size: 64, color: AppRenkleri.aktif.shade200),
                        const SizedBox(height: 12),
                        const Text('Henüz yemek kaydı yok.', style: TextStyle(color: Colors.grey, fontSize: 16)),
                        const SizedBox(height: 6),
                        const Text('Aşağıdaki butona basarak başlayın.', style: TextStyle(color: Colors.grey, fontSize: 12)),
                      ],
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: _kayitlar.length,
                    itemBuilder: (context, index) {
                      final kayit = _kayitlar[index];
                      final oncesiSeker = _yemekOncesiSekeri(kayit['tarih']?.toString());
                      final sonrasiSeker = _yemekSonrasiSekeri(kayit['tarih']?.toString());
                      final resimYolu = kayit['resim_yolu']?.toString() ?? '';
                      final kalori = kayit['kalori']?.toString() ?? '';
                      final aiAnaliz = kayit['ai_analiz']?.toString() ?? '';

                      return Card(
                        margin: const EdgeInsets.symmetric(vertical: 5),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(12),
                          onTap: () => _yemekEkleFormunuAc(duzenlenecekKayit: kayit),
                          child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              if (resimYolu.isNotEmpty && File(resimYolu).existsSync())
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child: Image.file(File(resimYolu), width: 70, height: 70, fit: BoxFit.cover),
                                )
                              else
                                Container(
                                  width: 70, height: 70,
                                  decoration: BoxDecoration(color: Colors.orange.shade50, borderRadius: BorderRadius.circular(8)),
                                  child: Icon(Icons.restaurant, color: Colors.orange.shade300, size: 32),
                                ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(kayit['yemek_adi']?.toString() ?? '', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                                    Text(_tarihiBicimlendir(kayit['tarih']?.toString()), style: TextStyle(fontSize: 11, color: Colors.grey.shade500)),
                                    if (kalori.isNotEmpty && kalori != '0')
                                      Padding(
                                        padding: const EdgeInsets.only(top: 2),
                                        child: Row(
                                          children: [
                                            Icon(Icons.local_fire_department, size: 13, color: Colors.orange.shade600),
                                            const SizedBox(width: 2),
                                            Text('$kalori kcal', style: TextStyle(fontSize: 12, color: Colors.orange.shade700, fontWeight: FontWeight.w600)),
                                          ],
                                        ),
                                      ),
                                    if (oncesiSeker != null || sonrasiSeker != null)
                                      Padding(
                                        padding: const EdgeInsets.only(top: 6),
                                        child: Container(
                                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                                          decoration: BoxDecoration(color: Colors.red.shade50, borderRadius: BorderRadius.circular(8)),
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              if (oncesiSeker != null) Text('🩸 Önce: ${oncesiSeker['deger']} mg/dL', style: const TextStyle(fontSize: 11, color: Colors.red)),
                                              if (sonrasiSeker != null) Text('🩸 Sonra: ${sonrasiSeker['deger']} mg/dL', style: TextStyle(fontSize: 11, color: Colors.red.shade700, fontWeight: FontWeight.bold)),
                                            ],
                                          ),
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                              // ÖNEMLİ: İlaç ekranındaki gibi — dağınık ayrı
                              // ikonlar (AI Analizi metni + Sesli Dinle +
                              // Sil) yerine artık TEK bir ⋮ menüsünde
                              // toplanıyor, kart daha temiz görünüyor.
                              PopupMenuButton<String>(
                                icon: const Icon(Icons.more_vert, color: Colors.grey),
                                onSelected: (secim) async {
                                  if (secim == 'analiz') {
                                    _analiziGoster(kayit);
                                  } else if (secim == 'sil') {
                                    await VeritabaniYardimcisi().beslenmeSil(kayit['id'] as int);
                                    await _kayitlariYukle();
                                  }
                                },
                                itemBuilder: (context) => [
                                  PopupMenuItem(
                                    value: 'analiz',
                                    child: ListTile(
                                      contentPadding: EdgeInsets.zero,
                                      leading: Icon(Icons.info_outline, color: AppRenkleri.aktif),
                                      title: const Text('Detayları Gör'),
                                    ),
                                  ),
                                  const PopupMenuItem(
                                    value: 'sil',
                                    child: ListTile(
                                      contentPadding: EdgeInsets.zero,
                                      leading: Icon(Icons.delete_outline, color: Colors.red),
                                      title: Text('Sil'),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }  // --- build() sonu ---
}
