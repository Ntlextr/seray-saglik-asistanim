import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_tts/flutter_tts.dart';
import '../services/veritabani_yardimcisi.dart';
import '../widgets/ust_menu.dart';
import 'yapay_zeka_ekrani.dart';

class AnalizlerEkrani extends StatefulWidget {
  const AnalizlerEkrani({Key? key}) : super(key: key);
  @override
  _AnalizlerEkraniState createState() => _AnalizlerEkraniState();
}

class _AnalizlerEkraniState extends State<AnalizlerEkrani> {
  List<Map<String, dynamic>> _sekerler = [];
  List<Map<String, dynamic>> _tansiyonlar = [];
  List<Map<String, dynamic>> _enabizGecmisi = [];
  List<Map<String, String>> _tahlilOzeti = [];
  bool _yukleniyor = true;
  String _diyabetTipi = "Yok";
  final FlutterTts _tts = FlutterTts();

  @override
  void initState() { super.initState(); _tts.setLanguage('tr-TR'); _verileriYukle(); }

  @override
  void dispose() { _tts.stop(); super.dispose(); }

  Future<void> _verileriYukle() async {
    final prefs = await SharedPreferences.getInstance();
    final sekerListesi = await VeritabaniYardimcisi().sekerleriGetir();
    final tansiyonListesi = await VeritabaniYardimcisi().tansiyonlariGetir();
    final enabizListesi = await VeritabaniYardimcisi().yorumlariGetir();
    final tumTahliller = await VeritabaniYardimcisi().tumTahlilleriGetir();

    final Map<String, Map<String, String>> ozetMap = {};
    for (var t in tumTahliller) {
      final ad = t['tahlil_adi'].toString();
      if (!ozetMap.containsKey(ad)) {
        ozetMap[ad] = {'ad': ad, 'sonuc': t['sonuc'].toString(), 'ref': t['referans_degeri'].toString(), 'tarih': t['tarih'].toString()};
      }
    }

    setState(() {
      _diyabetTipi = prefs.getString('user_diyabet') ?? "Yok";
      _sekerler = sekerListesi;
      _tansiyonlar = tansiyonListesi;
      _enabizGecmisi = enabizListesi;
      _tahlilOzeti = ozetMap.values.toList();
      _yukleniyor = false;
    });
  }

  bool _refDisindaMi(String? deger, String ref) {
    if (deger == null) return false;
    final sayi = double.tryParse(deger.replaceAll(',', '.'));
    final parcalar = ref.split('-');
    if (sayi == null || parcalar.length != 2) return false;
    final min = double.tryParse(parcalar[0].trim().replaceAll(',', '.'));
    final maks = double.tryParse(parcalar[1].trim().replaceAll(',', '.'));
    if (min == null || maks == null) return false;
    return sayi < min || sayi > maks;
  }

  int get _sekerYuksekSiniri {
    switch (_diyabetTipi) {
      case 'Tip 1 Diyabet':
        return 180;
      case 'Tip 2 Diyabet':
        return 140;
      case 'Gizli Şeker':
        return 100;
      default:
        return 140;
    }
  }

  String _tarihiBicimlendir(String? isoTarih) {
    if (isoTarih == null || isoTarih.isEmpty) return '';
    final t = DateTime.tryParse(isoTarih);
    if (t == null) return isoTarih;
    String iki(int n) => n.toString().padLeft(2, '0');
    return '${iki(t.day)}.${iki(t.month)}.${t.year} ${iki(t.hour)}:${iki(t.minute)}';
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: Colors.grey.shade50,
        appBar: AppBar(
          title: const Text('Sağlık Analizleri & İkazlar'),
          backgroundColor: Colors.teal,
          foregroundColor: Colors.white,
          actions: const [UstMenu()],
          bottom: const TabBar(labelColor: Colors.white, unselectedLabelColor: Colors.white70, tabs: [Tab(text: 'Şeker Seyri'), Tab(text: 'Tansiyon Seyri')]),
        ),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: ElevatedButton.icon(
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => const YapayZekaEkrani())).then((_) => _verileriYukle()),
                icon: const Icon(Icons.picture_as_pdf, color: Colors.white),
                label: const Text('E-NABIZ TAHLİL OKUMA MERKEZİ'),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.orange.shade700, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 14), minimumSize: const Size.fromHeight(48)),
              ),
            ),
            if (_enabizGecmisi.isNotEmpty) Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Geçmiş e-Nabız Tahlilleri', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Colors.black54)),
                  const SizedBox(height: 4),
                  SizedBox(
                    height: 60,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: _enabizGecmisi.length,
                      separatorBuilder: (context, index) => const SizedBox(width: 8),
                      itemBuilder: (context, index) {
                        final kayit = _enabizGecmisi[index];
                        return ActionChip(
                          avatar: const Icon(Icons.table_chart, size: 18),
                          label: Text(_tarihiBicimlendir(kayit['tarih']?.toString())),
                          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => const YapayZekaEkrani())).then((_) => _verileriYukle()),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: _yukleniyor ? const Center(child: CircularProgressIndicator()) : TabBarView(children: [_sekerSayfasi(), _tansiyonSayfasi()]),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sekerSayfasi() {
    if (_sekerler.isEmpty) return const Center(child: Text('Kayıtlı ölçüm bulunamadı.'));
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _sekerler.length,
      itemBuilder: (context, index) {
        final int deger = int.tryParse(_sekerler[index]['deger'].toString()) ?? 0;
        bool yuksekMi = deger > _sekerYuksekSiniri;
        return Card(
          color: yuksekMi ? Colors.red.shade50 : Colors.green.shade50,
          child: ListTile(
            title: Text('$deger mg/dL', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: yuksekMi ? Colors.red.shade900 : Colors.green.shade900)),
            subtitle: Text('Durum: ${_sekerler[index]['durum']}\nTarih: ${_tarihiBicimlendir(_sekerler[index]['tarih']?.toString())}'),
            trailing: IconButton(icon: const Icon(Icons.volume_up), onPressed: () => _tts.speak('Kan şekeri $deger miligram, durum: ${_sekerler[index]['durum']}')),
          ),
        );
      },
    );
  }

  Widget _tansiyonSayfasi() {
    if (_tansiyonlar.isEmpty) return const Center(child: Text('Kayıtlı ölçüm bulunamadı.'));
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _tansiyonlar.length,
      itemBuilder: (context, index) {
        final t = _tansiyonlar[index];
        return Card(
          child: ListTile(
            title: Text('${t['buyuk']}/${t['kucuk']} mmHg', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)), 
            subtitle: Text('Nabız: ${t['nabiz']} bpm\nTarih: ${_tarihiBicimlendir(t['tarih']?.toString())}'),
          ),
        );
      },
    );
  }
}
