import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import '../services/veritabani_yardimcisi.dart';

class SekerEkleEkrani extends StatefulWidget {
  const SekerEkleEkrani({Key? key}) : super(key: key);

  @override
  State<SekerEkleEkrani> createState() => _SekerEkleEkraniState();
}

class _SekerEkleEkraniState extends State<SekerEkleEkrani> {
  final FlutterTts _flutterTts = FlutterTts();
  bool _sesCaliniyor = false;
  bool _yukleniyor = true;

  // Veritabanından gelen gerçek ölçüm listesi
  List<Map<String, dynamic>> _olcumler = [];

  @override
  void initState() {
    super.initState();
    _olcumleriYukle();
  }

  Future<void> _olcumleriYukle() async {
    final liste = await VeritabaniYardimcisi().sekerleriGetir();
    if (!mounted) return;
    setState(() {
      _olcumler = liste;
      _yukleniyor = false;
    });
  }

  String _tarihiBicimlendir(String? isoTarih) {
    if (isoTarih == null) return '';
    final t = DateTime.tryParse(isoTarih);
    if (t == null) return isoTarih;
    String iki(int n) => n.toString().padLeft(2, '0');
    return '${iki(t.day)}.${iki(t.month)}.${t.year}';
  }

  // Yeni ölçüm ekleme penceresi
  void _yeniOlcumEkle() {
    final degerController = TextEditingController();
    String tip = 'Açlık';

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Padding(
              padding: EdgeInsets.only(
                left: 24,
                right: 24,
                top: 24,
                bottom: MediaQuery.of(context).viewInsets.bottom + 24,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Yeni Şeker Ölçümü',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: degerController,
                    keyboardType: TextInputType.number,
                    autofocus: true,
                    decoration: InputDecoration(
                      labelText: 'Şeker Değeri (mg/dL)',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                      prefixIcon: const Icon(Icons.bloodtype),
                    ),
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    value: tip,
                    decoration: InputDecoration(
                      labelText: 'Ölçüm Tipi',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    items: const [
                      DropdownMenuItem(value: 'Açlık', child: Text('Açlık Ölçümü')),
                      DropdownMenuItem(value: 'Tokluk', child: Text('Tokluk Ölçümü')),
                    ],
                    onChanged: (val) {
                      if (val != null) setModalState(() => tip = val);
                    },
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.teal,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      onPressed: () async {
                        final metin = degerController.text.trim();
                        final deger = int.tryParse(metin);
                        if (deger == null) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Lütfen geçerli bir sayı girin.')),
                          );
                          return;
                        }
                        bool yuksekMi = (tip == 'Açlık' && deger > 125) ||
                            (tip == 'Tokluk' && deger > 140);
                        bool dusukMu = (tip == 'Açlık' && deger < 70);
                        String durum = yuksekMi ? 'Yüksek' : (dusukMu ? 'Düşük' : 'Normal');

                        await VeritabaniYardimcisi().sekerEkle({
                          'deger': deger,
                          'durum': '$tip - $durum',
                          'tarih': DateTime.now().toIso8601String(),
                        });

                        if (context.mounted) Navigator.pop(context);
                        await _olcumleriYukle();
                      },
                      child: const Text(
                        'Kaydet',
                        style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Future<void> _olcumSil(int id) async {
    await VeritabaniYardimcisi().sekerSil(id);
    await _olcumleriYukle();
  }

  // 🔊 ŞEKER DEĞERLERİNİ ANALİZ EDİP SESLİ OKUYAN FONKSİYON
  Future<void> _sekerAnaliziniSeslendir() async {
    if (_sesCaliniyor) {
      await _flutterTts.stop();
      setState(() => _sesCaliniyor = false);
      return;
    }

    if (_olcumler.isEmpty) {
      await _flutterTts.speak("Henüz kaydedilmiş bir şeker ölçümünüz bulunmamaktadır.");
      return;
    }

    final sonOlcum = _olcumler.first;
    int deger = sonOlcum['deger'] as int;
    String durumBilgisi = (sonOlcum['durum'] ?? '').toString();
    String tip = durumBilgisi.contains('Tokluk') ? 'Tokluk' : 'Açlık';

    String durumMetni = "Son ölçümünüze göre $tip kan şekeri değeriniz $deger miligram bölü desilitredir. ";

    if (tip == 'Açlık') {
      if (deger > 125) {
        durumMetni += "Açlık şekeriniz normal sınırların üzerindedir. Lütfen beslenmenize dikkat ediniz ve doktorunuzla görüşünüz.";
      } else if (deger < 70) {
        durumMetni += "Açlık şekeriniz düşük seyretmektedir. Halsizlik veya titreme hissediyorsanız hızlı emilen bir şeker kaynağı tüketebilirsiniz.";
      } else {
        durumMetni += "Açlık şekeri seyriniz tamamen ideal ve normal sınırlardadır. Tebrik ederiz.";
      }
    } else {
      if (deger > 140) {
        durumMetni += "Tokluk şekeriniz hedef değerlerin biraz üzerinde çıkmıştır. Karbonhidrat tüketiminizi gözden geçirmenizi öneririz.";
      } else if (deger < 100) {
        durumMetni += "Tokluk şekeriniz normal sınırlardadır, gidişatınız gayet güzel.";
      } else {
        durumMetni += "Tokluk şekeri seyriniz ideal aralıktadır. Sağlıklı günler dileriz.";
      }
    }

    setState(() => _sesCaliniyor = true);
    await _flutterTts.setLanguage("tr-TR");
    await _flutterTts.setPitch(1.0);
    await _flutterTts.speak(durumMetni);

    _flutterTts.setCompletionHandler(() {
      if (mounted) setState(() => _sesCaliniyor = false);
    });
  }

  @override
  void dispose() {
    _flutterTts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Şeker Takibi', style: TextStyle(color: Color(0xFF111424), fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Color(0xFF111424)),
        actions: [
          IconButton(
            icon: Icon(
              _sesCaliniyor ? Icons.stop_circle : Icons.volume_up,
              color: Colors.blue,
              size: 28,
            ),
            onPressed: _sekerAnaliziniSeslendir,
          ),
          const SizedBox(width: 12),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _yeniOlcumEkle,
        backgroundColor: Colors.teal,
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text('Ölçüm Ekle', style: TextStyle(color: Colors.white)),
      ),
      body: _yukleniyor
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Ölçüm Geçmişiniz', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  Expanded(
                    child: _olcumler.isEmpty
                        ? const Center(
                            child: Text(
                              'Henüz kaydedilmiş bir ölçüm bulunmuyor.\nSağ alttaki + butonuyla ekleyebilirsiniz.',
                              textAlign: TextAlign.center,
                              style: TextStyle(color: Colors.grey),
                            ),
                          )
                        : ListView.builder(
                            itemCount: _olcumler.length,
                            itemBuilder: (context, index) {
                              final olcum = _olcumler[index];
                              final durum = (olcum['durum'] ?? '').toString();
                              bool yuksekMi = durum.contains('Yüksek');
                              String tip = durum.contains('Tokluk') ? 'Tokluk' : 'Açlık';

                              return Card(
                                margin: const EdgeInsets.symmetric(vertical: 6),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                child: ListTile(
                                  leading: Icon(
                                    Icons.opacity,
                                    color: yuksekMi ? Colors.red : Colors.green,
                                    size: 28,
                                  ),
                                  title: Text(
                                    '${olcum['deger']} mg/dL',
                                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                                  ),
                                  subtitle: Text('$tip Ölçümü - ${_tarihiBicimlendir(olcum['tarih']?.toString())}'),
                                  trailing: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                        decoration: BoxDecoration(
                                          color: yuksekMi ? Colors.red.shade50 : Colors.green.shade50,
                                          borderRadius: BorderRadius.circular(8),
                                        ),
                                        child: Text(
                                          yuksekMi ? 'Yüksek' : 'Normal',
                                          style: TextStyle(color: yuksekMi ? Colors.red : Colors.green, fontWeight: FontWeight.bold),
                                        ),
                                      ),
                                      IconButton(
                                        icon: const Icon(Icons.delete_outline, color: Colors.grey),
                                        onPressed: () => _olcumSil(olcum['id'] as int),
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                  ),
                ],
              ),
            ),
    );
  }
}
