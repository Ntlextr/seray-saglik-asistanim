import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/api_service.dart';
import '../services/veritabani_yardimcisi.dart';
import '../services/pdf_rapor_servisi.dart';
import '../widgets/ust_menu.dart';

class YapayZekaEkrani extends StatefulWidget {
  const YapayZekaEkrani({Key? key}) : super(key: key);
  @override
  _YapayZekaEkraniState createState() => _YapayZekaEkraniState();
}

class _YapayZekaEkraniState extends State<YapayZekaEkrani> {
  bool _yukleniyor = false;
  String _durumMesaji = "";
  String _aiYorumu = "e-Nabız PDF tahlil dosyanızı yükledikten sonra Seray AI tıbbi değerlendirmesi ve tarihli matris tablosu burada görüntülenecektir.";
  Map<String, Map<String, String>> _tabloVerisi = {};
  List<String> _tarihSutunlari = [];
  final FlutterTts _tts = FlutterTts();
  // Her kategori grubunun kendi yatay kaydırma çubuğu vardır; bunları
  // dış dikey kaydırma ile karışmaması için ayrı ayrı ScrollController'larla
  // yönetiyoruz (aksi halde bazı cihazlarda sağa kaydırma çalışmıyordu).
  final Map<String, ScrollController> _grupKaydirmaControllerlari = {};

  // 🗣️ SESLI OKUMA İÇİN METİN TEMİZLEME MOTORU (Nokta, Parantez, Yıldız Okumaz)
  String _konusmaMetniniTemizle(String metin) {
    String t = metin;
    t = t.replaceAll(RegExp(r'\]*\]'), ''); // Citations/Kaynak etiketlerini temizler
    t = t.replaceAll(RegExp(r'\([^)]*\)'), '');      // Parantez içlerini temizler
    t = t.replaceAll(RegExp(r'[\*\#\_\~\`\>]'), '');  // Markdown işaretlerini temizler
    t = t.replaceAll('%', ' yüzde ');
    t = t.replaceAll('+', ' artı ');
    t = t.replaceAll(':', ',');
    t = t.replaceAll(';', ',');
    t = t.replaceAll(RegExp(r'\s+'), ' ').trim();
    return t;
  }

  String _tahlilKisaAdi(String ad) {
    String t = ad.trim();
    if (t.contains('Alanin Aminotransferaz')) return 'ALT';
    if (t.contains('Aspartat Transaminaz')) return 'AST';
    if (t.contains('Gama Glutamil')) return 'GGT';
    if (t.contains('Açlık Kan Şekeri') || t.contains('Glukoz')) return 'Glukoz (AKŞ)';
    if (t.contains('Hemogram') || t.contains('Tam Kan')) return 'Hemogram';
    if (t.contains('Kreatinin')) return 'Kreatinin';
    if (t.contains('Trigliserid')) return 'Trigliserid';
    if (t.contains('Kolesterol')) return 'Kolesterol';
    if (t.contains('Vitamin B12')) return 'B12 Vitamini';
    if (t.contains('25-Hidroksi')) return 'D Vitamini';
    return t.length > 18 ? '${t.substring(0, 16)}..' : t;
  }

  String _kategoriBul(String tahlilAdi) {
    String t = tahlilAdi.toLowerCase();
    if (t.contains('kolesterol') || t.contains('trigliserid') || t.contains('hdl') || t.contains('ldl') || t.contains('troponin')) {
      return '🫀 Kalp & Lipid Sağlığı';
    }
    if (t.contains('üre') || t.contains('kreatinin') || t.contains('gfr') || t.contains('sodyum') || t.contains('potasyum')) {
      return '🩺 Böbrek & Elektrolit Sağlığı';
    }
    if (t.contains('b12') || t.contains('vitamin') || t.contains('ferritin') || t.contains('demir') || t.contains('folat')) {
      return '💊 Vitaminler & Mineraller';
    }
    if (t.contains('wbc') || t.contains('rbc') || t.contains('hgb') || t.contains('hemogram') || t.contains('lökosit') || t.contains('anemi')) {
      return '🩸 Kan & Hemogram Tablosu';
    }
    return '🧬 Karaciğer & Genel Metabolizma';
  }

  String _tahlilAciklamasiGetir(String tahlilAdi) {
    String t = tahlilAdi.toLowerCase();
    if (t.contains('alt') || t.contains('ast')) return 'Karaciğer hücre hasarını ve enzim fonksiyonlarını gösterir.';
    if (t.contains('kreatinin') || t.contains('üre')) return 'Böbreklerin süzme kabiliyetini ve atık atma performansını ölçer.';
    if (t.contains('b12')) return 'Sinir sistemi, beyin sağlığı ve alyuvar üretimi için kritik vitamindir.';
    if (t.contains('glukoz') || t.contains('şeker') || t.contains('hba1c')) return 'Kandaki şeker düzeyini ve uzun dönemli şeker seyrini gösterir.';
    if (t.contains('kolesterol') || t.contains('trigliserid')) return 'Damar sağlığı ve kalp hastalığı risk profilini belirler.';
    return 'Vücuttaki genel metabolik dengenin değerlendirilmesinde kullanılır.';
  }

  @override
  void initState() {
    super.initState();
    _tts.setLanguage('tr-TR');
    _tts.setSpeechRate(0.5); // Doğal konuşma hızı
    _tabloyuYukle();
  }

  @override
  void dispose() {
    _tts.stop();
    for (final c in _grupKaydirmaControllerlari.values) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _sesliOku(String metin) async { 
    await _tts.stop(); 
    final temizMetin = _konusmaMetniniTemizle(metin);
    await _tts.speak(temizMetin); 
  }

  Future<void> _tabloyuYukle() async {
    final tahliller = await VeritabaniYardimcisi().tumTahlilleriGetir();
    Map<String, Map<String, String>> geciciTablo = {};
    Set<String> tarihler = {};
    for (var t in tahliller) {
      String tarih = t['tarih'].toString();
      String ad = t['tahlil_adi'].toString();
      String sonuc = t['sonuc'].toString();
      String ref = t['referans_degeri'].toString();
      tarihler.add(tarih);
      if (!geciciTablo.containsKey(ad)) geciciTablo[ad] = {"_ref": ref};
      geciciTablo[ad]![tarih] = sonuc;
    }
    setState(() { 
      _tabloVerisi = geciciTablo; 
      _tarihSutunlari = tarihler.toList()..sort((a, b) => b.compareTo(a)); 
    });
  }

  Future<String> _dosyaMetniniOku(String yol) async {
    if (yol.toLowerCase().endsWith('.pdf')) {
      final belge = PdfDocument(inputBytes: File(yol).readAsBytesSync());
      final metin = PdfTextExtractor(belge).extractText();
      belge.dispose();
      return metin;
    }
    return File(yol).readAsString();
  }

  String? _metindenTarihCikar(String metin) {
    final regex = RegExp(r'\b(\d{2}[\.\/]\d{2}[\.\/]\d{4}|\d{4}[\-\.\/]\d{2}[\-\.\/]\d{2})\b');
    final match = regex.firstMatch(metin);
    return match?.group(0);
  }

  Future<void> _pdfSecVeAnalizEt() async {
    FilePickerResult? sonuc = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pdf', 'txt']);
    if (sonuc != null && sonuc.files.single.path != null) {
      setState(() { _yukleniyor = true; _durumMesaji = "PDF kontrol ediliyor..."; });
      try {
        final gercekMetin = await _dosyaMetniniOku(sonuc.files.single.path!);
        
        final yuklenenTarih = _metindenTarihCikar(gercekMetin);
        if (yuklenenTarih != null && _tarihSutunlari.contains(yuklenenTarih)) {
          setState(() { _yukleniyor = false; _durumMesaji = ""; });
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('⚠️ $yuklenenTarih tarihli tahlil kaydı veritabanında zaten var!'),
              backgroundColor: Colors.orange.shade800,
              duration: const Duration(seconds: 4),
            ),
          );
          return;
        }

        setState(() { _durumMesaji = "PDF yapay zeka ile taranıyor..."; });

        final cevap = await ApiService.tahlilMetniniAnalizEt(gercekMetin);
        
        // --- EKSİK KÖPRÜ: VERİTABANINA KAYIT (TABLOLARIN DOLMASI İÇİN) ---
        final tarihStr = yuklenenTarih ?? DateTime.now().toIso8601String();
        
        // Yapay Zeka Yorumunu Veritabanına Kaydediyoruz
        await VeritabaniYardimcisi().yorumEkle({
          'tarih': tarihStr,
          'yorum': cevap,
        });

        // PDF metninden satırları ayrıştırıp tahlil tablosuna kaydediyoruz
        final satirlar = gercekMetin.split('\n');
        for (var satir in satirlar) {
          final parcalar = satir.split(RegExp(r'\s{2,}'));
          if (parcalar.length >= 3) {
            final tahlilAdi = parcalar[0].trim();
            final sonucDegeri = parcalar[1].trim();
            final refDegeri = parcalar[2].trim();
            
            if (tahlilAdi.isNotEmpty && sonucDegeri.isNotEmpty) {
              await VeritabaniYardimcisi().tahlilEkle({
                'tarih': tarihStr,
                'tahlil_adi': tahlilAdi,
                'sonuc': sonucDegeri,
                'referans_degeri': refDegeri,
              });
            }
          }
        }
        // -------------------------------------------------------------

        setState(() { _yukleniyor = false; _durumMesaji = ""; _aiYorumu = cevap; });
        _tabloyuYukle();
      } catch (e) {
        setState(() { _yukleniyor = false; _durumMesaji = ""; _aiYorumu = "Dosya işlenirken hata oluştu: $e"; });
      }
    }
  }

  Future<void> _yazdirPaylas() async {
    final prefs = await SharedPreferences.getInstance();
    final ad = prefs.getString('user_ad') ?? '';
    final soyad = prefs.getString('user_soyad') ?? '';
    await PdfRaporServisi.enabizRaporuOlusturVePaylas(
      tabloVerisi: _tabloVerisi,
      tarihSutunlari: _tarihSutunlari,
      kullaniciAdi: '$ad $soyad',
    );
  }

  bool _refDisindaMi(String? deger, String ref) {
    if (deger == null) return false;
    final sayi = double.tryParse(deger.replaceAll(',', '.'));
    final parcalar = ref.split('-');
    if (sayi == null || parcalar.length != 2) return false;
    final min = double.tryParse(parcalar[0].trim().replaceAll(',', '.'));
    final maks = double.tryParse(parcalar[1].trim().replaceAll(',', '.'));
    if (min == null || maks == null) return false;
    return sayi < min || sayi > maks;
  }

  // Bir kategori grubundaki tüm tahlillerin en güncel tarihine göre
  // sesli bir özet metni üretir (örn. "Kolesterol referans dışı, diğerleri normal").
  String _grupAnaliziniOlustur(String kategori, List<MapEntry<String, Map<String, String>>> tahliller) {
    if (_tarihSutunlari.isEmpty) return '$kategori grubunda henüz yeterli veri yok.';
    final sonTarih = _tarihSutunlari.first;
    final List<String> refDisiOlanlar = [];
    final List<String> normalOlanlar = [];

    for (final entry in tahliller) {
      final deger = entry.value[sonTarih];
      final ref = entry.value['_ref'] ?? '-';
      if (deger == null) continue;
      final kisaAd = _tahlilKisaAdi(entry.key);
      if (_refDisindaMi(deger, ref)) {
        refDisiOlanlar.add('$kisaAd, $deger');
      } else {
        normalOlanlar.add(kisaAd);
      }
    }

    final buffer = StringBuffer();
    buffer.write('$kategori grubunda, en son ölçümlerinize göre: ');
    if (refDisiOlanlar.isEmpty) {
      buffer.write('bu gruptaki tüm değerleriniz referans aralığında ve normal görünüyor.');
    } else {
      buffer.write('${refDisiOlanlar.join(', ')} değerleri referans aralığının dışında çıkmıştır. ');
      buffer.write('Bu konuda doktorunuzla görüşmenizi öneririz. ');
      if (normalOlanlar.isNotEmpty) {
        buffer.write('${normalOlanlar.join(', ')} değerleriniz ise normal sınırlardadır.');
      }
    }
    return buffer.toString();
  }

  // Bir tahlile ait bilgi kartını POPUP (PopupMenuButton/Dialog) OLARAK DEĞİL,
  // alttan kayan tam genişlikte bir bilgi kartı (bottom sheet) olarak açar.
  void _tahlilBilgiKartiniAc(String tahlilAdi, String ref) {
    final aciklama = _tahlilAciklamasiGetir(tahlilAdi);
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 40,
                height: 4,
                margin: const EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      tahlilAdi,
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.teal),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.volume_up, color: Colors.teal),
                    onPressed: () => _sesliOku('$tahlilAdi. $aciklama. Referans aralığı $ref.'),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Text('Referans Aralığı: $ref', style: TextStyle(fontSize: 13, color: Colors.grey.shade700, fontWeight: FontWeight.bold)),
              const Divider(height: 24),
              Text(aciklama, style: const TextStyle(fontSize: 15, height: 1.5, color: Color(0xFF111424))),
              const SizedBox(height: 12),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final Map<String, List<MapEntry<String, Map<String, String>>>> gruplanmisTahliller = {};
    for (var entry in _tabloVerisi.entries) {
      final kat = _kategoriBul(entry.key);
      gruplanmisTahliller.putIfAbsent(kat, () => []).add(entry);
    }

    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(
        title: const Text('Seray AI - e-Nabız Tahlil Matrisi'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
        actions: const [UstMenu()],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            ElevatedButton.icon(
              onPressed: _yukleniyor ? null : _pdfSecVeAnalizEt,
              icon: const Icon(Icons.picture_as_pdf),
              label: const Text('E-NABIZ PDF TAHLİL DOSYASI YÜKLE'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.teal,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            if (_yukleniyor) Padding(
              padding: const EdgeInsets.only(top: 16),
              child: Column(children: [const LinearProgressIndicator(color: Colors.teal), const SizedBox(height: 8), Text(_durumMesaji)]),
            ),
            const SizedBox(height: 16),

            Card(
              elevation: 2,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              color: Colors.teal.shade50,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const CircleAvatar(
                          backgroundColor: Colors.teal,
                          child: Icon(Icons.psychology, color: Colors.white),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            _tarihSutunlari.length > 1
                                ? 'Seray AI Tarihsel Karşılaştırma & Değişim Analizi'
                                : 'Seray AI Laboratuvar Değerlendirmesi',
                            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Colors.teal),
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.volume_up, color: Colors.teal),
                          onPressed: () => _sesliOku(_aiYorumu),
                        ),
                      ],
                    ),
                    const Divider(),
                    Text(
                      _aiYorumu,
                      style: const TextStyle(fontSize: 14, height: 1.4, color: Color(0xFF111424)),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            if (_tabloVerisi.isNotEmpty) ...[
              OutlinedButton.icon(
                onPressed: _yazdirPaylas,
                icon: const Icon(Icons.print, color: Colors.teal),
                label: const Text('TAHLİL MATRİSİNİ PDF YAZDIR / PAYLAŞ', style: TextStyle(color: Colors.teal)),
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: Colors.teal),
                  padding: const EdgeInsets.symmetric(vertical: 12),
                ),
              ),
              const SizedBox(height: 16),
            ],

            if (_tabloVerisi.isNotEmpty)
              ...gruplanmisTahliller.entries.map((grup) {
                _grupKaydirmaControllerlari.putIfAbsent(grup.key, () => ScrollController());
                return Card(
                  margin: const EdgeInsets.only(bottom: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  child: ExpansionTile(
                    initiallyExpanded: true,
                    title: Row(
                      children: [
                        Expanded(
                          child: Text(
                            grup.key,
                            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: Colors.teal),
                          ),
                        ),
                        // HER GRUP İÇİN AYRI SESLİ ANALİZ BUTONU
                        IconButton(
                          icon: const Icon(Icons.volume_up, color: Colors.teal),
                          tooltip: 'Bu grubu sesli dinle: ${grup.key}',
                          onPressed: () => _sesliOku(_grupAnaliziniOlustur(grup.key, grup.value)),
                        ),
                      ],
                    ),
                    children: [
                      Scrollbar(
                        controller: _grupKaydirmaControllerlari[grup.key],
                        thumbVisibility: true,
                        child: SingleChildScrollView(
                          controller: _grupKaydirmaControllerlari[grup.key],
                          scrollDirection: Axis.horizontal,
                          physics: const ClampingScrollPhysics(),
                          child: DataTable(
                          columnSpacing: 18,
                          horizontalMargin: 12,
                          headingRowColor: MaterialStateProperty.all(Colors.teal.shade100),
                          columns: [
                            const DataColumn(label: Text('Tahlil & Ref', style: TextStyle(fontWeight: FontWeight.bold))),
                            ..._tarihSutunlari.map((t) => DataColumn(label: Text(t, style: const TextStyle(fontWeight: FontWeight.bold)))),
                          ],
                          rows: grup.value.map((entry) {
                            final ref = entry.value["_ref"] ?? "-";
                            final kisaAd = _tahlilKisaAdi(entry.key);

                            return DataRow(cells: [
                              DataCell(
                                InkWell(
                                  onTap: () => _tahlilBilgiKartiniAc(entry.key, ref),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Text(kisaAd, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                                          Text('Ref: $ref', style: TextStyle(fontSize: 10, color: Colors.grey.shade600)),
                                        ],
                                      ),
                                      const SizedBox(width: 4),
                                      const Icon(Icons.info_outline, size: 14, color: Colors.teal),
                                    ],
                                  ),
                                ),
                              ),
                              ..._tarihSutunlari.map((t) {
                                final deger = entry.value[t];
                                final refDisi = _refDisindaMi(deger, ref);
                                return DataCell(
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: refDisi ? Colors.red.shade50 : Colors.transparent,
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    child: Text(
                                      deger ?? "-",
                                      style: TextStyle(
                                        color: refDisi ? Colors.red.shade900 : Colors.black87,
                                        fontWeight: refDisi ? FontWeight.bold : FontWeight.normal,
                                      ),
                                    ),
                                  ),
                                );
                              }),
                            ]);
                          }).toList(),
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              }),
          ],
        ),
      ),
    );
  }
}
