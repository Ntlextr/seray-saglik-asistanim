import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import '../services/veritabani_yardimcisi.dart';

class TansiyonEkleEkrani extends StatefulWidget {
  const TansiyonEkleEkrani({Key? key}) : super(key: key);

  @override
  State<TansiyonEkleEkrani> createState() => _TansiyonEkleEkraniState();
}

class _TansiyonEkleEkraniState extends State<TansiyonEkleEkrani> {
  final FlutterTts _flutterTts = FlutterTts();
  bool _sesCaliniyor = false;
  bool _yukleniyor = true;

  List<Map<String, dynamic>> _olcumler = [];

  @override
  void initState() {
    super.initState();
    _olcumleriYukle();
  }

  Future<void> _olcumleriYukle() async {
    final liste = await VeritabaniYardimcisi().tansiyonlariGetir();
    if (!mounted) return;
    setState(() {
      _olcumler = liste;
      _yukleniyor = false;
    });
  }

  String _tarihiBicimlendir(String? isoTarih) {
    if (isoTarih == null) return '';
    final t = DateTime.tryParse(isoTarih);
    if (t == null) return isoTarih;
    String iki(int n) => n.toString().padLeft(2, '0');
    return '${iki(t.day)}.${iki(t.month)}.${t.year}';
  }

  void _yeniOlcumEkle() {
    final buyukController = TextEditingController();
    final kucukController = TextEditingController();
    final nabizController = TextEditingController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        return Padding(
          padding: EdgeInsets.only(
            left: 24,
            right: 24,
            top: 24,
            bottom: MediaQuery.of(context).viewInsets.bottom + 24,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Yeni Tansiyon Ölçümü',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: buyukController,
                keyboardType: TextInputType.number,
                autofocus: true,
                decoration: InputDecoration(
                  labelText: 'Büyük Tansiyon (Sistolik)',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  prefixIcon: const Icon(Icons.favorite),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: kucukController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'Küçük Tansiyon (Diastolik)',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  prefixIcon: const Icon(Icons.favorite_border),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: nabizController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'Nabız (isteğe bağlı)',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  prefixIcon: const Icon(Icons.monitor_heart_outlined),
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.teal.shade700,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  onPressed: () async {
                    final buyuk = int.tryParse(buyukController.text.trim());
                    final kucuk = int.tryParse(kucukController.text.trim());
                    final nabiz = int.tryParse(nabizController.text.trim());

                    if (buyuk == null || kucuk == null) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Lütfen büyük ve küçük tansiyon değerlerini girin.')),
                      );
                      return;
                    }

                    await VeritabaniYardimcisi().tansiyonEkle({
                      'buyuk': buyuk,
                      'kucuk': kucuk,
                      'nabiz': nabiz,
                      'tarih': DateTime.now().toIso8601String(),
                    });

                    if (context.mounted) Navigator.pop(context);
                    await _olcumleriYukle();
                  },
                  child: const Text(
                    'Kaydet',
                    style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _olcumSil(int id) async {
    await VeritabaniYardimcisi().tansiyonSil(id);
    await _olcumleriYukle();
  }

  // 🔊 TANSİYON DEĞERLERİNİ ANALİZ EDİP SESLİ OKUYAN FONKSİYON
  Future<void> _tansiyonAnaliziniSeslendir() async {
    if (_sesCaliniyor) {
      await _flutterTts.stop();
      setState(() => _sesCaliniyor = false);
      return;
    }

    if (_olcumler.isEmpty) {
      await _flutterTts.speak("Henüz kaydedilmiş bir tansiyon ölçümünüz bulunmamaktadır.");
      return;
    }

    final sonOlcum = _olcumler.first;
    int buyuk = sonOlcum['buyuk'] as int;
    int kucuk = sonOlcum['kucuk'] as int;

    String durumMetni = "Son ölçümünüze göre büyük tansiyonunuz $buyuk, küçük tansiyonunuz $kucuk değerindedir. ";

    if (buyuk > 135 || kucuk > 85) {
      durumMetni += "Tansiyon değerleriniz normal sınırların biraz üzerinde seyretmektedir. Lütfen dinlenip tekrar ölçüm yapınız.";
    } else if (buyuk < 90 || kucuk < 60) {
      durumMetni += "Tansiyon değerleriniz normal sınırların altında seyretmektedir. Halsizlik hissediyorsanız lütfen doktorunuza danışınız.";
    } else {
      durumMetni += "Tansiyon seyriniz tamamen ideal ve normal sınırlardadır. Sağlıklı günler dileriz.";
    }

    setState(() => _sesCaliniyor = true);
    await _flutterTts.setLanguage("tr-TR");
    await _flutterTts.setPitch(1.0);
    await _flutterTts.speak(durumMetni);

    _flutterTts.setCompletionHandler(() {
      if (mounted) setState(() => _sesCaliniyor = false);
    });
  }

  @override
  void dispose() {
    _flutterTts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Tansiyon Takibi', style: TextStyle(color: Color(0xFF111424), fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Color(0xFF111424)),
        actions: [
          IconButton(
            icon: Icon(
              _sesCaliniyor ? Icons.stop_circle : Icons.volume_up,
              color: Colors.blue,
              size: 28,
            ),
            onPressed: _tansiyonAnaliziniSeslendir,
          ),
          const SizedBox(width: 12),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _yeniOlcumEkle,
        backgroundColor: Colors.teal.shade700,
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text('Ölçüm Ekle', style: TextStyle(color: Colors.white)),
      ),
      body: _yukleniyor
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Ölçüm Geçmişiniz', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  Expanded(
                    child: _olcumler.isEmpty
                        ? const Center(
                            child: Text(
                              'Henüz kaydedilmiş bir ölçüm bulunmuyor.\nSağ alttaki + butonuyla ekleyebilirsiniz.',
                              textAlign: TextAlign.center,
                              style: TextStyle(color: Colors.grey),
                            ),
                          )
                        : ListView.builder(
                            itemCount: _olcumler.length,
                            itemBuilder: (context, index) {
                              final olcum = _olcumler[index];
                              final buyuk = olcum['buyuk'] as int;
                              final kucuk = olcum['kucuk'] as int;
                              bool yuksekMi = buyuk > 135 || kucuk > 85;

                              return Card(
                                margin: const EdgeInsets.symmetric(vertical: 6),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                child: ListTile(
                                  leading: Icon(
                                    Icons.favorite,
                                    color: yuksekMi ? Colors.red : Colors.green,
                                    size: 28,
                                  ),
                                  title: Text(
                                    '$buyuk / $kucuk mmHg',
                                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                                  ),
                                  subtitle: Text(_tarihiBicimlendir(olcum['tarih']?.toString())),
                                  trailing: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                        decoration: BoxDecoration(
                                          color: yuksekMi ? Colors.red.shade50 : Colors.green.shade50,
                                          borderRadius: BorderRadius.circular(8),
                                        ),
                                        child: Text(
                                          yuksekMi ? 'Yüksek' : 'Normal',
                                          style: TextStyle(color: yuksekMi ? Colors.red : Colors.green, fontWeight: FontWeight.bold),
                                        ),
                                      ),
                                      IconButton(
                                        icon: const Icon(Icons.delete_outline, color: Colors.grey),
                                        onPressed: () => _olcumSil(olcum['id'] as int),
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                  ),
                ],
              ),
            ),
    );
  }
}
