import 'dart:convert';
import 'package:google_generative_ai/google_generative_ai.dart';

class ApiService {
  // API Key'i doğrudan koda yazmak yerine derleme parametresinden alıyoruz.
  // Test ederken veya çalıştırırken '--dart-define=GEMINI_KEY=SENIN_KEYIN' şeklinde verilebilir.
  static const String _apiKey = String.fromEnvironment(
    'GEMINI_KEY', 
    defaultValue: 'BURAYA_TEST_KEY_YAZILABILIR' // Yerel testlerin için
  );

  static Future<String> tahlilMetniniAnalizEt(String metin) async {
    if (_apiKey.isEmpty || _apiKey == 'BURAYA_TEST_KEY_YAZILABILIR') {
      return "Uyarı: Geçerli bir Gemini API anahtarı bulunamadı. Lütfen --dart-define=GEMINI_KEY=... parametresini kontrol edin.";
    }
    
    try {
      final model = GenerativeModel(
        model: 'gemini-1.5-flash',
        apiKey: _apiKey,
      );
      
      final prompt = '''
Sen kıdemli, şefkatli ve çok dikkatli bir sağlık asistanısın. Aşağıda kullanıcının e-Nabız sisteminden alınan tahlil sonuçları metni yer almaktadır. 
Bu sonuçları teknik terimlere boğmadan, son derece anlaşılır, sakinleştirici ve empatik bir dille analiz et. 
Özellikle sınır değerlerin dışındaki sonuçları açıkça belirt ve kullanıcının doktoruna başvurması gereken durumlar için nazikçe yönlendirme yap.

Tahlil Metni:
$metin
''';

      final response = await model.generateContent([Content.text(prompt)]);
      return response.text ?? "Analiz oluşturulamadı, lütfen tekrar deneyin.";
      
    } catch (e) {
      return "Yapay zeka analizi sırasında bir hata oluştu: $e";
    }
  }
}
