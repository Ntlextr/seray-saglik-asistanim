package com.serayteknoloji.saglik_asistanim

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
