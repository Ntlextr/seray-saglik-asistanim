import 'package:flutter/material.dart';
import '../services/veritabani_yardimcisi.dart';

class AnalizlerEkrani extends StatefulWidget {
  const AnalizlerEkrani({Key? key}) : super(key: key);

  @override
  _AnalizlerEkraniState createState() => _AnalizlerEkraniState();
}

class _AnalizlerEkraniState extends State<AnalizlerEkrani> {
  List<Map<String, dynamic>> _sekerler = [];
  List<Map<String, dynamic>> _tansiyonlar = [];
  bool _yukleniyor = true;

  @override
  void initState() {
    super.initState();
    _verileriYukle();
  }

  Future<void> _verileriYukle() async {
    try {
      final sekerListesi = await VeritabaniYardimcisi().sekerleriGetir();
      final tansiyonListesi = await VeritabaniYardimcisi().tansiyonlariGetir();
      setState(() {
        _sekerler = sekerListesi;
        _tansiyonlar = tansiyonListesi;
        _yukleniyor = false;
      });
    } catch (e) {
      setState(() => _yukleniyor = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: Colors.grey.shade50,
        appBar: AppBar(
          title: const Text('Sağlık Analizleri & İkazlar'),
          backgroundColor: Colors.teal,
          foregroundColor: Colors.white,
          bottom: const TabBar(
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white70,
            indicatorColor: Colors.white,
            tabs: [
              Tab(icon: Icon(Icons.bloodtype), text: 'Şeker Seyri'),
              Tab(icon: Icon(Icons.favorite), text: 'Tansiyon Seyri'),
            ],
          ),
        ),
        body: _yukleniyor
            ? const Center(child: CircularProgressIndicator())
            : TabBarView(
                children: [
                  _sekerGrafikSayfasi(),
                  _tansiyonGrafikSayfasi(),
                ],
              ),
      ),
    );
  }

  Widget _sekerGrafikSayfasi() {
    if (_sekerler.isEmpty) {
      return const Center(child: Text('Kayıtlı şeker ölçümü bulunamadı.', style: TextStyle(fontSize: 18, color: Colors.black54)));
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _sekerler.length,
      itemBuilder: (context, index) {
        final veri = _sekerler[index];
        final int deger = int.tryParse(veri['deger'].toString()) ?? 0;
        
        bool yuksekMi = deger > 140;
        Color kartRengi = yuksekMi ? Colors.red.shade50 : Colors.green.shade50;
        Color yaziRengi = yuksekMi ? Colors.red.shade900 : Colors.green.shade900;

        return Card(
          color: kartRengi,
          margin: const EdgeInsets.only(bottom: 12),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween, // DÜZELTME: Nesne adı tam yazıldı
                  children: [
                    Text('${veri['durum']} Ölçümü', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: yaziRengi)),
                    if (yuksekMi) 
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(color: Colors.red, borderRadius: BorderRadius.circular(8)),
                        child: const Text('YÜKSEK DEĞER', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 11)),
                      ),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween, // DÜZELTME: Nesne adı tam yazıldı
                  children: [
                    Text('$deger mg/dL', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: yaziRengi)),
                    IconButton(
                      icon: const Icon(Icons.volume_up, size: 28, color: Colors.black54),
                      onPressed: () {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('Sesli Okunuyor: Şeker değeriniz $deger mg/dL. ${yuksekMi ? "Dikkat, sınır aşılmış!" : "Normal seviye."}')),
                        );
                      },
                    )
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _tansiyonGrafikSayfasi() {
    if (_tansiyonlar.isEmpty) {
      return const Center(child: Text('Kayıtlı tansiyon ölçümü bulunamadı.', style: TextStyle(fontSize: 18, color: Colors.black54)));
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _tansiyonlar.length,
      itemBuilder: (context, index) {
        final veri = _tansiyonlar[index];
        final int buyuk = int.tryParse(veri['buyuk'].toString()) ?? 0;
        final int kucuk = int.tryParse(veri['kucuk'].toString()) ?? 0;

        bool yuksekMi = buyuk > 135 || kucuk > 85;
        Color kartRengi = yuksekMi ? Colors.orange.shade50 : Colors.teal.shade50;

        return Card(
          color: kartRengi,
          margin: const EdgeInsets.only(bottom: 12),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              children: [
                Icon(Icons.favorite, color: yuksekMi ? Colors.red : Colors.teal, size: 36),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Büyük / Küçük Tansiyon', style: TextStyle(fontSize: 14, color: Colors.grey.shade700)),
                      const SizedBox(height: 4),
                      Text('$buyuk / $kucuk mm Hg', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                      if (yuksekMi) const Text('⚠️ Limit Aşımı İkazı', style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold, fontSize: 13)),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    const Text('Nabız', style: TextStyle(fontSize: 12, color: Colors.black54)),
                    Text('${veri['nabiz']} bpm', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.blue)),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
