import 'package:flutter/material.dart';
import '../services/veritabani_yardimcisi.dart';
import '../services/bildirim_servisi.dart';
import '../widgets/ust_menu.dart';

class IlacEkrani extends StatefulWidget {
  const IlacEkrani({Key? key}) : super(key: key);
  @override
  _IlacEkraniState createState() => _IlacEkraniState();
}

class _IlacEkraniState extends State<IlacEkrani> {
  List<Map<String, dynamic>> _ilacListesi = [];

  @override
  void initState() {
    super.initState();
    BildirimServisi.baslat();
    _ilaclariYukle();
  }

  Future<void> _ilaclariYukle() async {
    final veriler = await VeritabaniYardimcisi().ilaclariGetir();
    if (mounted) setState(() => _ilacListesi = veriler);
  }

  // Hem yeni ilaç eklerken hem de mevcut bir ilacı düzenlerken kullanılan diyalog.
  void _ilacFormunuAc({Map<String, dynamic>? duzenlenecekIlac}) {
    final adController = TextEditingController(text: duzenlenecekIlac?['ad']?.toString() ?? '');
    final dozController = TextEditingController(text: duzenlenecekIlac?['dozaj']?.toString() ?? '');
    TimeOfDay secilenSaat = const TimeOfDay(hour: 9, minute: 0);
    if (duzenlenecekIlac != null && duzenlenecekIlac['saat'] != null) {
      final parcalar = duzenlenecekIlac['saat'].toString().split(':');
      if (parcalar.length == 2) {
        final saat = int.tryParse(parcalar[0].trim());
        final dakika = int.tryParse(parcalar[1].trim().split(' ').first);
        if (saat != null && dakika != null) secilenSaat = TimeOfDay(hour: saat, minute: dakika);
      }
    }

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: Text(duzenlenecekIlac == null ? 'İlaç Ekle' : 'İlacı Düzenle'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: adController, decoration: const InputDecoration(labelText: 'İlaç Adı')),
              TextField(controller: dozController, decoration: const InputDecoration(labelText: 'Doz')),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Hatırlatma Saati:', style: TextStyle(fontSize: 15)),
                  TextButton.icon(
                    icon: const Icon(Icons.access_time),
                    label: Text(secilenSaat.format(context), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    onPressed: () async {
                      final yeniSaat = await showTimePicker(context: context, initialTime: secilenSaat);
                      if (yeniSaat != null) setDialogState(() => secilenSaat = yeniSaat);
                    },
                  ),
                ],
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Vazgeç')),
            TextButton(
              onPressed: () async {
                if (adController.text.trim().isEmpty) return;
                final veri = {'ad': adController.text.trim(), 'dozaj': dozController.text.trim(), 'saat': secilenSaat.format(context)};
                int ilacId;
                if (duzenlenecekIlac == null) {
                  ilacId = await VeritabaniYardimcisi().ilacEkle(veri);
                } else {
                  ilacId = int.parse(duzenlenecekIlac['id'].toString());
                  await VeritabaniYardimcisi().ilacGuncelle(ilacId, veri);
                }
                // İlaç kaydı her durumda tamamlanmalı; alarm kurulamasa bile
                // (izin verilmediyse vb.) kullanıcı ilacı ekleyebilmeli.
                try {
                  await BildirimServisi.ilacHatirlaticisiKur(id: ilacId, ilacAdi: adController.text.trim(), saat: secilenSaat);
                } catch (e) {
                  debugPrint('Hatırlatıcı kurulamadı: $e');
                }
                if (context.mounted) Navigator.pop(context);
                _ilaclariYukle();
              },
              child: Text(duzenlenecekIlac == null ? 'EKLE' : 'KAYDET'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('İlaçlarım & Alarmlar'), backgroundColor: Colors.teal, foregroundColor: Colors.white, actions: const [UstMenu()]),
      body: _ilacListesi.isEmpty
          ? const Center(child: Text('Henüz ilaç eklemediniz.'))
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _ilacListesi.length,
              itemBuilder: (context, index) {
                final ilac = _ilacListesi[index];
                return Card(
                  child: ListTile(
                    leading: const Icon(Icons.medication, color: Colors.teal),
                    title: Text(ilac['ad'].toString(), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                    subtitle: Text('Doz: ${ilac['dozaj']} | Saat: ${ilac['saat']}\n🔔 Hatırlatma Sesi Aktif', style: const TextStyle(color: Colors.orange)),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(icon: const Icon(Icons.edit, color: Colors.teal), onPressed: () => _ilacFormunuAc(duzenlenecekIlac: ilac)),
                        IconButton(icon: const Icon(Icons.delete, color: Colors.red), onPressed: () async {
                          final ilacId = int.parse(ilac['id'].toString());
                          await VeritabaniYardimcisi().ilacSil(ilacId);
                          await BildirimServisi.iptalEt(ilacId);
                          _ilaclariYukle();
                        }),
                      ],
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _ilacFormunuAc(),
        label: const Text('İlaç Ekle'),
        icon: const Icon(Icons.add_alarm),
      ),
    );
  }
}
