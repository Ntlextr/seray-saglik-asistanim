import 'package:flutter/material.dart';
import '../theme/renkler.dart';
import '../services/veritabani_yardimcisi.dart';

// GEÇMİŞ İLAÇLAR: doktor değişikliği/tedavi bitişi gibi nedenlerle
// "Sonlandır" ile silinmeyip arşivlenen ilaçları gösterir. Bu ekran daha
// önce yoktu — DB fonksiyonu (sonlandirilmisIlaclariGetir) hazırdı ama
// gösterecek bir UI yoktu, bu oturumda eklendi.
class GecmisIlaclarEkrani extends StatefulWidget {
  const GecmisIlaclarEkrani({Key? key}) : super(key: key);

  @override
  State<GecmisIlaclarEkrani> createState() => _GecmisIlaclarEkraniState();
}

class _GecmisIlaclarEkraniState extends State<GecmisIlaclarEkrani> {
  bool _yukleniyor = true;
  List<Map<String, dynamic>> _ilaclar = [];

  @override
  void initState() {
    super.initState();
    _yukle();
  }

  Future<void> _yukle() async {
    final liste = await VeritabaniYardimcisi().sonlandirilmisIlaclariGetir();
    if (!mounted) return;
    setState(() {
      _ilaclar = liste;
      _yukleniyor = false;
    });
  }  // --- _yukle() sonu ---

  String _tarihiBicimlendir(String? isoTarih) {
    if (isoTarih == null || isoTarih.isEmpty) return '-';
    final t = DateTime.tryParse(isoTarih);
    if (t == null) return isoTarih;
    String iki(int n) => n.toString().padLeft(2, '0');
    return '${iki(t.day)}.${iki(t.month)}.${t.year}';
  }  // --- _tarihiBicimlendir() sonu ---

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(
        title: const Text('Geçmiş İlaçlar', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: AppRenkleri.aktif,
        foregroundColor: Colors.white,
      ),
      body: _yukleniyor
          ? const Center(child: CircularProgressIndicator())
          : _ilaclar.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Text(
                      'Henüz sonlandırılmış bir ilaç yok.\n(İlaçlarım listesinde bir ilacı "Sonlandır" ile arşivlerseniz burada görünür.)',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey),
                    ),
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: _ilaclar.length,
                  itemBuilder: (context, i) {
                    final ilac = _ilaclar[i];
                    final tip = ilac['tip']?.toString() ?? 'Hap';
                    final insulinMi = tip == 'İnsülin';
                    return Card(
                      margin: const EdgeInsets.only(bottom: 10),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: Colors.grey.shade200,
                          child: Icon(insulinMi ? Icons.vaccines : Icons.medication, color: Colors.grey.shade600),
                        ),
                        title: Text(ilac['ad']?.toString() ?? '-', style: const TextStyle(fontWeight: FontWeight.bold)),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SizedBox(height: 4),
                            Text('Yazıldığı tarih: ${_tarihiBicimlendir(ilac['yazildigi_tarih']?.toString())}'),
                            Text('Sonlandırıldığı tarih: ${_tarihiBicimlendir(ilac['sonlandirma_tarihi']?.toString())}'),
                            if ((ilac['sonlandirma_notu']?.toString() ?? '').isNotEmpty)
                              Padding(
                                padding: const EdgeInsets.only(top: 4),
                                child: Text(
                                  'Not: ${ilac['sonlandirma_notu']}',
                                  style: const TextStyle(fontStyle: FontStyle.italic, fontSize: 12),
                                ),
                              ),
                          ],
                        ),
                        isThreeLine: true,
                      ),
                    );
                  },
                ),
    );
  }  // --- build() sonu ---
}
