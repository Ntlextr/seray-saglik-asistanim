import 'package:flutter/material.dart';
import '../theme/renkler.dart';

class KullanimKilavuzuEkrani extends StatelessWidget {
  const KullanimKilavuzuEkrani({Key? key}) : super(key: key);

  static const List<Map<String, String>> bolumler = [
    {
      'baslik': '🏠 Ana Sayfa',
      'metin': 'Ana sayfada en son girdiğiniz şeker ve tansiyon ölçümünüzü görürsünüz. "Şeker Ekle" ve "Tansiyon Ekle" butonlarıyla yeni ölçüm kaydedebilirsiniz.'
    },
    {
      'baslik': '📊 Analizler',
      'metin': 'Şeker, Tansiyon, Su, Kilo ve Adım geçmişinizi burada tarih/saatiyle görürsünüz. Referans değerlerin dışındaki ölçümler kırmızı renkte gösterilir. Hoparlör ikonuna basarak ölçümü sesli dinleyebilirsiniz.'
    },
    {
      'baslik': '❤️ Nabız Ölçümü',
      'metin': 'Tansiyon ekleme ekranındaki nabız alanına dokununca, parmağınızı arka kameranın ve flaşın üzerine kapatarak nabzınızı ölçebilirsiniz. Ayarlar\'dan "Basit (Hızlı)" veya "Gelişmiş (FFT — daha isabetli)" yöntemini seçebilirsiniz. Ölçüm sonunda BPM\'in yanında kaba bir Stres/Enerji göstergesi de görürsünüz — bu tıbbi bir ölçüm değildir, sadece kalp atışlarınızın düzenliliğinden çıkarılan bir fikirdir.'
    },
    {
      'baslik': '📄 e-Nabız Tahlil Okuma Merkezi',
      'metin': 'e-Nabız\'dan indirdiğiniz PDF dosyasını yükleyin — yapay zeka tahlilinizi okuyup tabloya işler. Sonuçlar artık kategoriye göre gruplu (Kan Sayımı, Biyokimya, İdrar Tahlili vb.) ve tarihe göre doğru sırayla gösterilir. Bir tahlil adına dokununca açıklaması açılır ve hoparlör ikonuyla sesli dinlenebilir. Her tarih sütununun üstündeki ✨ ikonuyla sadece o tarihe ait sonuçların yorumunu, "AI Değerlendirme" butonuyla da tüm geçmişinizin genel bir değerlendirmesini alabilirsiniz — ikisi de sesli dinlenebilir.'
    },
    {
      'baslik': '💊 İlaçlarım',
      'metin': '"İlaç Ekle" ile ilacınızı, dozunu ve hatırlatma saatini girin. Belirlediğiniz saatte telefonunuz sesli olarak uyarır. Kalem ikonuyla düzenleyebilir, çöp kutusuyla silebilirsiniz.'
    },
    {
      'baslik': '🤖 Seray AI Sağlık Asistanı',
      'metin': 'Sağlık konularında merak ettiklerinizi Seray\'a sorabilirsiniz. Artık girdiğiniz kan şekeri/tansiyon geçmişinizin yanı sıra yüklediğiniz TÜM e-Nabız tahlil sonuçlarını da bilir — "kolesterolüm nasıl" gibi sorulara gerçek verilerinizle cevap verebilir. Mesaj kutusunun yanındaki mikrofon ikonuna basıp konuşarak da soru sorabilirsiniz, yazmanıza gerek yok.'
    },
    {
      'baslik': '👤 Profil',
      'metin': 'Adınızı, yaşınızı, diyabet durumunuzu ve fotoğrafınızı buradan güncelleyebilirsiniz. "Çıkış Yap" uygulamayı kapatır; verileriniz cihazınızda saklı kalır.'
    },
    {
      'baslik': '☰ Üst Menü',
      'metin': 'Her ekranın sağ üstündeki menüden: günlük ölçüm sonuçlarınızı PDF olarak paylaşabilir, verilerinizi yedekleyip geri yükleyebilir, ayarlara ve bu kılavuza her an ulaşabilirsiniz.'
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Kullanma Kılavuzu'), backgroundColor: AppRenkleri.aktif, foregroundColor: Colors.white),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: bolumler.length,
        separatorBuilder: (context, index) => const SizedBox(height: 12),
        itemBuilder: (context, index) {
          final b = bolumler[index];
          return Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(b['baslik']!, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text(b['metin']!, style: const TextStyle(fontSize: 14, height: 1.4)),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
