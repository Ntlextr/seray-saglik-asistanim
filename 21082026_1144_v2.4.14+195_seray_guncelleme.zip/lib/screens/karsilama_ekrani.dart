import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../theme/renkler.dart';
import '../services/dil_servisi.dart';
import '../services/veritabani_yardimcisi.dart';
import '../services/adim_servisi.dart';

// ============================================================================
// KARŞILAMA EKRANI — kullanıcının gönderdiği poster/mockup görseline göre
// tasarlandı. ÖNEMLİ: bu, Ana Sayfa'nın İÇİNE eklenen bir bölüm DEĞİL —
// Ana Sayfa'dan tamamen AYRI, kendi başına bir ekran. Uygulama açılışında
// (izin/PIN akışından sonra) SADECE BİR KEZ gösterilir, tek ekrana sığar
// (KAYDIRMA yok), sonra dokununca (ya da Seray AI bandına basınca) mevcut
// Ana Sayfa'ya (AnaEkranYonlendirici'ye) geçer. Ana Sayfa'nın kendisi
// eski, sade (büyük renkli butonlu) hâline döndürüldü — özet bilgilerin
// hepsi artık SADECE burada gösteriliyor.
// ============================================================================
class KarsilamaEkrani extends StatefulWidget {
  final Widget sonrakiEkran;
  const KarsilamaEkrani({Key? key, required this.sonrakiEkran}) : super(key: key);

  @override
  _KarsilamaEkraniState createState() => _KarsilamaEkraniState();
}

class _KarsilamaEkraniState extends State<KarsilamaEkrani> {
  String _kullaniciAdi = "...";
  String _cinsiyet = "Bay";
  List<Map<String, dynamic>> _sonSekerler = [];
  List<Map<String, dynamic>> _sonTansiyonlar = [];
  List<Map<String, dynamic>> _ilaclar = [];
  int _bugunAdim = 0;
  int _bugunSuMl = 0;
  double? _sonKilo;
  bool _yukleniyor = true;
  static const int _gunlukSuHedefiMl = 2000;

  String get _hitap => DilServisi.dilKodu == 'en' ? '' : ((_cinsiyet == 'Bayan' || _cinsiyet == 'Kadın') ? 'Hanım' : 'Bey');

  String get _selamlama {
    final saat = DateTime.now().hour;
    if (saat >= 5 && saat < 12) return DilServisi.metin('selamlamaGunaydin');
    if (saat >= 12 && saat < 18) return DilServisi.metin('selamlamaIyiGunler');
    if (saat >= 18 && saat < 23) return DilServisi.metin('selamlamaIyiAksamlar');
    return DilServisi.metin('selamlamaIyiGeceler');
  }

  // Bugün için henüz saati gelmemiş ilaçları, saate göre artan sırada
  // döndürür (en yakın olan önce). "saat" alanı veritabanında tek bir
  // "HH:mm" metni olarak tutuluyor.
  List<Map<String, dynamic>> get _yaklasanIlaclar {
    final simdi = TimeOfDay.now();
    final simdiDakika = simdi.hour * 60 + simdi.minute;

    final sonuc = _ilaclar.where((ilac) {
      final saatMetni = ilac['saat']?.toString();
      if (saatMetni == null || !saatMetni.contains(':')) return false;
      final parcalar = saatMetni.split(':');
      final saat = int.tryParse(parcalar[0]);
      final dakika = int.tryParse(parcalar.length > 1 ? parcalar[1] : '0');
      if (saat == null || dakika == null) return false;
      return (saat * 60 + dakika) > simdiDakika;
    }).toList();

    sonuc.sort((a, b) {
      final aParcalar = a['saat'].toString().split(':');
      final bParcalar = b['saat'].toString().split(':');
      final aDakika = (int.tryParse(aParcalar[0]) ?? 0) * 60 + (int.tryParse(aParcalar.length > 1 ? aParcalar[1] : '0') ?? 0);
      final bDakika = (int.tryParse(bParcalar[0]) ?? 0) * 60 + (int.tryParse(bParcalar.length > 1 ? bParcalar[1] : '0') ?? 0);
      return aDakika.compareTo(bDakika);
    });

    return sonuc;
  }  // --- _yaklasanIlaclar getter sonu ---

  @override
  void initState() {
    super.initState();
    _verileriYukle();
  }

  Future<void> _verileriYukle() async {
    final prefs = await SharedPreferences.getInstance();
    final sekerler = await VeritabaniYardimcisi().sekerleriGetir();
    final tansiyonlar = await VeritabaniYardimcisi().tansiyonlariGetir();
    final ilaclar = await VeritabaniYardimcisi().ilaclariGetir();
    final bugunSu = await VeritabaniYardimcisi().bugunToplamSuGetir();
    final kiloKayitlari = await VeritabaniYardimcisi().kiloKayitlariniGetir();
    await AdimServisi.baslat();
    final adim = await AdimServisi.bugunkuAdimGetir();
    if (!mounted) return;
    setState(() {
      _kullaniciAdi = prefs.getString('kullanici_ad') ?? prefs.getString('user_ad') ?? "Kullanıcı";
      _cinsiyet = prefs.getString('kullanici_cinsiyet') ?? prefs.getString('user_cinsiyet') ?? "Bay";
      _sonSekerler = sekerler;
      _sonTansiyonlar = tansiyonlar;
      _ilaclar = ilaclar;
      _bugunSuMl = bugunSu;
      _sonKilo = kiloKayitlari.isNotEmpty ? (kiloKayitlari.first['kilo'] as num?)?.toDouble() : null;
      _bugunAdim = adim;
      _yukleniyor = false;
    });
  }  // --- _verileriYukle() sonu ---

  String _tarihiBicimlendir(String? isoTarih) {
    if (isoTarih == null) return '';
    final t = DateTime.tryParse(isoTarih);
    if (t == null) return isoTarih;
    String iki(int n) => n.toString().padLeft(2, '0');
    return '${iki(t.day)}.${iki(t.month)}.${t.year} ${iki(t.hour)}:${iki(t.minute)}';
  }

  void _devamEt() {
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (context) => widget.sonrakiEkran),
    );
  }  // --- _devamEt() sonu ---

  // Küçük, kompakt istatistik kartı — Adım/Su/Kilo için (poster tarzına
  // göre eklendi, kullanıcının "eski Ana Sayfa'daki özetler heroya
  // taşınsın" isteği üzerine).
  Widget _kompaktKart({required IconData ikon, required Color renk, required String etiket, required String deger}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(ikon, color: renk, size: 18),
          const SizedBox(height: 4),
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(deger, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
          ),
          Text(etiket, style: TextStyle(fontSize: 10, color: Colors.grey.shade500)),
        ],
      ),
    );
  }  // --- _kompaktKart() sonu ---

  @override
  Widget build(BuildContext context) {
    if (_yukleniyor) {
      return Scaffold(
        backgroundColor: AppRenkleri.aktif,
        body: const Center(child: CircularProgressIndicator(color: Colors.white)),
      );
    }

    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      body: SafeArea(
        // ÖNEMLİ: Bilinçli olarak SingleChildScrollView KULLANILMADI —
        // kullanıcı "mobil uygulamanın ilk ekranı kaydırılmaz" dedi,
        // bu ekran her zaman TEK ekrana sığmalı.
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 14, 20, 12),
          child: GestureDetector(
            onTap: _devamEt,
            behavior: HitTestBehavior.translucent,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Selamlama — kompakt, poster referansındaki gibi küçük
                // tek satır (önceki turda çok büyüktü, küçültüldü).
                Text(
                  '$_selamlama,',
                  style: TextStyle(fontSize: 14, color: Colors.grey.shade600),
                ),
                Text(
                  '$_kullaniciAdi${_hitap.isEmpty ? "" : " $_hitap"}',
                  style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold, color: Color(0xFF006655)),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 10),

                // Adım / Su / Kilo — kompakt, yan yana 3 küçük kart
                Expanded(
                  flex: 2,
                  child: Row(
                    children: [
                      Expanded(child: _kompaktKart(ikon: Icons.directions_walk, renk: Colors.orange, etiket: DilServisi.metin('adimBaslik'), deger: '$_bugunAdim')),
                      const SizedBox(width: 8),
                      Expanded(child: _kompaktKart(ikon: Icons.water_drop, renk: Colors.lightBlue, etiket: DilServisi.metin('suBaslik'), deger: '${(_bugunSuMl / 1000).toStringAsFixed(1)}/${(_gunlukSuHedefiMl / 1000).toStringAsFixed(0)} L')),
                      const SizedBox(width: 8),
                      Expanded(child: _kompaktKart(ikon: Icons.monitor_weight, renk: Colors.purple, etiket: DilServisi.metin('kiloBaslik'), deger: _sonKilo != null ? '${_sonKilo!.toStringAsFixed(1)} kg' : '—')),
                    ],
                  ),
                ),
                const SizedBox(height: 8),

                // Son Kan Şekeri + Son Tansiyon — yan yana, büyük punto
                Expanded(
                  flex: 3,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: Colors.grey.shade200),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(DilServisi.metin('kanSekeriBaslik'), style: TextStyle(fontSize: 11, color: Colors.grey.shade600, fontWeight: FontWeight.w600)),
                              const SizedBox(height: 4),
                              if (_sonSekerler.isNotEmpty) ...[
                                FittedBox(
                                  fit: BoxFit.scaleDown,
                                  alignment: Alignment.centerLeft,
                                  child: Text('${_sonSekerler.first['deger']}', style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: Colors.red)),
                                ),
                                Text('mg/dL', style: TextStyle(fontSize: 10, color: Colors.grey.shade500)),
                                const SizedBox(height: 2),
                                Text(_tarihiBicimlendir(_sonSekerler.first['tarih']?.toString()), style: TextStyle(fontSize: 9, color: Colors.grey.shade500), maxLines: 1, overflow: TextOverflow.ellipsis),
                              ] else
                                Text('—', style: TextStyle(fontSize: 24, color: Colors.grey.shade400)),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: Colors.grey.shade200),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(DilServisi.metin('tansiyon'), style: TextStyle(fontSize: 11, color: Colors.grey.shade600, fontWeight: FontWeight.w600)),
                              const SizedBox(height: 4),
                              if (_sonTansiyonlar.isNotEmpty) ...[
                                FittedBox(
                                  fit: BoxFit.scaleDown,
                                  alignment: Alignment.centerLeft,
                                  child: Text('${_sonTansiyonlar.first['buyuk']}/${_sonTansiyonlar.first['kucuk']}', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: AppRenkleri.aktif.shade700)),
                                ),
                                Text('mmHg', style: TextStyle(fontSize: 10, color: Colors.grey.shade500)),
                                const SizedBox(height: 2),
                                Text(_tarihiBicimlendir(_sonTansiyonlar.first['tarih']?.toString()), style: TextStyle(fontSize: 9, color: Colors.grey.shade500), maxLines: 1, overflow: TextOverflow.ellipsis),
                              ] else
                                Text('—', style: TextStyle(fontSize: 24, color: Colors.grey.shade400)),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),

                // Yaklaşan İlaçlarınız
                Expanded(
                  flex: 3,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.grey.shade200),
                    ),
                    child: _yaklasanIlaclar.isEmpty
                        ? Center(
                            child: Text(DilServisi.metin('bugunIcinIlacYok'), style: TextStyle(color: Colors.grey.shade500, fontSize: 13)),
                          )
                        : Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Row(
                                children: [
                                  Icon(Icons.medication_outlined, size: 15, color: AppRenkleri.aktif),
                                  const SizedBox(width: 6),
                                  Text(DilServisi.metin('yaklasanIlaclariniz'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                                ],
                              ),
                              const SizedBox(height: 6),
                              for (final ilac in _yaklasanIlaclar.take(2))
                                Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 2),
                                  child: Row(
                                    children: [
                                      Container(
                                        width: 44,
                                        alignment: Alignment.centerLeft,
                                        child: Text(ilac['saat']?.toString() ?? '', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11, color: AppRenkleri.aktif.shade700)),
                                      ),
                                      Expanded(
                                        child: Text(
                                          '${ilac['ad'] ?? ''}${(ilac['dozaj'] ?? '').toString().isNotEmpty ? ' ${ilac['dozaj']}' : ''}',
                                          style: const TextStyle(fontSize: 11),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                            ],
                          ),
                  ),
                ),
                const SizedBox(height: 8),

                // Seray AI tanıtım bandı
                Expanded(
                  flex: 2,
                  child: Material(
                    color: AppRenkleri.aktif,
                    borderRadius: BorderRadius.circular(16),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(16),
                      onTap: _devamEt,
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Row(
                          children: [
                            const CircleAvatar(
                              radius: 16,
                              backgroundColor: Colors.white24,
                              child: Icon(Icons.auto_awesome, color: Colors.white, size: 18),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  const Text('Seray AI', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
                                  Text(DilServisi.metin('serayAiKisaTanitim'), style: const TextStyle(color: Colors.white70, fontSize: 10), maxLines: 1, overflow: TextOverflow.ellipsis),
                                ],
                              ),
                            ),
                            const Icon(Icons.chevron_right, color: Colors.white, size: 20),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 6),

                // Devam Et — dokunma ipucu
                Center(
                  child: Text(
                    DilServisi.metin('devamEtmekIcinDokun'),
                    style: TextStyle(fontSize: 11, color: Colors.grey.shade500),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
