import 'package:home_widget/home_widget.dart';
import 'dil_servisi.dart';

// Ana ekran widget'ına (SerayWidgetProvider.kt) veri gönderir. Widget,
// Android'in kendi kısıtı gereği en fazla ~30 dakikada bir otomatik
// yenilenir — bu yüzden uygulama içinde adım/su verisi her tazelendiğinde
// (Özet ekranı açıldığında, su eklendiğinde vb.) burayı da çağırıyoruz ki
// widget mümkün olduğunca güncel görünsün.
//
// ÖNEMLİ: Widget'ı ana ekrana TAMAMEN otomatik (kullanıcıya hiç sormadan)
// eklemek Android'de mümkün değil — ama requestPinWidget() ile kullanıcıya
// sistemin kendi "Ana ekrana ekle?" onay penceresini gösterip TEK dokunuşla
// eklettirebiliyoruz; elle basılı tutup widget listesinde arama derdi kalmıyor.
class WidgetServisi {
  static Future<void> guncelle({required int adim, required int suMl}) async {
    try {
      await HomeWidget.saveWidgetData<String>('adim_metni', '$adim ${DilServisi.metin('adimKelime')}');
      await HomeWidget.saveWidgetData<String>('su_metni', '$suMl mL ${DilServisi.metin('suBaslik').toLowerCase()}');
      await HomeWidget.updateWidget(
        name: 'SerayWidgetProvider',
        androidName: 'SerayWidgetProvider',
      );
    } catch (e) {
      // Widget eklenmemişse veya bir sorun olursa sessizce geç — ana
      // uygulama işleyişini ASLA etkilememeli.
    }
  }  // --- guncelle() sonu ---

  // "Widget Ekle" butonuna basılınca çağrılır — Android'in kendi ekleme
  // onayını gösterir. ÖNEMLİ DÜZELTME: requestPinWidget() bu paket
  // sürümünde bool DEĞİL, void (hiçbir şey) döndürüyor — derleme hatası
  // buradan geliyordu. İstek başarıyla GÖNDERİLDİYSE (hata fırlatmadıysa)
  // true dönüyoruz; kullanıcının asıl "Ekle" onayı Android'in kendi
  // penceresinde gerçekleşiyor, onun sonucunu koddan öğrenemiyoruz.
  static Future<bool> anaEkraneSabitle() async {
    try {
      await HomeWidget.requestPinWidget(
        name: 'SerayWidgetProvider',
        androidName: 'SerayWidgetProvider',
      );
      return true;
    } catch (e) {
      return false;
    }
  }  // --- anaEkraneSabitle() sonu ---
}  // --- WidgetServisi sonu ---
