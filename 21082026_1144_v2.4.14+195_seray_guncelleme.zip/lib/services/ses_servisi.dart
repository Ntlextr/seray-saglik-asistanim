import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dil_servisi.dart';

// Uygulama genelinde TEK bir yerden yönetilen sesli okuma (TTS) servisi.
// Ayarlar ekranında seçilen ses (bay/bayan) ve hız, her "Sesli Dinle"
// çağrısında otomatik olarak uygulanır — her ekranın kendi TTS ayarını
// ayrıca yapmasına gerek kalmaz.
class SesServisi {
  static final FlutterTts _tts = FlutterTts();
  static const double varsayilanHiz = 0.52;

  static Future<void> _ayarlariUygula() async {
    final prefs = await SharedPreferences.getInstance();
    final hiz = prefs.getDouble('tts_hiz') ?? varsayilanHiz;
    await _tts.setSpeechRate(hiz);
    // ÖNEMLİ DÜZELTME: Uygulama dili İngilizce ise, Ayarlar'da kayıtlı
    // Türkçe ses adını UYGULAMA — cihazın varsayılan İngilizce sesiyle
    // okusun. Önceden dil ne olursa olsun hep 'tr-TR' zorlanıyordu, bu
    // yüzden İngilizce metinler de Türkçe aksanlı sesle okunuyordu.
    if (DilServisi.dilKodu == 'en') {
      await _tts.setLanguage('en-US');
      return;
    }
    final sesAdi = prefs.getString('tts_ses_adi');
    final sesLocale = prefs.getString('tts_ses_locale');
    await _tts.setLanguage('tr-TR');
    if (sesAdi != null && sesLocale != null && sesAdi.isNotEmpty) {
      try {
        await _tts.setVoice({'name': sesAdi, 'locale': sesLocale});
      } catch (_) {
        // Kayıtlı ses artık mevcut değilse (cihaz değişmiş vb.) sessizce geç.
      }
    }
  }

  // Cihazda kurulu Türkçe TTS seslerini döndürür (Ayarlar ekranındaki
  // seçim listesi için).
  static Future<List<Map<String, String>>> turkceSesleriGetir() async {
    try {
      final sesler = await _tts.getVoices;
      final List<Map<String, String>> turkce = [];
      for (final s in sesler) {
        final map = Map<String, dynamic>.from(s as Map);
        final locale = (map['locale'] ?? '').toString();
        if (locale.toLowerCase().startsWith('tr')) {
          turkce.add({'name': (map['name'] ?? '').toString(), 'locale': locale});
        }
      }
      return turkce;
    } catch (_) {
      return [];
    }
  }

  static Future<void> konus(String metin, {VoidCallback? onTamamlandi}) async {
    await _ayarlariUygula();
    await _tts.stop();
    if (onTamamlandi != null) {
      _tts.setCompletionHandler(onTamamlandi);
    }
    await _tts.speak(metin);
  }

  static Future<void> durdur() async => _tts.stop();
}
