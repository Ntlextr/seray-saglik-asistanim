import 'dart:io';
import 'package:flutter/services.dart' show rootBundle;
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import 'veritabani_yardimcisi.dart';

class PdfRaporServisi {
  // Kayıtlı tüm şeker ve tansiyon ölçümlerini, Seray logosuyla birlikte
  // tek bir PDF raporu haline getirir ve paylaşım (WhatsApp dahil) ekranını açar.
  static Future<void> gunlukRaporuOlusturVePaylas({required String kullaniciAdi}) async {
    final sekerler = await VeritabaniYardimcisi().sekerleriGetir();
    final tansiyonlar = await VeritabaniYardimcisi().tansiyonlariGetir();

    final logoBaytlari = await rootBundle.load('assets/images/app_logo.png');
    final logo = pw.MemoryImage(logoBaytlari.buffer.asUint8List());

    // Türkçe karakterlerin (ı, ğ, ş, ç, ö, ü) PDF çıktısında kutucuk olarak
    // görünmesini engellemek için Türkçe glifleri destekleyen bir font kullanıyoruz.
    final normalFontBaytlari = await rootBundle.load('assets/fonts/DejaVuSans.ttf');
    final kalinFontBaytlari = await rootBundle.load('assets/fonts/DejaVuSans-Bold.ttf');
    final normalFont = pw.Font.ttf(normalFontBaytlari);
    final kalinFont = pw.Font.ttf(kalinFontBaytlari);

    String tarihiBicimlendir(String? isoTarih) {
      if (isoTarih == null) return '-';
      final t = DateTime.tryParse(isoTarih);
      if (t == null) return '-';
      String iki(int n) => n.toString().padLeft(2, '0');
      return '${iki(t.day)}.${iki(t.month)}.${t.year} ${iki(t.hour)}:${iki(t.minute)}';
    }

    final belge = pw.Document(theme: pw.ThemeData.withFont(base: normalFont, bold: kalinFont));
    belge.addPage(
      pw.MultiPage(
        build: (context) => [
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.center,
            children: [
              pw.Image(logo, width: 60, height: 60),
              pw.SizedBox(width: 12),
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text('Seray Sağlık Asistanım', style: pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold)),
                  pw.Text('Ölçüm Raporu - $kullaniciAdi'),
                ],
              ),
            ],
          ),
          pw.SizedBox(height: 20),
          pw.Text('Kan Şekeri Ölçümleri', style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 8),
          pw.Table.fromTextArray(
            headers: ['Tarih / Saat', 'Değer (mg/dL)', 'Durum'],
            data: sekerler.map((s) => [tarihiBicimlendir(s['tarih']?.toString()), '${s['deger']}', '${s['durum']}']).toList(),
          ),
          pw.SizedBox(height: 24),
          pw.Text('Tansiyon Ölçümleri', style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 8),
          pw.Table.fromTextArray(
            headers: ['Tarih / Saat', 'Büyük/Küçük', 'Nabız'],
            data: tansiyonlar.map((t) => [tarihiBicimlendir(t['tarih']?.toString()), '${t['buyuk']}/${t['kucuk']}', '${t['nabiz']}']).toList(),
          ),
        ],
      ),
    );

    final gecici = await getTemporaryDirectory();
    final dosyaYolu = '${gecici.path}/seray_saglik_raporu.pdf';
    final dosya = File(dosyaYolu);
    await dosya.writeAsBytes(await belge.save());

    await Share.shareXFiles([XFile(dosyaYolu, name: 'seray_saglik_raporu.pdf')], text: 'Seray Sağlık Asistanım - Ölçüm Raporu');
  }

  // e-Nabız tahlil matrisini (tahlil adı, referans, tarihe göre sonuçlar)
  // logolu bir PDF olarak paylaşır/yazdırır.
  static Future<void> enabizRaporuOlusturVePaylas({
    required Map<String, Map<String, String>> tabloVerisi,
    required List<String> tarihSutunlari,
    required String kullaniciAdi,
  }) async {
    final logoBaytlari = await rootBundle.load('assets/images/app_logo.png');
    final logo = pw.MemoryImage(logoBaytlari.buffer.asUint8List());
    final normalFontBaytlari = await rootBundle.load('assets/fonts/DejaVuSans.ttf');
    final kalinFontBaytlari = await rootBundle.load('assets/fonts/DejaVuSans-Bold.ttf');
    final normalFont = pw.Font.ttf(normalFontBaytlari);
    final kalinFont = pw.Font.ttf(kalinFontBaytlari);

    final belge = pw.Document(theme: pw.ThemeData.withFont(base: normalFont, bold: kalinFont));
    belge.addPage(
      pw.MultiPage(
        build: (context) => [
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.center,
            children: [
              pw.Image(logo, width: 60, height: 60),
              pw.SizedBox(width: 12),
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text('Seray Sağlık Asistanım', style: pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold)),
                  pw.Text('e-Nabız Tarihli Tahlil Sonuçları - $kullaniciAdi'),
                ],
              ),
            ],
          ),
          pw.SizedBox(height: 20),
          pw.Table.fromTextArray(
            headers: ['Tahlil Adı', 'Referans', ...tarihSutunlari],
            data: tabloVerisi.entries.map((entry) {
              final ref = entry.value["_ref"] ?? "-";
              return [entry.key, ref, ...tarihSutunlari.map((t) => entry.value[t] ?? "-")];
            }).toList(),
          ),
        ],
      ),
    );

    final gecici = await getTemporaryDirectory();
    final dosyaYolu = '${gecici.path}/seray_enabiz_tahlil_raporu.pdf';
    final dosya = File(dosyaYolu);
    await dosya.writeAsBytes(await belge.save());

    await Share.shareXFiles([XFile(dosyaYolu, name: 'seray_enabiz_tahlil_raporu.pdf')], text: 'Seray Sağlık Asistanım - e-Nabız Tahlil Sonuçları');
  }
}
