import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/api_service.dart';
import '../services/veritabani_yardimcisi.dart';
import '../services/pdf_rapor_servisi.dart';
import '../widgets/ust_menu.dart';

class YapayZekaEkrani extends StatefulWidget {
  const YapayZekaEkrani({Key? key}) : super(key: key);
  @override
  _YapayZekaEkraniState createState() => _YapayZekaEkraniState();
}

class _YapayZekaEkraniState extends State<YapayZekaEkrani> {
  bool _yukleniyor = false;
  String _durumMesaji = "";
  String _aiYorumu = "e-Nabız tahlilinizi yükledikten sonra detaylı matris ve tıbbi yorum buraya dökülecektir.";
  Map<String, Map<String, String>> _tabloVerisi = {};
  List<String> _tarihSutunlari = [];
  final FlutterTts _tts = FlutterTts();

  @override
  void initState() {
    super.initState();
    _tts.setLanguage('tr-TR');
    _tabloyuYukle();
  }

  @override
  void dispose() { _tts.stop(); super.dispose(); }

  Future<void> _sesliOku(String metin) async { await _tts.stop(); await _tts.speak(metin); }

  Future<void> _tabloyuYukle() async {
    final tahliller = await VeritabaniYardimcisi().tumTahlilleriGetir();
    Map<String, Map<String, String>> geciciTablo = {};
    Set<String> tarihler = {};
    for (var t in tahliller) {
      String tarih = t['tarih'].toString();
      String ad = t['tahlil_adi'].toString();
      String sonuc = t['sonuc'].toString();
      String ref = t['referans_degeri'].toString();
      tarihler.add(tarih);
      if (!geciciTablo.containsKey(ad)) geciciTablo[ad] = {"_ref": ref};
      geciciTablo[ad]![tarih] = sonuc;
    }
    setState(() { _tabloVerisi = geciciTablo; _tarihSutunlari = tarihler.toList()..sort((a, b) => b.compareTo(a)); });
  }

  // Seçilen dosyanın (PDF veya TXT) gerçek metnini okur. Önceden burada
  // sabit/uydurma bir örnek metin gönderiliyordu; artık gerçek dosya içeriği kullanılıyor.
  Future<String> _dosyaMetniniOku(String yol) async {
    if (yol.toLowerCase().endsWith('.pdf')) {
      final belge = PdfDocument(inputBytes: File(yol).readAsBytesSync());
      final metin = PdfTextExtractor(belge).extractText();
      belge.dispose();
      return metin;
    }
    return File(yol).readAsString();
  }

  Future<void> _pdfSecVeAnalizEt() async {
    FilePickerResult? sonuc = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pdf', 'txt']);
    if (sonuc != null && sonuc.files.single.path != null) {
      setState(() { _yukleniyor = true; _durumMesaji = "Dosya çözümleniyor, lütfen bekleyin..."; });
      try {
        final gercekMetin = await _dosyaMetniniOku(sonuc.files.single.path!);
        final cevap = await ApiService.tahlilMetniniAnalizEt(gercekMetin);
        setState(() { _yukleniyor = false; _durumMesaji = ""; _aiYorumu = cevap; });
        _tabloyuYukle();
      } catch (e) {
        setState(() { _yukleniyor = false; _durumMesaji = ""; _aiYorumu = "Dosya okunurken bir hata oluştu: $e"; });
      }
    }
  }

  Future<void> _yazdirPaylas() async {
    final prefs = await SharedPreferences.getInstance();
    final ad = prefs.getString('user_ad') ?? '';
    final soyad = prefs.getString('user_soyad') ?? '';
    await PdfRaporServisi.enabizRaporuOlusturVePaylas(
      tabloVerisi: _tabloVerisi,
      tarihSutunlari: _tarihSutunlari,
      kullaniciAdi: '$ad $soyad',
    );
  }

  // "80-110" gibi bir referans aralığına göre değerin dışarıda olup olmadığını kontrol eder.
  bool _refDisindaMi(String? deger, String ref) {
    if (deger == null) return false;
    final sayi = double.tryParse(deger.replaceAll(',', '.'));
    final parcalar = ref.split('-');
    if (sayi == null || parcalar.length != 2) return false;
    final min = double.tryParse(parcalar[0].trim().replaceAll(',', '.'));
    final maks = double.tryParse(parcalar[1].trim().replaceAll(',', '.'));
    if (min == null || maks == null) return false;
    return sayi < min || sayi > maks;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('e-Nabız Analiz Matrisi'), actions: const [UstMenu()]),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Center(child: Image.asset('assets/images/app_logo.png', height: 80, width: 80)),
            const SizedBox(height: 16),
            ElevatedButton.icon(onPressed: _yukleniyor ? null : _pdfSecVeAnalizEt, icon: const Icon(Icons.upload_file), label: const Text('E-NABIZ PDF/METİN DOSYASI YÜKLE')),
            if (_yukleniyor) Padding(
              padding: const EdgeInsets.only(top: 16),
              child: Column(children: [const LinearProgressIndicator(), const SizedBox(height: 8), Text(_durumMesaji)]),
            ),
            const SizedBox(height: 20),
            if (_tabloVerisi.isNotEmpty) ...[
              OutlinedButton.icon(onPressed: _yazdirPaylas, icon: const Icon(Icons.print), label: const Text('TAHLİL SONUÇLARINI YAZDIR / PAYLAŞ')),
              const SizedBox(height: 12),
            ],
            if (_tabloVerisi.isNotEmpty) SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: DataTable(
                columnSpacing: 16,
                columns: [
                  const DataColumn(label: Text('Tahlil Adı\n(Ref. Değer)')),
                  ..._tarihSutunlari.map((t) => DataColumn(label: Text(t))),
                ],
                rows: _tabloVerisi.entries.map((entry) {
                  final ref = entry.value["_ref"] ?? "-";
                  return DataRow(cells: [
                    DataCell(SizedBox(
                      width: 130,
                      child: Text.rich(
                        TextSpan(children: [
                          TextSpan(text: '${entry.key}\n', style: const TextStyle(fontWeight: FontWeight.bold)),
                          TextSpan(text: '($ref)', style: TextStyle(fontSize: 11, color: Colors.grey.shade600)),
                        ]),
                        softWrap: true,
                      ),
                    )),
                    ..._tarihSutunlari.map((t) {
                      final deger = entry.value[t];
                      final refDisi = _refDisindaMi(deger, ref);
                      return DataCell(Text(deger ?? "-", style: TextStyle(color: refDisi ? Colors.red : null, fontWeight: refDisi ? FontWeight.bold : null)));
                    }),
                  ]);
                }).toList(),
              ),
            ),
            const SizedBox(height: 16),
            Card(child: Padding(padding: const EdgeInsets.all(16.0), child: Text(_aiYorumu))),
            const SizedBox(height: 12),
            OutlinedButton.icon(onPressed: () => _sesliOku(_aiYorumu), icon: const Icon(Icons.volume_up), label: const Text('SESLİ DİNLE')),
          ],
        ),
      ),
    );
  }
}
