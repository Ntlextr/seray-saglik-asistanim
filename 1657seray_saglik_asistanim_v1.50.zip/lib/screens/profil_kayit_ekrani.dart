import 'package:flutter/material.dart';

class ProfilKayitEkrani extends StatefulWidget {
  const ProfilKayitEkrani({Key? key}) : super(key: key);

  @override
  State<ProfilKayitEkrani> createState() => _ProfilKayitEkraniState();
}

class _ProfilKayitEkraniState extends State<ProfilKayitEkrani> {
  // Switch butonlarının durumları
  bool _kullanimKosullari = false;
  bool _gizlilikPolitikasi = false;
  bool _aydinlatmaMetni = false;
  bool _rizaMetni = false;
  bool _kampanyaOnay = false;

  // Metinlerin okunup onaylandığını doğrulayan kilitler
  bool _kullanimOkundu = false;
  bool _gizlilikOkundu = false;
  bool _aydinlatmaOkundu = false;
  bool _rizaOkundu = false;

  // Zorunlu olan tüm (*) maddeler okunup kabul edildi mi kontrolü
  bool get _kayitButonuAktifMi {
    return _kullanimOkundu &&
        _gizlilikOkundu &&
        _aydinlatmaOkundu &&
        _rizaOkundu;
  }

  // Alttan açılan metin okuma penceresi (BottomSheet)
  void _metniOkuVeOnayla({
    required String baslik,
    required String icerik,
    required Function(bool) onOnay,
  }) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        return DraggableScrollableSheet(
          initialChildSize: 0.75,
          minChildSize: 0.5,
          maxChildSize: 0.95,
          expand: false,
          builder: (context, scrollController) {
            return Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    baslik,
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF111424),
                    ),
                  ),
                  const SizedBox(height: 15),
                  Expanded(
                    child: ListView(
                      controller: scrollController,
                      children: [
                        Text(
                          icerik,
                          style: const TextStyle(
                            fontSize: 15,
                            color: Colors.black87,
                            height: 1.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 15),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF111424),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      onPressed: () {
                        onOnay(true);
                        Navigator.pop(context);
                      },
                      child: const Text(
                        'Okudum, Kabul Ediyorum',
                        style: TextStyle(color: Colors.white, fontSize: 16),
                      ),
                    ),
                  )
                ],
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text(
          'Profil Kaydı',
          style: TextStyle(
            color: Color(0xFF111424),
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Color(0xFF111424)),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Form widget'ı aynı dosya içinde aşağıda tanımlandı
              const ProfilKayitForm(),
              const SizedBox(height: 30),

              const Divider(height: 1),
              const SizedBox(height: 20),

              const Text(
                'Yasal Onaylar',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF111424),
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Lütfen devam etmeden önce zorunlu yasal metinleri gözden geçirin.',
                style: TextStyle(fontSize: 13, color: Colors.grey),
              ),
              const SizedBox(height: 16),

              // 1. Kullanım Koşulları (Zorunlu *)
              _buildYasalSatir(
                baslik: 'Kullanım koşulu',
                isZorunlu: true,
                value: _kullanimKosullari,
                onTap: () {
                  _metniOkuVeOnayla(
                    baslik: 'Kullanım Koşulları',
                    icerik:
                        'Seray Sağlık Asistanım uygulamasını kullanırken uymanız gereken kurallar ve şartlar burada yer almaktadır. Uygulama tıbbi teşhis koymaz, sadece bir asistanlık hizmeti sunar...',
                    onOnay: (onay) => setState(() {
                      _kullanimOkundu = onay;
                      _kullanimKosullari = onay;
                    }),
                  );
                },
              ),

              // 2. Gizlilik Politikası (Zorunlu *)
              _buildYasalSatir(
                baslik: 'Gizlilik politikası',
                isZorunlu: true,
                value: _gizlilikPolitikasi,
                onTap: () {
                  _metniOkuVeOnayla(
                    baslik: 'Gizlilik Politikası',
                    icerik:
                        'Sağlık verileriniz ve kişisel kimliğiniz bizimle tamamen güvendedir. Verileriniz üçüncü şahıslarla asla paylaşılmaz ve sadece cihazınızda veya şifreli yerel veritabanında saklanır...',
                    onOnay: (onay) => setState(() {
                      _gizlilikOkundu = onay;
                      _gizlilikPolitikasi = onay;
                    }),
                  );
                },
              ),

              // 3. Çerez Politikası (İsteğe Bağlı)
              _buildYasalSatir(
                baslik: 'Çerez politikası',
                isZorunlu: false,
                value: _kampanyaOnay,
                onTap: () => setState(() => _kampanyaOnay = !_kampanyaOnay),
              ),

              // 4. Aydınlatma Metni (Zorunlu *)
              _buildYasalSatir(
                baslik: 'Aydınlatma metni',
                isZorunlu: true,
                value: _aydinlatmaMetni,
                onTap: () {
                  _metniOkuVeOnayla(
                    baslik: 'KVKK Aydınlatma Metni',
                    icerik:
                        '6698 sayılı Kişisel Verilerin Korunması Kanunu uyarınca, Seray Teknoloji olarak sağlık verilerinizin işlenme amaçları, saklanma süreleri ve haklarınız hakkında bilgilendirme metnidir...',
                    onOnay: (onay) => setState(() {
                      _aydinlatmaOkundu = onay;
                      _aydinlatmaMetni = onay;
                    }),
                  );
                },
              ),

              // 5. Rıza Metni (Zorunlu *)
              _buildYasalSatir(
                baslik: 'Rıza metni',
                isZorunlu: true,
                value: _rizaMetni,
                onTap: () {
                  _metniOkuVeOnayla(
                    baslik: 'Açık Rıza Metni',
                    icerik:
                        'Yapay zeka tahlil analizi ve seslendirme servislerinin çalışabilmesi için anonimleştirilmiş sağlık verilerinizin güvenli API modelleri ile işlenmesine açık rıza gösteriyorsunuz...',
                    onOnay: (onay) => setState(() {
                      _rizaOkundu = onay;
                      _rizaMetni = onay;
                    }),
                  );
                },
              ),

              const SizedBox(height: 32),

              // Kaydet / İlerle Butonu
              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _kayitButonuAktifMi
                        ? const Color(0xFF111424)
                        : Colors.grey.shade300,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(24),
                    ),
                    elevation: _kayitButonuAktifMi ? 2 : 0,
                  ),
                  onPressed: _kayitButonuAktifMi
                      ? () {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Profil onayları başarıyla kaydedildi!'),
                            ),
                          );
                        }
                      : null,
                  child: Text(
                    'Sonraki',
                    style: TextStyle(
                      color: _kayitButonuAktifMi
                          ? Colors.white
                          : Colors.grey.shade600,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildYasalSatir({
    required String baslik,
    required bool isZorunlu,
    required bool value,
    required VoidCallback onTap,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 4),
      padding: const EdgeInsets.symmetric(vertical: 6),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: Colors.grey.shade300,
          ),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: GestureDetector(
              onTap: onTap,
              child: RichText(
                text: TextSpan(
                  style: const TextStyle(fontSize: 14, color: Colors.black87),
                  children: [
                    if (isZorunlu)
                      const TextSpan(
                        text: '* ',
                        style: TextStyle(
                          color: Colors.red,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    const TextSpan(text: 'Okudum ve kabul ediyorum '),
                    TextSpan(
                      text: baslik,
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        decoration: TextDecoration.underline,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Switch(
            value: value,
            activeColor: const Color(0xFF00cc88),
            onChanged: (bool newValue) {
              if (isZorunlu && !value) {
                onTap();
              } else if (isZorunlu && value) {
                onTap();
              } else {
                onTap();
              }
            },
          ),
        ],
      ),
    );
  }
}

// ------------------------------------------------------------------
// AŞAĞIDAKİ WIDGET TEK DOSYA ÇÖZÜMÜ İÇİN EKNLENMİŞTİR:
// ------------------------------------------------------------------
class ProfilKayitForm extends StatefulWidget {
  const ProfilKayitForm({Key? key}) : super(key: key);

  @override
  State<ProfilKayitForm> createState() => _ProfilKayitFormState();
}

class _ProfilKayitFormState extends State<ProfilKayitForm> {
  final _adController = TextEditingController();
  final _soyadController = TextEditingController();
  final _yasController = TextEditingController();
  String _cinsiyet = 'Bay';

  @override
  void dispose() {
    _adController.dispose();
    _soyadController.dispose();
    _yasController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Kişisel Bilgiler',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Color(0xFF111424),
          ),
        ),
        const SizedBox(height: 16),
        TextField(
          controller: _adController,
          decoration: InputDecoration(
            labelText: 'Adınız',
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
            prefixIcon: const Icon(Icons.person),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _soyadController,
          decoration: InputDecoration(
            labelText: 'Soyadınız',
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
            prefixIcon: const Icon(Icons.person_outline),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _yasController,
          keyboardType: TextInputType.number,
          decoration: InputDecoration(
            labelText: 'Yaşınız',
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
            prefixIcon: const Icon(Icons.cake),
          ),
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: _cinsiyet,
          decoration: InputDecoration(
            labelText: 'Cinsiyet',
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
            prefixIcon: const Icon(Icons.wc),
          ),
          items: const [
            DropdownMenuItem(value: 'Bay', child: Text('Bay')),
            DropdownMenuItem(value: 'Bayan', child: Text('Bayan')),
          ],
          onChanged: (val) {
            if (val != null) setState(() => _cinsiyet = val);
          },
        ),
      ],
    );
  }
}
