import 'package:flutter/material.dart';

// Not: Kodunuzda geçen 'olcum' nesnesinin yapısına göre burayı modelinizden import edebilirsiniz.
// Örneğin: import 'package:seray_saglik_asistanim/models/olcum_model.dart';

class TansiyonEkleEkrani extends StatefulWidget {
  const TansiyonEkleEkrani({Key? key}) : super(key: key);

  @override
  State<TansiyonEkleEkrani> createState() => _TansiyonEkleEkraniState();
}

class _TansiyonEkleEkraniState extends State<TansiyonEkleEkrani> {
  // Örnek ölçüm değerleri (Sizin mevcut yapınıza göre otomatik gelecektir)
  final dynamic olcum = null; 

  @override
  Widget build(BuildContext context) {
    // 1. DÜZELTME: Türkçe karakter ve boşluk içeren 'yüksek Mi' değişkeni 'yuksekMi' olarak güncellendi.
    // olcum nesnesinin null gelme ihtimaline karşı güvenli bir kontrol eklendi.
    bool yuksekMi = olcum != null && (olcum.buyuk > 135 || olcum.kucuk > 85);

    return Scaffold(
      appBar: AppBar(
        // 2. DÜZELTME: Dinamik durumlarda başta const kullanılmaz, sadece sabit yazıya verilir.
        title: const Text('Tansiyon Kaydı Ekle'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Örnek Kart Tasarımı ve Hatalı Widget'ların Düzeltilmiş Hali
            Container(
              // 3. DÜZELTME: Eksik virgüller ve süslü parantez hataları giderildi.
              decoration: BoxDecoration(
                color: yuksekMi ? Colors.red.shade50 : Colors.green.shade50,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: yuksekMi ? Colors.red : Colors.green,
                ),
              ),
              padding: const EdgeInsets.all(16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // 4. DÜZELTME: Icon argüman hatası (Too many positional arguments) düzeltildi.
                  Icon(
                    yuksekMi ? Icons.warning : Icons.check_circle,
                    color: yuksekMi ? Colors.red : Colors.green,
                  ),
                  const SizedBox(width: 12),
                  // 5. DÜZELTME: Ternary operatör (? :) kullanımındaki string ve stil hataları giderildi.
                  Text(
                    yuksekMi ? 'Yüksek' : 'Normal',
                    style: TextStyle(
                      color: yuksekMi ? Colors.red : Colors.green,
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
