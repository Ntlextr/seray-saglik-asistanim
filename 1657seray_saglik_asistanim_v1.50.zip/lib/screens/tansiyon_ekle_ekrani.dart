import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';

// Örnek Veri Modeli (Senin projedeki model yapına göre uyarlandı)
class TansiyonModel {
  final int buyuk;
  final int kucuk;
  final String tarih;

  TansiyonModel({required this.buyuk, required this.kucuk, required this.tarih});
}

class TansiyonEkleEkrani extends StatefulWidget {
  const TansiyonEkleEkrani({Key? key}) : super(key: key);

  @override
  State<TansiyonEkleEkrani> createState() => _TansiyonEkleEkraniState();
}

class _TansiyonEkleEkraniState extends State<TansiyonEkleEkrani> {
  final FlutterTts _flutterTts = FlutterTts();
  bool _sesCaliniyor = false;

  // Örnek Ölçüm Listesi (Veritabanından gelen verilerle otomatik eşleşir)
  final List<TansiyonModel> _olcumler = [
    TansiyonModel(buyuk: 120, kucuk: 80, tarih: '22.07.2026'),
    TansiyonModel(buyuk: 140, kucuk: 90, tarih: '21.07.2026'),
  ];

  // 🔊 TANSİYON DEĞERLERİNİ ANALİZ EDİP SESLİ OKUYAN SİHİRLİ FONKSİYON
  Future<void> _tansiyonAnaliziniSeslendir() async {
    if (_sesCaliniyor) {
      await _flutterTts.stop();
      setState(() => _sesCaliniyor = false);
      return;
    }

    if (_olcumler.isEmpty) {
      await _flutterTts.speak("Henüz kaydedilmiş bir tansiyon ölçümünüz bulunmamaktadır.");
      return;
    }

    // En son girilen tansiyon kaydını analiz ediyoruz
    final sonOlcum = _olcumler.first;
    int buyuk = sonOlcum.buyuk;
    int kucuk = sonOlcum.kucuk;
    
    String durumMetni = "Son ölçümünüze göre büyük tansiyonunuz $buyuk, küçük tansiyonunuz $kucuk değerindedir. ";

    if (buyuk > 135 || kucuk > 85) {
      durumMetni += "Tansiyon değerleriniz normal sınırların biraz üzerinde seyretmektedir. Lütfen dinlenip tekrar ölçüm yapınız.";
    } else if (buyuk < 90 || kucuk < 60) {
      durumMetni += "Tansiyon değerleriniz normal sınırların altında seyretmektedir. Halsizlik hissediyorsanız lütfen doktorunuza danışınız.";
    } else {
      durumMetni += "Tansiyon seyriniz tamamen ideal ve normal sınırlardadır. Sağlıklı günler dileriz.";
    }

    setState(() => _sesCaliniyor = true);
    await _flutterTts.setLanguage("tr-TR");
    await _flutterTts.setPitch(1.0);
    await _flutterTts.speak(durumMetni);

    _flutterTts.setCompletionHandler(() {
      setState(() => _sesCaliniyor = false);
    });
  }

  @override
  void dispose() {
    _flutterTts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Tansiyon Takibi', style: TextStyle(color: Color(0xFF111424), fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Color(0xFF111424)),
        actions: [
          // 🔔 İSTEDİĞİNİZ SESLİ OKUMA HOPARLÖR BUTONU
          IconButton(
            icon: Icon(
              _sesCaliniyor ? Icons.stop_circle : Icons.volume_up,
              color: Colors.blue,
              size: 28,
            ),
            onPressed: _tansiyonAnaliziniSeslendir,
          ),
          const SizedBox(width: 12),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Ölçüm Geçmişiniz', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Expanded(
              child: ListView.builder(
                itemCount: _olcumler.length,
                itemBuilder: (context, index) {
                  final olcum = _olcumler[index];
                  bool yuksekMi = olcum.buyuk > 135 || olcum.kucuk > 85;
                  return Card(
                    margin: const EdgeInsets.symmetric(vertical: 6),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    child: ListTile(
                      leading: Icon(
                        Icons.favorite, 
                        color: yuksekMi ? Colors.red : Colors.green,
                        size: 28,
                      ),
                      title: Text(
                        '${olcum.buyuk} / ${olcum.kucuk} mmHg',
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                      ),
                      subtitle: Text(olcum.tarih),
                      trailing: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: yuksekMi ? Colors.red.shade50 : Colors.green.shade50,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          yuksekMi ? 'Yüksek' : 'Normal',
                          style: TextStyle(color: yuksekMi ? Colors.red : Colors.green, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
