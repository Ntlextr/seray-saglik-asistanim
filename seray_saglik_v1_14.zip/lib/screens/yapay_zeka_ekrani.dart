import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../services/veritabani_yardimcisi.dart';

class YapayZekaEkrani extends StatefulWidget {
  const YapayZekaEkrani({Key? key}) : super(key: key);

  @override
  _YapayZekaEkraniState createState() => _YapayZekaEkraniState();
}

class _YapayZekaEkraniState extends State<YapayZekaEkrani> {
  bool _yukleniyor = false;
  String _aiYorumu = "e-Nabız metninizi yapıştırıp analiz ettikten sonra, geçmiş tahlilleriniz yan yana sütunlar halinde burada listelenecektir.";
  final _textController = TextEditingController();
  
  Map<String, Map<String, String>> _tabloVerisi = {}; // Satır: Tahlil Adı, Sütun: Tarih verisi
  List<String> _tarihSutunlari = [];

  @override
  void initState() {
    super.initState();
    _tabloyuYukle();
  }

  Future<void> _tabloyuYukle() async {
    final tahliller = await VeritabaniYardimcisi().tumTahlilleriGetir();
    Map<String, Map<String, String>> geciciTablo = {};
    Set<String> tarihler = {};

    for (var t in tahliller) {
      String tarih = t['tarih'].toString();
      String ad = t['tahlil_adi'].toString();
      String sonuc = t['sonuc'].toString();
      String ref = t['referans_degeri'].toString();

      tarihler.add(tarih);
      if (!geciciTablo.containsKey(ad)) {
        geciciTablo[ad] = {"_ref": ref};
      }
      geciciTablo[ad]![tarih] = sonuc;
    }

    setState(() {
      _tabloVerisi = geciciTablo;
      _tarihSutunlari = tarihler.toList()..sort((a, b) => b.compareTo(a)); // En yeni tarih ilk sütun
    });
  }

  Future<void> _analizEt() async {
    if (_textController.text.trim().isEmpty) return;
    setState(() { _yukleniyor = true; _aiYorumu = "Tahlilleriniz işleniyor..."; });
    
    final cevap = await ApiService.tahlilMetniniAnalizEt(_textController.text.trim());
    
    setState(() { _yukleniyor = false; _aiYorumu = cevap; });
    _tabloyuYukle(); // Tabloyu anında güncelle
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(title: const Text('e-Nabız Analiz Merkezi'), backgroundColor: Colors.teal, foregroundColor: Colors.white),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // LOGOMUZ ARTIK EN ÜSTTE PARLIYOR!
            Center(child: Image.asset('assets/images/app_logo.png', height: 90, width: 90)),
            const SizedBox(height: 12),
            
            // Canlı Sütunlu e-Nabız Matris Tablosu
            if (_tabloVerisi.isNotEmpty) ...[
              const Text('Geçmiş Tahlil Matrisi', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.teal)),
              const SizedBox(height: 8),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: DataTable(
                  border: TableBorder.all(color: Colors.grey.shade300, width: 1),
                  columns: [
                    const DataColumn(label: Text('Tahlil Adı', style: TextStyle(fontWeight: FontWeight.bold))),
                    const DataColumn(label: Text('Normal Ref.', style: TextStyle(fontWeight: FontWeight.bold))),
                    ..._tarihSutunlari.map((t) => DataColumn(label: Text(t, style: const TextStyle(fontWeight: FontWeight.bold)))),
                  ],
                  rows: _tabloVerisi.entries.map((entry) {
                    String tahlilAdi = entry.key;
                    String refDegeri = entry.value["_ref"] ?? "-";

                    return DataRow(
                      cells: [
                        DataCell(Text(tahlilAdi, style: const TextStyle(fontWeight: FontWeight.bold))),
                        DataCell(Text(refDegeri)),
                        ..._tarihSutunlari.map((tarih) {
                          String sonuc = entry.value[tarih] ?? "-";
                          
                          // Referans dışı kontrolü (Basit şeker/HbA1c renklendirme örneği)
                          bool tehlikeli = false;
                          if (tahlilAdi.toLowerCase().contains('glukoz') && (double.tryParse(sonuc) ?? 0) > 110) tehlikeli = true;
                          if (tahlilAdi.toLowerCase().contains('hba1c') && (double.tryParse(sonuc) ?? 0) > 6.0) tehlikeli = true;
                          if (tahlilAdi.toLowerCase().contains('b12') && (double.tryParse(sonuc) ?? 0) < 211) tehlikeli = true;

                          return DataCell(
                            Container(
                              padding: const EdgeInsets.all(6),
                              decoration: BoxDecoration(
                                color: tehlikeli ? Colors.red.shade100 : Colors.transparent,
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text(sonuc, style: TextStyle(color: tehlikeli ? Colors.red.shade900 : Colors.black87, fontWeight: tehlikeli ? FontWeight.bold : FontWeight.normal)),
                            ),
                          );
                        }),
                      ],
                    );
                  }).toList(),
                ),
              ),
              const SizedBox(height: 20),
            ],

            Card(
              color: Colors.teal.shade50,
              child: Padding(padding: const EdgeInsets.all(16.0), child: Text(_aiYorumu, style: const TextStyle(fontSize: 16, height: 1.4))),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _textController,
              maxLines: 4,
              decoration: InputDecoration(labelText: 'e-Nabız Metnini Buraya Yapıştırın', border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)), filled: true, fillColor: Colors.white),
            ),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              onPressed: _yukleniyor ? null : _analizEt,
              icon: const Icon(Icons.bolt),
              label: const Text('ANALİZ ET VE MATRİSE EKLE', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.teal, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 14)),
            ),
          ],
        ),
      ),
    );
  }
}
