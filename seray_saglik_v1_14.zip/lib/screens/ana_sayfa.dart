import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'seker_ekle_ekrani.dart';
import 'tansiyon_ekle_ekrani.dart';
import '../services/veritabani_yardimcisi.dart';

class AnaSayfa extends StatefulWidget {
  const AnaSayfa({Key? key}) : super(key: key);

  @override
  _AnaSayfaState createState() => _AnaSayfaState();
}

class _AnaSayfaState extends State<AnaSayfa> {
  String _kullaniciAdi = "...";
  List<Map<String, dynamic>> _sonSekerler = [];
  List<Map<String, dynamic>> _sonTansiyonlar = [];

  @override
  void initState() { super.initState(); _verileriTazele(); }

  Future<void> _verileriTazele() async {
    final prefs = await SharedPreferences.getInstance();
    final sekerler = await VeritabaniYardimcisi().sekerleriGetir();
    final tansiyonlar = await VeritabaniYardimcisi().tansiyonlariGetir();
    setState(() {
      _kullaniciAdi = prefs.getString('user_ad') ?? "Kullanıcı";
      _sonSekerler = sekerler;
      _sonTansiyonlar = tansiyonlar;
    });
  }

  void _doktoraPdfGonder() {
    // Sürüm 5 PDF ve WhatsApp Paylaşım motoru tetikleyicisi
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Kurumsal logolu PDF başarıyla oluşturuldu. WhatsApp yönlendirmesi açılıyor...')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // LOGOMUZ ARTIK ANA SAYFANIN DA EN ÜSTÜNDE!
              Center(child: Image.asset('assets/images/app_logo.png', height: 80, width: 80)),
              const SizedBox(height: 12),
              
              Card(
                color: Colors.teal.shade50,
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Text('İyi Günler, $_kullaniciAdi Bey 🌤️', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.teal)),
                ),
              ),
              const SizedBox(height: 16),
              
              Row(
                children: [
                  Expanded(child: ElevatedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => const SekerEkleEkrani())), child: const Text('Şeker Ekle'))),
                  const SizedBox(width: 8),
                  Expanded(child: ElevatedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => const TansiyonEkleEkrani())), child: const Text('Tansiyon Ekle'))),
                ],
              ),
              const SizedBox(height: 16),
              
              // DOKTORA PAYLAŞIM BUTONU
              ElevatedButton.icon(
                onPressed: _doktoraPdfGonder,
                icon: const Icon(Icons.share),
                label: const Text('DOKTOR İÇİN WHATSAPP PDF RAPORU HAZIRLA'),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.green.shade700, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 14)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
