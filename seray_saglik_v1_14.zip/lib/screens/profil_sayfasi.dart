import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:file_picker/file_picker.dart';
import 'profil_kayit_ekrani.dart';
import '../services/veritabani_yardimcisi.dart';

class ProfilSayfasi extends StatefulWidget {
  const ProfilSayfasi({Key? key}) : super(key: key);

  @override
  _ProfilSayfasiState createState() => _ProfilSayfasiState();
}

class _ProfilSayfasiState extends State<ProfilSayfasi> {
  String _ad = "..."; 
  String _soyad = "..."; 
  int _yas = 0;
  String _diyabet = "Bilinmiyor";

  @override
  void initState() { 
    super.initState(); 
    _verileriYukle(); 
  }

  Future<void> _verileriYukle() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _ad = prefs.getString('user_ad') ?? "Bilinmiyor";
      _soyad = prefs.getString('user_soyad') ?? "Bilinmiyor";
      _yas = prefs.getInt('user_yas') ?? 0;
      _diyabet = prefs.getString('user_diyabet') ?? "Bilinmiyor";
    });
  }

  // WhatsApp yedek bulma mantığı ile telefondan .db seçtiren fonksiyon
  Future<void> _yedekYükleHafizadan() async {
    FilePickerResult? sonuc = await FilePicker.platform.pickFiles(type: FileType.any);
    if (sonuc != null && sonuc.files.single.path != null) {
      bool basarili = await VeritabaniYardimcisi().yedegiGeriYukle(sonuc.files.single.path!);
      if (basarili && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('🎉 GÜVENLİ YEDEK BULUNDU VE BAŞARIYLA GERİ YÜKLENDİ!', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold))),
        );
      }
    }
  }

  Future<void> _cikisYapVeSifirla() async {
    await VeritabaniYardimcisi().veritabaniSifirla();
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (mounted) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const ProfilKayitEkrani()));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 30),
            Center(child: Image.asset('assets/images/app_logo.png', height: 80, width: 80)), // KURUMSAL LOGOMUZ ARTIK BURADA DA VAR
            const SizedBox(height: 16),
            Card(
              color: Colors.teal.shade50,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  children: [
                    Text("$_ad $_soyad", style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 24, color: Colors.black87)),
                    const Divider(),
                    _profilBilgiSatiri("Kayıtlı Yaş:", "$_yas"),
                    const SizedBox(height: 8),
                    _profilBilgiSatiri("Diyabet Durumu:", _diyabet),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            
            // BULUT YEDEKLEME ALANI BUTONLARI
            ElevatedButton.icon(
              onPressed: () => VeritabaniYardimcisi().veritabaniYedekleHafizaya(),
              icon: const Icon(Icons.cloud_upload),
              label: const Text('Verileri WhatsApp / Google Drive\'a Yedekle'),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.teal, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 14)),
            ),
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed: _yedekYükleHafizadan,
              icon: const Icon(Icons.cloud_download),
              label: const Text('Yedek Bul ve Geri Yükle'),
              style: OutlinedButton.styleFrom(side: const BorderSide(color: Colors.teal), padding: const EdgeInsets.symmetric(vertical: 14)),
            ),
            
            const Spacer(),
            OutlinedButton.icon(
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: const Text("Güvenli Çıkış"),
                    content: const Text("Tüm profil bilgileriniz ve tahlil geçmişiniz silinecektir. Çıkış yapmak istediğinize emin misiniz?"),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(context), child: const Text("İptal")),
                      TextButton(onPressed: _cikisYapVeSifirla, child: const Text("Evet, Sıfırla", style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold))),
                    ],
                  ),
                );
              },
              icon: const Icon(Icons.logout, color: Colors.red),
              label: const Text("Hesabı Kapat ve Verileri Temizle", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.red)),
              style: OutlinedButton.styleFrom(side: const BorderSide(color: Colors.red), padding: const EdgeInsets.symmetric(vertical: 16), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
            ),
          ],
        ),
      ),
    );
  }

  Widget _profilBilgiSatiri(String baslik, String deger) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(baslik, style: const TextStyle(fontSize: 16, color: Colors.black54)),
        Text(deger, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.teal)),
      ],
    );
  }
}
