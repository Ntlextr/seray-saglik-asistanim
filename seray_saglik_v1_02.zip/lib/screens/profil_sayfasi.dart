import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'profil_kayit_ekrani.dart';
import '../services/veritabanı_yardimcisi.dart';

class ProfilSayfasi extends StatefulWidget {
  const ProfilSayfasi({Key? key}) : super(key: key);

  @override
  _ProfilSayfasiState createState() => _ProfilSayfasiState();
}

class _ProfilSayfasiState extends State<ProfilSayfasi> {
  String _ad = "..."; 
  String _soyad = "..."; 
  int _yas = 0;
  String _diyabet = "Bilinmiyor";

  @override
  void initState() { 
    super.initState(); 
    _verileriYukle(); 
  }

  Future<void> _verileriYukle() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _ad = prefs.getString('user_ad') ?? "Bilinmiyor";
      _soyad = prefs.getString('user_soyad') ?? "Bilinmiyor";
      _yas = prefs.getInt('user_yas') ?? 0;
      _diyabet = prefs.getString('user_diyabet') ?? "Bilinmiyor";
    });
  }

  Future<void> _cikisYapVeSifirla() async {
    await VeritabaniYardimcisi().veritabaniSifirla();
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (mounted) {
      Navigator.pushAndRemoveUntil(
        context, 
        MaterialPageRoute(builder: (context) => const ProfilKayitEkrani()), 
        (route) => false,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 40),
            Card(
              color: Colors.teal.shade50,
              elevation: 0,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  children: [
                    const Icon(Icons.account_circle, size: 90, color: Colors.teal),
                    const SizedBox(height: 12),
                    Text(
                      "$_ad $_soyad", 
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 24, color: Colors.black87),
                    ),
                    const SizedBox(height: 12),
                    const Divider(),
                    const SizedBox(height: 8),
                    _profilBilgiSatiri("Kayıtlı Yaş:", "$_yas"),
                    const SizedBox(height: 8),
                    _profilBilgiSatiri("Diyabet Durumu:", _diyabet),
                  ],
                ),
              ),
            ),
            const Spacer(),
            ElevatedButton.icon(
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: const Text("Güvenli Çıkış"),
                    content: const Text("Uygulamadaki tüm profil bilgileriniz ve tahlil geçmişiniz silinecektir. Çıkış yapmak istediğinize emin misiniz?"),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(context), child: const Text("İptal")),
                      TextButton(
                        onPressed: _cikisYapVeSifirla, 
                        child: const Text("Evet, Verileri Sil", style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
                      ),
                    ],
                  ),
                );
              },
              icon: const Icon(Icons.power_settings_new),
              label: const Text("GÜVENLİ ÇIKIŞ YAP & VERİLERİ SİL", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red.shade700, 
                foregroundColor: Colors.white, 
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _profilBilgiSatiri(String baslik, String deger) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.between,
      children: [
        Text(baslik, style: const TextStyle(fontSize: 16, color: Colors.black54)),
        Text(deger, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.teal)),
      ],
    );
  }
}
