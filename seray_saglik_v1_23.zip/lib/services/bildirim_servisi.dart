import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest_all.dart' as tz_data;

class BildirimServisi {
  static final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  static bool _hazir = false;

  static Future<void> baslat() async {
    if (_hazir) return;
    tz_data.initializeTimeZones();
    // Uygulama şu an için Türkiye saatine göre çalışıyor.
    tz.setLocalLocation(tz.getLocation('Europe/Istanbul'));

    const androidAyarlari = AndroidInitializationSettings('@mipmap/ic_launcher');
    const ayarlar = InitializationSettings(android: androidAyarlari);
    await _plugin.initialize(ayarlar, onDidReceiveNotificationResponse: _bildirimYanitlandi);

    final androidUygulama = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await androidUygulama?.requestNotificationsPermission();
    await androidUygulama?.createNotificationChannel(const AndroidNotificationChannel(
      'ilac_hatirlatma_kanali',
      'İlaç Hatırlatmaları',
      description: 'Günlük ilaç saatlerinde çalan hatırlatmalar',
      importance: Importance.max,
      playSound: true,
    ));
    _hazir = true;
  }

  // "Ertele" butonuna basıldığında bildirimi 10 dakika sonrasına tekrar kurar.
  static void _bildirimYanitlandi(NotificationResponse yanit) async {
    if (yanit.actionId == 'ertele') {
      final ilacAdi = yanit.payload ?? 'İlaç';
      await _plugin.zonedSchedule(
        yanit.id ?? 0,
        '💊 İlaç Hatırlatması (Ertelendi)',
        '$ilacAdi zamanı geldi!',
        tz.TZDateTime.now(tz.local).add(const Duration(minutes: 10)),
        _bildirimDetaylari(),
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        payload: ilacAdi,
      );
    }
  }

  static NotificationDetails _bildirimDetaylari() {
    return const NotificationDetails(
      android: AndroidNotificationDetails(
        'ilac_hatirlatma_kanali',
        'İlaç Hatırlatmaları',
        channelDescription: 'Günlük ilaç saatlerinde çalan hatırlatmalar',
        importance: Importance.max,
        priority: Priority.high,
        playSound: true,
        fullScreenIntent: true,
        actions: [
          AndroidNotificationAction('ertele', 'Ertele', showsUserInterface: false),
          AndroidNotificationAction('kapat', 'Kapat', cancelNotification: true),
        ],
      ),
    );
  }

  // Her gün aynı saatte tekrar eden ilaç alarmı kurar. id olarak ilacın
  // veritabanındaki id'si kullanılır, böylece silinince/düzenlenince eşleşir.
  static Future<void> ilacHatirlaticisiKur({required int id, required String ilacAdi, required TimeOfDay saat}) async {
    await baslat();
    final simdi = tz.TZDateTime.now(tz.local);
    var hedef = tz.TZDateTime(tz.local, simdi.year, simdi.month, simdi.day, saat.hour, saat.minute);
    if (hedef.isBefore(simdi)) hedef = hedef.add(const Duration(days: 1));

    await _plugin.zonedSchedule(
      id,
      '💊 İlaç Zamanı: $ilacAdi',
      '$ilacAdi ilacınızı almayı unutmayın.',
      hedef,
      _bildirimDetaylari(),
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      matchDateTimeComponents: DateTimeComponents.time, // her gün aynı saatte tekrar eder
      payload: ilacAdi,
    );
  }

  static Future<void> iptalEt(int id) async {
    await baslat();
    await _plugin.cancel(id);
  }
}
