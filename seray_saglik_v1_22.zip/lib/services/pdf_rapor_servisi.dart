import 'dart:io';
import 'package:flutter/services.dart' show rootBundle;
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import 'veritabani_yardimcisi.dart';

class PdfRaporServisi {
  // Kayıtlı tüm şeker ve tansiyon ölçümlerini, Seray logosuyla birlikte
  // tek bir PDF raporu haline getirir ve paylaşım (WhatsApp dahil) ekranını açar.
  static Future<void> gunlukRaporuOlusturVePaylas({required String kullaniciAdi}) async {
    final sekerler = await VeritabaniYardimcisi().sekerleriGetir();
    final tansiyonlar = await VeritabaniYardimcisi().tansiyonlariGetir();

    final logoBaytlari = await rootBundle.load('assets/images/app_logo.png');
    final logo = pw.MemoryImage(logoBaytlari.buffer.asUint8List());

    String tarihiBicimlendir(String? isoTarih) {
      if (isoTarih == null) return '-';
      final t = DateTime.tryParse(isoTarih);
      if (t == null) return '-';
      String iki(int n) => n.toString().padLeft(2, '0');
      return '${iki(t.day)}.${iki(t.month)}.${t.year} ${iki(t.hour)}:${iki(t.minute)}';
    }

    final belge = pw.Document();
    belge.addPage(
      pw.MultiPage(
        build: (context) => [
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.center,
            children: [
              pw.Image(logo, width: 60, height: 60),
              pw.SizedBox(width: 12),
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text('Seray Sağlık Asistanım', style: pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold)),
                  pw.Text('Ölçüm Raporu - $kullaniciAdi'),
                ],
              ),
            ],
          ),
          pw.SizedBox(height: 20),
          pw.Text('Kan Şekeri Ölçümleri', style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 8),
          pw.Table.fromTextArray(
            headers: ['Tarih / Saat', 'Değer (mg/dL)', 'Durum'],
            data: sekerler.map((s) => [tarihiBicimlendir(s['tarih']?.toString()), '${s['deger']}', '${s['durum']}']).toList(),
          ),
          pw.SizedBox(height: 24),
          pw.Text('Tansiyon Ölçümleri', style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 8),
          pw.Table.fromTextArray(
            headers: ['Tarih / Saat', 'Büyük/Küçük', 'Nabız'],
            data: tansiyonlar.map((t) => [tarihiBicimlendir(t['tarih']?.toString()), '${t['buyuk']}/${t['kucuk']}', '${t['nabiz']}']).toList(),
          ),
        ],
      ),
    );

    final gecici = await getTemporaryDirectory();
    final dosyaYolu = '${gecici.path}/seray_saglik_raporu.pdf';
    final dosya = File(dosyaYolu);
    await dosya.writeAsBytes(await belge.save());

    await Share.shareXFiles([XFile(dosyaYolu, name: 'seray_saglik_raporu.pdf')], text: 'Seray Sağlık Asistanım - Ölçüm Raporu');
  }
}
