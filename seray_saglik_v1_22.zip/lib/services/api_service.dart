import 'dart:convert';
import 'package:googleai_dart/googleai_dart.dart';
import 'veritabani_yardimcisi.dart';

class ApiService {
  static final GoogleAIClient _client = GoogleAIClient(
    config: GoogleAIConfig.googleAI(
      authProvider: ApiKeyProvider('AQ.Ab8RN6LQTThMgNTmxqX8O5VfkGFxrSRGPG5UjUgYN0TdR2Y8Lg'),
    ),
  );

  static Future<String> tahlilMetniniAnalizEt(String pdfMetni) async {
    if (pdfMetni.trim().isEmpty) return "Metin içeriği boş.";

    final istek = 'Sen profesyonel bir laboratuvar uzmanısın. Aşağıdaki e-Nabız metnindeki tüm tahlilleri, sonuçları ve referans değerlerini bul.\n'
        'Cevabı başka hiçbir metin eklemeden SADECE şu formatta bir JSON listesi olarak döndür:\n'
        '[{"tarih":"2026-06-24", "ad":"Glukoz", "sonuc":"155", "ref":"80-110"}, {"tarih":"2026-06-24", "ad":"HbA1c", "sonuc":"9.4", "ref":"4.8-5.9"}]\n\n'
        'METİN:\n$pdfMetni';

    try {
      final response = await _client.models.generateContent(
        model: 'gemini-flash-latest', 
        request: GenerateContentRequest(
          contents: [Content(parts: [TextPart(istek)], role: 'user')],
          generationConfig: GenerationConfig(responseMimeType: 'application/json'),
        ),
      );

      String hamCevap = _metniCikar(response.candidates?.first.content?.parts);
      hamCevap = hamCevap.replaceAll('```json', '').replaceAll('```', '').trim();
      
      List<dynamic> tahlilListesi = jsonDecode(hamCevap);
      String yorumMetni = "📄 E-NABIZ LABORATUVAR ANALİZ RAPORU\n\n";
      final bugun = DateTime.now();
      final bugununTarihi = '${bugun.year}-${bugun.month.toString().padLeft(2, '0')}-${bugun.day.toString().padLeft(2, '0')}';

      for (var tahlil in tahlilListesi) {
        await VeritabaniYardimcisi().tahlilEkle({
          'tarih': bugununTarihi, // AI'nin döndürdüğü tarihe güvenmek yerine gerçek yükleme tarihini kullanıyoruz
          'tahlil_adi': tahlil['ad'],
          'sonuc': tahlil['sonuc'],
          'referans_degeri': tahlil['ref'],
        });
        yorumMetni += "• ${tahlil['ad']}: ${tahlil['sonuc']} (Ref: ${tahlil['ref']})\n";
      }

      final yorumIstegi = 'Aşağıdaki tahlil sonuçlarını incele, referans aralığı dışındaki tehlikeli olanları büyük harflerle belirt ve yaşlı bir amcanın anlayacağı dilde tatlı dille uyar:\n$yorumMetni';
      final yorumResponse = await _client.models.generateContent(
        model: 'gemini-flash-latest',
        request: GenerateContentRequest(contents: [Content(parts: [TextPart(yorumIstegi)], role: 'user')]),
      );

      final yorumSonuc = _metniCikar(yorumResponse.candidates?.first.content?.parts);
      return yorumSonuc.isNotEmpty ? yorumSonuc : yorumMetni;
    } catch (e) {
      return "Analiz esnasında bir bağlantı hatası oluştu.";
    }
  }

  // 'Part' sealed sınıfından güvenli şekilde metni çıkarır.
  // (googleai_dart paketinde Part.text getter'ı kaldırıldığı için gerekli)
  static String _metniCikar(List<Part>? parts) {
    if (parts == null || parts.isEmpty) return '';
    for (final part in parts) {
      if (part is TextPart) {
        return part.text;
      }
    }
    return '';
  }
}
