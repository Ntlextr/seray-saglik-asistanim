import 'package:flutter/material.dart';

class ProfilKayitEkrani extends StatefulWidget {
  const ProfilKayitEkrani({super.key});

  @override
  State<ProfilKayitEkrani> createState() => _ProfilKayitEkraniState();
}

class _ProfilKayitEkraniState extends State<ProfilKayitEkrani> {
  final _formKey = GlobalKey<FormState>();
  String? _diyabetTipi = 'Yok';
  bool _kvkkOnay = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Profil Kayıt"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              DropdownButtonFormField<String>(
                value: _diyabetTipi,
                decoration: const InputDecoration(labelText: 'Diyabet Tipi'),
                items: ['Yok', 'Tip 1 Diyabet', 'Tip 2 Diyabet', 'Gizli Şeker'].map((String deger) {
                  return DropdownMenuItem<String>(
                    value: deger,
                    child: Text(deger),
                  );
                }).toList(),
                onChanged: (yeniDeger) => setState(() => _diyabetTipi = yeniDeger!),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Checkbox(
                    value: _kvkkOnay,
                    onChanged: (deger) => setState(() => _kvkkOnay = deger!),
                  ),
                  const Text("KVKK Onayı"),
                ],
              ),
              const Spacer(),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    // Kayıt işlemleri buraya
                  }
                },
                child: const Text("Kaydet"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
