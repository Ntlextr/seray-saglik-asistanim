import 'dart:async';
import '../theme/renkler.dart';
import '../theme/sablon.dart';
import '../services/dil_servisi.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'seker_ekle_ekrani.dart';
import 'tansiyon_ekle_ekrani.dart';
import 'su_kilo_ekrani.dart';
import 'beslenme_ekrani.dart';
import 'ilac_ekrani.dart';
import 'yapay_zeka_ekrani.dart';
import 'rapor_ekrani.dart';
import 'seray_asistan_ekrani.dart';
import '../services/veritabani_yardimcisi.dart';
import '../services/adim_servisi.dart';
import '../services/widget_servisi.dart';
import '../widgets/ust_menu.dart';

class AnaSayfa extends StatefulWidget {
  const AnaSayfa({Key? key}) : super(key: key);

  @override
  _AnaSayfaState createState() => _AnaSayfaState();
}

class _AnaSayfaState extends State<AnaSayfa> {
  // Alt menüde sekme değiştirdiğinde main.dart bu ekranı YENİDEN KURUYOR
  // (veri tazelensin diye). Bu "static" bayrak sayesinde karşılama banner'ı
  // uygulama açıldığında sadece BİR KEZ gösteriliyor, her "Özet"e dönüşte değil.
  static bool _buOturumdaGosterildi = false;

  String _kullaniciAdi = "...";
  String _cinsiyet = "Bay";
  List<Map<String, dynamic>> _sonSekerler = [];
  List<Map<String, dynamic>> _sonTansiyonlar = [];
  // YENİ: "Yaklaşan İlaçlarınız" bölümü için — kullanıcının isteği üzerine
  // (Ana Sayfa'nın "veri giriş paneli" gibi görünmesi şikayeti sonrası)
  // eklendi. Randevu takibi diye bir özellik projede hiç yoktu, bunun
  // yerine zaten var olan ilaç saatleri kullanılarak "bugün henüz saati
  // gelmemiş ilaçlar" listesi gösteriliyor.
  List<Map<String, dynamic>> _ilaclar = [];
  int _bugunSuMl = 0;
  double? _sonKilo;
  int _bugunAdim = 0;
  Timer? _adimYenilemeTimer;
  static const int _gunlukSuHedefiMl = 2000;

  // Karşılama banner'ı popup DEĞİL; ekrana girince görünür, birkaç
  // saniye sonra kendiliğinden solup kaybolur.
  bool _selamGorunur = true;
  bool _selamSoluyor = false;
  Timer? _selamZamanlayici;
  Timer? _selamKaybolmaZamanlayici;

  // Widget ekleme bannerı — kullanıcı ekleyince veya kapatınca bir daha
  // görünmesin diye SharedPreferences'ta kalıcı olarak saklanıyor.
  bool _widgetBanneriGizli = false;

  String get _hitap => DilServisi.dilKodu == 'en' ? '' : ((_cinsiyet == 'Bayan' || _cinsiyet == 'Kadın') ? 'Hanım' : 'Bey');

  String get _selamlama {
    final saat = DateTime.now().hour;
    if (saat >= 5 && saat < 12) return DilServisi.metin('selamlamaGunaydin');
    if (saat >= 12 && saat < 18) return DilServisi.metin('selamlamaIyiGunler');
    if (saat >= 18 && saat < 23) return DilServisi.metin('selamlamaIyiAksamlar');
    return DilServisi.metin('selamlamaIyiGeceler');
  }

  // YENİ: Bugün için henüz saati gelmemiş ilaçları, saate göre artan
  // sırada döndürür (en yakın olan önce). "saat" alanı veritabanında tek
  // bir "HH:mm" metni olarak tutuluyor (bkz. ilac_ekrani.dart satır ~312).
  List<Map<String, dynamic>> get _yaklasanIlaclar {
    final simdi = TimeOfDay.now();
    final simdiDakika = simdi.hour * 60 + simdi.minute;

    final sonuc = _ilaclar.where((ilac) {
      final saatMetni = ilac['saat']?.toString();
      if (saatMetni == null || !saatMetni.contains(':')) return false;
      final parcalar = saatMetni.split(':');
      final saat = int.tryParse(parcalar[0]);
      final dakika = int.tryParse(parcalar.length > 1 ? parcalar[1] : '0');
      if (saat == null || dakika == null) return false;
      return (saat * 60 + dakika) > simdiDakika;
    }).toList();

    sonuc.sort((a, b) {
      final aParcalar = a['saat'].toString().split(':');
      final bParcalar = b['saat'].toString().split(':');
      final aDakika = (int.tryParse(aParcalar[0]) ?? 0) * 60 + (int.tryParse(aParcalar.length > 1 ? aParcalar[1] : '0') ?? 0);
      final bDakika = (int.tryParse(bParcalar[0]) ?? 0) * 60 + (int.tryParse(bParcalar.length > 1 ? bParcalar[1] : '0') ?? 0);
      return aDakika.compareTo(bDakika);
    });

    return sonuc;
  }  // --- _yaklasanIlaclar getter sonu ---

  String _tarihiBicimlendir(String? isoTarih) {
    if (isoTarih == null) return '';
    final t = DateTime.tryParse(isoTarih);
    if (t == null) return isoTarih;
    String iki(int n) => n.toString().padLeft(2, '0');
    return '${iki(t.day)}.${iki(t.month)}.${t.year} ${iki(t.hour)}:${iki(t.minute)}';
  }

  @override
  void initState() {
    super.initState();
    _verileriTazele();
    if (!_buOturumdaGosterildi) {
      _buOturumdaGosterildi = true;
      _selamZamanlayici = Timer(const Duration(seconds: 5), () {
        if (!mounted) return;
        setState(() => _selamSoluyor = true);
        _selamKaybolmaZamanlayici = Timer(const Duration(milliseconds: 1400), () {
          if (mounted) setState(() => _selamGorunur = false);
        });
      });
    } else {
      // Bu oturumda zaten gösterildi — tekrar açılmasın.
      _selamGorunur = false;
    }
    AdimServisi.baslat();
    _adimYenilemeTimer = Timer.periodic(const Duration(seconds: 5), (_) async {
      final adim = await AdimServisi.bugunkuAdimGetir();
      if (mounted) setState(() => _bugunAdim = adim);
      WidgetServisi.guncelle(adim: adim, suMl: _bugunSuMl);
    });
  }

  @override
  void dispose() {
    _selamZamanlayici?.cancel();
    _selamKaybolmaZamanlayici?.cancel();
    _adimYenilemeTimer?.cancel();
    super.dispose();
  }

  Future<void> _verileriTazele() async {
    final prefs = await SharedPreferences.getInstance();
    final sekerler = await VeritabaniYardimcisi().sekerleriGetir();
    final tansiyonlar = await VeritabaniYardimcisi().tansiyonlariGetir();
    final bugunSu = await VeritabaniYardimcisi().bugunToplamSuGetir();
    final kiloKayitlari = await VeritabaniYardimcisi().kiloKayitlariniGetir();
    final ilaclar = await VeritabaniYardimcisi().ilaclariGetir();

    setState(() {
      // Hem profil_kayit_ekrani hem eski kayıt anahtarları kontrol ediliyor
      _kullaniciAdi = prefs.getString('kullanici_ad') ?? 
                       prefs.getString('user_ad') ?? 
                       "Kullanıcı";
      _cinsiyet = prefs.getString('kullanici_cinsiyet') ?? 
                  prefs.getString('user_cinsiyet') ?? 
                  "Bay";
                  
      _sonSekerler = sekerler;
      _sonTansiyonlar = tansiyonlar;
      _bugunSuMl = bugunSu;
      _sonKilo = kiloKayitlari.isNotEmpty ? (kiloKayitlari.first['kilo'] as num?)?.toDouble() : null;
      _ilaclar = ilaclar;
      _widgetBanneriGizli = prefs.getBool('widget_banneri_gizli') ?? false;
    });
    WidgetServisi.guncelle(adim: _bugunAdim, suMl: _bugunSuMl);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(
        shape: AppSablon.appBarSekli,
        clipBehavior: Clip.antiAlias,
        title: Text(DilServisi.metin('anaSayfaBaslik'), style: const TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: AppRenkleri.aktif,
        foregroundColor: Colors.white,
        elevation: 0,
        actions: const [UstMenu()],
      ),
      body: Stack(
        children: [
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [

              // ============================================================
              // YENİ: "Son Kan Şekeri" + "Son Tansiyon" — poster/mockup
              // referansına göre yan yana, büyük punto özet kartları.
              // Kullanıcının "Ana Sayfa veri giriş paneline dönüşmüş"
              // şikayeti üzerine, hızlı ekleme butonlarının ÖNÜNE alındı.
              // ============================================================
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
                        border: Border.all(color: Colors.grey.shade200),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(DilServisi.metin('kanSekeriBaslik'), style: TextStyle(fontSize: 12, color: Colors.grey.shade600, fontWeight: FontWeight.w600)),
                          const SizedBox(height: 6),
                          if (_sonSekerler.isNotEmpty) ...[
                            Text('${_sonSekerler.first['deger']}', style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Colors.red)),
                            Text('mg/dL', style: TextStyle(fontSize: 11, color: Colors.grey.shade500)),
                            const SizedBox(height: 4),
                            Text(_tarihiBicimlendir(_sonSekerler.first['tarih']?.toString()), style: TextStyle(fontSize: 11, color: Colors.grey.shade500)),
                          ] else
                            Text('—', style: TextStyle(fontSize: 22, color: Colors.grey.shade400)),                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
                        border: Border.all(color: Colors.grey.shade200),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(DilServisi.metin('tansiyon'), style: TextStyle(fontSize: 12, color: Colors.grey.shade600, fontWeight: FontWeight.w600)),
                          const SizedBox(height: 6),
                          if (_sonTansiyonlar.isNotEmpty) ...[
                            Text('${_sonTansiyonlar.first['buyuk']}/${_sonTansiyonlar.first['kucuk']}', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: AppRenkleri.aktif.shade700)),
                            Text('mmHg', style: TextStyle(fontSize: 11, color: Colors.grey.shade500)),
                            const SizedBox(height: 4),
                            Text(_tarihiBicimlendir(_sonTansiyonlar.first['tarih']?.toString()), style: TextStyle(fontSize: 11, color: Colors.grey.shade500)),
                          ] else
                            Text('—', style: TextStyle(fontSize: 22, color: Colors.grey.shade400)),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),

              // YENİ (geri eklendi): Kilo özeti — önceki turda Şeker/
              // Tansiyon kartlarıyla birlikte yanlışlıkla silinmişti,
              // kullanıcı geri istedi. Kompakt, tek satırlık bir kart.
              if (_sonKilo != null)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
                    border: Border.all(color: Colors.grey.shade200),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.monitor_weight_outlined, color: Colors.purple, size: 20),
                      const SizedBox(width: 10),
                      Text(DilServisi.metin('kiloBaslik'), style: TextStyle(fontSize: 13, color: Colors.grey.shade600)),
                      const Spacer(),
                      Text('${_sonKilo!.toStringAsFixed(1)} kg', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                    ],
                  ),
                ),
              if (_sonKilo != null) const SizedBox(height: 10),

              // Boş durum: hiçbir ölçüm yoksa (yeni kullanıcı) kısa bir
              // bilgilendirme — önceki turda bu mesaj sabit Türkçe idi,
              // artık DilServisi'ye bağlandı.
              if (_sonSekerler.isEmpty && _sonTansiyonlar.isEmpty && _sonKilo == null)
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
                  ),
                  child: Center(
                    child: Text(
                      DilServisi.metin('henuzOlcumYok'),
                      style: const TextStyle(color: Colors.grey),
                    ),
                  ),
                ),
              if (_sonSekerler.isEmpty && _sonTansiyonlar.isEmpty && _sonKilo == null) const SizedBox(height: 10),

              // YENİ: "Yaklaşan İlaçlarınız" — randevu takibi diye bir
              // özellik hiç yoktu (kullanıcıyla netleştirildi), bunun
              // yerine zaten var olan ilaç saatlerinden bugün için henüz
              // gelmemiş olanlar gösteriliyor.
              if (_yaklasanIlaclar.isNotEmpty)
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
                    border: Border.all(color: Colors.grey.shade200),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(Icons.medication_outlined, size: 18, color: AppRenkleri.aktif),
                          const SizedBox(width: 8),
                          Text(DilServisi.metin('yaklasanIlaclariniz'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                        ],
                      ),
                      const SizedBox(height: 10),
                      for (final ilac in _yaklasanIlaclar.take(3))
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          child: Row(
                            children: [
                              Container(
                                width: 52,
                                alignment: Alignment.centerLeft,
                                child: Text(ilac['saat']?.toString() ?? '', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: AppRenkleri.aktif.shade700)),
                              ),
                              Expanded(
                                child: Text(
                                  '${ilac['ad'] ?? ''}${(ilac['dozaj'] ?? '').toString().isNotEmpty ? ' ${ilac['dozaj']}' : ''}',
                                  style: const TextStyle(fontSize: 13),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                        ),
                    ],
                  ),
                ),
              if (_yaklasanIlaclar.isNotEmpty) const SizedBox(height: 10),


              // YENİ: "Seray AI" tanıtım/kısayol bandı — poster referansına
              // göre eklendi, Seray AI sohbet ekranına doğrudan götürüyor.
              Material(
                color: AppRenkleri.aktif,
                borderRadius: BorderRadius.circular(14),
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const SerayAsistanEkrani()),
                    ).then((_) => _verileriTazele());
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        const CircleAvatar(
                          radius: 22,
                          backgroundColor: Colors.white24,
                          child: Icon(Icons.auto_awesome, color: Colors.white, size: 24),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Seray AI', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
                              const SizedBox(height: 2),
                              Text(DilServisi.metin('serayAiKisaTanitim'), style: const TextStyle(color: Colors.white70, fontSize: 12)),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_right, color: Colors.white),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),

                  // HIZLI BUTONLAR (Şeker / Tansiyon / Su & Kilo — ekrana sığacak şekilde)
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppRenkleri.aktif,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
                        ),
                      ),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => SekerEkleEkrani(),
                          ),
                        ).then((_) => _verileriTazele());
                      },
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          (AppSablon.modernMi || AppSablon.enerjikMi)
                              ? Container(
                                  width: 34,
                                  height: 34,
                                  decoration: BoxDecoration(color: AppSablon.ikonRozetiRengi, shape: BoxShape.circle),
                                  child: Icon(AppSablon.enerjikMi ? Icons.bloodtype_rounded : Icons.bloodtype_outlined, size: AppSablon.ikonBoyutu),
                                )
                              : Icon(Icons.bloodtype, size: AppSablon.ikonBoyutu),
                          SizedBox(height: 2),
                          Text(DilServisi.metin('sekerEkle'), style: TextStyle(fontSize: 11), textAlign: TextAlign.center),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppRenkleri.aktif.shade700,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
                        ),
                      ),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => TansiyonEkleEkrani(),
                          ),
                        ).then((_) => _verileriTazele());
                      },
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          (AppSablon.modernMi || AppSablon.enerjikMi)
                              ? Container(
                                  width: 34,
                                  height: 34,
                                  decoration: BoxDecoration(color: AppSablon.ikonRozetiRengi, shape: BoxShape.circle),
                                  child: Icon(AppSablon.enerjikMi ? Icons.favorite_rounded : Icons.favorite_border, size: AppSablon.ikonBoyutu),
                                )
                              : Icon(Icons.favorite, size: AppSablon.ikonBoyutu),
                          SizedBox(height: 2),
                          Text(DilServisi.metin('tansiyonEkle'), style: TextStyle(fontSize: 11), textAlign: TextAlign.center),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blue.shade600,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
                        ),
                      ),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const SuKiloEkrani(),
                          ),
                        ).then((_) => _verileriTazele());
                      },
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          (AppSablon.modernMi || AppSablon.enerjikMi)
                              ? Container(
                                  width: 34,
                                  height: 34,
                                  decoration: BoxDecoration(color: AppSablon.ikonRozetiRengi, shape: BoxShape.circle),
                                  child: Icon(AppSablon.enerjikMi ? Icons.water_drop_rounded : Icons.water_drop_outlined, size: AppSablon.ikonBoyutu),
                                )
                              : Icon(Icons.water_drop, size: AppSablon.ikonBoyutu),
                          SizedBox(height: 2),
                          Text(DilServisi.metin('suKilo'), style: TextStyle(fontSize: 11), textAlign: TextAlign.center),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              // YENİ: Yemek ve İlaç Ekle de artık burada — önceden sadece
              // kendi ekranlarından erişilebiliyordu, kullanıcı geri
              // bildirimiyle "hızlı ekleme" mantığı tutarlı hale getirildi.
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.deepOrange.shade400,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
                      ),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const BeslenmeEkrani()),
                        ).then((_) => _verileriTazele());
                      },
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          (AppSablon.modernMi || AppSablon.enerjikMi)
                              ? Container(
                                  width: 34,
                                  height: 34,
                                  decoration: BoxDecoration(color: AppSablon.ikonRozetiRengi, shape: BoxShape.circle),
                                  child: Icon(AppSablon.enerjikMi ? Icons.restaurant_menu_rounded : Icons.restaurant_menu_outlined, size: AppSablon.ikonBoyutu),
                                )
                              : Icon(Icons.restaurant_menu, size: AppSablon.ikonBoyutu),
                          SizedBox(height: 2),
                          Text(DilServisi.metin('yemekEkle'), style: TextStyle(fontSize: 11), textAlign: TextAlign.center),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red.shade400,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
                      ),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const IlacEkrani()),
                        ).then((_) => _verileriTazele());
                      },
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          (AppSablon.modernMi || AppSablon.enerjikMi)
                              ? Container(
                                  width: 34,
                                  height: 34,
                                  decoration: BoxDecoration(color: AppSablon.ikonRozetiRengi, shape: BoxShape.circle),
                                  child: Icon(AppSablon.enerjikMi ? Icons.medication_rounded : Icons.medication_outlined, size: AppSablon.ikonBoyutu),
                                )
                              : Icon(Icons.medication, size: AppSablon.ikonBoyutu),
                          SizedBox(height: 2),
                          Text(DilServisi.metin('ilacEkle'), style: TextStyle(fontSize: 11), textAlign: TextAlign.center),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),

              // WIDGET EKLEME BANNERI — bir kere eklenince veya "Kapat"
              // denince bir daha görünmez (SharedPreferences'ta saklanır).
              if (!_widgetBanneriGizli)
                Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppRenkleri.aktif.shade50,
                    borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
                    border: Border.all(color: AppRenkleri.aktif.shade200),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.widgets_outlined, color: AppRenkleri.aktif.shade700, size: 26),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(DilServisi.metin('adimSuWidgetEkle'), style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: AppRenkleri.aktif.shade800)),
                            const SizedBox(height: 6),
                            Row(
                              children: [
                                ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: AppRenkleri.aktif,
                                    foregroundColor: Colors.white,
                                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                                    minimumSize: Size.zero,
                                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                  ),
                                  onPressed: () async {
                                    await WidgetServisi.anaEkraneSabitle();
                                    final tercihler = await SharedPreferences.getInstance();
                                    await tercihler.setBool('widget_banneri_gizli', true);
                                    if (mounted) setState(() => _widgetBanneriGizli = true);
                                    // ÖNEMLİ: requestPinWidget() başarıyla ÇAĞRILDI mı yoksa
                                    // telefonun kendi ekleme penceresi GERÇEKTEN açıldı mı,
                                    // bunu koddan kesin olarak bilemiyoruz (bazı telefonlarda/
                                    // launcher'larda bu özellik desteklenmeyebilir, sessizce
                                    // hiçbir şey olmaz). Bu yüzden her durumda elle ekleme
                                    // talimatını da gösteriyoruz.
                                    if (mounted) {
                                      showDialog(
                                        context: context,
                                        builder: (dialogContext) => AlertDialog(
                                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                                          title: Text(DilServisi.metin('widgetEklemeBaslik')),
                                          content: Text(DilServisi.metin('widgetEklemeAciklama')),
                                          actions: [
                                            TextButton(onPressed: () => Navigator.pop(dialogContext), child: Text(DilServisi.metin('anladim'))),
                                          ],
                                        ),
                                      );
                                    }
                                  },
                                  child: Text(DilServisi.metin('widgetEkle'), style: const TextStyle(fontSize: 12)),
                                ),
                                TextButton(
                                  onPressed: () async {
                                    final tercihler = await SharedPreferences.getInstance();
                                    await tercihler.setBool('widget_banneri_gizli', true);
                                    if (mounted) setState(() => _widgetBanneriGizli = true);
                                  },
                                  child: Text(DilServisi.metin('kapat'), style: const TextStyle(fontSize: 12)),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

              // e-NABIZ TAHLİLLERİM — hızlı ölçüm ekleme butonlarından ayrı
              // ve göze çarpan bir kart: bu bir "ölçüm ekle" değil, "tahlil
              // yükle / görüntüle" eylemi olduğu için tek başına vurgulandı.
              Material(
                color: AppRenkleri.aktif,
                borderRadius: BorderRadius.circular(14),
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const YapayZekaEkrani()),
                    ).then((_) => _verileriTazele());
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: Row(
                      children: [
                        const CircleAvatar(
                          radius: 18,
                          backgroundColor: Colors.white24,
                          child: Icon(Icons.picture_as_pdf, color: Colors.white, size: 20),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(DilServisi.metin('eNabizTahlillerim'), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
                              const SizedBox(height: 2),
                              Text(DilServisi.metin('eNabizAciklama'), style: const TextStyle(color: Colors.white70, fontSize: 12)),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_right, color: Colors.white),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),

              // RAPOR ANALİZİ — e-Nabız kartının hemen altında, aynı vurgu
              // seviyesinde: bu da bir "ölçüm ekle" değil, "rapor yükle /
              // yapay zekaya yorumlat" eylemi. Kullanıcının önceden Gemini/
              // ChatGPT'ye elle yaptırdığı işi uygulama içine taşıyor.
              Material(
                color: AppRenkleri.aktif.shade700,
                borderRadius: BorderRadius.circular(14),
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const RaporEkrani()),
                    ).then((_) => _verileriTazele());
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: Row(
                      children: [
                        const CircleAvatar(
                          radius: 18,
                          backgroundColor: Colors.white24,
                          child: Icon(Icons.description, color: Colors.white, size: 20),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(DilServisi.metin('raporAnalizi'), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
                              const SizedBox(height: 2),
                              Text(DilServisi.metin('raporAciklama'), style: const TextStyle(color: Colors.white70, fontSize: 12)),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_right, color: Colors.white),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 24),

              // SON ÖLÇÜMLER BAŞLIĞI
              Text(
                DilServisi.metin('sonOlcumleriniz'),
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF111424),
                ),
              ),
              const SizedBox(height: 12),

              // ADIM SAYAR ÖZETİ
              Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
                ),
                child: ListTile(
                  leading: const CircleAvatar(
                    backgroundColor: Color(0xFFFFF3E0),
                    child: Icon(Icons.directions_walk, color: Colors.deepOrange),
                  ),
                  title: Text(
                    '${DilServisi.metin('adimBaslik')}: $_bugunAdim',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text('${DilServisi.metin('tahminiYakilanKalori')}: ${AdimServisi.kaloriTahminEt(_bugunAdim).toStringAsFixed(0)} kcal'),
                ),
              ),
              const SizedBox(height: 8),

              // SU TAKİBİ ÖZETİ
              Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
                ),
                child: ListTile(
                  leading: const CircleAvatar(
                    backgroundColor: Color(0xFFE1F5FE),
                    child: Icon(Icons.water_drop, color: Colors.blue),
                  ),
                  title: Text(
                    '${DilServisi.metin('suBaslik')}: ${(_bugunSuMl / 1000).toStringAsFixed(1)} L / ${(_gunlukSuHedefiMl / 1000).toStringAsFixed(0)} L',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text(
                    _bugunSuMl >= _gunlukSuHedefiMl
                        ? '🎉 ${DilServisi.metin('bugunkuHedefeUlastiniz')}'
                        : '${DilServisi.metin('bugunKelime')} ${(_gunlukSuHedefiMl - _bugunSuMl).clamp(0, _gunlukSuHedefiMl)} mL ${DilServisi.metin('kaldiTek')}',
                  ),
                ),
              ),
              const SizedBox(height: 8),

            ],
              ),
            ),
          ),
          // KARŞILAMA OVERLAY'İ — popup DEĞİL: ekranın ortasında belirir,
          // birkaç saniye sonra bulut gibi yavaşça büyüyüp solarak kaybolur.
          // IgnorePointer sayesinde altındaki içeriğe dokunmaya engel olmaz.
          if (_selamGorunur)
            Positioned.fill(
              child: IgnorePointer(
                child: Center(
                  child: AnimatedOpacity(
                    opacity: _selamSoluyor ? 0.0 : 1.0,
                    duration: const Duration(milliseconds: 1400),
                    curve: Curves.easeOut,
                    child: AnimatedScale(
                      scale: _selamSoluyor ? 1.25 : 1.0,
                      duration: const Duration(milliseconds: 1400),
                      curve: Curves.easeOut,
                      child: Container(
                        margin: const EdgeInsets.symmetric(horizontal: 32),
                        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
                        decoration: BoxDecoration(
                          color: AppRenkleri.aktif.shade50,
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.12), blurRadius: 16, offset: const Offset(0, 6))],
                        ),
                        child: Text(
                          '$_selamlama, $_kullaniciAdi${_hitap.isEmpty ? "" : " $_hitap"} 🌤️',
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Color(0xFF006655)),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
      // NOT: Alt navigasyon menüsü artık sadece main.dart'taki
      // AnaEkranYonlendirici içinde tek bir yerden yönetiliyor.
      // Burada ikinci bir bottomNavigationBar OLMAMALI, aksi halde
      // eski (Ana Sayfa/Şeker/Tansiyon/Profil) menü ile yeni
      // (Özet/Analizler/İlaçlarım/Profil) menü çakışır.
    );
  }
}
