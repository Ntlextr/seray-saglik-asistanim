import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';

// Örnek Şeker Veri Modeli (Senin projedeki model yapına göre uyarlandı)
class SekerModel {
  final int deger;
  final String tip; // "Açlık" veya "Tokluk"
  final String tarih;

  SekerModel({required this.deger, required this.tip, required this.tarih});
}

class SekerTakipScreen extends StatefulWidget {
  const SekerTakipScreen({Key? key}) : super(key: key);

  @override
  State<SekerTakipScreen> createState() => _SekerTakipScreenState();
}

class _SekerTakipScreenState extends State<SekerTakipScreen> {
  final FlutterTts _flutterTts = FlutterTts();
  bool _sesCaliniyor = false;

  // Örnek Ölçüm Listesi (Veritabanından gelen verilerle otomatik eşleşir)
  final List<SekerModel> _olcumler = [
    SekerModel(deger: 95, tip: 'Açlık', tarih: '22.07.2026'),
    SekerModel(deger: 155, tip: 'Tokluk', tarih: '21.07.2026'),
  ];

  // 🔊 ŞEKER DEĞERLERİNİ ANALİZ EDİP SESLİ OKUYAN SİHİRLİ FONKSİYON
  Future<void> _sekerAnaliziniSeslendir() async {
    if (_sesCaliniyor) {
      await _flutterTts.stop();
      setState(() => _sesCaliniyor = false);
      return;
    }

    if (_olcumler.isEmpty) {
      await _flutterTts.speak("Henüz kaydedilmiş bir şeker ölçümünüz bulunmamaktadır.");
      return;
    }

    // En son girilen şeker kaydını alıp analiz ediyoruz
    final sonOlcum = _olcumler.first;
    int deger = sonOlcum.deger;
    String tip = sonOlcum.tip;
    
    String durumMetni = "Son ölçümünüze göre $tip kan şekeri değeriniz $deger miligram bölü desilitredir. ";

    if (tip == 'Açlık') {
      if (deger > 125) {
        durumMetni += "Açlık şekeriniz normal sınırların üzerindedir. Lütfen beslenmenize dikkat ediniz ve doktorunuzla görüşünüz.";
      } else if (deger < 70) {
        durumMetni += "Açlık şekeriniz düşük seyretmektedir. Halsizlik veya titreme hissediyorsanız hızlı emilen bir şeker kaynağı tüketebilirsiniz.";
      } else {
        durumMetni += "Açlık şekeri seyriniz tamamen ideal ve normal sınırlardadır. Tebrik ederiz.";
      }
    } else { // Tokluk Ölçümü
      if (deger > 140) {
        durumMetni += "Tokluk şekeriniz hedef değerlerin biraz üzerinde çıkmıştır. Karbonhidrat tüketiminizi gözden geçirmenizi öneririz.";
      } else if (deger < 100) {
        durumMetni += "Tokluk şekeriniz normal sınırlardadır, gidişatınız gayet güzel.";
      } else {
        durumMetni += "Tokluk şekeri seyriniz ideal aralıktadır. Sağlıklı günler dileriz.";
      }
    }

    setState(() => _sesCaliniyor = true);
    await _flutterTts.setLanguage("tr-TR");
    await _flutterTts.setPitch(1.0);
    await _flutterTts.speak(durumMetni);

    _flutterTts.setCompletionHandler(() {
      setState(() => _sesCaliniyor = false);
    });
  }

  @override
  void dispose() {
    _flutterTts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Şeker Takibi', style: TextStyle(color: Color(0xFF111424), fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Color(0xFF111424)),
        actions: [
          // 🔔 İSTEDİĞİNİZ SESLİ OKUMA HOPARLÖR BUTONU
          IconButton(
            icon: Icon(
              _sesCaliniyor ? Icons.stop_circle : Icons.volume_up,
              color: Colors.blue,
              size: 28,
            ),
            onPressed: _sekerAnaliziniSeslendir,
          ),
          const SizedBox(width: 12),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Ölçüm Geçmişiniz', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Expanded(
              child: ListView.builder(
                itemCount: _olcumler.length,
                itemBuilder: (context, index) {
                  final olcum = _olcumler[index];
                  
                  // Tıbbi yüksek/normal sınır kontrolleri
                  bool yuksekMi = (olcum.tip == 'Açlık' && olcum.deger > 125) || 
                                  (olcum.tip == 'Tokluk' && olcum.deger > 140);
                                  
                  return Card(
                    margin: const EdgeInsets.symmetric(vertical: 6),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    child: ListTile(
                      leading: Icon(
                        Icons.opacity, 
                        color: yuksekMi ? Colors.red : Colors.green,
                        size: 28
                      ),
                      title: Text(
                        '${olcum.deger} mg/dL',
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                      ),
                      subtitle: Text('${olcum.tip} Ölçümü - ${olcum.tarih}'),
                      trailing: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: yuksekMi ? Colors.red.shade50 : Colors.green.shade50,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          yuksekMi ? 'Yüksek' : 'Normal',
                          style: TextStyle(color: yuksekMi ? Colors.red : Colors.green, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
