import 'package:shared_preferences/shared_preferences.dart';

// ═══════════════════════════════════════════════════════════
// ÇOKLU DİL SİSTEMİ — 17 Ağustos'ta başlandı. Bu, sadece ALTYAPI +
// KÜÇÜK BİR PİLOT (Ana Sayfa 5 buton + alt menü). Geri kalan ~30 ekran
// BİLİNÇLİ OLARAK bırakıldı — kullanım limiti nedeniyle bu turda yarım
// bırakmamak için kapsam küçük tutuldu.
//
// NASIL ÇALIŞIR: Kod hiçbir zaman düz Türkçe yazmaz. Ekrana yazı
// basarken DilServisi.metin('anahtarAdi') çağrılır, o an seçili dile
// göre doğru karşılık aşağıdaki haritalardan bulunup döndürülür.
// Yeni bir metin eklemek için: HER İKİ haritaya (tr + en) aynı anahtarla
// bir satır eklemek yeterli.
// ═══════════════════════════════════════════════════════════
class DilServisi {
  static String dilKodu = 'tr'; // 'tr' | 'en'

  static const Map<String, String> _tr = {
    'anasayfa': 'Anasayfa',
    'analizler': 'Analizler',
    'serayAi': 'Seray AI',
    'ilaclarim': 'İlaçlarım',
    'beslenme': 'Beslenme',
    'sekerEkle': 'Şeker Ekle',
    'tansiyonEkle': 'Tansiyon Ekle',
    'suKilo': 'Su & Kilo',
    'yemekEkle': 'Yemek Ekle',
    'ilacEkle': 'İlaç Ekle',
    'dil': 'Dil',
    'dilAciklama': 'Uygulama dilini seçin',
    'anaSayfaBaslik': 'Ana Sayfa',
    'eNabizTahlillerim': 'e-Nabız Tahlillerim',
    'eNabizAciklama': 'PDF yükle, referans dışı sonuçları gör',
    'raporAnalizi': 'Rapor Analizi',
    'raporAciklama': 'Röntgen/MR/konsültasyon raporu yükle, AI yorumlasın',
    'sonOlcumleriniz': 'Son Ölçümleriniz',
    'widgetEkle': 'Widget Ekle',
    'kapat': 'Kapat',
    'sekerTakibi': 'Şeker Takibi',
    'tansiyonTakibi': 'Tansiyon Takibi',
    'suKiloTakibi': 'Su & Kilo Takibi',
    'ayarlarBaslik': 'Ayarlar',
    'beslenmeTakibi': 'Beslenme Takibi',
    'ilaclarimAlarmlar': 'İlaçlarım & Alarmlar',
    'analizlerIkazlar': 'Analizler & İkazlar',
    'eNabizTahlilAnalizi': 'e-Nabız Tahlil Analizi',
    'gecmisIlaclar': 'Geçmiş İlaçlar',
    'gidaDegisimListesi': 'Gıda Değişim Listesi',
    'uygulamaHakkinda': 'Uygulama Hakkında',
    'kullanmaKilavuzu': 'Kullanma Kılavuzu',
    'bilgiKutuphanesi': 'Bilgi Kütüphanesi',
    'nabizOlcumu': 'Nabız Ölçümü',
    'profil': 'Profil',
    'raporAnaliziBaslik': 'Rapor Analizi',
    // 17 Ağustos ikinci tur — kalan 9 ekranın başlıkları
    'alarmInsulinZamani': 'İnsülin Zamanı',
    'alarmIlacZamani': 'İlaç Zamanı',
    'alarmSordu': 'Bu ilacı aldınız mı?',
    'alarmIctim': 'İÇTİM',
    'alarmAtladim': 'ATLADIM',
    'alarmErtele': 'Ertele (10 dk)',
    'turuGec': 'Geç',
    'turuIleri': 'İleri',
    'turuBaslayalim': 'Başlayalım',
    'turuBaslik1': 'Seray Sağlık Asistanım\'a Hoş Geldiniz',
    'turuAciklama1': 'Şeker, tansiyon, su, kilo ve adımlarınızı tek yerden takip edin — 30 yıllık bir diyabet tecrübesinden doğdu.',
    'turuBaslik2': 'İlaç ve İnsülin Hatırlatmaları',
    'turuAciklama2': 'İlaçlarınızı fotoğraflayın, saatinde hatırlatma alın; İçtim/Atladım/Ertele ile kolayca takip edin.',
    'turuBaslik3': 'Yapay Zeka Destekli Analiz',
    'turuAciklama3': 'e-Nabız tahlillerinizi, ilaç kutunuzu, yemeklerinizi ve gidişatınızı yapay zeka sizin için sade bir dille yorumlar.',
    'turuBaslik4': 'Aileniz İçin de Kullanın',
    'turuAciklama4': 'Anne, baba ya da sevdikleriniz için ayrı profiller oluşturup onların sağlığını da aynı uygulamadan takip edebilirsiniz.',
    'yedekBaslik': 'Önceki Verileriniz Bulundu',
    'yedekAciklamaOncesi': 'Bu telefonda daha önce kayıtlı olan ',
    'yedekAciklamaSonrasi': ' adına ait veriler otomatik olarak geri yüklendi.',
    'yedekEvetDevam': 'Evet, Bu Benim — Devam Et',
    'yedekHayirDuzenle': 'Hayır, Bu Ben Değilim — Profili Düzenle',
    'kritikIzinlerBaslik': 'İlaç Hatırlatmaları İçin Önemli',
    'pinGirBaslik': 'PIN Girin',
    'pinKurtarmaCevapBaslik': 'Kurtarma Kelimenizi Girin',
    'pinYeniBelirleBaslik': 'Yeni PIN Belirleyin',
    'pinYeniTekrarBaslik': 'PIN\'i Tekrar Girin',
    'pinKurtarmaBelirleBaslik': 'Kurtarma Kelimesi Belirleyin',
    'pinKurtarmaCevapAciklama': 'PIN belirlerken kaydettiğiniz kurtarma kelimesini girin.',
    'pinKurtarmaBelirleAciklama': 'PIN\'inizi unutursanız bu kelimeyi kullanarak yeni bir PIN belirleyebilirsiniz. Kolay hatırlayacağınız bir kelime seçin.',
    'profilKayitBaslik': 'Profil Kaydı',
    'serayAltBaslik': 'Sağlık Asistanınız',
    'yardimAsistaniBaslik': 'Yardım Asistanı',
    'yardimAsistaniAltBaslik': 'Uygulama Kullanımı',
  };

  static const Map<String, String> _en = {
    'anasayfa': 'Home',
    'analizler': 'Analytics',
    'serayAi': 'Seray AI',
    'ilaclarim': 'Medicines',
    'beslenme': 'Nutrition',
    'sekerEkle': 'Log Sugar',
    'tansiyonEkle': 'Log BP',
    'suKilo': 'Water & Weight',
    'yemekEkle': 'Log Meal',
    'ilacEkle': 'Log Med',
    'dil': 'Language',
    'dilAciklama': 'Choose app language',
    'anaSayfaBaslik': 'Home',
    'eNabizTahlillerim': 'e-Nabız Lab Results',
    'eNabizAciklama': 'Upload PDF, see out-of-range results',
    'raporAnalizi': 'Report Analysis',
    'raporAciklama': 'Upload X-ray/MRI/consult report, AI explains it',
    'sonOlcumleriniz': 'Your Recent Readings',
    'widgetEkle': 'Add Widget',
    'kapat': 'Close',
    'sekerTakibi': 'Sugar Tracking',
    'tansiyonTakibi': 'Blood Pressure Tracking',
    'suKiloTakibi': 'Water & Weight Tracking',
    'ayarlarBaslik': 'Settings',
    'beslenmeTakibi': 'Nutrition Tracking',
    'ilaclarimAlarmlar': 'My Meds & Alarms',
    'analizlerIkazlar': 'Analytics & Alerts',
    'eNabizTahlilAnalizi': 'e-Nabız Lab Analysis',
    'gecmisIlaclar': 'Past Medications',
    'gidaDegisimListesi': 'Food Exchange List',
    'uygulamaHakkinda': 'About the App',
    'kullanmaKilavuzu': 'User Guide',
    'bilgiKutuphanesi': 'Knowledge Library',
    'nabizOlcumu': 'Pulse Measurement',
    'profil': 'Profile',
    'raporAnaliziBaslik': 'Report Analysis',
    // Aug 17 second round — remaining 9 screens' titles
    'alarmInsulinZamani': 'Insulin Time',
    'alarmIlacZamani': 'Medicine Time',
    'alarmSordu': 'Did you take this medicine?',
    'alarmIctim': 'TAKEN',
    'alarmAtladim': 'SKIPPED',
    'alarmErtele': 'Snooze (10 min)',
    'turuGec': 'Skip',
    'turuIleri': 'Next',
    'turuBaslayalim': 'Get Started',
    'turuBaslik1': 'Welcome to Seray Health Assistant',
    'turuAciklama1': 'Track your sugar, blood pressure, water, weight, and steps all in one place — built from 30 years of diabetes experience.',
    'turuBaslik2': 'Medication & Insulin Reminders',
    'turuAciklama2': 'Photograph your medicines, get reminded on time; easily track them with Taken/Skipped/Snooze.',
    'turuBaslik3': 'AI-Powered Analysis',
    'turuAciklama3': 'AI explains your e-Nabız lab results, medicine box, meals, and trends for you in plain language.',
    'turuBaslik4': 'Use It for Your Family Too',
    'turuAciklama4': 'Create separate profiles for your parents or loved ones and track their health from the same app.',
    'yedekBaslik': 'Your Previous Data Was Found',
    'yedekAciklamaOncesi': 'Data previously saved on this device under ',
    'yedekAciklamaSonrasi': ' was automatically restored.',
    'yedekEvetDevam': 'Yes, This Is Me — Continue',
    'yedekHayirDuzenle': 'No, Not Me — Edit Profile',
    'kritikIzinlerBaslik': 'Important for Medication Reminders',
    'pinGirBaslik': 'Enter PIN',
    'pinKurtarmaCevapBaslik': 'Enter Your Recovery Word',
    'pinYeniBelirleBaslik': 'Set a New PIN',
    'pinYeniTekrarBaslik': 'Re-enter Your PIN',
    'pinKurtarmaBelirleBaslik': 'Set a Recovery Word',
    'pinKurtarmaCevapAciklama': 'Enter the recovery word you saved when setting your PIN.',
    'pinKurtarmaBelirleAciklama': 'If you forget your PIN, you can use this word to set a new one. Choose a word you\'ll easily remember.',
    'profilKayitBaslik': 'Profile Registration',
    'serayAltBaslik': 'Your Health Assistant',
    'yardimAsistaniBaslik': 'Help Assistant',
    'yardimAsistaniAltBaslik': 'App Usage',
  };

  static String metin(String anahtar) {
    final harita = dilKodu == 'en' ? _en : _tr;
    return harita[anahtar] ?? _tr[anahtar] ?? anahtar;
  }  // --- metin() sonu ---

  static Future<void> yukle() async {
    final prefs = await SharedPreferences.getInstance();
    dilKodu = prefs.getString('dil_kodu') ?? 'tr';
  }  // --- yukle() sonu ---

  static Future<void> kaydet(String kod) async {
    dilKodu = kod;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('dil_kodu', kod);
  }  // --- kaydet() sonu ---
}
