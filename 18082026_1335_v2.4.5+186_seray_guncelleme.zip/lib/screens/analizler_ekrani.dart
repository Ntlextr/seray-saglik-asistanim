import 'package:flutter/material.dart';
import '../services/dil_servisi.dart';
import 'dart:math' show pow, log, ln10;
import '../theme/renkler.dart';
import '../theme/sablon.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:fl_chart/fl_chart.dart';
import '../services/veritabani_yardimcisi.dart';
import '../services/adim_servisi.dart';
import '../services/ses_servisi.dart';
import '../services/api_service.dart';
import '../services/pdf_rapor_servisi.dart';
import '../services/profil_yoneticisi.dart';
import '../widgets/ust_menu.dart';
import 'yapay_zeka_ekrani.dart';

// Grafik sol eksenindeki sayıların (örn. 335, 310, 232, 155, 77, 25 gibi
// düzensiz, göze çirkin görünen aralıklarla) yerine 5/10/20/25/50/100 gibi
// YUVARLAK aralıklarla gösterilmesini sağlar — hem daha okunaklı hem de
// üst üste binip karışma ihtimalini azaltır (daha az basamak, daha kısa
// metin).
double _guzelAralik(double ham) {
  if (ham <= 0) return 1;
  final buyukluk = pow(10, (log(ham) / ln10).floor()).toDouble();
  final oran = ham / buyukluk;
  double guzelOran;
  if (oran <= 1) {
    guzelOran = 1;
  } else if (oran <= 2) {
    guzelOran = 2;
  } else if (oran <= 2.5) {
    guzelOran = 2.5;
  } else if (oran <= 5) {
    guzelOran = 5;
  } else {
    guzelOran = 10;
  }
  return guzelOran * buyukluk;
}  // --- _guzelAralik() sonu ---

class AnalizlerEkrani extends StatefulWidget {
  const AnalizlerEkrani({Key? key}) : super(key: key);
  @override
  _AnalizlerEkraniState createState() => _AnalizlerEkraniState();
}

class _AnalizlerEkraniState extends State<AnalizlerEkrani> with SingleTickerProviderStateMixin {
  late final TabController _tabController;
  List<Map<String, dynamic>> _sekerler = [];
  List<Map<String, dynamic>> _tansiyonlar = [];
  List<Map<String, dynamic>> _suKayitlari = [];
  List<Map<String, dynamic>> _kiloKayitlari = [];
  List<Map<String, dynamic>> _beslenmeKayitlari = [];
  List<MapEntry<String, int>> _adimGecmisi = [];
  int _omurBoyuToplamAdim = 0;
  List<Map<String, dynamic>> _enabizGecmisi = [];
  List<Map<String, String>> _tahlilOzeti = [];
  bool _yukleniyor = true;
  bool _barGorunumu = false; // Kullanıcı çizgi/bar grafik arasında seçebiliyor
  String? _sesCalanGidisatAnahtari; // Hangi gidişat kartının TTS'i şu an çalıyor
  double? _hedefKilo;
  int _hedefAdim = 6000;
  int _hedefSuMl = 2000;

  // Her sekme için AI'nin ürettiği kısa gidişat yorumu + önbellek imzası
  // (veri değişmediyse aynı yorumu tekrar AI'ya sormuyoruz).
  final Map<String, String?> _gidisatYorumlari = {};
  final Map<String, bool> _yorumYukleniyorMu = {};
  String _diyabetTipi = "Yok";

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 5, vsync: this);
    _tabController.addListener(() {
      // Sadece Şeker/Tansiyon sekmelerinde E-Nabız butonu ve geçmiş listesini
      // göstermek için ekranı yeniden çiziyoruz (diğerlerinde yer kazanmak için).
      if (!_tabController.indexIsChanging) setState(() {});
    });
    _verileriYukle();
  }  // --- initState() sonu ---

  @override
  void dispose() { _tabController.dispose(); SesServisi.durdur(); super.dispose(); }

  // ÖNEMLİ: Sonuç günlük olarak önbelleğe alınıyor (aynı gün tekrar
  // tıklanırsa AI'ya tekrar sorulmuyor) — diğer AI özelliklerindeki
  // önbellekleme mantığıyla tutarlı.
  Future<void> _haftalikIcgoruGoster() async {
    showDialog(
      context: context,
      builder: (dialogContext) => PopScope(
        onPopInvokedWithResult: (didPop, result) => SesServisi.durdur(),
        child: AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(DilServisi.metin('haftalikIcgoru')),
        content: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: FutureBuilder<String>(
              future: _haftalikIcgoruGetirVeyaUret(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const SizedBox(
                    height: 80,
                    child: Center(child: CircularProgressIndicator()),
                  );
                }
                return Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // Kullanıcı isteğiyle eklendi — haftalık içgörü de artık
                        // uygulamadaki diğer AI yorumları gibi sesli dinlenebiliyor.
                        IconButton(
                          icon: Icon(Icons.volume_up, color: AppRenkleri.aktif, size: 28),
                          tooltip: DilServisi.metin('sesliDinle'),
                          onPressed: () => SesServisi.konus(snapshot.data!),
                        ),
                        // ÖNEMLİ: Kullanıcı fark etti — diğer AI yorumlarında
                        // (Genel AI Analizi, Ref Dışı vb.) yazdır/paylaş butonu
                        // varken Haftalık İçgörü'de hiç yoktu. Eklendi.
                        IconButton(
                          icon: Icon(Icons.share_outlined, color: AppRenkleri.aktif, size: 26),
                          tooltip: DilServisi.metin('paylas'),
                          onPressed: () async {
                            try {
                              final ad = (await ProfilYoneticisi().aktifProfil()).ad;
                              await PdfRaporServisi.analizRaporuOlusturVePaylas(
                                kullaniciAdi: ad,
                                baslik: DilServisi.metin('haftalikIcgoruSekerBeslenme'),
                                analizMetni: snapshot.data!,
                              );
                            } catch (e) {
                              if (context.mounted) {
                                showDialog(
                                  context: context,
                                  builder: (d) => AlertDialog(
                                    title: Text(DilServisi.metin('pdfOlusturulamadi')),
                                    content: SelectableText(e.toString()),
                                    actions: [TextButton(onPressed: () => Navigator.pop(d), child: Text(DilServisi.metin('kapat')))],
                                  ),
                                );
                              }
                            }
                          },
                        ),
                        IconButton(
                          icon: Icon(Icons.print_outlined, color: AppRenkleri.aktif, size: 26),
                          tooltip: DilServisi.metin('yazdir'),
                          onPressed: () async {
                            try {
                              final ad = (await ProfilYoneticisi().aktifProfil()).ad;
                              await PdfRaporServisi.analizRaporuYazdir(
                                kullaniciAdi: ad,
                                baslik: DilServisi.metin('haftalikIcgoruSekerBeslenme'),
                                analizMetni: snapshot.data!,
                              );
                            } catch (e) {
                              if (context.mounted) {
                                showDialog(
                                  context: context,
                                  builder: (d) => AlertDialog(
                                    title: Text(DilServisi.metin('pdfOlusturulamadi')),
                                    content: SelectableText(e.toString()),
                                    actions: [TextButton(onPressed: () => Navigator.pop(d), child: Text(DilServisi.metin('kapat')))],
                                  ),
                                );
                              }
                            }
                          },
                        ),
                      ],
                    ),
                    SelectableText(snapshot.data!, style: const TextStyle(fontSize: 14, height: 1.4)),
                  ],
                );
              },
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: Text(DilServisi.metin('kapat'))),
        ],
        ),
      ),
    );
  }  // --- _haftalikIcgoruGoster() sonu ---

  Future<String> _haftalikIcgoruGetirVeyaUret() async {
    final bugun = DateTime.now();
    final gunAnahtari = '${bugun.year}-${bugun.month}-${bugun.day}';
    final prefs = await SharedPreferences.getInstance();
    final onbellekAnahtari = 'haftalik_icgoru_$gunAnahtari';
    final onbellek = prefs.getString(onbellekAnahtari);
    if (onbellek != null && onbellek.isNotEmpty) return onbellek;

    final sonSekerler = _sekerler.take(30).toList();

    if (sonSekerler.isEmpty && _beslenmeKayitlari.isEmpty) {
      return 'Yeterli veri yok — bir içgörü çıkarmak için en az birkaç günlük şeker ölçümü ve yemek kaydı gerekiyor.';
    }

    final sb = StringBuffer();
    sb.writeln('Son şeker ölçümleri:');
    for (final s in sonSekerler.take(20)) {
      sb.writeln('- ${s['deger']} mg/dL (${s['durum']}, ${s['tarih']})');
    }
    sb.writeln('\nSon yemek kayıtları:');
    for (final b in _beslenmeKayitlari.take(20)) {
      sb.writeln('- ${b['yemek_adi']}: ${b['kalori']} kcal (${b['tarih']})');
    }

    final yorum = await ApiService.haftalikIcgoruOlustur(sb.toString());
    if (!ApiService.cevapHataMi(yorum)) {
      await prefs.setString(onbellekAnahtari, yorum);
    }
    return yorum;
  }  // --- _haftalikIcgoruGetirVeyaUret() sonu ---

  Future<void> _verileriYukle() async {
    final prefs = await SharedPreferences.getInstance();
    final sekerListesi = await VeritabaniYardimcisi().sekerleriGetir();
    final tansiyonListesi = await VeritabaniYardimcisi().tansiyonlariGetir();
    final suListesi = await VeritabaniYardimcisi().suKayitlariniGetir();
    final kiloListesi = await VeritabaniYardimcisi().kiloKayitlariniGetir();
    final enabizListesi = await VeritabaniYardimcisi().yorumlariGetir();
    final tumTahliller = await VeritabaniYardimcisi().tumTahlilleriGetir();
    final adimGecmisi = await AdimServisi.sonYediGunGetir();
    final omurBoyuAdim = await AdimServisi.omurBoyuToplamAdimGetir();
    final suHedefi = await VeritabaniYardimcisi().suHedefiMlGetir();
    final beslenmeListesi = await VeritabaniYardimcisi().beslenmeKayitlariniGetir();

    final Map<String, Map<String, String>> ozetMap = {};
    for (var t in tumTahliller) {
      final ad = t['tahlil_adi'].toString();
      if (!ozetMap.containsKey(ad)) {
        ozetMap[ad] = {'ad': ad, 'sonuc': t['sonuc'].toString(), 'ref': t['referans_degeri'].toString(), 'tarih': t['tarih'].toString()};
      }
    }

    final py = ProfilYoneticisi();
    final diyabetAnahtari = await py.profilAnahtari('kullanici_diyabet_turu');
    final hedefKiloAnahtari = await py.profilAnahtari('hedef_kilo');
    final hedefAdimAnahtari = await py.profilAnahtari('hedef_adim');
    setState(() {
      _diyabetTipi = prefs.getString(diyabetAnahtari) ?? "Yok";
      _hedefKilo = prefs.getDouble(hedefKiloAnahtari);
      _hedefAdim = prefs.getInt(hedefAdimAnahtari) ?? 6000;
      _hedefSuMl = suHedefi;
      _sekerler = sekerListesi;
      _tansiyonlar = tansiyonListesi;
      _suKayitlari = suListesi;
      _kiloKayitlari = kiloListesi;
      _beslenmeKayitlari = beslenmeListesi;
      _adimGecmisi = adimGecmisi;
      _omurBoyuToplamAdim = omurBoyuAdim;
      _enabizGecmisi = enabizListesi;
      _tahlilOzeti = ozetMap.values.toList();
      _yukleniyor = false;
    });
    _tumYorumlariTetikle();
  }  // --- _verileriYukle() sonu ---

  bool _refDisindaMi(String? deger, String ref) {
    if (deger == null) return false;
    final sayi = double.tryParse(deger.replaceAll(',', '.'));
    final parcalar = ref.split('-');
    if (sayi == null || parcalar.length != 2) return false;
    final min = double.tryParse(parcalar[0].trim().replaceAll(',', '.'));
    final maks = double.tryParse(parcalar[1].trim().replaceAll(',', '.'));
    if (min == null || maks == null) return false;
    return sayi < min || sayi > maks;
  }  // --- _refDisindaMi() sonu ---

  int get _sekerYuksekSiniri {
    switch (_diyabetTipi) {
      case 'Tip 1 Diyabet':
        return 180;
      case 'Tip 2 Diyabet':
        return 140;
      case 'Gizli Şeker':
        return 100;
      default:
        return 140;
    }
  }

  String _tarihiBicimlendir(String? isoTarih) {
    if (isoTarih == null || isoTarih.isEmpty) return '';
    final t = DateTime.tryParse(isoTarih);
    if (t == null) return isoTarih;
    String iki(int n) => n.toString().padLeft(2, '0');
    return '${iki(t.day)}.${iki(t.month)}.${t.year} ${iki(t.hour)}:${iki(t.minute)}';
  }  // --- _tarihiBicimlendir() sonu ---

  // Üst sekmeler (Şeker/Tansiyon/Su/Kilo/Adım) için, Özet ekranındaki
  // ölçüm kartları ve alt navigasyon çubuğuyla AYNI stil: shade50 dolgun
  // pastel zemin + shade700 doygun ikon rengi, her zaman renkli. Aktif
  // sekme ayrıca kalın (2.5) bir halka ile belirginleştiriliyor.
  Widget _sekmeIkon(IconData ikon, MaterialColor renk, int index) {
    final secili = _tabController.index == index;
    return Container(
      width: 34,
      height: 34,
      decoration: BoxDecoration(
        color: renk.shade50,
        shape: BoxShape.circle,
        border: secili ? Border.all(color: renk.shade700, width: 2.5) : null,
      ),
      child: Icon(ikon, color: renk.shade700, size: 18),
    );
  }  // --- _sekmeIkon() sonu ---

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(
        shape: AppSablon.appBarSekli,
        clipBehavior: Clip.antiAlias,
        title: FittedBox(
          fit: BoxFit.scaleDown,
          alignment: Alignment.centerLeft,
          child: Text(DilServisi.metin('analizlerIkazlar'), maxLines: 1),
        ),
        backgroundColor: AppRenkleri.aktif,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.insights),
            tooltip: DilServisi.metin('haftalikIcgoru'),
            onPressed: _haftalikIcgoruGoster,
          ),
          const UstMenu(),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(72),
          child: AnimatedBuilder(
            animation: _tabController,
            builder: (context, _) => TabBar(
              controller: _tabController,
              isScrollable: false,
              labelPadding: const EdgeInsets.symmetric(horizontal: 2),
              labelStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
              unselectedLabelStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.normal),
              labelColor: Colors.white,
              unselectedLabelColor: Colors.white,
              indicatorColor: Colors.white,
              indicatorWeight: 3,
              tabs: [
                Tab(icon: _sekmeIkon(Icons.bloodtype, Colors.red, 0), text: DilServisi.metin('sekerKelime'), iconMargin: const EdgeInsets.only(bottom: 3)),
                Tab(icon: _sekmeIkon(Icons.favorite, Colors.pink, 1), text: DilServisi.metin('tansiyon'), iconMargin: const EdgeInsets.only(bottom: 3)),
                Tab(icon: _sekmeIkon(Icons.water_drop, Colors.blue, 2), text: DilServisi.metin('suBaslik'), iconMargin: const EdgeInsets.only(bottom: 3)),
                Tab(icon: _sekmeIkon(Icons.monitor_weight, Colors.deepPurple, 3), text: DilServisi.metin('kiloBaslik'), iconMargin: const EdgeInsets.only(bottom: 3)),
                Tab(icon: _sekmeIkon(Icons.directions_walk, Colors.green, 4), text: DilServisi.metin('adimBaslik'), iconMargin: const EdgeInsets.only(bottom: 3)),
              ],
            ),
          ),
        ),
      ),
      body: Column(
        children: [
          // Geçmiş e-Nabız tahlilleri artık hangi sekmede olursan ol görünür
          // (küçük, tek satırlık bir şerit — yer kaplamıyor).
          if (_enabizGecmisi.isNotEmpty)
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
              child: SizedBox(
                height: 40,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: _enabizGecmisi.length,
                  separatorBuilder: (context, index) => const SizedBox(width: 8),
                  itemBuilder: (context, index) {
                    final kayit = _enabizGecmisi[index];
                    return ActionChip(
                      avatar: const Icon(Icons.table_chart, size: 15),
                      label: Text(_tarihiBicimlendir(kayit['tarih']?.toString()), style: const TextStyle(fontSize: 11)),
                      onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => const YapayZekaEkrani())).then((_) => _verileriYukle()),
                    );
                  },
                ),
              ),
            ),
          Expanded(
            child: _yukleniyor
                ? const Center(child: CircularProgressIndicator())
                : TabBarView(controller: _tabController, children: [_sekerSayfasi(), _tansiyonSayfasi(), _suSayfasi(), _kiloSayfasi(), _adimSayfasi()]),
          ),
        ],
      ),
    );
  }  // --- build() sonu ---

  Widget _sekerSayfasi() {
    if (_sekerler.isEmpty) return Center(child: Text(DilServisi.metin('kayitliOlcumBulunamadi')));
    // Grafik için kronolojik sırada (eskiden yeniye) son 15 ölçüm
    final grafikVerisi = _sekerler.take(15).toList().reversed.toList();
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
          child: _gidisatYorumKarti('seker', AppRenkleri.aktif),
        ),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: _sekerler.length + 1,
            itemBuilder: (context, index) {
              if (index == 0) {
                return _trendGrafigi(
                  baslik: '${DilServisi.metin('sekerSeyri')} (${DilServisi.metin('sonKelime')} ${grafikVerisi.length} ${grafikVerisi.length == 1 ? DilServisi.metin('olcumu') : DilServisi.metin('olcumuCogul')})',
                  degerler: grafikVerisi.map((e) => (int.tryParse(e['deger'].toString()) ?? 0).toDouble()).toList(),
                  renk: Colors.red,
                  riskEsigi: _sekerYuksekSiniri.toDouble(),
                );
              }
              final i = index - 1;
              final int deger = int.tryParse(_sekerler[i]['deger'].toString()) ?? 0;
              bool yuksekMi = deger > _sekerYuksekSiniri;
              int? oncekiDeger = i + 1 < _sekerler.length ? int.tryParse(_sekerler[i + 1]['deger'].toString()) : null;
              return Card(
                color: yuksekMi ? Colors.red.shade50 : Colors.green.shade50,
                child: InkWell(
                  onTap: () => SesServisi.konus('Kan şekeri $deger miligram, durum: ${_sekerler[i]['durum']}'),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Row(
                          children: [
                            Text('$deger mg/dL', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: yuksekMi ? Colors.red.shade900 : Colors.green.shade900)),
                            const SizedBox(width: 6),
                            if (oncekiDeger != null) _karsilastirmaIkonu(deger, oncekiDeger),
                            const Spacer(),
                            IconButton(
                              icon: const Icon(Icons.volume_up, size: 20),
                              padding: EdgeInsets.zero,
                              constraints: const BoxConstraints(),
                              onPressed: () => SesServisi.konus('Kan şekeri $deger miligram, durum: ${_sekerler[i]['durum']}'),
                            ),
                          ],
                        ),
                        const SizedBox(height: 2),
                        Text(
                          '${DilServisi.metin('durumBaslik')}: ${DilServisi.durumGoster(_sekerler[i]['durum']?.toString())}  •  ${_tarihiBicimlendir(_sekerler[i]['tarih']?.toString())}${oncekiDeger != null ? '\n${_karsilastirmaMetni(deger, oncekiDeger, 'mg/dL')}' : ''}',
                          style: TextStyle(fontSize: 11, color: Colors.grey.shade700, height: 1.25),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }  // --- _sekerSayfasi() sonu ---

  Widget _tansiyonSayfasi() {
    if (_tansiyonlar.isEmpty) return Center(child: Text(DilServisi.metin('kayitliOlcumBulunamadi')));
    final grafikVerisi = _tansiyonlar.take(15).toList().reversed.toList();
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
          child: _gidisatYorumKarti('tansiyon', AppRenkleri.aktif),
        ),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: _tansiyonlar.length + 1,
            itemBuilder: (context, index) {
              if (index == 0) {
                return _trendGrafigi(
                  baslik: '${DilServisi.metin('tansiyonSeyri')} (${DilServisi.metin('sonKelime')} ${grafikVerisi.length} ${grafikVerisi.length == 1 ? DilServisi.metin('olcumu') : DilServisi.metin('olcumuCogul')})',
                  degerler: grafikVerisi.map((e) => (int.tryParse(e['buyuk'].toString()) ?? 0).toDouble()).toList(),
                  renk: Colors.red,
                  ikinciSeri: grafikVerisi.map((e) => (int.tryParse(e['kucuk'].toString()) ?? 0).toDouble()).toList(),
                  ikinciRenk: AppRenkleri.aktif,
                  riskEsigi: 140,
                  aciklama: '● ${DilServisi.metin('buyukSistolik')}   ● ${DilServisi.metin('kucukDiyastolik')}',
                );
              }
              final i = index - 1;
              final t = _tansiyonlar[i];
              final int buyuk = int.tryParse(t['buyuk'].toString()) ?? 0;
              int? oncekiBuyuk = i + 1 < _tansiyonlar.length ? int.tryParse(_tansiyonlar[i + 1]['buyuk'].toString()) : null;
              return Card(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Row(
                        children: [
                          Text('${t['buyuk']}/${t['kucuk']} mmHg', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                          const SizedBox(width: 6),
                          if (oncekiBuyuk != null) _karsilastirmaIkonu(buyuk, oncekiBuyuk),
                          const Spacer(),
                          IconButton(
                            icon: const Icon(Icons.volume_up, size: 20),
                            padding: EdgeInsets.zero,
                            constraints: const BoxConstraints(),
                            onPressed: () => SesServisi.konus('Tansiyon ${t['buyuk']}/${t['kucuk']} mmHg, nabız ${t['nabiz']}'),
                          ),
                        ],
                      ),
                      const SizedBox(height: 2),
                      Text(
                        '${DilServisi.metin('nabizBaslik')}: ${t['nabiz']} bpm  •  ${_tarihiBicimlendir(t['tarih']?.toString())}${oncekiBuyuk != null ? '\n${_karsilastirmaMetni(buyuk, oncekiBuyuk, 'mmHg (' + DilServisi.metin('buyukTansiyon') + ')')}' : ''}',
                        style: TextStyle(fontSize: 11, color: Colors.grey.shade700, height: 1.25),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }  // --- _tansiyonSayfasi() sonu ---

  Widget _suSayfasi() {
    if (_suKayitlari.isEmpty) return Center(child: Text(DilServisi.metin('kayitliOlcumBulunamadi')));

    // Bugünkü toplam (donut için)
    final bugun = DateTime.now();
    int bugunToplam = 0;
    final Map<String, int> gunlukToplam = {};
    for (final k in _suKayitlari) {
      final t = DateTime.tryParse(k['tarih']?.toString() ?? '');
      if (t == null) continue;
      final anahtar = '${t.year}-${t.month.toString().padLeft(2, '0')}-${t.day.toString().padLeft(2, '0')}';
      final miktar = int.tryParse(k['miktar_ml'].toString()) ?? 0;
      gunlukToplam[anahtar] = (gunlukToplam[anahtar] ?? 0) + miktar;
      if (t.year == bugun.year && t.month == bugun.month && t.day == bugun.day) bugunToplam += miktar;
    }
    final gunler = gunlukToplam.keys.toList()..sort();
    final sonYediGun = gunler.length > 7 ? gunler.sublist(gunler.length - 7) : gunler;
    final gunAdlari = [DilServisi.metin('gunPzt'), DilServisi.metin('gunSal'), DilServisi.metin('gunCar'), DilServisi.metin('gunPer'), DilServisi.metin('gunCum'), DilServisi.metin('gunCmt'), DilServisi.metin('gunPaz')];
    final oran = (bugunToplam / _hedefSuMl).clamp(0.0, 1.0);

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
          child: _gidisatYorumKarti('su', AppRenkleri.aktif),
        ),
        Expanded(
          child: ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _suKayitlari.length + 2,
      itemBuilder: (context, index) {
        if (index == 0) {
          // BUGÜNKÜ İLERLEME HALKASI (Donut)
          return Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Text(DilServisi.metin('bugunkuIlerleme'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                  const SizedBox(height: 12),
                  SizedBox(
                    height: 115,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        PieChart(
                          PieChartData(
                            sectionsSpace: 0,
                            centerSpaceRadius: 45,
                            sections: [
                              PieChartSectionData(value: oran * 100, color: Colors.blue, radius: 22, showTitle: false),
                              PieChartSectionData(value: (1 - oran) * 100, color: Colors.blue.shade50, radius: 22, showTitle: false),
                            ],
                          ),
                        ),
                        Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text('${(oran * 100).round()}%', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.blue)),
                            Text('${(bugunToplam / 1000).toStringAsFixed(1)} / ${(_hedefSuMl / 1000).toStringAsFixed(1)} L', style: TextStyle(fontSize: 11, color: Colors.grey.shade600)),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        }
        if (index == 1) {
          if (sonYediGun.length < 2) return const SizedBox.shrink();
          final suGunlukOrtalama = sonYediGun.isEmpty
              ? 0
              : (sonYediGun.map((g) => gunlukToplam[g]!).reduce((a, b) => a + b) / sonYediGun.length).round();
          final suHedefTutulanGunSayisi = sonYediGun.where((g) => gunlukToplam[g]! >= _hedefSuMl).length;
          // GÜNLÜK TOPLAM SÜTUN GRAFİĞİ (Son 7 gün)
          return Column(
            children: [
              Card(
                margin: const EdgeInsets.only(top: 12),
                child: ListTile(
                  leading: const Icon(Icons.insights, color: Colors.blue),
                  title: Text('${DilServisi.metin('gunlukOrtalama')}: ${(suGunlukOrtalama / 1000).toStringAsFixed(1)} L'),
                ),
              ),
              const SizedBox(height: 12),
              _haftalikSeriKarti(
                gunler: sonYediGun.map((g) => MapEntry(g, gunlukToplam[g]! >= _hedefSuMl)).toList(),
                gunAdlari: gunAdlari,
                renk: Colors.blue,
                hedefTutulanGunSayisi: suHedefTutulanGunSayisi,
              ),
              Card(
            margin: const EdgeInsets.only(top: 12),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 14, 16, 14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(child: Text(DilServisi.metin('suSeyriSonGunler'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14))),
                      IconButton(
                        icon: Icon(_barGorunumu ? Icons.show_chart : Icons.bar_chart, size: 20, color: Colors.grey.shade600),
                        tooltip: _barGorunumu ? DilServisi.metin('cizgiGrafigeGec') : DilServisi.metin('barGrafigeGec'),
                        onPressed: () => setState(() => _barGorunumu = !_barGorunumu),
                        padding: EdgeInsets.zero,
                        constraints: const BoxConstraints(),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    height: 130,
                    child: Builder(builder: (context) {
                      final maksimumSu = sonYediGun.isEmpty
                          ? 0.0
                          : sonYediGun.map((g) => gunlukToplam[g]!.toDouble()).reduce((a, b) => a > b ? a : b);
                      final suAralik = _guzelAralik(maksimumSu == 0 ? 125 : maksimumSu / 4);
                      // ÖNEMLİ DÜZELTME: fl_chart varsayılan olarak eksenin
                      // gerçek min/max veri değeri için AYRICA bir etiket
                      // ekliyor — bu, bizim yuvarlak interval etiketimize çok
                      // yakın çıkıp üst üste binen sayılara (ör. "162"/"160")
                      // sebep oluyordu. Kullandığımız fl_chart sürümünde
                      // (0.68.0) bunu kapatan minIncluded/maxIncluded
                      // parametresi YOK — bu yüzden eksenin üst sınırını
                      // (maxY) baştan interval'in tam katı olacak şekilde
                      // hesaplıyoruz; böylece "gerçek max" etiketiyle
                      // "interval" etiketi zaten AYNI sayı oluyor, çakışma
                      // hiç oluşmuyor.
                      final suMaxY = ((maksimumSu / suAralik).ceil() * suAralik).clamp(suAralik, double.infinity).toDouble();
                      FlTitlesData suBaslikVerisi() => FlTitlesData(
                            topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                            rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                            leftTitles: AxisTitles(
                              sideTitles: SideTitles(
                                showTitles: true,
                                reservedSize: 44,
                                interval: suAralik,
                                getTitlesWidget: (value, meta) => Padding(
                                  padding: const EdgeInsets.only(right: 4),
                                  child: Text(value.toInt().toString(), style: const TextStyle(fontSize: 10), maxLines: 1, softWrap: false),
                                ),
                              ),
                            ),
                            bottomTitles: AxisTitles(
                              sideTitles: SideTitles(
                                showTitles: true,
                                // Aynı düzeltme: kesirli pozisyonlarda tekrarlanan gün
                                // etiketlerini önlemek için interval:1 (bkz. beslenme_ekrani.dart).
                                interval: 1,
                                getTitlesWidget: (value, meta) {
                                  final i = value.toInt();
                                  if (i < 0 || i >= sonYediGun.length) return const SizedBox.shrink();
                                  final t = DateTime.tryParse(sonYediGun[i]);
                                  return Padding(padding: const EdgeInsets.only(top: 6), child: Text(t != null ? gunAdlari[t.weekday - 1] : '', style: const TextStyle(fontSize: 10)));
                                },
                              ),
                            ),
                          );
                      if (_barGorunumu) {
                        return BarChart(
                          BarChartData(
                            maxY: suMaxY,
                            gridData: const FlGridData(show: true, drawVerticalLine: false),
                            titlesData: suBaslikVerisi(),
                            borderData: FlBorderData(show: false),
                            barGroups: [
                              for (int i = 0; i < sonYediGun.length; i++)
                                BarChartGroupData(x: i, barRods: [
                                  BarChartRodData(
                                    toY: gunlukToplam[sonYediGun[i]]!.toDouble(),
                                    color: gunlukToplam[sonYediGun[i]]! >= _hedefSuMl ? Colors.blue : Colors.blue.shade200,
                                    width: 16, borderRadius: BorderRadius.circular(4),
                                  ),
                                ]),
                            ],
                          ),
                        );
                      }
                      return LineChart(
                        LineChartData(
                          maxY: suMaxY,
                          gridData: const FlGridData(show: true, drawVerticalLine: false),
                          titlesData: suBaslikVerisi(),
                          borderData: FlBorderData(show: false),
                          lineBarsData: [
                            LineChartBarData(
                              spots: [for (int i = 0; i < sonYediGun.length; i++) FlSpot(i.toDouble(), gunlukToplam[sonYediGun[i]]!.toDouble())],
                              isCurved: true,
                              color: Colors.blue,
                              barWidth: 3,
                              dotData: const FlDotData(show: true),
                              belowBarData: BarAreaData(show: true, color: Colors.blue.withOpacity(0.12)),
                            ),
                          ],
                        ),
                      );
                    }),
                  ),
                ],
              ),
            ),
              ),
            ],
          );
        }
        final i = index - 2;
        final int miktar = int.tryParse(_suKayitlari[i]['miktar_ml'].toString()) ?? 0;
        int? onceki = i + 1 < _suKayitlari.length ? int.tryParse(_suKayitlari[i + 1]['miktar_ml'].toString()) : null;
        return Card(
          margin: const EdgeInsets.only(top: 8),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    const Icon(Icons.water_drop, color: Colors.blue, size: 18),
                    const SizedBox(width: 6),
                    Text('$miktar mL', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.blue)),
                    const SizedBox(width: 6),
                    if (onceki != null) _karsilastirmaIkonu(miktar, onceki),
                    const Spacer(),
                    IconButton(
                      icon: const Icon(Icons.volume_up, size: 20),
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                      onPressed: () => SesServisi.konus('Su tüketimi $miktar mililitre'),
                    ),
                  ],
                ),
                const SizedBox(height: 2),
                Text(
                  '${DilServisi.metin('tarihBaslik')}: ${_tarihiBicimlendir(_suKayitlari[i]['tarih']?.toString())}${onceki != null ? '\n${_karsilastirmaMetni(miktar, onceki, 'mL')}' : ''}',
                  style: TextStyle(fontSize: 11, color: Colors.grey.shade700, height: 1.25),
                ),
              ],
            ),
          ),
        );
      },
    ),
        ),
      ],
    );
  }  // --- _suSayfasi() sonu ---

  Widget _kiloSayfasi() {
    if (_kiloKayitlari.isEmpty) return Center(child: Text(DilServisi.metin('kayitliOlcumBulunamadi')));
    final grafikVerisi = _kiloKayitlari.take(15).toList().reversed.toList();
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
          child: _gidisatYorumKarti('kilo', AppRenkleri.aktif),
        ),
        Expanded(
          child: ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _kiloKayitlari.length + 2,
      itemBuilder: (context, index) {
        if (index == 0) {
          return Card(
            child: ListTile(
              leading: const Icon(Icons.flag, color: Colors.purple),
              title: Text(_hedefKilo != null ? '${DilServisi.metin('hedefKilo')}: ${_hedefKilo!.toStringAsFixed(1)} kg' : DilServisi.metin('hedefKiloBelirlenmedi')),
              trailing: TextButton(onPressed: _hedefKiloDuzenle, child: Text(DilServisi.metin('duzenle'))),
            ),
          );
        }
        if (index == 1) {
          return _trendGrafigi(
            baslik: '${DilServisi.metin('kiloSeyri')} (${DilServisi.metin('sonKelime')} ${grafikVerisi.length} ${grafikVerisi.length == 1 ? DilServisi.metin('olcumu') : DilServisi.metin('olcumuCogul')})',
            degerler: grafikVerisi.map((e) => (double.tryParse(e['kilo'].toString()) ?? 0)).toList(),
            renk: Colors.purple,
            hedefDegeri: _hedefKilo,
            hedefEtiketi: 'Hedef',
          );
        }
        final i = index - 2;
        final double kilo = double.tryParse(_kiloKayitlari[i]['kilo'].toString()) ?? 0;
        double? onceki = i + 1 < _kiloKayitlari.length ? double.tryParse(_kiloKayitlari[i + 1]['kilo'].toString()) : null;
        return Card(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    const Icon(Icons.monitor_weight, color: Colors.purple, size: 18),
                    const SizedBox(width: 6),
                    Text('${kilo.toStringAsFixed(1)} kg', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.purple)),
                    const SizedBox(width: 6),
                    if (onceki != null) _karsilastirmaIkonu(kilo, onceki),
                    const Spacer(),
                    IconButton(
                      icon: const Icon(Icons.volume_up, size: 20),
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                      onPressed: () => SesServisi.konus('Kilo ${kilo.toStringAsFixed(1)} kilogram'),
                    ),
                  ],
                ),
                const SizedBox(height: 2),
                Text(
                  '${DilServisi.metin('tarihBaslik')}: ${_tarihiBicimlendir(_kiloKayitlari[i]['tarih']?.toString())}${onceki != null ? '\n${_karsilastirmaMetni(kilo, onceki, 'kg')}' : ''}',
                  style: TextStyle(fontSize: 11, color: Colors.grey.shade700, height: 1.25),
                ),
              ],
            ),
          ),
        );
      },
    ),
        ),
      ],
    );
  }  // --- _kiloSayfasi() sonu ---

  Future<void> _hedefKiloDuzenle() async {
    final controller = TextEditingController(text: _hedefKilo?.toStringAsFixed(1) ?? '');
    final yeniDeger = await showDialog<double>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(DilServisi.metin('hedefKilo')),
        content: TextField(
          controller: controller,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(suffixText: 'kg', border: OutlineInputBorder()),
          autofocus: true,
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: Text(DilServisi.metin('vazgec'))),
          TextButton(
            onPressed: () => Navigator.pop(context, double.tryParse(controller.text.replaceAll(',', '.'))),
            child: Text(DilServisi.metin('kaydet')),
          ),
        ],
      ),
    );
    if (yeniDeger == null) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(await ProfilYoneticisi().profilAnahtari('hedef_kilo'), yeniDeger);
    if (mounted) setState(() => _hedefKilo = yeniDeger);
  }  // --- _hedefKiloDuzenle() sonu ---

  Widget _adimSayfasi() {
    if (_adimGecmisi.isEmpty || _adimGecmisi.every((e) => e.value == 0)) {
      return Center(child: Text(DilServisi.metin('henuzAdimVerisiYok'), textAlign: TextAlign.center));
    }
    final gunAdlari = [DilServisi.metin('gunPzt'), DilServisi.metin('gunSal'), DilServisi.metin('gunCar'), DilServisi.metin('gunPer'), DilServisi.metin('gunCum'), DilServisi.metin('gunCmt'), DilServisi.metin('gunPaz')];
    final gunlukOrtalama = _adimGecmisi.isEmpty
        ? 0
        : (_adimGecmisi.map((e) => e.value).reduce((a, b) => a + b) / _adimGecmisi.length).round();
    final hedefTutulanGunSayisi = _adimGecmisi.where((e) => e.value >= _hedefAdim).length;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: ListTile(
            leading: const Icon(Icons.flag, color: Colors.deepOrange),
            title: Text('${DilServisi.metin('gunlukHedef')}: $_hedefAdim ${DilServisi.metin('adimKelime')}'),
            subtitle: Text('${DilServisi.metin('gunlukOrtalama')}: $gunlukOrtalama ${DilServisi.metin('adimKelime')}'),
            trailing: TextButton(onPressed: _hedefAdimDuzenle, child: Text(DilServisi.metin('duzenle'))),
          ),
        ),
        const SizedBox(height: 12),
        _mesafeRozetKarti(_omurBoyuToplamAdim),
        const SizedBox(height: 12),
        _haftalikSeriKarti(
          gunler: _adimGecmisi.map((e) => MapEntry(e.key, e.value >= _hedefAdim)).toList(),
          gunAdlari: gunAdlari,
          renk: Colors.deepOrange,
          hedefTutulanGunSayisi: hedefTutulanGunSayisi,
        ),
        const SizedBox(height: 12),
        Card(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 14, 16, 14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  Expanded(child: Text(DilServisi.metin('adimSeyriSon7Gun'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14))),
                  IconButton(
                    icon: Icon(_barGorunumu ? Icons.show_chart : Icons.bar_chart, size: 20, color: Colors.grey.shade600),
                    tooltip: _barGorunumu ? DilServisi.metin('cizgiGrafigeGec') : DilServisi.metin('barGrafigeGec'),
                    onPressed: () => setState(() => _barGorunumu = !_barGorunumu),
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                  ),
                  const SizedBox(width: 6),
                  Row(children: [
                    Container(width: 10, height: 10, decoration: const BoxDecoration(color: Colors.green, shape: BoxShape.circle)),
                    const SizedBox(width: 4),
                    Text(DilServisi.metin('hedefTuttu'), style: const TextStyle(fontSize: 10, color: Colors.grey)),
                  ]),
                ]),
                const SizedBox(height: 12),
                SizedBox(
                  height: 145,
                  child: Builder(builder: (context) {
                    final maksimumAdim = _adimGecmisi.isEmpty
                        ? 0.0
                        : _adimGecmisi.map((e) => e.value.toDouble()).reduce((a, b) => a > b ? a : b);
                    final adimAralik = _guzelAralik(maksimumAdim == 0 ? 250 : maksimumAdim / 4);
                    final adimMaxY = ((maksimumAdim / adimAralik).ceil() * adimAralik).clamp(adimAralik, double.infinity).toDouble();
                    FlTitlesData adimBaslikVerisi() => FlTitlesData(
                          topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                          rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                          leftTitles: AxisTitles(
                            sideTitles: SideTitles(
                              showTitles: true,
                              reservedSize: 52,
                              interval: adimAralik,
                              getTitlesWidget: (value, meta) => Padding(
                                padding: const EdgeInsets.only(right: 4),
                                child: Text(value.toInt().toString(), style: const TextStyle(fontSize: 10), maxLines: 1, softWrap: false),
                              ),
                            ),
                          ),
                          bottomTitles: AxisTitles(
                            sideTitles: SideTitles(
                              showTitles: true,
                              interval: 1,
                              getTitlesWidget: (value, meta) {
                                final i = value.toInt();
                                if (i < 0 || i >= _adimGecmisi.length) return const SizedBox.shrink();
                                final tarih = DateTime.tryParse(_adimGecmisi[i].key);
                                return Padding(
                                  padding: const EdgeInsets.only(top: 6),
                                  child: Text(tarih != null ? gunAdlari[tarih.weekday - 1] : '', style: const TextStyle(fontSize: 10)),
                                );
                              },
                            ),
                          ),
                        );
                    if (_barGorunumu) {
                      return BarChart(
                        BarChartData(
                          maxY: adimMaxY,
                          gridData: const FlGridData(show: true, drawVerticalLine: false),
                          titlesData: adimBaslikVerisi(),
                          borderData: FlBorderData(show: false),
                          barGroups: [
                            for (int i = 0; i < _adimGecmisi.length; i++)
                              BarChartGroupData(x: i, barRods: [
                                BarChartRodData(
                                  toY: _adimGecmisi[i].value.toDouble(),
                                  color: _adimGecmisi[i].value >= _hedefAdim ? Colors.green : Colors.grey.shade400,
                                  width: 16, borderRadius: BorderRadius.circular(4),
                                ),
                              ]),
                          ],
                        ),
                      );
                    }
                    return LineChart(
                      LineChartData(
                        maxY: adimMaxY,
                        gridData: const FlGridData(show: true, drawVerticalLine: false),
                        titlesData: adimBaslikVerisi(),
                        borderData: FlBorderData(show: false),
                        lineBarsData: [
                          LineChartBarData(
                            spots: [for (int i = 0; i < _adimGecmisi.length; i++) FlSpot(i.toDouble(), _adimGecmisi[i].value.toDouble())],
                            isCurved: true,
                            color: Colors.green,
                            barWidth: 3,
                            dotData: const FlDotData(show: true),
                            belowBarData: BarAreaData(show: true, color: Colors.green.withOpacity(0.12)),
                          ),
                        ],
                      ),
                    );
                  }),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        ..._adimGecmisi.reversed.map((e) {
          final tarih = DateTime.tryParse(e.key);
          final gunAdi = tarih != null ? gunAdlari[tarih.weekday - 1] : '';
          final hedefTuttu = e.value >= _hedefAdim;
          return Card(
            child: ListTile(
              leading: Icon(Icons.directions_walk, color: hedefTuttu ? Colors.green : Colors.deepOrange),
              title: Text('${e.value} ${DilServisi.metin('adimKelime')}', style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text('$gunAdi, ${e.key} — ${DilServisi.metin('tahmini')} ${AdimServisi.kaloriTahminEt(e.value).toStringAsFixed(0)} kcal'),
              trailing: hedefTuttu ? const Icon(Icons.check_circle, color: Colors.green, size: 20) : null,
            ),
          );
        }),
      ],
    );
  }  // --- _adimSayfasi() sonu ---

  // Toplam kümülatif mesafeye göre rozet ilerlemesi (rakip fitness
  // uygulamasındaki "100KM" rozetinden esinlenildi). Basamaklar: 10, 25,
  // 50, 100, 250, 500, 1000 km — hangisine yaklaşıyorsa onu gösterir.
  Widget _mesafeRozetKarti(int omurBoyuAdim) {
    const basamaklar = [10, 25, 50, 100, 250, 500, 1000];
    final mesafeKm = AdimServisi.mesafeTahminEt(omurBoyuAdim);
    final hedefKm = basamaklar.firstWhere((b) => b > mesafeKm, orElse: () => basamaklar.last);
    final oncekiBasamak = basamaklar.indexOf(hedefKm) > 0 ? basamaklar[basamaklar.indexOf(hedefKm) - 1] : 0;
    final oran = ((mesafeKm - oncekiBasamak) / (hedefKm - oncekiBasamak)).clamp(0.0, 1.0);
    final kalanKm = (hedefKm - mesafeKm).clamp(0, hedefKm);

    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        child: Row(
          children: [
            Container(
              width: 46, height: 46,
              decoration: BoxDecoration(color: Colors.deepOrange.shade50, shape: BoxShape.circle),
              child: Icon(Icons.emoji_events, color: Colors.deepOrange.shade700, size: 24),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('${mesafeKm.toStringAsFixed(1)} km / $hedefKm km ${DilServisi.metin('rozet')}',
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                  const SizedBox(height: 6),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(6),
                    child: LinearProgressIndicator(
                      value: oran, minHeight: 8,
                      backgroundColor: Colors.grey.shade200,
                      color: Colors.deepOrange,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text('$kalanKm km ${DilServisi.metin('kaldiToplam')} ${omurBoyuAdim.toString()} ${DilServisi.metin('adimKelime')}',
                      style: TextStyle(fontSize: 11, color: Colors.grey.shade600)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }  // --- _mesafeRozetKarti() sonu ---
  // Haftalık "seri" kartı: her gün için küçük bir halka (hedefi tutan gün
  // dolu/renkli, tutmayan gün boş) ve hedefi TAM 7/7 tutulmuşsa bir yıldız
  // rozeti. Rakip bir fitness uygulamasının haftalık takvim görünümünden
  // esinlenildi — motive edici, sade bir özet.
  Widget _haftalikSeriKarti({
    required List<MapEntry<String, bool>> gunler, // tarih (ISO) -> hedef tuttu mu
    required List<String> gunAdlari,
    required MaterialColor renk,
    required int hedefTutulanGunSayisi,
  }) {
    final tamHafta = gunler.length >= 7 && hedefTutulanGunSayisi == gunler.length;
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(DilServisi.metin('buHaftakiSeri'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                ),
                if (tamHafta) ...[
                  Icon(Icons.star, color: Colors.amber.shade600, size: 18),
                  const SizedBox(width: 3),
                  Text(DilServisi.metin('tamHafta'), style: TextStyle(fontSize: 12, color: Colors.amber.shade800, fontWeight: FontWeight.bold)),
                ] else
                  Text('$hedefTutulanGunSayisi/${gunler.length} ${DilServisi.metin('gunKelime')}', style: TextStyle(fontSize: 12, color: renk.shade700, fontWeight: FontWeight.w600)),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: gunler.map((gun) {
                final tarih = DateTime.tryParse(gun.key);
                final harf = tarih != null ? gunAdlari[tarih.weekday - 1][0] : '?';
                final tutuldu = gun.value;
                final buGunMu = tarih != null &&
                    tarih.year == DateTime.now().year &&
                    tarih.month == DateTime.now().month &&
                    tarih.day == DateTime.now().day;
                return Column(
                  children: [
                    Container(
                      width: 30,
                      height: 30,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: tutuldu ? renk : Colors.transparent,
                        border: Border.all(color: tutuldu ? renk : Colors.grey.shade300, width: 2),
                      ),
                      child: tutuldu
                          ? const Icon(Icons.check, color: Colors.white, size: 16)
                          : null,
                    ),
                    const SizedBox(height: 4),
                    Text(harf, style: TextStyle(fontSize: 11, color: buGunMu ? renk.shade700 : Colors.grey, fontWeight: buGunMu ? FontWeight.bold : FontWeight.normal)),
                  ],
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }  // --- _haftalikSeriKarti() sonu ---

  Future<void> _hedefAdimDuzenle() async {
    final controller = TextEditingController(text: _hedefAdim.toString());
    final yeniDeger = await showDialog<int>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(DilServisi.metin('gunlukAdimHedefi')),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(suffixText: 'adım', border: OutlineInputBorder()),
          autofocus: true,
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: Text(DilServisi.metin('vazgec'))),
          TextButton(onPressed: () => Navigator.pop(context, int.tryParse(controller.text)), child: Text(DilServisi.metin('kaydet'))),
        ],
      ),
    );
    if (yeniDeger == null) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(await ProfilYoneticisi().profilAnahtari('hedef_adim'), yeniDeger);
    if (mounted) setState(() => _hedefAdim = yeniDeger);
  }  // --- _hedefAdimDuzenle() sonu ---

  // --- SEKME BAŞINA DİNAMİK AI YORUMU (önbellekli — veri değişmedikçe tekrar sorulmaz) ---
  Future<void> _gidisatYorumuGetir({
    required String anahtar,
    required String metrikAdi,
    required String imza,
    required String veriOzeti,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    // Önbellek anahtarına dil kodu eklendi — dil değişince eski dildeki
    // yorum önbellekte kalıp yanlış dilde gösterilmesin diye.
    final onbellekAnahtari = '${anahtar}_${DilServisi.dilKodu}';
    final onbellekImza = prefs.getString('yorum_imza_$onbellekAnahtari');
    final onbellekYorum = prefs.getString('yorum_metin_$onbellekAnahtari');
    if (onbellekImza == imza && onbellekYorum != null) {
      if (mounted) setState(() => _gidisatYorumlari[anahtar] = onbellekYorum);
      return;
    }  // --- _gidisatYorumuGetir() sonu ---

    if (mounted) setState(() => _yorumYukleniyorMu[anahtar] = true);
    final yorum = await ApiService.gidisatYorumuOlustur(metrikAdi: metrikAdi, veriOzeti: veriOzeti);

    // ÖNEMLİ: hata mesajları asla önbelleğe kalıcı olarak yazılmaz. Önceden
    // bir hata bir kere önbelleğe düşerse (örn. geçici bağlantı sorunu), o
    // sekme veri değişene kadar SONSUZA KADAR o hatayı gösteriyordu — bir
    // daha asla yeniden denenmiyordu. Bu, "sadece şeker sekmesinde yorum
    // çıkıyor, diğerlerinde hiç çıkmıyor" şikayetinin asıl sebebiydi: diğer
    // sekmeler ilk denemede hata almış ve o hata kalıcılaşmıştı.
    if (ApiService.cevapHataMi(yorum)) {
      if (mounted) setState(() => _yorumYukleniyorMu[anahtar] = false);
      return; // Önbelleğe yazmadan çık — bir sonraki ekran açılışında tekrar denenecek.
    }

    await prefs.setString('yorum_imza_$onbellekAnahtari', imza);
    await prefs.setString('yorum_metin_$onbellekAnahtari', yorum);
    if (mounted) {
      setState(() {
        _gidisatYorumlari[anahtar] = yorum;
        _yorumYukleniyorMu[anahtar] = false;
      });
    }
  }

  void _tumYorumlariTetikle() {
    if (_sekerler.isNotEmpty) {
      final ozet = _sekerler.take(6).map((s) => '${s['deger']} mg/dL (${s['durum']}, ${s['tarih']})').join('; ');
      _gidisatYorumuGetir(
        anahtar: 'seker', metrikAdi: 'kan şekeri',
        imza: '${_sekerler.length}_${_sekerler.first['deger']}',
        veriOzeti: 'Son kan şekeri ölçümleri: $ozet',
      );
    }
    if (_tansiyonlar.isNotEmpty) {
      final ozet = _tansiyonlar.take(6).map((t) => '${t['buyuk']}/${t['kucuk']} mmHg (${t['tarih']})').join('; ');
      _gidisatYorumuGetir(
        anahtar: 'tansiyon', metrikAdi: 'tansiyon',
        imza: '${_tansiyonlar.length}_${_tansiyonlar.first['buyuk']}',
        veriOzeti: 'Son tansiyon ölçümleri: $ozet',
      );
    }
    if (_suKayitlari.isNotEmpty) {
      final ozet = _suKayitlari.take(8).map((s) => '${s['miktar_ml']} mL (${s['tarih']})').join('; ');
      _gidisatYorumuGetir(
        anahtar: 'su', metrikAdi: 'su tüketimi',
        imza: '${_suKayitlari.length}_${_suKayitlari.first['miktar_ml']}',
        veriOzeti: 'Son su tüketim kayıtları (günlük hedef 2000 mL): $ozet',
      );
    }
    if (_kiloKayitlari.isNotEmpty) {
      final ozet = _kiloKayitlari.take(6).map((k) => '${k['kilo']} kg (${k['tarih']})').join('; ');
      _gidisatYorumuGetir(
        anahtar: 'kilo', metrikAdi: 'kilo',
        imza: '${_kiloKayitlari.length}_${_kiloKayitlari.first['kilo']}',
        veriOzeti: 'Son kilo ölçümleri${_hedefKilo != null ? " (hedef: $_hedefKilo kg)" : ""}: $ozet',
      );
    }
  }  // --- _tumYorumlariTetikle() sonu ---

  Widget _gidisatYorumKarti(String anahtar, Color renk) {
    final yukleniyor = _yorumYukleniyorMu[anahtar] ?? false;
    final yorum = _gidisatYorumlari[anahtar];
    if (yorum == null && !yukleniyor) return const SizedBox.shrink();
    final tiklanabilir = !yukleniyor && yorum != null && yorum.isNotEmpty;
    // ÖNEMLİ DÜZELTME: Kullanıcı fark etti — bu kart tüm yorum metnini
    // AÇIK hâlde gösterip çok yer kaplıyordu. Artık sadece 2 satırlık bir
    // ÖN İZLEME gösteriyor (yaklaşık 1/3 boyut) — dokununca tam metin,
    // Sesli Dinle/Yazdır/Paylaş ile birlikte AYRI BİR PENCEREDE açılıyor
    // (tahlil detay penceresiyle aynı desen).
    return Card(
      color: renk.withOpacity(0.14),
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        borderRadius: BorderRadius.circular(4),
        onTap: tiklanabilir ? () => _gidisatYorumPenceresiGoster(anahtar, renk, yorum) : null,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(Icons.auto_awesome, color: renk, size: 18),
              const SizedBox(width: 8),
              Expanded(
                child: yukleniyor
                    ? Text(DilServisi.metin('gidisatAnalizEdiliyor'), style: const TextStyle(fontSize: 12, color: Colors.grey))
                    : Text(
                        yorum ?? '',
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 13, height: 1.4),
                      ),
              ),
              if (tiklanabilir) Icon(Icons.chevron_right, color: renk, size: 22),
            ],
          ),
        ),
      ),
    );
  }  // --- _gidisatYorumKarti() sonu ---

  // Gidişat yorumunu AYRI BİR PENCERE (Dialog) olarak açar — üst bantta
  // başlık + hoparlör + yazdır/paylaş + X (kapat) var, içerik telefon
  // genişliğine sığacak şekilde dikey kaydırılıyor.
  // ÖNEMLİ: Kullanıcı istedi — çıktı/dosya adında hangi metriğe ait
  // olduğu belli olsun (ör. "Kilo Gidişat Analizi" → dosya adı
  // "seray_kilo_gidisat_analizi_...").
  static Map<String, String> get _metrikAdlari => {
    'seker': DilServisi.metin('sekerKelime'), 'tansiyon': DilServisi.metin('tansiyon'),
    'su': DilServisi.metin('suBaslik'), 'kilo': DilServisi.metin('kiloBaslik'),
  };

  void _gidisatYorumPenceresiGoster(String anahtar, Color renk, String yorum) {
    final metrikAdi = _metrikAdlari[anahtar] ?? '';
    final baslik = metrikAdi.isNotEmpty ? '$metrikAdi ${DilServisi.metin('gidisatAnalizi')}' : DilServisi.metin('gidisatAnalizi');
    showDialog(
      context: context,
      builder: (dialogContext) => PopScope(
        onPopInvokedWithResult: (didPop, result) => SesServisi.durdur(),
        child: Dialog(
        insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 40),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: ConstrainedBox(
          constraints: BoxConstraints(maxHeight: MediaQuery.of(dialogContext).size.height * 0.75),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                decoration: BoxDecoration(
                  color: renk,
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
                ),
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
                child: Row(
                  children: [
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(baslik, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
                    ),
                    IconButton(
                      icon: const Icon(Icons.volume_up, color: Colors.white),
                      tooltip: DilServisi.metin('sesliDinle'),
                      onPressed: () => SesServisi.konus(yorum),
                    ),
                    IconButton(
                      icon: const Icon(Icons.share_outlined, color: Colors.white),
                      tooltip: DilServisi.metin('paylas'),
                      onPressed: () async {
                        try {
                          final ad = (await ProfilYoneticisi().aktifProfil()).ad;
                          await PdfRaporServisi.analizRaporuOlusturVePaylas(
                            kullaniciAdi: ad,
                            baslik: baslik,
                            analizMetni: yorum,
                          );
                        } catch (_) {
                          // Sessizce geç — kullanıcı tekrar deneyebilir.
                        }
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.print_outlined, color: Colors.white),
                      tooltip: DilServisi.metin('yazdir'),
                      onPressed: () async {
                        try {
                          final ad = (await ProfilYoneticisi().aktifProfil()).ad;
                          await PdfRaporServisi.analizRaporuYazdir(
                            kullaniciAdi: ad,
                            baslik: baslik,
                            analizMetni: yorum,
                          );
                        } catch (_) {
                          // Sessizce geç — kullanıcı tekrar deneyebilir.
                        }
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.close, color: Colors.white),
                      tooltip: DilServisi.metin('kapat'),
                      onPressed: () => Navigator.pop(dialogContext),
                    ),
                  ],
                ),
              ),
              Flexible(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(14),
                  child: SelectableText(yorum, style: const TextStyle(fontSize: 14, height: 1.4)),
                ),
              ),
            ],
          ),
        ),
        ),
      ),
    );
  }  // --- _gidisatYorumPenceresiGoster() sonu ---

  // --- Ortak grafik ve karşılaştırma yardımcıları ---
  Widget _trendGrafigi({
    required String baslik,
    required List<double> degerler,
    required Color renk,
    List<double>? ikinciSeri,
    Color? ikinciRenk,
    double? riskEsigi,
    double? hedefDegeri,
    String? hedefEtiketi,
    String? aciklama,
  }) {
    if (degerler.length < 2) return const SizedBox.shrink();
    final tumDegerler = [...degerler, if (ikinciSeri != null) ...ikinciSeri, if (hedefDegeri != null) hedefDegeri];
    final hamMinY = tumDegerler.reduce((a, b) => a < b ? a : b) - 15;
    final hamMaxY = tumDegerler.reduce((a, b) => a > b ? a : b) + 15;
    final hamGercekMinY = hamMinY < 0 ? 0.0 : hamMinY;
    // ÖNEMLİ DÜZELTME: fl_chart varsayılan olarak eksenin gerçek min/max
    // veri değeri için AYRICA bir etiket ekliyor — bu, bizim yuvarlak
    // interval etiketimize çok yakın çıkıp üst üste binen sayılara (ör.
    // "162"/"160") sebep oluyordu. Kullandığımız fl_chart sürümünde bunu
    // kapatan minIncluded/maxIncluded parametresi YOK — bu yüzden eksenin
    // alt/üst sınırını baştan interval'in tam katı olacak şekilde
    // hesaplıyoruz; böylece "gerçek min/max" etiketiyle "interval" etiketi
    // zaten AYNI sayı oluyor, çakışma hiç oluşmuyor.
    final aralik = _guzelAralik((hamMaxY - hamGercekMinY) / 4);
    final gercekMinY = (hamGercekMinY / aralik).floor() * aralik;
    final maxY = (hamMaxY / aralik).ceil() * aralik;
    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 14, 16, 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(child: Text(baslik, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14))),
                // Çizgi / Bar grafik seçimi — tüm grafiklerde ortak
                IconButton(
                  icon: Icon(_barGorunumu ? Icons.show_chart : Icons.bar_chart, size: 20, color: Colors.grey.shade600),
                  tooltip: _barGorunumu ? DilServisi.metin('cizgiGrafigeGec') : DilServisi.metin('barGrafigeGec'),
                  onPressed: () => setState(() => _barGorunumu = !_barGorunumu),
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                ),
              ],
            ),
            if (aciklama != null) ...[
              const SizedBox(height: 2),
              Text(aciklama, style: TextStyle(fontSize: 11, color: Colors.grey.shade600)),
            ],
            const SizedBox(height: 8),
            SizedBox(
              height: 120,
              child: _barGorunumu
                  ? BarChart(
                      BarChartData(
                        minY: gercekMinY,
                        maxY: maxY,
                        gridData: const FlGridData(show: true, drawVerticalLine: false),
                        titlesData: FlTitlesData(
                          topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                          rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                          bottomTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                          leftTitles: AxisTitles(
                            sideTitles: SideTitles(
                              showTitles: true,
                              reservedSize: 50,
                              interval: aralik,
                              getTitlesWidget: (value, meta) => Padding(
                                padding: const EdgeInsets.only(right: 4),
                                child: Text(value.toInt().toString(), style: const TextStyle(fontSize: 10), maxLines: 1, softWrap: false),
                              ),
                            ),
                          ),
                        ),
                        borderData: FlBorderData(show: false),
                        barGroups: [
                          for (int i = 0; i < degerler.length; i++)
                            BarChartGroupData(x: i, barRods: [
                              BarChartRodData(toY: degerler[i], color: renk, width: ikinciSeri != null ? 7 : 12, borderRadius: BorderRadius.circular(3)),
                              if (ikinciSeri != null)
                                BarChartRodData(toY: ikinciSeri[i], color: ikinciRenk ?? renk, width: 7, borderRadius: BorderRadius.circular(3)),
                            ]),
                        ],
                      ),
                    )
                  : LineChart(
                      LineChartData(
                        minY: gercekMinY,
                        maxY: maxY,
                        gridData: const FlGridData(show: true, drawVerticalLine: false),
                        titlesData: FlTitlesData(
                          topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                          rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                          bottomTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                          leftTitles: AxisTitles(
                            sideTitles: SideTitles(
                              showTitles: true,
                              reservedSize: 50,
                              interval: aralik,
                              getTitlesWidget: (value, meta) => Padding(
                                padding: const EdgeInsets.only(right: 4),
                                child: Text(value.toInt().toString(), style: const TextStyle(fontSize: 10), maxLines: 1, softWrap: false),
                              ),
                            ),
                          ),
                        ),
                        borderData: FlBorderData(show: false),
                        // Risk bölgesi: eşik değerin üstü hafif kırmızı/turuncu gölgeli
                        rangeAnnotations: riskEsigi != null
                            ? RangeAnnotations(
                                horizontalRangeAnnotations: [
                                  HorizontalRangeAnnotation(y1: riskEsigi, y2: maxY, color: Colors.red.withOpacity(0.08)),
                                ],
                              )
                            : const RangeAnnotations(),
                        // Hedef çizgisi (kesikli) — örn. hedef kilo
                        extraLinesData: hedefDegeri != null
                            ? ExtraLinesData(horizontalLines: [
                                HorizontalLine(
                                  y: hedefDegeri,
                                  color: Colors.purple.shade300,
                                  strokeWidth: 2,
                                  dashArray: [6, 4],
                                  label: HorizontalLineLabel(
                                    show: true,
                                    labelResolver: (line) => hedefEtiketi ?? 'Hedef',
                                    style: TextStyle(color: Colors.purple.shade400, fontSize: 10, fontWeight: FontWeight.bold),
                                    alignment: Alignment.topRight,
                                  ),
                                ),
                              ])
                            : const ExtraLinesData(),
                        lineBarsData: [
                          LineChartBarData(
                            spots: [for (int i = 0; i < degerler.length; i++) FlSpot(i.toDouble(), degerler[i])],
                            isCurved: true,
                            color: renk,
                            barWidth: 3,
                            dotData: const FlDotData(show: true),
                            belowBarData: BarAreaData(show: ikinciSeri == null, color: renk.withOpacity(0.12)),
                          ),
                          if (ikinciSeri != null)
                            LineChartBarData(
                              spots: [for (int i = 0; i < ikinciSeri.length; i++) FlSpot(i.toDouble(), ikinciSeri[i])],
                              isCurved: true,
                              color: ikinciRenk ?? renk,
                              barWidth: 3,
                              dotData: const FlDotData(show: true),
                              belowBarData: BarAreaData(show: false),
                            ),
                        ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }  // --- _trendGrafigi() sonu ---

  Widget _karsilastirmaIkonu(num guncel, num onceki) {
    if (guncel == onceki) return const Icon(Icons.remove, color: Colors.grey, size: 20);
    final yukseldi = guncel > onceki;
    return Icon(yukseldi ? Icons.arrow_upward : Icons.arrow_downward, color: yukseldi ? Colors.red : Colors.green, size: 20);
  }  // --- _karsilastirmaIkonu() sonu ---

  String _karsilastirmaMetni(num guncel, num onceki, String birim) {
    if (guncel == onceki) return DilServisi.metin('oncekiOlcumleAyni');
    final fark = (guncel - onceki).abs();
    final yon = guncel > onceki ? DilServisi.metin('yukseldi') : DilServisi.metin('dustu');
    return '${DilServisi.metin('oncekiOlcumeGore')} $fark $birim $yon';
  }  // --- _karsilastirmaMetni() sonu ---
}
