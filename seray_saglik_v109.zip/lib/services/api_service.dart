import 'dart:convert';
import 'package:googleai_dart/googleai_dart.dart';

class ApiService {
  static final GoogleAIClient _client = GoogleAIClient(
    config: GoogleAIConfig.googleAI(
      authProvider: ApiKeyProvider(
        const String.fromEnvironment('GEMINI_KEY'),
      ),
    ),
  );

  static Future<String> tahlilMetniniAnalizEt(String pdfMetni) async {
    if (pdfMetni.trim().isEmpty) {
      return jsonEncode({"hata": "PDF icerigi bos."});
    }

    final istek = 'Sen profesyonel bir laboratuvar ve saglik uzmanisina yardimci olan yapay zekasin.\n'
        'Asagidaki E-Nabiz metnindeki en guncel tahlil sonuclarini bul.\n'
        'Cevabi baska hicbir metin, aciklama veya ters bolu isareti eklemeden SADECE tek bir satirda su JSON formatinda dondur:\n\n'
        '{"tarih": "2026-07-15", "seker": 0, "tansiyonUst": 0, "tansiyonAlt": 0, "nabiz": 0, "kolesterol": 0, "ldl": 0, "hdl": 0, "trigliserid": 0, "ast": 0, "alt": 0, "ure": 0, "kreatinin": 0, "hemoglobin": 0, "b12": 0, "d_vitamini": 0, "tsh": 0}\n\n'
        'Metinde bulunmayan sayisal alanlara 0 yaz. tarih alanina tahlil tarihini YYYY-MM-DD formatinda yaz.\n'
        'METIN:\n$pdfMetni';

    try {
      final response = await _client.models.generateContent(
        model: 'gemini-1.5-flash', 
        request: GenerateContentRequest(
          contents: [Content(parts: [TextPart(istek)], role: 'user')],
          generationConfig: GenerationConfig(responseMimeType: 'application/json'),
        ),
      );

      String hamCevap = '';
      final parcalar = response.candidates?.first.content?.parts ?? [];
      for (final p in parcalar) {
        if (p is TextPart) { 
          hamCevap = p.text; 
          break; 
        }
      }

      hamCevap = hamCevap.replaceAll('```json', '').replaceAll('```', '').trim();
      final Map<String, dynamic> jsonNesnesi = jsonDecode(hamCevap);
      
      return "Tahlil Sonucunuz Başarıyla Çözümlendi:\n\n"
             "• Açlık Şekeri: ${jsonNesnesi['seker'] ?? 0} mg/dL\n"
             "• Kolesterol (LDL): ${jsonNesnesi['ldl'] ?? 0} mg/dL\n"
             "• B12 Vitamini: ${jsonNesnesi['b12'] ?? 0} pg/mL\n"
             "• D Vitamini: ${jsonNesnesi['d_vitamini'] ?? 0} ng/mL\n\n"
             "Değerleriniz başarıyla yerel hafızaya kaydedildi.";
    } catch (e) {
      return "Bir hata oluştu. Lütfen metni veya bağlantınızı kontrol edin.";
    }
  }
}
