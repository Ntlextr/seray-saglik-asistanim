import 'dart:async';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class VeritabaniYardimcisi {
  static final VeritabaniYardimcisi _instance = VeritabaniYardimcisi._internal();
  static Database? _database;

  factory VeritabaniYardimcisi() => _instance;

  VeritabaniYardimcisi._internal();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    String path = join(await getDatabasesPath(), 'saglik_verileri.db');
    return await openDatabase(
      path,
      version: 2,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
  }

  Future _onCreate(Database db, int version) async {
    await db.execute('CREATE TABLE seker_olcumleri (id INTEGER PRIMARY KEY AUTOINCREMENT, deger INTEGER, durum TEXT, tarih TEXT)');
    await db.execute('CREATE TABLE tansiyon_olcumleri (id INTEGER PRIMARY KEY AUTOINCREMENT, buyuk INTEGER, kucuk INTEGER, nabiz INTEGER, tarih TEXT)');
    await db.execute('CREATE TABLE ilaclar (id INTEGER PRIMARY KEY AUTOINCREMENT, ad TEXT, dozaj TEXT, saat TEXT)');
  }

  Future _onUpgrade(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 2) {
      await db.execute('CREATE TABLE ilaclar (id INTEGER PRIMARY KEY AUTOINCREMENT, ad TEXT, dozaj TEXT, saat TEXT)');
    }
  }

  Future<int> sekerEkle(Map<String, dynamic> veri) async { Database db = await database; return await db.insert('seker_olcumleri', veri); }
  Future<List<Map<String, dynamic>>> sekerleriGetir() async { Database db = await database; return await db.query('seker_olcumleri', orderBy: 'tarih DESC'); }

  Future<int> tansiyonEkle(Map<String, dynamic> veri) async { Database db = await database; return await db.insert('tansiyon_olcumleri', veri); }
  Future<List<Map<String, dynamic>>> tansiyonlariGetir() async { Database db = await database; return await db.query('tansiyon_olcumleri', orderBy: 'tarih DESC'); }

  Future<int> ilacEkle(Map<String, dynamic> veri) async { Database db = await database; return await db.insert('ilaclar', veri); }
  Future<List<Map<String, dynamic>>> ilaclariGetir() async { Database db = await database; return await db.query('ilaclar', orderBy: 'id DESC'); }
  Future<int> ilacSil(int id) async { Database db = await database; return await db.delete('ilaclar', where: 'id = ?', whereArgs: [id]); }

  Future<void> veritabaniSifirla() async {
    Database db = await database;
    await db.delete('seker_olcumleri');
    await db.delete('tansiyon_olcumleri');
    await db.delete('ilaclar');
  }
}
