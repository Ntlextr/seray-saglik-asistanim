import 'package:flutter/material.dart';
import '../services/veritabani_yardimcisi.dart';

class SekerEkleEkrani extends StatefulWidget {
  const SekerEkleEkrani({Key? key}) : super(key: key);

  @override
  _SekerEkleEkraniState createState() => _SekerEkleEkraniState();
}

class _SekerEkleEkraniState extends State<SekerEkleEkrani> {
  final _formKey = GlobalKey<FormState>();
  final _degerController = TextEditingController();
  String _durum = 'Açlık';

  Future<void> _kaydet() async {
    if (_formKey.currentState!.validate()) {
      final veri = {
        'deger': int.parse(_degerController.text.trim()),
        'durum': _durum,
        'tarih': DateTime.now().toIso8601String(),
      };
      await VeritabaniYardimcisi().sekerEkle(veri);
      if (mounted) {
        Navigator.pop(context, true);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Şeker Ölçümü Ekle'), backgroundColor: Colors.red.shade600, foregroundColor: Colors.white),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 20),
              TextFormField(
                controller: _degerController,
                keyboardType: TextInputType.number,
                style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
                decoration: InputDecoration(
                  labelText: 'Kan Şekeri Değeri (mg/dL)',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                  prefixIcon: const Icon(Icons.bloodtype, size: 30),
                ),
                validator: (v) => int.tryParse(v ?? '') == null ? 'Lütfen geçerli bir değer girin' : null,
              ),
              const SizedBox(height: 24),
              const Text('Ölçüm Zamanı:', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: _durum,
                style: const TextStyle(fontSize: 20, color: Colors.black87),
                decoration: InputDecoration(border: OutlineInputBorder(borderRadius: BorderRadius.circular(16))),
                items: ['Açlık', 'Tokluk', 'Gece'].map((String s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
                onChanged: (v) => setState(() => _durum = v!),
              ),
              const SizedBox(height: 40),
              ElevatedButton(
                onPressed: _kaydet,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red.shade600,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                child: const Text('KAYDI TAMAMLA', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
