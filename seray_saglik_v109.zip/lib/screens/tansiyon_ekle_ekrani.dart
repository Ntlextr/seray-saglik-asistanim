import 'package:flutter/material.dart';
import '../services/veritabani_yardimcisi.dart';

class TansiyonEkleEkrani extends StatefulWidget {
  const TansiyonEkleEkrani({Key? key}) : super(key: key);

  @override
  _TansiyonEkleEkraniState createState() => _TansiyonEkleEkraniState();
}

class _TansiyonEkleEkraniState extends State<TansiyonEkleEkrani> {
  final _formKey = GlobalKey<FormState>();
  final _buyukController = TextEditingController();
  final _kucukController = TextEditingController();
  final _nabizController = TextEditingController();

  Future<void> _kaydet() async {
    if (_formKey.currentState!.validate()) {
      final veri = {
        'buyuk': int.parse(_buyukController.text.trim()),
        'kucuk': int.parse(_kucukController.text.trim()),
        'nabiz': int.parse(_nabizController.text.trim()),
        'tarih': DateTime.now().toIso8601String(),
      };
      await VeritabaniYardimcisi().tansiyonEkle(veri);
      if (mounted) {
        Navigator.pop(context, true);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Tansiyon Ölçümü Ekle'), backgroundColor: Colors.teal.shade600, foregroundColor: Colors.white),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _buyukController,
                      keyboardType: TextInputType.number,
                      style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                      decoration: InputDecoration(
                        labelText: 'Büyük (Sistolik)',
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                      ),
                      validator: (v) => int.tryParse(v ?? '') == null ? 'Hatalı' : null,
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: TextFormField(
                      controller: _kucukController,
                      keyboardType: TextInputType.number,
                      style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                      decoration: InputDecoration(
                        labelText: 'Küçük (Diastolik)',
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                      ),
                      validator: (v) => int.tryParse(v ?? '') == null ? 'Hatalı' : null,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              TextFormField(
                controller: _nabizController,
                keyboardType: TextInputType.number,
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
                decoration: InputDecoration(
                  labelText: 'Nabız (Kalp Atış Hızı)',
                  prefixIcon: const Icon(Icons.favorite, color: Colors.red),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                ),
                validator: (v) => int.tryParse(v ?? '') == null ? 'Lütfen geçerli bir nabız girin' : null,
              ),
              const SizedBox(height: 40),
              ElevatedButton(
                onPressed: _kaydet,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.teal.shade600,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                child: const Text('KAYDI TAMAMLA', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
