import 'package:flutter/material.dart';
import '../services/api_service.dart';

class YapayZekaEkrani extends StatefulWidget {
  const YapayZekaEkrani({Key? key}) : super(key: key);

  @override
  _YapayZekaEkraniState createState() => _YapayZekaEkraniState();
}

class _YapayZekaEkraniState extends State<YapayZekaEkrani> {
  bool _yukleniyor = false;
  String _aiCevap = "Merhaba! Ben Seray Sağlık Asistanınızım. e-Nabız tahlil metninizi aşağıya yapıştırarak analiz etmemi isteyebilirsiniz.";
  final _textController = TextEditingController();

  Future<void> _analizBaslat() async {
    if (_textController.text.trim().isEmpty) return;

    setState(() {
      _yukleniyor = true;
      _aiCevap = "Tahlilleriniz inceleniyor, lütfen bekleyin...";
    });

    final sonucJson = await ApiService.tahlilMetniniAnalizEt(_textController.text.trim());

    setState(() {
      _yukleniyor = false;
      _aiCevap = sonucJson;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(
        title: const Text('Yapay Zeka Danışmanı'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              color: Colors.teal.shade50,
              elevation: 0,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Text(
                  _aiCevap,
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w500, color: Colors.black87, height: 1.4),
                ),
              ),
            ),
            const SizedBox(height: 24),
            TextField(
              controller: _textController,
              maxLines: 6,
              style: const TextStyle(fontSize: 16),
              decoration: InputDecoration(
                labelText: 'e-Nabız Tahlil Metni veya PDF İçeriği',
                alignLabelWithHint: true,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                filled: true,
                fillColor: Colors.white,
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: _yukleniyor ? null : _analizBaslat,
              icon: _yukleniyor 
                ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                : const Icon(Icons.analytics),
              label: const Text('TAHLİLİ ANALİZ ET', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.teal,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              '⚠️ Not: Yapay zeka yorumları sadece bilgilendirme amaçlıdır, kesinlikle doktor teşhisi yerine geçmez.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 13, color: Colors.black54, fontWeight: FontWeight.w500),
            ),
          ],
        ),
      ),
    );
  }
}
