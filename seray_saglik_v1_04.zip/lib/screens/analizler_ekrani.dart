import 'package:flutter/material.dart';
import '../services/veritabani_yardimcisi.dart';

class AnalizlerEkrani extends StatefulWidget {
  const AnalizlerEkrani({Key? key}) : super(key: key);

  @override
  _AnalizlerEkraniState createState() => _AnalizlerEkraniState();
}

class _AnalizlerEkraniState extends State<AnalizlerEkrani> {
  List<Map<String, dynamic>> _sekerler = [];
  List<Map<String, dynamic>> _tansiyonlar = [];
  bool _yukleniyor = true;

  @override
  void initState() {
    super.initState();
    _verileriYukle();
  }

  Future<void> _verileriYukle() async {
    final sekerListesi = await VeritabaniYardimcisi().sekerleriGetir();
    final tansiyonListesi = await VeritabaniYardimcisi().tansiyonlariGetir();
    setState(() {
      _sekerler = sekerListesi;
      _tansiyonlar = tansiyonListesi;
      _yukleniyor = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: Colors.grey.shade50,
        appBar: AppBar(
          title: const Text('Sağlık Analizleri'),
          backgroundColor: Colors.teal,
          foregroundColor: Colors.white,
          bottom: const TabBar(
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white70,
            indicatorColor: Colors.white,
            tabs: [
              Tab(icon: Icon(Icons.bloodtype), text: 'Şeker Seyri'),
              Tab(icon: Icon(Icons.favorite), text: 'Tansiyon Seyri'),
            ],
          ),
        ),
        body: _yukleniyor
            ? const Center(child: CircularProgressIndicator())
            : TabBarView(
                children: [
                  _sekerGrafikSayfasi(),
                  _tansiyonGrafikSayfasi(),
                ],
              ),
      ),
    );
  }

  Widget _sekerGrafikSayfasi() {
    if (_sekerler.isEmpty) {
      return const Center(child: Text('Grafik için henüz şeker ölçümü yok.', style: TextStyle(fontSize: 16)));
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _sekerler.take(7).length,
      itemBuilder: (context, index) {
        final veri = _sekerler[index];
        final int deger = int.tryParse(veri['deger'].toString()) ?? 0;
        
        Color barRengi = deger > 140 ? Colors.red.shade400 : Colors.green.shade400;
        double barGenislik = (deger / 300).clamp(0.1, 1.0);

        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.between,
                  children: [
                    Text('${veri['durum']} Ölçümü', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    Text('$deger mg/dL', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: barRengi)),
                  ],
                ),
                const SizedBox(height: 8),
                Container(
                  height: 14,
                  width: double.infinity,
                  decoration: BoxDecoration(color: Colors.grey.shade200, borderRadius: BorderRadius.circular(7)),
                  child: FractionallySizedBox(
                    alignment: Alignment.centerLeft,
                    widthFactor: barGenislik,
                    child: Container(
                      decoration: BoxDecoration(color: barRengi, borderRadius: BorderRadius.circular(7)),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _tansiyonGrafikSayfasi() {
    if (_tansiyonlar.isEmpty) {
      return const Center(child: Text('Grafik için henüz tansiyon ölçümü yok.', style: TextStyle(fontSize: 16)));
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _tansiyonlar.take(7).length,
      itemBuilder: (context, index) {
        final veri = _tansiyonlar[index];
        final int buyuk = int.tryParse(veri['buyuk'].toString()) ?? 0;
        final int kucuk = int.tryParse(veri['kucuk'].toString()) ?? 0;

        Color tansiyonRengi = (buyuk > 135 || kucuk > 85) ? Colors.orange.shade700 : Colors.teal.shade600;

        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              children: [
                Icon(Icons.favorite, color: tansiyonRengi, size: 36),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Büyük / Küçük Tansiyon', style: TextStyle(fontSize: 14, color: Colors.grey.shade600)),
                      const SizedBox(height: 4),
                      Text('$buyuk / $kucuk mm Hg', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    const Text('Nabız', style: TextStyle(fontSize: 12, color: Colors.black54)),
                    Text('${veri['nabiz']} bpm', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.blue)),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
