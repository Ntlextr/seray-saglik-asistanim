import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../main.dart';

class ProfilKayitEkrani extends StatefulWidget {
  const ProfilKayitEkrani({Key? key}) : super(key: key);

  @override
  _ProfilKayitEkraniState createState() => _ProfilKayitEkraniState();
}

class _ProfilKayitEkraniState extends State<ProfilKayitEkrani> {
  final _formKey = GlobalKey<FormState>();
  final _adController = TextEditingController();
  final _soyadController = TextEditingController();
  final _yasController = TextEditingController();
  String _diyabetTipi = 'Yok';
  bool _kvkkOnay = false;

  Future<void> _profiliKaydet() async {
    if (!_kvkkOnay) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Lütfen devam etmek için KVKK Aydınlatma Metni\'ni onaylayın.', style: TextStyle(fontSize: 16))),
      );
      return;
    }

    if (_formKey.currentState!.validate()) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('user_ad', _adController.text.trim());
      await prefs.setString('user_soyad', _soyadController.text.trim());
      await prefs.setInt('user_yas', int.parse(_yasController.text.trim()));
      await prefs.setString('user_diyabet', _diyabetTipi);
      await prefs.setBool('is_logged_in', true);

      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const AnaEkranYonlendirici()),
        );
      }
    }
  }

  void _kvkkMetniniGoster() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('KVKK Aydınlatma Metni', style: TextStyle(fontWeight: FontWeight.bold)),
        content: const SingleChildScrollView(
          child: Text(
            'Seray Sağlık Asistanım uygulaması olarak kişisel sağlık verilerinizin güvenliğine önem veriyoruz. '
            'Uygulama içerisine kaydettiğiniz kan şekeri, tansiyon, nabız ve ilaç takibi gibi verileriniz '
            'KESİNLİKLE uzak bir sunucuya yedeklenmez, tamamen telefonunuzun yerel hafızasında saklanır. '
            'Tahlil analizi için yapay zeka servisi kullanıldığında, verileriniz anonim olarak işlenir. '
            'İstediğiniz zaman Profil sekmesinden "Güvenli Çıkış" yaparak telefondaki tüm verilerinizi kalıcı olarak silebilirsiniz.',
            style: TextStyle(fontSize: 15, height: 1.4),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Anladım', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold))),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.teal.shade50,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SizedBox(height: 20),
                Image.asset('assets/images/app_logo.png', height: 140, width: 140),
                const SizedBox(height: 16),
                const Text(
                  'Seray Sağlık Asistanım',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Colors.teal),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Lütfen profil bilgilerinizi eksiksiz doldurun.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 16, color: Colors.black54),
                ),
                const SizedBox(height: 24),
                TextFormField(
                  controller: _adController,
                  style: const TextStyle(fontSize: 18),
                  decoration: InputDecoration(
                    labelText: 'Adınız',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                    filled: true,
                    fillColor: Colors.white,
                  ),
                  validator: (v) => v!.isEmpty ? 'Ad alanı boş bırakılamaz' : null,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _soyadController,
                  style: const TextStyle(fontSize: 18),
                  decoration: InputDecoration(
                    labelText: 'Soyadınız',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                    filled: true,
                    fillColor: Colors.white,
                  ),
                  validator: (v) => v!.isEmpty ? 'Soyad alanı boş bırakılamaz' : null,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _yasController,
                  keyboardType: TextInputType.number,
                  style: const TextStyle(fontSize: 18),
                  decoration: InputDecoration(
                    labelText: 'Yaşınız',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                    filled: true,
                    fillColor: Colors.white,
                  ),
                  validator: (v) => int.tryParse(v ?? '') == null ? 'Geçerli bir yaş girin' : null,
                ),
                const SizedBox(height: 16),
                const Text('Diyabet (Şeker) Durumu:', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                DropdownButtonFormField<String>(
                  value: _diyabetTipi,
                  style: const TextStyle(fontSize: 18, color: Colors.black87),
                  decoration: InputDecoration(
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                    filled: true,
                    fillColor: Colors.white,
                  ),
                  items: ['Yok', 'Tip 1 Diyabet', 'Tip 2 Diyabet', 'Gizli Şeker'].map((String değer) {
                    return DropdownMenuItem<String>(value: değer, child: Text(değer));
                  }).toList(),
                  onChanged: (yeniDeğer) => setState(() => _diyabetTipi = yeniDeğer!),
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Checkbox(
                      value: _kvkkOnay,
                      onChanged: (değer) => setState(() => _kvkkOnay = değer!),
                    ),
                    Expanded(
                      child: GestureDetector(
                        onTap: _kvkkMetniniGoster,
                        child: const Text(
                          'Kişisel verilerimin işlenmesine ilişkin KVKK Aydınlatma Metni\'ni okudum ve onaylıyorum.',
                          style: TextStyle(fontSize: 14, color: Colors.teal, fontWeight: FontWeight.bold, decoration: TextDecoration.underline),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: _kvkkOnay ? _profiliKaydet : null,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.teal,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: const Text('KAYDET VE BAŞLA', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
