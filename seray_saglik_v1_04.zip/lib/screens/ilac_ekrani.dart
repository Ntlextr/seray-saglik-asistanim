import 'package:flutter/material.dart';
import '../services/veritabani_yardimcisi.dart';

class IlacEkrani extends StatefulWidget {
  const IlacEkrani({Key? key}) : super(key: key);

  @override
  _IlacEkraniState createState() => _IlacEkraniState();
}

class _IlacEkraniState extends State<IlacEkrani> {
  List<Map<String, dynamic>> _ilacListesi = [];
  final _adController = TextEditingController();
  final _dozController = TextEditingController();
  TimeOfDay _secilenSaat = const TimeOfDay(hour: 09, minute: 00);

  @override
  void initState() {
    super.initState();
    _ilaclariYukle();
  }

  Future<void> _ilaclariYukle() async {
    final veriler = await VeritabaniYardimcisi().ilaclariGetir();
    setState(() {
      _ilacListesi = veriler;
    });
  }

  Future<void> _ilacEkleDialog() async {
    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('Yeni İlaç Ekle'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: _adController, decoration: const InputDecoration(labelText: 'İlaç Adı (Örn: Sanjardy)')),
                TextField(controller: _dozController, decoration: const InputDecoration(labelText: 'Dozaj (Örn: 1 Adet, 1 Ölçek)')),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.between,
                  children: [
                    Text('Saat: ${_secilenSaat.format(context)}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    ElevatedButton(
                      onPressed: () async {
                        final TimeOfDay? time = await showTimePicker(context: context, initialTime: _secilenSaat);
                        if (time != null) setDialogState(() => _secilenSaat = time);
                      },
                      child: const Text('Saat Seç'),
                    ),
                  ],
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('İptal')),
            TextButton(
              onPressed: () async {
                if (_adController.text.isNotEmpty) {
                  await VeritabaniYardimcisi().ilacEkle({
                    'ad': _adController.text.trim(),
                    'dozaj': _dozController.text.trim(),
                    'saat': _secilenSaat.format(context),
                  });
                  _adController.clear();
                  _dozController.clear();
                  Navigator.pop(context);
                  _ilaclariYukle();
                }
              },
              child: const Text('Ekle', style: TextStyle(fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('İlaç Takibi'), backgroundColor: Colors.teal, foregroundColor: Colors.white),
      body: _ilacListesi.isEmpty
          ? const Center(child: Text('Henüz ilaç eklemediniz.', style: TextStyle(fontSize: 18, color: Colors.black54)))
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _ilacListesi.length,
              itemBuilder: (context, index) {
                final ilac = _ilacListesi[index];
                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  child: ListTile(
                    leading: const Icon(Icons.medication, color: Colors.teal, size: 36),
                    title: Text(ilac['ad'].toString(), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                    subtitle: Text('Doz: ${ilac['dozaj']} | Saat: ${ilac['saat']}', style: const TextStyle(fontSize: 16)),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline, color: Colors.red),
                      onPressed: () async {
                        await VeritabaniYardimcisi().ilacSil(int.parse(ilac['id'].toString()));
                        _ilaclariYukle();
                      },
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _ilacEkleDialog,
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add),
        label: const Text('İlaç Ekle', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      ),
    );
  }
}
