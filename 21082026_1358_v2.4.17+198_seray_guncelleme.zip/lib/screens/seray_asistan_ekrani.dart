import 'dart:convert';
import 'dart:io';
import '../theme/renkler.dart';
import '../theme/sablon.dart';
import '../widgets/ust_menu.dart';
import '../services/dil_servisi.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:permission_handler/permission_handler.dart';
import 'package:share_plus/share_plus.dart';
import '../services/api_service.dart';
import '../services/veritabani_yardimcisi.dart';
import '../services/ses_servisi.dart';
import '../services/pdf_rapor_servisi.dart';
import '../services/profil_yoneticisi.dart';

class SerayAsistanEkrani extends StatefulWidget {
  const SerayAsistanEkrani({Key? key}) : super(key: key);
  @override
  State<SerayAsistanEkrani> createState() => _SerayAsistanEkraniState();
}

class _SerayAsistanEkraniState extends State<SerayAsistanEkrani> {
  final TextEditingController _mesajController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  // Her mesaj: {'rol': 'kullanici' | 'seray', 'metin': '...'}
  final List<Map<String, String>> _mesajlar = [];
  bool _yanitBekleniyor = false;
  bool _ttsCalisiyor = false;
  int? _ttsIndex; // Hangi mesajın TTS'i çalıyor
  int? _oturumId; // Şu an kayıtlı olan sohbet oturumunun veritabanı id'si
  File? _secilenGorsel; // Ataç ile eklenen, henüz gönderilmemiş fotoğraf

  // --- Mikrofonla konuşarak yazma (STT) ---
  final stt.SpeechToText _sesTanima = stt.SpeechToText();
  bool _sesTanimaHazir = false;
  bool _dinleniyor = false;

  List<String> get _hizliSorular => [
    DilServisi.metin('hizliSoru1'),
    DilServisi.metin('hizliSoru2'),
    DilServisi.metin('hizliSoru3'),
    DilServisi.metin('hizliSoru4'),
    DilServisi.metin('hizliSoru5'),
    DilServisi.metin('hizliSoru6'),
  ];

  @override
  void initState() {
    super.initState();
    _yeniSohbetBaslat(kaydetmedenTemizle: true);
    _sesTanimayiHazirla();
  }  // --- initState() sonu ---

  Future<void> _sesTanimayiHazirla() async {
    final hazir = await _sesTanima.initialize(
      onError: (hata) {
        if (mounted) setState(() => _dinleniyor = false);
      },
      onStatus: (durum) {
        if (durum == 'notListening' && mounted) setState(() => _dinleniyor = false);
      },
    );
    if (mounted) setState(() => _sesTanimaHazir = hazir);
  }  // --- _sesTanimayiHazirla() sonu ---

  Future<void> _mikrofonuBaslatVeyaDurdur() async {
    if (_dinleniyor) {
      await _sesTanima.stop();
      if (mounted) setState(() => _dinleniyor = false);
      return;
    }

    final izin = await Permission.microphone.request();
    if (!izin.isGranted) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(DilServisi.metin('mikrofonIzniGerekli'))),
        );
      }
      return;
    }

    if (!_sesTanimaHazir) {
      await _sesTanimayiHazirla();
      if (!_sesTanimaHazir) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(DilServisi.metin('sesTanimaYok'))),
          );
        }
        return;
      }
    }

    setState(() => _dinleniyor = true);
    await _sesTanima.listen(
      localeId: 'tr_TR',
      onResult: (sonuc) {
        setState(() {
          _mesajController.text = sonuc.recognizedWords;
          _mesajController.selection = TextSelection.fromPosition(
            TextPosition(offset: _mesajController.text.length),
          );
        });
        // Kullanıcı konuşmayı bitirip son (kesin) sonuç geldiğinde otomatik gönder
        if (sonuc.finalResult && sonuc.recognizedWords.trim().isNotEmpty) {
          setState(() => _dinleniyor = false);
          _mesajGonder(sonuc.recognizedWords);
        }
      },
    );
  }  // --- _mikrofonuBaslatVeyaDurdur() sonu ---

  // Ataç ikonu: kamera, galeri VEYA dosyalardan (Files) fotoğraf seçtirir
  // (nabız ölçümünde zaten kullanılan izin/akışla aynı mantık). "Dosyalardan
  // Seç" özellikle galeri dışında (WhatsApp/İndirilenler/vb. klasörlerde)
  // duran görselleri seçebilmek için eklendi — kullanıcı sadece Kamera/
  // Galeri olduğunu, dosya seçeneğinin eksik olduğunu fark etti.
  Future<void> _gorselEkle() async {
    final secim = await showModalBottomSheet<String>(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (context) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: Icon(Icons.photo_camera, color: AppRenkleri.aktif),
              title: Text(DilServisi.metin('kameraylaCek')),
              onTap: () => Navigator.pop(context, 'camera'),
            ),
            ListTile(
              leading: Icon(Icons.photo_library, color: AppRenkleri.aktif),
              title: Text(DilServisi.metin('galeridenSec')),
              onTap: () => Navigator.pop(context, 'gallery'),
            ),
            ListTile(
              leading: Icon(Icons.folder_open, color: AppRenkleri.aktif),
              title: Text(DilServisi.metin('dosyalardanSec')),
              onTap: () => Navigator.pop(context, 'file'),
            ),
          ],
        ),
      ),
    );
    if (secim == null) return;

    if (secim == 'file') {
      final sonuc = await FilePicker.platform.pickFiles(type: FileType.image);
      final yol = sonuc?.files.single.path;
      if (yol != null && mounted) {
        setState(() => _secilenGorsel = File(yol));
      }
      return;
    }

    final kaynak = secim == 'camera' ? ImageSource.camera : ImageSource.gallery;
    if (kaynak == ImageSource.camera) {
      final izin = await Permission.camera.request();
      if (!izin.isGranted) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(DilServisi.metin('kameraIzniGerekli'))),
          );
        }
        return;
      }
    }

    final XFile? secilen = await ImagePicker().pickImage(source: kaynak, imageQuality: 70);
    if (secilen != null && mounted) {
      setState(() => _secilenGorsel = File(secilen.path));
    }
  }  // --- _gorselEkle() sonu ---

  void _yeniSohbetBaslat({bool kaydetmedenTemizle = false}) {
    setState(() {
      _mesajlar.clear();
      _oturumId = null;
      _mesajlar.add({
        'rol': 'seray',
        'metin': DilServisi.metin('serayKarsilamaMesaji'),
      });
    });
  }

  @override
  void dispose() {
    _mesajController.dispose();
    _scrollController.dispose();
    SesServisi.durdur();
    _sesTanima.stop();
    super.dispose();
  }  // --- dispose() sonu ---

  Future<void> _mesajGonder(String metin) async {
    final temizMetin = metin.trim();
    if (temizMetin.isEmpty && _secilenGorsel == null) return;
    if (_yanitBekleniyor) return;
    final gonderilecekGorsel = _secilenGorsel;
    _mesajController.clear();
    setState(() => _secilenGorsel = null);

    final gosterilecekMetin = temizMetin.isEmpty ? '📎 Fotoğraf gönderildi' : temizMetin;
    setState(() {
      _mesajlar.add({'rol': 'kullanici', 'metin': gosterilecekMetin});
      _yanitBekleniyor = true;
    });
    _sayfaSonunaKaydir();

    // Geçmiş sohbeti hazırla (karşılama hariç)
    final gecmis = _mesajlar
        .skip(1) // Karşılama mesajını atla
        .where((m) => m['metin'] != gosterilecekMetin) // Yeni mesajı dahil etme (API zaten ekleyecek)
        .toList();

    String yanit;
    try {
      yanit = await ApiService.serayileSohbet(
        kullaniciMesaji: temizMetin,
        sohbetGecmisi: gecmis,
        gorsel: gonderilecekGorsel,
      );
    } catch (e) {
      // ÖNEMLİ: Bir hata olsa bile buraya düşüp devam ediyoruz. Eskiden
      // burada bir hata fırlarsa _yanitBekleniyor hiç sıfırlanmıyordu ve
      // o andan sonra hiçbir mesaj (yazılan da, hazır sorular da) cevap
      // alamıyordu — sohbet sessizce kilitleniyordu.
      yanit = 'Bir sorun oluştu, lütfen tekrar deneyin: $e';
    }

    setState(() {
      _mesajlar.add({'rol': 'seray', 'metin': yanit});
      _yanitBekleniyor = false;
    });
    _sayfaSonunaKaydir();
    await _oturumuKaydet();
  }  // --- _mesajGonder() sonu ---

  // Sohbeti veritabanına kaydeder (ilk gerçek mesajda yeni kayıt açar,
  // sonraki mesajlarda aynı kaydı günceller — böylece geçmişte görünür).
  Future<void> _oturumuKaydet() async {
    if (_mesajlar.length <= 1) return; // Sadece karşılama mesajı varsa kaydetme
    final ilkKullaniciMesaji = _mesajlar.firstWhere(
      (m) => m['rol'] == 'kullanici',
      orElse: () => {'metin': 'Sohbet'},
    )['metin']!;
    final baslik = ilkKullaniciMesaji.length > 40 ? '${ilkKullaniciMesaji.substring(0, 40)}...' : ilkKullaniciMesaji;
    final json = jsonEncode(_mesajlar);

    if (_oturumId == null) {
      final yeniId = await VeritabaniYardimcisi().sohbetOturumuKaydet(baslik: baslik, mesajlarJson: json);
      if (mounted) setState(() => _oturumId = yeniId);
    } else {
      await VeritabaniYardimcisi().sohbetOturumuGuncelle(_oturumId!, json);
    }
  }  // --- _oturumuKaydet() sonu ---

  Future<void> _gecmisSohbetleriGoster() async {
    final oturumlar = await VeritabaniYardimcisi().sohbetOturumlariniGetir();
    if (!mounted) return;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.6,
        maxChildSize: 0.9,
        expand: false,
        builder: (context, scrollController) => Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Expanded(child: Text(DilServisi.metin('gecmisSohbetler'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16))),
                  TextButton.icon(
                    onPressed: () {
                      Navigator.pop(context);
                      _yeniSohbetBaslat();
                    },
                    icon: const Icon(Icons.add, size: 18),
                    label: Text(DilServisi.metin('yeniSohbet')),
                  ),
                ],
              ),
            ),
            Expanded(
              child: oturumlar.isEmpty
                  ? Center(child: Text(DilServisi.metin('kayitliSohbetYok'), style: const TextStyle(color: Colors.grey)))
                  : ListView.builder(
                      controller: scrollController,
                      itemCount: oturumlar.length,
                      itemBuilder: (context, index) {
                        final oturum = oturumlar[index];
                        return ListTile(
                          leading: Icon(Icons.chat_bubble_outline, color: AppRenkleri.aktif),
                          title: Text(oturum['baslik']?.toString() ?? 'Sohbet', maxLines: 1, overflow: TextOverflow.ellipsis),
                          subtitle: Text(_tarihiKisaGoster(oturum['tarih']?.toString())),
                          trailing: IconButton(
                            icon: const Icon(Icons.delete_outline, color: Colors.red, size: 20),
                            onPressed: () async {
                              await VeritabaniYardimcisi().sohbetOturumuSil(oturum['id'] as int);
                              if (context.mounted) Navigator.pop(context);
                              _gecmisSohbetleriGoster();
                            },
                          ),
                          onTap: () {
                            final List<dynamic> kayitliMesajlar = jsonDecode(oturum['mesajlar_json'].toString());
                            setState(() {
                              _mesajlar
                                ..clear()
                                ..addAll(kayitliMesajlar.map((m) => Map<String, String>.from(m)));
                              _oturumId = oturum['id'] as int;
                            });
                            Navigator.pop(context);
                            _sayfaSonunaKaydir();
                          },
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }  // --- _gecmisSohbetleriGoster() sonu ---

  String _tarihiKisaGoster(String? isoTarih) {
    if (isoTarih == null) return '';
    final t = DateTime.tryParse(isoTarih);
    if (t == null) return '';
    String iki(int n) => n.toString().padLeft(2, '0');
    return '${iki(t.day)}.${iki(t.month)}.${t.year} ${iki(t.hour)}:${iki(t.minute)}';
  }  // --- _tarihiKisaGoster() sonu ---

  void _sayfaSonunaKaydir() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }  // --- _sayfaSonunaKaydir() sonu ---

  Future<void> _ttsSeslendir(int index, String metin) async {
    if (_ttsCalisiyor && _ttsIndex == index) {
      await SesServisi.durdur();
      setState(() { _ttsCalisiyor = false; _ttsIndex = null; });
      return;
    }
    String temiz = metin
        .replaceAll(RegExp(r'\([^)]*\)'), '')
        .replaceAll(RegExp(r'[*#_~`]'), '')
        .replaceAll(RegExp(r'^\s*[-•]\s*', multiLine: true), '')
        .replaceAll('\n\n', '. ')
        .replaceAll('\n', ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
    setState(() { _ttsCalisiyor = true; _ttsIndex = index; });
    await SesServisi.konus(temiz, onTamamlandi: () {
      if (mounted) setState(() { _ttsCalisiyor = false; _ttsIndex = null; });
    });
  }  // --- _ttsSeslendir() sonu ---

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(
        shape: AppSablon.appBarSekli,
        clipBehavior: Clip.antiAlias,
        title: Row(
          children: [
            CircleAvatar(
              radius: 16,
              backgroundColor: AppRenkleri.aktif.shade100,
              child: Icon(Icons.health_and_safety, color: AppRenkleri.aktif, size: 18),
            ),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Seray', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                Text(DilServisi.metin('serayAltBaslik'), style: const TextStyle(fontSize: 11, fontWeight: FontWeight.normal)),
              ],
            ),
          ],
        ),
        backgroundColor: AppRenkleri.aktif,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.history),
            tooltip: DilServisi.metin('gecmisSohbetler'),
            onPressed: _gecmisSohbetleriGoster,
          ),
          IconButton(
            icon: const Icon(Icons.add_comment_outlined),
            tooltip: DilServisi.metin('yeniSohbet'),
            onPressed: _yeniSohbetBaslat,
          ),
          const UstMenu(),
        ],
      ),
      body: Column(
        children: [
          // UYARI BANTI
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            color: Colors.amber.shade50,
            child: Row(
              children: [
                Icon(Icons.info_outline, size: 16, color: Colors.amber.shade800),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    DilServisi.metin('serayUyariBanner'),
                    style: TextStyle(fontSize: 11, color: Colors.amber.shade900),
                  ),
                ),
              ],
            ),
          ),
          // MESAJLAR
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.all(12),
              itemCount: _mesajlar.length + (_yanitBekleniyor ? 1 : 0),
              itemBuilder: (context, index) {
                if (index == _mesajlar.length && _yanitBekleniyor) {
                  return _yaziyorGostergesi();
                }
                final mesaj = _mesajlar[index];
                final kullanicimi = mesaj['rol'] == 'kullanici';
                return _mesajBaloncugu(
                  index: index,
                  metin: mesaj['metin'] ?? '',
                  kullanicimi: kullanicimi,
                );
              },
            ),
          ),
          // HIZLI SORULAR
          if (_mesajlar.length <= 1)
            SizedBox(
              height: 44,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                itemCount: _hizliSorular.length,
                itemBuilder: (context, index) => Padding(
                  padding: const EdgeInsets.only(right: 6),
                  child: ActionChip(
                    label: Text(_hizliSorular[index], style: const TextStyle(fontSize: 11)),
                    backgroundColor: AppRenkleri.aktif.shade50,
                    side: BorderSide(color: AppRenkleri.aktif.shade200),
                    onPressed: () => _mesajGonder(_hizliSorular[index]),
                  ),
                ),
              ),
            ),
          // MESAJ GİRİŞ ALANI
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 4, offset: const Offset(0, -1))],
            ),
            padding: EdgeInsets.only(
              left: 12, right: 8, top: 8,
              bottom: MediaQuery.of(context).viewInsets.bottom + 8,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Ataç ile seçilen, henüz gönderilmemiş fotoğrafın önizlemesi
                if (_secilenGorsel != null)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Row(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.file(_secilenGorsel!, width: 48, height: 48, fit: BoxFit.cover),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(DilServisi.metin('fotografEklendi'), style: const TextStyle(fontSize: 12, color: Colors.grey)),
                        ),
                        IconButton(
                          icon: const Icon(Icons.close, size: 18),
                          onPressed: () => setState(() => _secilenGorsel = null),
                        ),
                      ],
                    ),
                  ),
                Row(
                  children: [
                    // Ataç: fotoğraf ekleyip Seray'a gösterme (yemek, tahlil kağıdı, ilaç kutusu vb.)
                    Material(
                      color: Colors.grey.shade200,
                      borderRadius: BorderRadius.circular(22),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(22),
                        onTap: _yanitBekleniyor ? null : _gorselEkle,
                        child: Padding(
                          padding: const EdgeInsets.all(10),
                          child: Icon(Icons.attach_file, color: Colors.grey.shade700, size: 22),
                        ),
                      ),
                    ),
                    const SizedBox(width: 6),
                    Expanded(
                      child: TextField(
                        controller: _mesajController,
                        maxLines: 3,
                        minLines: 1,
                        textInputAction: TextInputAction.newline,
                        decoration: InputDecoration(
                          hintText: _dinleniyor ? DilServisi.metin('dinliyorum') : DilServisi.metin('sorunuzuYazin'),
                          hintStyle: const TextStyle(fontSize: 14),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(22),
                            borderSide: BorderSide(color: Colors.grey.shade300),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(22),
                            borderSide: BorderSide(color: AppRenkleri.aktif),
                          ),
                          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                          isDense: true,
                        ),
                      ),
                    ),
                    const SizedBox(width: 6),
                    // Mikrofon: konuşarak soru sorma (STT) — TTS'in tersi
                    Material(
                      color: _dinleniyor ? Colors.red.shade400 : Colors.grey.shade200,
                      borderRadius: BorderRadius.circular(22),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(22),
                        onTap: _yanitBekleniyor ? null : _mikrofonuBaslatVeyaDurdur,
                        child: Padding(
                          padding: const EdgeInsets.all(10),
                          child: Icon(
                            _dinleniyor ? Icons.mic : Icons.mic_none,
                            color: _dinleniyor ? Colors.white : Colors.grey.shade700,
                            size: 22,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 6),
                    Material(
                      color: AppRenkleri.aktif,
                      borderRadius: BorderRadius.circular(22),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(22),
                        onTap: _yanitBekleniyor ? null : () => _mesajGonder(_mesajController.text),
                        child: const Padding(
                          padding: EdgeInsets.all(10),
                          child: Icon(Icons.send_rounded, color: Colors.white, size: 22),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }  // --- build() sonu ---

  Widget _mesajBaloncugu({required int index, required String metin, required bool kullanicimi}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: kullanicimi ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (!kullanicimi) ...[
            CircleAvatar(
              radius: 14,
              backgroundColor: AppRenkleri.aktif.shade100,
              child: Icon(Icons.health_and_safety, color: AppRenkleri.aktif, size: 14),
            ),
            const SizedBox(width: 6),
          ],
          Flexible(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: kullanicimi ? AppRenkleri.aktif : Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(16),
                  topRight: const Radius.circular(16),
                  bottomLeft: kullanicimi ? const Radius.circular(16) : Radius.zero,
                  bottomRight: kullanicimi ? Radius.zero : const Radius.circular(16),
                ),
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 3, offset: const Offset(0, 1))],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SelectableText(
                    metin,
                    style: TextStyle(
                      color: kullanicimi ? Colors.white : Colors.black87,
                      fontSize: 14,
                      height: 1.4,
                    ),
                  ),
                  if (!kullanicimi) ...[
                    const SizedBox(height: 4),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        GestureDetector(
                          onTap: () => _ttsSeslendir(index, metin),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                (_ttsCalisiyor && _ttsIndex == index)
                                    ? Icons.stop_circle_outlined
                                    : Icons.volume_up_outlined,
                                size: 20,
                                color: AppRenkleri.aktif.shade400,
                              ),
                              const SizedBox(width: 3),
                              Text(
                                (_ttsCalisiyor && _ttsIndex == index) ? 'Durdur' : 'Sesli Dinle',
                                style: TextStyle(fontSize: 11, color: AppRenkleri.aktif.shade400),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 14),
                        // Paylaş: cevabı WhatsApp/e-posta/yazıcı gibi diğer
                        // uygulamalara gönderir — metni elle seçip kopyalamaya
                        // gerek kalmadan (örn. bir tedavi/plan cevabını
                        // saklamak veya birine iletmek isteyenler için).
                        GestureDetector(
                          onTap: () async {
                            final markali = await PdfRaporServisi.metneMarkaEkle(metin);
                            Share.share(markali, subject: 'Seray AI Cevabı');
                          },
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.share_outlined, size: 14, color: AppRenkleri.aktif.shade400),
                              const SizedBox(width: 3),
                              Text(DilServisi.metin('paylas'), style: TextStyle(fontSize: 11, color: AppRenkleri.aktif.shade400)),
                            ],
                          ),
                        ),
                        const SizedBox(width: 14),
                        // ÖNEMLİ: Kullanıcı istedi — uygulamadaki HER AI
                        // çıktısında Sesli+Print+Paylaş üçlüsü birlikte
                        // bulunsun. Seray AI'de önceden sadece ikisi vardı.
                        GestureDetector(
                          onTap: () async {
                            try {
                              final ad = (await ProfilYoneticisi().aktifProfil()).ad;
                              await PdfRaporServisi.analizRaporuYazdir(
                                kullaniciAdi: ad,
                                baslik: 'Seray AI Cevabı',
                                analizMetni: metin,
                              );
                            } catch (_) {
                              // Sessizce geç — kullanıcı tekrar deneyebilir.
                            }
                          },
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.print_outlined, size: 14, color: AppRenkleri.aktif.shade400),
                              const SizedBox(width: 3),
                              Text(DilServisi.metin('yazdir'), style: TextStyle(fontSize: 11, color: AppRenkleri.aktif.shade400)),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            ),
          ),
          if (kullanicimi) const SizedBox(width: 6),
        ],
      ),
    );
  }

  Widget _yaziyorGostergesi() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          CircleAvatar(
            radius: 14,
            backgroundColor: AppRenkleri.aktif.shade100,
            child: Icon(Icons.health_and_safety, color: AppRenkleri.aktif, size: 14),
          ),
          const SizedBox(width: 6),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(16), topRight: Radius.circular(16),
                bottomRight: Radius.circular(16),
              ),
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 3)],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                _noktaCizici(0),
                _noktaCizici(150),
                _noktaCizici(300),
              ],
            ),
          ),
        ],
      ),
    );
  }  // --- _yaziyorGostergesi() sonu ---

  Widget _noktaCizici(int gecikmems) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.0, end: 1.0),
      duration: Duration(milliseconds: 600 + gecikmems),
      builder: (context, value, _) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 3),
          child: Container(
            width: 7, height: 7,
            decoration: BoxDecoration(
              color: AppRenkleri.aktif.withOpacity(0.4 + 0.6 * value),
              shape: BoxShape.circle,
            ),
          ),
        );
      },
    );
  }  // --- _noktaCizici() sonu ---
}
