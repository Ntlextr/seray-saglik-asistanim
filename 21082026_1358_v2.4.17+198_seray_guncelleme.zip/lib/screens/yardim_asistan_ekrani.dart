import '../theme/renkler.dart';
import '../theme/sablon.dart';
import '../widgets/ust_menu.dart';
import '../services/dil_servisi.dart';
import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:permission_handler/permission_handler.dart';
import 'package:share_plus/share_plus.dart';
import '../services/api_service.dart';
import '../services/ses_servisi.dart';
import '../services/pdf_rapor_servisi.dart';
import '../services/profil_yoneticisi.dart';

// Uygulama kullanımı hakkında soru-cevap: Seray AI'dan (sağlık sohbeti)
// tamamen ayrı, kendi ekranı. Basit tutuldu — geçmiş sohbet kaydı YOK
// (her açılışta sıfırdan başlar), fotoğraf ekleme YOK. Mikrofon, yaşlı/
// az deneyimli kullanıcılar için erişilebilirlik amacıyla korundu.
class YardimAsistanEkrani extends StatefulWidget {
  const YardimAsistanEkrani({Key? key}) : super(key: key);
  @override
  State<YardimAsistanEkrani> createState() => _YardimAsistanEkraniState();
}

class _YardimAsistanEkraniState extends State<YardimAsistanEkrani> {
  final TextEditingController _mesajController = TextEditingController();
  bool _ttsCalisiyor = false;
  int? _ttsIndex;
  final ScrollController _scrollController = ScrollController();

  // Her mesaj: {'rol': 'kullanici' | 'yardimci', 'metin': '...'}
  final List<Map<String, String>> _mesajlar = [];
  bool _yanitBekleniyor = false;

  final stt.SpeechToText _sesTanima = stt.SpeechToText();
  bool _sesTanimaHazir = false;
  bool _dinleniyor = false;

  List<String> get _hizliSorular => [
    DilServisi.metin('yardimSoru1'),
    DilServisi.metin('yardimSoru2'),
    DilServisi.metin('yardimSoru3'),
    DilServisi.metin('yardimSoru4'),
    DilServisi.metin('yardimSoru5'),
    DilServisi.metin('yardimSoru6'),
  ];

  @override
  void initState() {
    super.initState();
    _mesajlar.add({
      'rol': 'yardimci',
      'metin': DilServisi.metin('yardimKarsilamaMesaji'),
    });
    _sesTanimayiHazirla();
  }  // --- initState() sonu ---

  Future<void> _sesTanimayiHazirla() async {
    final hazir = await _sesTanima.initialize(
      onError: (hata) {
        if (mounted) setState(() => _dinleniyor = false);
      },
      onStatus: (durum) {
        if (durum == 'notListening' && mounted) setState(() => _dinleniyor = false);
      },
    );
    if (mounted) setState(() => _sesTanimaHazir = hazir);
  }  // --- _sesTanimayiHazirla() sonu ---

  Future<void> _mikrofonuBaslatVeyaDurdur() async {
    if (_dinleniyor) {
      await _sesTanima.stop();
      if (mounted) setState(() => _dinleniyor = false);
      return;
    }

    final izin = await Permission.microphone.request();
    if (!izin.isGranted) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(DilServisi.metin('mikrofonIzniGerekli'))),
        );
      }
      return;
    }

    if (!_sesTanimaHazir) {
      await _sesTanimayiHazirla();
      if (!_sesTanimaHazir) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(DilServisi.metin('sesTanimaYok'))),
          );
        }
        return;
      }
    }

    setState(() => _dinleniyor = true);
    await _sesTanima.listen(
      localeId: 'tr_TR',
      onResult: (sonuc) {
        setState(() {
          _mesajController.text = sonuc.recognizedWords;
          _mesajController.selection = TextSelection.fromPosition(
            TextPosition(offset: _mesajController.text.length),
          );
        });
        if (sonuc.finalResult && sonuc.recognizedWords.trim().isNotEmpty) {
          setState(() => _dinleniyor = false);
          _mesajGonder(sonuc.recognizedWords);
        }
      },
    );
  }  // --- _mikrofonuBaslatVeyaDurdur() sonu ---

  @override
  void dispose() {
    _mesajController.dispose();
    _scrollController.dispose();
    SesServisi.durdur();
    _sesTanima.stop();
    super.dispose();
  }  // --- dispose() sonu ---

  Future<void> _mesajGonder(String metin) async {
    final temizMetin = metin.trim();
    if (temizMetin.isEmpty) return;
    if (_yanitBekleniyor) return;
    _mesajController.clear();

    setState(() {
      _mesajlar.add({'rol': 'kullanici', 'metin': temizMetin});
      _yanitBekleniyor = true;
    });
    _sayfaSonunaKaydir();

    final gecmis = _mesajlar
        .skip(1) // Karşılama mesajını atla
        .where((m) => m['metin'] != temizMetin)
        .toList();

    String yanit;
    try {
      yanit = await ApiService.uygulamaYardimSohbeti(
        kullaniciMesaji: temizMetin,
        sohbetGecmisi: gecmis,
      );
    } catch (e) {
      yanit = 'Bir sorun oluştu, lütfen tekrar deneyin: $e';
    }

    setState(() {
      _mesajlar.add({'rol': 'yardimci', 'metin': yanit});
      _yanitBekleniyor = false;
    });
    _sayfaSonunaKaydir();
  }  // --- _mesajGonder() sonu ---

  void _sayfaSonunaKaydir() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }  // --- _sayfaSonunaKaydir() sonu ---

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(
        shape: AppSablon.appBarSekli,
        clipBehavior: Clip.antiAlias,
        title: Row(
          children: [
            CircleAvatar(
              radius: 16,
              backgroundColor: AppRenkleri.aktif.shade100,
              child: Icon(Icons.support_agent, color: AppRenkleri.aktif, size: 18),
            ),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(DilServisi.metin('yardimAsistaniBaslik'), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                Text(DilServisi.metin('yardimAsistaniAltBaslik'), style: const TextStyle(fontSize: 11, fontWeight: FontWeight.normal)),
              ],
            ),
          ],
        ),
        backgroundColor: AppRenkleri.aktif,
        foregroundColor: Colors.white,
        actions: const [UstMenu()],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.all(12),
              itemCount: _mesajlar.length + (_yanitBekleniyor ? 1 : 0),
              itemBuilder: (context, index) {
                if (index == _mesajlar.length && _yanitBekleniyor) {
                  return _yaziyorGostergesi();
                }
                final mesaj = _mesajlar[index];
                final kullanicimi = mesaj['rol'] == 'kullanici';
                return _mesajBaloncugu(index: index, metin: mesaj['metin'] ?? '', kullanicimi: kullanicimi);
              },
            ),
          ),
          if (_mesajlar.length <= 1)
            SizedBox(
              height: 44,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                itemCount: _hizliSorular.length,
                itemBuilder: (context, index) => Padding(
                  padding: const EdgeInsets.only(right: 6),
                  child: ActionChip(
                    label: Text(_hizliSorular[index], style: const TextStyle(fontSize: 11)),
                    backgroundColor: AppRenkleri.aktif.shade50,
                    side: BorderSide(color: AppRenkleri.aktif.shade200),
                    onPressed: () => _mesajGonder(_hizliSorular[index]),
                  ),
                ),
              ),
            ),
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 4, offset: const Offset(0, -1))],
            ),
            padding: EdgeInsets.only(
              left: 12, right: 8, top: 8,
              bottom: MediaQuery.of(context).viewInsets.bottom + 8,
            ),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _mesajController,
                    maxLines: 3,
                    minLines: 1,
                    textInputAction: TextInputAction.newline,
                    decoration: InputDecoration(
                      hintText: _dinleniyor ? DilServisi.metin('dinliyorum') : DilServisi.metin('sorunuzuYazin'),
                      hintStyle: const TextStyle(fontSize: 14),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(22),
                        borderSide: BorderSide(color: Colors.grey.shade300),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(22),
                        borderSide: BorderSide(color: AppRenkleri.aktif),
                      ),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                      isDense: true,
                    ),
                  ),
                ),
                const SizedBox(width: 6),
                Material(
                  color: _dinleniyor ? Colors.red.shade400 : Colors.grey.shade200,
                  borderRadius: BorderRadius.circular(22),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(22),
                    onTap: _yanitBekleniyor ? null : _mikrofonuBaslatVeyaDurdur,
                    child: Padding(
                      padding: const EdgeInsets.all(10),
                      child: Icon(
                        _dinleniyor ? Icons.mic : Icons.mic_none,
                        color: _dinleniyor ? Colors.white : Colors.grey.shade700,
                        size: 22,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 6),
                Material(
                  color: AppRenkleri.aktif,
                  borderRadius: BorderRadius.circular(22),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(22),
                    onTap: _yanitBekleniyor ? null : () => _mesajGonder(_mesajController.text),
                    child: const Padding(
                      padding: EdgeInsets.all(10),
                      child: Icon(Icons.send_rounded, color: Colors.white, size: 22),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }  // --- build() sonu ---

  Future<void> _ttsSeslendir(int index, String metin) async {
    if (_ttsCalisiyor && _ttsIndex == index) {
      await SesServisi.durdur();
      setState(() { _ttsCalisiyor = false; _ttsIndex = null; });
      return;
    }
    String temiz = metin
        .replaceAll(RegExp(r'\([^)]*\)'), '')
        .replaceAll(RegExp(r'[*#_~`]'), '')
        .replaceAll(RegExp(r'^\s*[-•]\s*', multiLine: true), '')
        .replaceAll('\n\n', '. ')
        .replaceAll('\n', ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
    setState(() { _ttsCalisiyor = true; _ttsIndex = index; });
    await SesServisi.konus(temiz, onTamamlandi: () {
      if (mounted) setState(() { _ttsCalisiyor = false; _ttsIndex = null; });
    });
  }  // --- _ttsSeslendir() sonu ---

  Widget _mesajBaloncugu({required int index, required String metin, required bool kullanicimi}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: kullanicimi ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (!kullanicimi) ...[
            CircleAvatar(
              radius: 14,
              backgroundColor: AppRenkleri.aktif.shade100,
              child: Icon(Icons.support_agent, color: AppRenkleri.aktif, size: 14),
            ),
            const SizedBox(width: 6),
          ],
          Flexible(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: kullanicimi ? AppRenkleri.aktif : Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(16),
                  topRight: const Radius.circular(16),
                  bottomLeft: kullanicimi ? const Radius.circular(16) : Radius.zero,
                  bottomRight: kullanicimi ? Radius.zero : const Radius.circular(16),
                ),
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 3, offset: const Offset(0, 1))],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SelectableText(
                    metin,
                    style: TextStyle(
                      color: kullanicimi ? Colors.white : Colors.black87,
                      fontSize: 14,
                      height: 1.4,
                    ),
                  ),
                  // ÖNEMLİ: Kullanıcı fark etti — Seray AI sohbetinde var olan
                  // Sesli Dinle + Paylaş, Yardım Asistanı'nda hiç yoktu.
                  // Aynı desen buraya da eklendi.
                  if (!kullanicimi) ...[
                    const SizedBox(height: 4),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        GestureDetector(
                          onTap: () => _ttsSeslendir(index, metin),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                (_ttsCalisiyor && _ttsIndex == index) ? Icons.stop_circle_outlined : Icons.volume_up_outlined,
                                size: 20,
                                color: AppRenkleri.aktif.shade400,
                              ),
                              const SizedBox(width: 3),
                              Text(
                                (_ttsCalisiyor && _ttsIndex == index) ? 'Durdur' : 'Sesli Dinle',
                                style: TextStyle(fontSize: 11, color: AppRenkleri.aktif.shade400),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 14),
                        GestureDetector(
                          onTap: () async {
                            final markali = await PdfRaporServisi.metneMarkaEkle(metin);
                            Share.share(markali, subject: 'Yardım Asistanı Cevabı');
                          },
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.share_outlined, size: 14, color: AppRenkleri.aktif.shade400),
                              const SizedBox(width: 3),
                              Text(DilServisi.metin('paylas'), style: TextStyle(fontSize: 11, color: AppRenkleri.aktif.shade400)),
                            ],
                          ),
                        ),
                        const SizedBox(width: 14),
                        // ÖNEMLİ: Önceden bu buton sadece "Paylaş" yapıyordu,
                        // ismi "Yazdır / Paylaş" olsa da gerçek bir PDF/yazdırma
                        // yoktu. Şimdi ayrı, GERÇEK bir Yazdır butonu var.
                        GestureDetector(
                          onTap: () async {
                            try {
                              final ad = (await ProfilYoneticisi().aktifProfil()).ad;
                              await PdfRaporServisi.analizRaporuYazdir(
                                kullaniciAdi: ad,
                                baslik: 'Yardım Asistanı Cevabı',
                                analizMetni: metin,
                              );
                            } catch (_) {
                              // Sessizce geç — kullanıcı tekrar deneyebilir.
                            }
                          },
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.print_outlined, size: 14, color: AppRenkleri.aktif.shade400),
                              const SizedBox(width: 3),
                              Text(DilServisi.metin('yazdir'), style: TextStyle(fontSize: 11, color: AppRenkleri.aktif.shade400)),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            ),
          ),
          if (kullanicimi) const SizedBox(width: 6),
        ],
      ),
    );
  }  // --- _mesajBaloncugu() sonu ---

  Widget _yaziyorGostergesi() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          CircleAvatar(
            radius: 14,
            backgroundColor: AppRenkleri.aktif.shade100,
            child: Icon(Icons.support_agent, color: AppRenkleri.aktif, size: 14),
          ),
          const SizedBox(width: 6),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(16), topRight: Radius.circular(16),
                bottomRight: Radius.circular(16),
              ),
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 3)],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                _noktaCizici(0),
                _noktaCizici(150),
                _noktaCizici(300),
              ],
            ),
          ),
        ],
      ),
    );
  }  // --- _yaziyorGostergesi() sonu ---

  Widget _noktaCizici(int gecikmems) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.0, end: 1.0),
      duration: Duration(milliseconds: 600 + gecikmems),
      builder: (context, value, _) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 3),
          child: Container(
            width: 7, height: 7,
            decoration: BoxDecoration(
              color: AppRenkleri.aktif.withOpacity(0.4 + 0.6 * value),
              shape: BoxShape.circle,
            ),
          ),
        );
      },
    );
  }  // --- _noktaCizici() sonu ---
}  // --- _YardimAsistanEkraniState sonu ---
