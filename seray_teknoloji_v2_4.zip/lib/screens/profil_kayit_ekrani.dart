import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../main.dart';

class ProfilKayitEkrani extends StatefulWidget {
  const ProfilKayitEkrani({Key? key}) : super(key: key);

  @override
  _ProfilKayitEkraniState createState() => _ProfilKayitEkraniState();
}

class _ProfilKayitEkraniState extends State<ProfilKayitEkrani> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _adController = TextEditingController();
  final TextEditingController _soyadController = TextEditingController();
  final TextEditingController _yasController = TextEditingController();

  bool _isFirstTime = true;
  String _selamlamaMetni = "";
  String _kayitliAd = "";

  @override
  void initState() {
    super.initState();
    _profilKontrolEt();
  }

  Future<void> _profilKontrolEt() async {
    final prefs = await SharedPreferences.getInstance();
    String? ad = prefs.getString('user_ad');
    
    if (ad != null && ad.isNotEmpty) {
      setState(() {
        _isFirstTime = false;
        _kayitliAd = ad;
        _selamlamaMetni = _getZamanAyarliSelamlama();
      });

      Future.delayed(const Duration(seconds: 2), () {
        if (mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => const AnaEkran()),
          );
        }
      });
    } else {
      setState(() {
        _isFirstTime = true;
      });
    }
  }

  String _getZamanAyarliSelamlama() {
    int saat = DateTime.now().hour;
    if (saat >= 5 && saat < 12) return "G\u00fcnayd\u0131n"; // Günaydın
    if (saat >= 12 && saat < 17) return "\u0130yi G\u00fcnler"; // İyi Günler
    if (saat >= 17 && saat < 22) return "\u0130yi Ak\u015famlar"; // İyi Akşamlar
    return "\u0130yi Geceler"; // İyi Geceler
  }

  Future<void> _profiliKaydet() async {
    if (_formKey.currentState!.validate()) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('user_ad', _adController.text.trim());
      await prefs.setString('user_soyad', _soyadController.text.trim());
      await prefs.setInt('user_yas', int.parse(_yasController.text.trim()));

      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const AnaEkran()),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_isFirstTime) {
      return Scaffold(
        backgroundColor: Colors.teal,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Image.asset(
                  'assets/images/app_logo.png',
                  width: 100,
                  height: 100,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) {
                    return const Icon(Icons.health_and_safety, size: 80, color: Colors.white);
                  },
                ),
              ),
              const SizedBox(height: 24),
              Text(
                "$_selamlamaMetni, $_kayitliAd! \u2764\ufe0f",
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: Colors.white),
              ),
              const SizedBox(height: 10),
              const Text("Seray Sa\u011fl\u0131k Paneline Giri\u015f Yap\u0131l\u0131yor...", style: TextStyle(fontSize: 16, color: Colors.white70)),
              const SizedBox(height: 30),
              const CircularProgressIndicator(color: Colors.white),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Profil Olu\u015ftur'), // Profil Oluştur
        backgroundColor: Colors.teal, 
        foregroundColor: Colors.white
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 10),
              Center(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(24),
                  child: Image.asset(
                    'assets/images/app_logo.png',
                    width: 120,
                    height: 120,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return const Icon(Icons.account_circle, size: 120, color: Colors.teal);
                    },
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'Ho\u015f Geldiniz!\nSa\u011fl\u0131k panelinizi ki\u015fiselle\u015ftirmek i\u00e7in l\u00fctfen bilgilerinizi girin.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
              const SizedBox(height: 32),
              TextFormField(
                controller: _adController,
                decoration: const InputDecoration(labelText: 'Ad\u0131n\u0131z', border: OutlineInputBorder()),
                validator: (v) => v == null || v.isEmpty ? 'L\u00fctfen ad\u0131n\u0131z\u0131 girin' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _soyadController,
                decoration: const InputDecoration(labelText: 'Soyad\u0131n\u0131z', border: OutlineInputBorder()),
                validator: (v) => v == null || v.isEmpty ? 'L\u00fctfen soyad\u0131n\u0131z\u0131 girin' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _yasController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Ya\u015f\u0131n\u0131z', border: OutlineInputBorder()),
                validator: (v) => v == null || int.tryParse(v) == null ? 'L\u00fctfen ge\u00e7erli bir ya\u015f girin' : null,
              ),
              const SizedBox(height: 32),
              ElevatedButton(
                onPressed: _profiliKaydet,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.teal, 
                  foregroundColor: Colors.white, 
                  padding: const EdgeInsets.symmetric(vertical: 16)
                ),
                child: const Text('KAYDET VE BA\u015eLA', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
