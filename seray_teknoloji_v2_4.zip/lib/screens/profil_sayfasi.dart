import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'profil_kayit_ekrani.dart';

class ProfilSayfasi extends StatefulWidget {
  const ProfilSayfasi({Key? key}) : super(key: key);

  @override
  _ProfilSayfasiState createState() => _ProfilSayfasiState();
}

class _ProfilSayfasiState extends State<ProfilSayfasi> {
  String _ad = "..."; 
  String _soyad = "..."; 
  int _yas = 0;

  @override
  void initState() { 
    super.initState(); 
    _verileriYukle(); 
  }

  Future<void> _verileriYukle() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _ad = prefs.getString('user_ad') ?? "Bilinmiyor";
      _soyad = prefs.getString('user_soyad') ?? "Bilinmiyor";
      _yas = prefs.getInt('user_yas') ?? 0;
    });
  }

  Future<void> _cikisYapVeSifirla() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (mounted) {
      Navigator.pushAndRemoveUntil(
        context, 
        MaterialPageRoute(builder: (context) => const ProfilKayitEkrani()), 
        (route) => false,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profil Y\u00f6netimi'), // Profil Yönetimi
        backgroundColor: Colors.teal, 
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 20),
            Card(
              color: Colors.teal.shade50,
              elevation: 2,
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  children: [
                    const Icon(Icons.account_circle, size: 80, color: Colors.teal),
                    const SizedBox(height: 12),
                    Text(
                      "$_ad $_soyad", 
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 22, color: Colors.black87),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      "Kay\u0131tl\u0131 Ya\u015f Bilgisi: $_yas", // Kayıtlı Yaş Bilgisi
                      style: const TextStyle(fontSize: 15, color: Colors.black54),
                    ),
                  ],
                ),
              ),
            ),
            const Spacer(),
            ElevatedButton.icon(
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: const Text("G\u00fcvenli \u00c7\u0131k\u0131\u015f"), // Güvenli Çıkış
                    content: const Text("Uygulamadaki t\u00fcm profil bilgileriniz ve tahlil ge\u00e7mi\u015finiz silinecektir. \u00c7\u0131k\u0131\u015f yapmak istedi\u011finize emin misiniz?"),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(context), child: const Text("\u0130ptal")), // İptal
                      TextButton(
                        onPressed: _cikisYapVeSifirla, 
                        child: const Text("Evet, \u00c7\u0131k\u0131\u015f Yap", style: TextStyle(color: Colors.red)), // Evet, Çıkış Yap
                      ),
                    ],
                  ),
                );
              },
              icon: const Icon(Icons.power_settings_new),
              label: const Text("G\u00dcVENL\u0130 \u00c7IKI\u015e YAP & VER\u0130LER\u0130 S\u0130L", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)), // GÜVENLİ ÇIKIŞ YAP
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red.shade700, 
                foregroundColor: Colors.white, 
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
