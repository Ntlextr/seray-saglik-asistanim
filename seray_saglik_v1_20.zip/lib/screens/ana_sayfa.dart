import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'seker_ekle_ekrani.dart';
import 'tansiyon_ekle_ekrani.dart';
import '../services/veritabani_yardimcisi.dart';

class AnaSayfa extends StatefulWidget {
  const AnaSayfa({Key? key}) : super(key: key);
  @override
  _AnaSayfaState createState() => _AnaSayfaState();
}

class _AnaSayfaState extends State<AnaSayfa> {
  String _kullaniciAdi = "...";
  List<Map<String, dynamic>> _sonSekerler = [];
  List<Map<String, dynamic>> _sonTansiyonlar = [];

  String get _selamlama {
    final saat = DateTime.now().hour;
    if (saat >= 5 && saat < 12) return 'Günaydın';
    if (saat >= 12 && saat < 18) return 'İyi Günler';
    return 'İyi Akşamlar';
  }

  @override
  void initState() { super.initState(); _verileriTazele(); }

  Future<void> _verileriTazele() async {
    final prefs = await SharedPreferences.getInstance();
    final sekerler = await VeritabaniYardimcisi().sekerleriGetir();
    final tansiyonlar = await VeritabaniYardimcisi().tansiyonlariGetir();
    setState(() {
      _kullaniciAdi = prefs.getString('user_ad') ?? "Kullanıcı";
      _sonSekerler = sekerler;
      _sonTansiyonlar = tansiyonlar;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Center(child: Image.asset('assets/images/app_logo.png', height: 80, width: 80)),
              const SizedBox(height: 12),
              Card(
                color: Colors.teal.shade50,
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Text('$_selamlama, $_kullaniciAdi Bey 🌤️', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.teal)),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(child: ElevatedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => const SekerEkleEkrani())).then((_) => _verileriTazele()), child: const Text('Şeker Ekle'))),
                  const SizedBox(width: 8),
                  Expanded(child: ElevatedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => const TansiyonEkleEkrani())).then((_) => _verileriTazele()), child: const Text('Tansiyon Ekle'))),
                ],
              ),
              const SizedBox(height: 24),
              const Text('Son Ölçümleriniz', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              if (_sonSekerler.isNotEmpty) Card(child: ListTile(leading: const Icon(Icons.bloodtype, color: Colors.red), title: Text('Kan Şekeri: ${_sonSekerler.first['deger']} mg/dL'), subtitle: Text('Zaman: ${_sonSekerler.first['durum']}'))),
              if (_sonTansiyonlar.isNotEmpty) Card(child: ListTile(leading: const Icon(Icons.favorite, color: Colors.teal), title: Text('Tansiyon: ${_sonTansiyonlar.first['buyuk']}/${_sonTansiyonlar.first['kucuk']} mm Hg'))),
            ],
          ),
        ),
      ),
    );
  }
}
