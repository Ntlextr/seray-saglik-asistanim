import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/veritabani_yardimcisi.dart';
import 'yapay_zeka_ekrani.dart';

class AnalizlerEkrani extends StatefulWidget {
  const AnalizlerEkrani({Key? key}) : super(key: key);
  @override
  _AnalizlerEkraniState createState() => _AnalizlerEkraniState();
}

class _AnalizlerEkraniState extends State<AnalizlerEkrani> {
  List<Map<String, dynamic>> _sekerler = [];
  List<Map<String, dynamic>> _tansiyonlar = [];
  bool _yukleniyor = true;
  String _diyabetTipi = "Yok";

  @override
  void initState() { super.initState(); _verileriYukle(); }

  Future<void> _verileriYukle() async {
    final prefs = await SharedPreferences.getInstance();
    final sekerListesi = await VeritabaniYardimcisi().sekerleriGetir();
    final tansiyonListesi = await VeritabaniYardimcisi().tansiyonlariGetir();
    setState(() {
      _diyabetTipi = prefs.getString('user_diyabet') ?? "Yok";
      _sekerler = sekerListesi;
      _tansiyonlar = tansiyonListesi;
      _yukleniyor = false;
    });
  }

  // Diyabet tipine göre şekerin "yüksek" sayılacağı sınır farklıdır.
  int get _sekerYuksekSiniri {
    switch (_diyabetTipi) {
      case 'Tip 1 Diyabet':
        return 180;
      case 'Tip 2 Diyabet':
        return 140;
      case 'Gizli Şeker':
        return 100;
      default:
        return 140;
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: Colors.grey.shade50,
        appBar: AppBar(
          title: const Text('Sağlık Analizleri & İkazlar'),
          backgroundColor: Colors.teal,
          foregroundColor: Colors.white,
          bottom: const TabBar(labelColor: Colors.white, unselectedLabelColor: Colors.white70, tabs: [Tab(text: 'Şeker Seyri'), Tab(text: 'Tansiyon Seyri')]),
        ),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: ElevatedButton.icon(
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => const YapayZekaEkrani())).then((_) => _verileriYukle()),
                icon: const Icon(Icons.picture_as_pdf, color: Colors.white),
                label: const Text('E-NABIZ TAHLİL OKUMA MERKEZİ'),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.orange.shade700, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 14), minimumSize: const Size.fromHeight(48)),
              ),
            ),
            Expanded(
              child: _yukleniyor ? const Center(child: CircularProgressIndicator()) : TabBarView(children: [_sekerSayfasi(), _tansiyonSayfasi()]),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sekerSayfasi() {
    if (_sekerler.isEmpty) return const Center(child: Text('Kayıtlı ölçüm bulunamadı.'));
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _sekerler.length,
      itemBuilder: (context, index) {
        final int deger = int.tryParse(_sekerler[index]['deger'].toString()) ?? 0;
        bool yuksekMi = deger > _sekerYuksekSiniri;
        return Card(
          color: yuksekMi ? Colors.red.shade50 : Colors.green.shade50,
          child: ListTile(
            title: Text('$deger mg/dL', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: yuksekMi ? Colors.red.shade900 : Colors.green.shade900)),
            subtitle: Text('Durum: ${_sekerler[index]['durum']}'),
            trailing: IconButton(icon: const Icon(Icons.volume_up), onPressed: () {}),
          ),
        );
      },
    );
  }

  Widget _tansiyonSayfasi() {
    if (_tansiyonlar.isEmpty) return const Center(child: Text('Kayıtlı ölçüm bulunamadı.'));
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _tansiyonlar.length,
      itemBuilder: (context, index) {
        final t = _tansiyonlar[index];
        return Card(child: ListTile(title: Text('${t['buyuk']}/${t['kucuk']} mm Hg'), subtitle: Text('Nabız: ${t['nabiz']} bpm')));
      },
    );
  }
}
