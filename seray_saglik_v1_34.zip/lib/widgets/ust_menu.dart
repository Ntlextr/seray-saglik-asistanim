import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/veritabani_yardimcisi.dart';
import '../services/pdf_rapor_servisi.dart';
import '../screens/ayarlar_ekrani.dart';
import '../screens/kullanim_kilavuzu_ekrani.dart';

// Her ekranın sağ üstünde görünen ortak üç nokta menüsü.
// Yedekleme, günlük sonuç raporu, ayarlar ve kullanma kılavuzuna tek yerden erişim sağlar.
class UstMenu extends StatelessWidget {
  const UstMenu({Key? key}) : super(key: key);

  Future<void> _yedekle(BuildContext context) async {
    await VeritabaniYardimcisi().veritabaniYedekleHafizaya();
  }

  Future<void> _yedekGeriYukle(BuildContext context) async {
    FilePickerResult? r = await FilePicker.pickFiles();
    if (r != null) {
      await VeritabaniYardimcisi().yedegiGeriYukle(r.files.single.path!);
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Yedek başarıyla yüklendi!')));
    }
  }

  Future<void> _gunlukSonuclar(BuildContext context) async {
    final prefs = await SharedPreferences.getInstance();
    final ad = prefs.getString('user_ad') ?? '';
    final soyad = prefs.getString('user_soyad') ?? '';
    await PdfRaporServisi.gunlukRaporuOlusturVePaylas(kullaniciAdi: '$ad $soyad');
  }

  @override
  Widget build(BuildContext context) {
    return PopupMenuButton<String>(
      icon: const Icon(Icons.menu),
      onSelected: (secim) {
        switch (secim) {
          case 'yedekle':
            _yedekle(context);
            break;
          case 'geri_yukle':
            _yedekGeriYukle(context);
            break;
          case 'gunluk_sonuc':
            _gunlukSonuclar(context);
            break;
          case 'ayarlar':
            Navigator.push(context, MaterialPageRoute(builder: (context) => const AyarlarEkrani()));
            break;
          case 'kilavuz':
            Navigator.push(context, MaterialPageRoute(builder: (context) => const KullanimKilavuzuEkrani()));
            break;
        }
      },
      itemBuilder: (context) => const [
        PopupMenuItem(value: 'gunluk_sonuc', child: ListTile(leading: Icon(Icons.picture_as_pdf), title: Text('Günlük Sonuçları Paylaş'))),
        PopupMenuItem(value: 'yedekle', child: ListTile(leading: Icon(Icons.backup), title: Text('Verileri Yedekle'))),
        PopupMenuItem(value: 'geri_yukle', child: ListTile(leading: Icon(Icons.restore), title: Text('Yedek Bul ve Geri Yükle'))),
        PopupMenuItem(value: 'ayarlar', child: ListTile(leading: Icon(Icons.settings), title: Text('Ayarlar'))),
        PopupMenuItem(value: 'kilavuz', child: ListTile(leading: Icon(Icons.help_outline), title: Text('Kullanma Kılavuzu'))),
      ],
    );
  }
}
