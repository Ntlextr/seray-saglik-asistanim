import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../theme/renkler.dart';

import '../theme/sablon.dart';

// ÖNEMLİ DÜZELTME: Kullanma Kılavuzu artık uygulama içinde metin kartları
// olarak DEĞİL, doğrudan sitedeki görselli kilavuz.html sayfasını (aynı
// site, aynı menü yapısı) bir WebView içinde AÇIYOR. Böylece kılavuzu
// güncellemek için artık ne kod yazmak ne de yeni APK basmak gerekiyor —
// sadece site güncellenir, uygulama her açılışta güncel hâlini gösterir.
class KullanimKilavuzuEkrani extends StatefulWidget {
  const KullanimKilavuzuEkrani({Key? key}) : super(key: key);

  static const String _kilavuzAdresi = 'https://empty-water-4101.serdarcirak.workers.dev/kilavuz.html';

  @override
  State<KullanimKilavuzuEkrani> createState() => _KullanimKilavuzuEkraniState();
}  // --- KullanimKilavuzuEkrani sonu ---

class _KullanimKilavuzuEkraniState extends State<KullanimKilavuzuEkrani> {
  late final WebViewController _controller;
  bool _yukleniyor = true;
  bool _hataVar = false;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.white)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (_) {
            if (mounted) setState(() { _yukleniyor = true; _hataVar = false; });
          },
          onPageFinished: (_) {
            if (mounted) setState(() => _yukleniyor = false);
          },
          onWebResourceError: (_) {
            if (mounted) setState(() { _yukleniyor = false; _hataVar = true; });
          },
        ),
      )
      ..loadRequest(Uri.parse(KullanimKilavuzuEkrani._kilavuzAdresi));
  }  // --- initState() sonu ---

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        shape: AppSablon.appBarSekli,
        title: const Text('Kullanma Kılavuzu'),
        backgroundColor: AppRenkleri.aktif,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'Yenile',
            onPressed: () => _controller.reload(),
          ),
        ],
      ),
      body: Stack(
        children: [
          if (!_hataVar) WebViewWidget(controller: _controller),
          if (_yukleniyor && !_hataVar)
            const Center(child: CircularProgressIndicator()),
          if (_hataVar)
            Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.wifi_off, size: 48, color: Colors.grey),
                    const SizedBox(height: 12),
                    const Text(
                      'Kılavuza ulaşılamadı.\nİnternet bağlantınızı kontrol edip tekrar deneyin.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey),
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton.icon(
                      onPressed: () {
                        setState(() { _hataVar = false; _yukleniyor = true; });
                        _controller.reload();
                      },
                      icon: const Icon(Icons.refresh),
                      label: const Text('Tekrar Dene'),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }  // --- build() sonu ---
}  // --- _KullanimKilavuzuEkraniState sonu ---
