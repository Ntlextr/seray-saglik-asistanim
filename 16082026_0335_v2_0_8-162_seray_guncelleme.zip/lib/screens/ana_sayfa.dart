import 'dart:async';
import '../theme/renkler.dart';
import '../theme/sablon.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'seker_ekle_ekrani.dart';
import 'tansiyon_ekle_ekrani.dart';
import 'su_kilo_ekrani.dart';
import 'beslenme_ekrani.dart';
import 'ilac_ekrani.dart';
import 'yapay_zeka_ekrani.dart';
import 'rapor_ekrani.dart';
import '../services/veritabani_yardimcisi.dart';
import '../services/adim_servisi.dart';
import '../services/widget_servisi.dart';
import '../widgets/ust_menu.dart';

class AnaSayfa extends StatefulWidget {
  const AnaSayfa({Key? key}) : super(key: key);

  @override
  _AnaSayfaState createState() => _AnaSayfaState();
}

class _AnaSayfaState extends State<AnaSayfa> {
  // Alt menüde sekme değiştirdiğinde main.dart bu ekranı YENİDEN KURUYOR
  // (veri tazelensin diye). Bu "static" bayrak sayesinde karşılama banner'ı
  // uygulama açıldığında sadece BİR KEZ gösteriliyor, her "Özet"e dönüşte değil.
  static bool _buOturumdaGosterildi = false;

  String _kullaniciAdi = "...";
  String _cinsiyet = "Bay";
  List<Map<String, dynamic>> _sonSekerler = [];
  List<Map<String, dynamic>> _sonTansiyonlar = [];
  int _bugunSuMl = 0;
  double? _sonKilo;
  int _bugunAdim = 0;
  Timer? _adimYenilemeTimer;
  static const int _gunlukSuHedefiMl = 2000;

  // Karşılama banner'ı popup DEĞİL; ekrana girince görünür, birkaç
  // saniye sonra kendiliğinden solup kaybolur.
  bool _selamGorunur = true;
  bool _selamSoluyor = false;
  Timer? _selamZamanlayici;
  Timer? _selamKaybolmaZamanlayici;

  // Widget ekleme bannerı — kullanıcı ekleyince veya kapatınca bir daha
  // görünmesin diye SharedPreferences'ta kalıcı olarak saklanıyor.
  bool _widgetBanneriGizli = false;

  String get _hitap => (_cinsiyet == 'Bayan' || _cinsiyet == 'Kadın') ? 'Hanım' : 'Bey';

  String get _selamlama {
    final saat = DateTime.now().hour;
    if (saat >= 5 && saat < 12) return 'Günaydın';
    if (saat >= 12 && saat < 18) return 'İyi Günler';
    if (saat >= 18 && saat < 23) return 'İyi Akşamlar';
    return 'İyi Geceler';
  }

  String _tarihiBicimlendir(String? isoTarih) {
    if (isoTarih == null) return '';
    final t = DateTime.tryParse(isoTarih);
    if (t == null) return isoTarih;
    String iki(int n) => n.toString().padLeft(2, '0');
    return '${iki(t.day)}.${iki(t.month)}.${t.year} ${iki(t.hour)}:${iki(t.minute)}';
  }

  @override
  void initState() {
    super.initState();
    _verileriTazele();
    if (!_buOturumdaGosterildi) {
      _buOturumdaGosterildi = true;
      _selamZamanlayici = Timer(const Duration(seconds: 5), () {
        if (!mounted) return;
        setState(() => _selamSoluyor = true);
        _selamKaybolmaZamanlayici = Timer(const Duration(milliseconds: 1400), () {
          if (mounted) setState(() => _selamGorunur = false);
        });
      });
    } else {
      // Bu oturumda zaten gösterildi — tekrar açılmasın.
      _selamGorunur = false;
    }
    AdimServisi.baslat();
    _adimYenilemeTimer = Timer.periodic(const Duration(seconds: 5), (_) async {
      final adim = await AdimServisi.bugunkuAdimGetir();
      if (mounted) setState(() => _bugunAdim = adim);
      WidgetServisi.guncelle(adim: adim, suMl: _bugunSuMl);
    });
  }

  @override
  void dispose() {
    _selamZamanlayici?.cancel();
    _selamKaybolmaZamanlayici?.cancel();
    _adimYenilemeTimer?.cancel();
    super.dispose();
  }

  Future<void> _verileriTazele() async {
    final prefs = await SharedPreferences.getInstance();
    final sekerler = await VeritabaniYardimcisi().sekerleriGetir();
    final tansiyonlar = await VeritabaniYardimcisi().tansiyonlariGetir();
    final bugunSu = await VeritabaniYardimcisi().bugunToplamSuGetir();
    final kiloKayitlari = await VeritabaniYardimcisi().kiloKayitlariniGetir();

    setState(() {
      // Hem profil_kayit_ekrani hem eski kayıt anahtarları kontrol ediliyor
      _kullaniciAdi = prefs.getString('kullanici_ad') ?? 
                       prefs.getString('user_ad') ?? 
                       "Kullanıcı";
      _cinsiyet = prefs.getString('kullanici_cinsiyet') ?? 
                  prefs.getString('user_cinsiyet') ?? 
                  "Bay";
                  
      _sonSekerler = sekerler;
      _sonTansiyonlar = tansiyonlar;
      _bugunSuMl = bugunSu;
      _sonKilo = kiloKayitlari.isNotEmpty ? (kiloKayitlari.first['kilo'] as num?)?.toDouble() : null;
      _widgetBanneriGizli = prefs.getBool('widget_banneri_gizli') ?? false;
    });
    WidgetServisi.guncelle(adim: _bugunAdim, suMl: _bugunSuMl);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(
        shape: AppSablon.appBarSekli,
        title: const Text('Ana Sayfa', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: AppRenkleri.aktif,
        foregroundColor: Colors.white,
        elevation: 0,
        actions: const [UstMenu()],
      ),
      body: Stack(
        children: [
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // HIZLI BUTONLAR (Şeker / Tansiyon / Su & Kilo — ekrana sığacak şekilde)
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppRenkleri.aktif,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
                        ),
                      ),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => SekerEkleEkrani(),
                          ),
                        ).then((_) => _verileriTazele());
                      },
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          AppSablon.modernMi
                              ? Container(
                                  width: 34,
                                  height: 34,
                                  decoration: BoxDecoration(color: Colors.white.withOpacity(0.22), shape: BoxShape.circle),
                                  child: Icon(Icons.bloodtype, size: AppSablon.ikonBoyutu),
                                )
                              : Icon(Icons.bloodtype, size: AppSablon.ikonBoyutu),
                          SizedBox(height: 2),
                          Text('Şeker Ekle', style: TextStyle(fontSize: 11), textAlign: TextAlign.center),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppRenkleri.aktif.shade700,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
                        ),
                      ),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => TansiyonEkleEkrani(),
                          ),
                        ).then((_) => _verileriTazele());
                      },
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          AppSablon.modernMi
                              ? Container(
                                  width: 34,
                                  height: 34,
                                  decoration: BoxDecoration(color: Colors.white.withOpacity(0.22), shape: BoxShape.circle),
                                  child: Icon(Icons.favorite, size: AppSablon.ikonBoyutu),
                                )
                              : Icon(Icons.favorite, size: AppSablon.ikonBoyutu),
                          SizedBox(height: 2),
                          Text('Tansiyon Ekle', style: TextStyle(fontSize: 11), textAlign: TextAlign.center),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blue.shade600,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
                        ),
                      ),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const SuKiloEkrani(),
                          ),
                        ).then((_) => _verileriTazele());
                      },
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          AppSablon.modernMi
                              ? Container(
                                  width: 34,
                                  height: 34,
                                  decoration: BoxDecoration(color: Colors.white.withOpacity(0.22), shape: BoxShape.circle),
                                  child: Icon(Icons.water_drop, size: AppSablon.ikonBoyutu),
                                )
                              : Icon(Icons.water_drop, size: AppSablon.ikonBoyutu),
                          SizedBox(height: 2),
                          Text('Su & Kilo', style: TextStyle(fontSize: 11), textAlign: TextAlign.center),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              // YENİ: Yemek ve İlaç Ekle de artık burada — önceden sadece
              // kendi ekranlarından erişilebiliyordu, kullanıcı geri
              // bildirimiyle "hızlı ekleme" mantığı tutarlı hale getirildi.
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.deepOrange.shade400,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
                      ),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const BeslenmeEkrani()),
                        ).then((_) => _verileriTazele());
                      },
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          AppSablon.modernMi
                              ? Container(
                                  width: 34,
                                  height: 34,
                                  decoration: BoxDecoration(color: Colors.white.withOpacity(0.22), shape: BoxShape.circle),
                                  child: Icon(Icons.restaurant_menu, size: AppSablon.ikonBoyutu),
                                )
                              : Icon(Icons.restaurant_menu, size: AppSablon.ikonBoyutu),
                          SizedBox(height: 2),
                          Text('Yemek Ekle', style: TextStyle(fontSize: 11), textAlign: TextAlign.center),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red.shade400,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
                      ),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const IlacEkrani()),
                        ).then((_) => _verileriTazele());
                      },
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          AppSablon.modernMi
                              ? Container(
                                  width: 34,
                                  height: 34,
                                  decoration: BoxDecoration(color: Colors.white.withOpacity(0.22), shape: BoxShape.circle),
                                  child: Icon(Icons.medication, size: AppSablon.ikonBoyutu),
                                )
                              : Icon(Icons.medication, size: AppSablon.ikonBoyutu),
                          SizedBox(height: 2),
                          Text('İlaç Ekle', style: TextStyle(fontSize: 11), textAlign: TextAlign.center),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),

              // WIDGET EKLEME BANNERI — bir kere eklenince veya "Kapat"
              // denince bir daha görünmez (SharedPreferences'ta saklanır).
              if (!_widgetBanneriGizli)
                Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppRenkleri.aktif.shade50,
                    borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
                    border: Border.all(color: AppRenkleri.aktif.shade200),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.widgets_outlined, color: AppRenkleri.aktif.shade700, size: 26),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Adım/Su özetini ana ekranınıza ekleyin', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: AppRenkleri.aktif.shade800)),
                            const SizedBox(height: 6),
                            Row(
                              children: [
                                ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: AppRenkleri.aktif,
                                    foregroundColor: Colors.white,
                                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                                    minimumSize: Size.zero,
                                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                  ),
                                  onPressed: () async {
                                    await WidgetServisi.anaEkraneSabitle();
                                    final tercihler = await SharedPreferences.getInstance();
                                    await tercihler.setBool('widget_banneri_gizli', true);
                                    if (mounted) setState(() => _widgetBanneriGizli = true);
                                    // ÖNEMLİ: requestPinWidget() başarıyla ÇAĞRILDI mı yoksa
                                    // telefonun kendi ekleme penceresi GERÇEKTEN açıldı mı,
                                    // bunu koddan kesin olarak bilemiyoruz (bazı telefonlarda/
                                    // launcher'larda bu özellik desteklenmeyebilir, sessizce
                                    // hiçbir şey olmaz). Bu yüzden her durumda elle ekleme
                                    // talimatını da gösteriyoruz.
                                    if (mounted) {
                                      showDialog(
                                        context: context,
                                        builder: (dialogContext) => AlertDialog(
                                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                                          title: const Text('Widget Ekleme'),
                                          content: const Text(
                                            'Az önce bir "Ana ekrana ekle?" penceresi açıldıysa onaylayın.\n\n'
                                            'Hiçbir pencere açılmadıysa (bazı telefonlarda bu otomatik olmuyor): '
                                            'ana ekranda BOŞ bir yere parmağınızı basılı tutun, açılan menüden '
                                            '"Widget\'lar" (Widgets) seçin, listede "Seray"ı bulup ana ekrana sürükleyin.',
                                          ),
                                          actions: [
                                            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Anladım')),
                                          ],
                                        ),
                                      );
                                    }
                                  },
                                  child: const Text('Widget Ekle', style: TextStyle(fontSize: 12)),
                                ),
                                TextButton(
                                  onPressed: () async {
                                    final tercihler = await SharedPreferences.getInstance();
                                    await tercihler.setBool('widget_banneri_gizli', true);
                                    if (mounted) setState(() => _widgetBanneriGizli = true);
                                  },
                                  child: const Text('Kapat', style: TextStyle(fontSize: 12)),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

              // e-NABIZ TAHLİLLERİM — hızlı ölçüm ekleme butonlarından ayrı
              // ve göze çarpan bir kart: bu bir "ölçüm ekle" değil, "tahlil
              // yükle / görüntüle" eylemi olduğu için tek başına vurgulandı.
              Material(
                color: AppRenkleri.aktif,
                borderRadius: BorderRadius.circular(14),
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const YapayZekaEkrani()),
                    ).then((_) => _verileriTazele());
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: Row(
                      children: [
                        const CircleAvatar(
                          radius: 18,
                          backgroundColor: Colors.white24,
                          child: Icon(Icons.picture_as_pdf, color: Colors.white, size: 20),
                        ),
                        const SizedBox(width: 12),
                        const Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('e-Nabız Tahlillerim', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
                              SizedBox(height: 2),
                              Text('PDF yükle, referans dışı sonuçları gör', style: TextStyle(color: Colors.white70, fontSize: 12)),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_right, color: Colors.white),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),

              // RAPOR ANALİZİ — e-Nabız kartının hemen altında, aynı vurgu
              // seviyesinde: bu da bir "ölçüm ekle" değil, "rapor yükle /
              // yapay zekaya yorumlat" eylemi. Kullanıcının önceden Gemini/
              // ChatGPT'ye elle yaptırdığı işi uygulama içine taşıyor.
              Material(
                color: AppRenkleri.aktif.shade700,
                borderRadius: BorderRadius.circular(14),
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const RaporEkrani()),
                    ).then((_) => _verileriTazele());
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: Row(
                      children: [
                        const CircleAvatar(
                          radius: 18,
                          backgroundColor: Colors.white24,
                          child: Icon(Icons.description, color: Colors.white, size: 20),
                        ),
                        const SizedBox(width: 12),
                        const Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Rapor Analizi', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
                              SizedBox(height: 2),
                              Text('Röntgen/MR/konsültasyon raporu yükle, AI yorumlasın', style: TextStyle(color: Colors.white70, fontSize: 12)),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_right, color: Colors.white),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 24),

              // SON ÖLÇÜMLER BAŞLIĞI
              const Text(
                'Son Ölçümleriniz',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF111424),
                ),
              ),
              const SizedBox(height: 12),

              // ADIM SAYAR ÖZETİ
              Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
                ),
                child: ListTile(
                  leading: const CircleAvatar(
                    backgroundColor: Color(0xFFFFF3E0),
                    child: Icon(Icons.directions_walk, color: Colors.deepOrange),
                  ),
                  title: Text(
                    'Adım: $_bugunAdim',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text('Tahmini yakılan kalori: ${AdimServisi.kaloriTahminEt(_bugunAdim).toStringAsFixed(0)} kcal'),
                ),
              ),
              const SizedBox(height: 8),

              // SU TAKİBİ ÖZETİ
              Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
                ),
                child: ListTile(
                  leading: const CircleAvatar(
                    backgroundColor: Color(0xFFE1F5FE),
                    child: Icon(Icons.water_drop, color: Colors.blue),
                  ),
                  title: Text(
                    'Su: ${(_bugunSuMl / 1000).toStringAsFixed(1)} L / ${(_gunlukSuHedefiMl / 1000).toStringAsFixed(0)} L',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text(
                    _bugunSuMl >= _gunlukSuHedefiMl
                        ? '🎉 Bugünkü hedefe ulaştınız!'
                        : 'Bugün ${(_gunlukSuHedefiMl - _bugunSuMl).clamp(0, _gunlukSuHedefiMl)} mL kaldı',
                  ),
                ),
              ),
              const SizedBox(height: 8),

              // KİLO ÖZETİ
              if (_sonKilo != null)
                Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
                  ),
                  child: ListTile(
                    leading: const CircleAvatar(
                      backgroundColor: Color(0xFFF3E5F5),
                      child: Icon(Icons.monitor_weight, color: Colors.purple),
                    ),
                    title: Text(
                      'Kilo: ${_sonKilo!.toStringAsFixed(1)} kg',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    subtitle: const Text('En son kaydedilen ölçüm'),
                  ),
                ),
              if (_sonKilo != null) const SizedBox(height: 8),

              // ŞEKER ÖLÇÜMÜ
              if (_sonSekerler.isNotEmpty)
                Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
                  ),
                  child: ListTile(
                    leading: const CircleAvatar(
                      backgroundColor: Color(0xFFFFEBEE),
                      child: Icon(Icons.bloodtype, color: Colors.red),
                    ),
                    title: Text(
                      'Kan Şekeri: ${_sonSekerler.first['deger']} mg/dL',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text(
                      'Durum: ${_sonSekerler.first['durum'] ?? 'Belirtilmedi'}\nTarih: ${_tarihiBicimlendir(_sonSekerler.first['tarih']?.toString())}',
                    ),
                  ),
                ),

              if (_sonSekerler.isNotEmpty && _sonTansiyonlar.isNotEmpty)
                const SizedBox(height: 8),

              // TANSİYON ÖLÇÜMÜ
              if (_sonTansiyonlar.isNotEmpty)
                Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
                  ),
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: const Color(0xE8E0F2F1),
                      child: Icon(Icons.favorite, color: AppRenkleri.aktif),
                    ),
                    title: Text(
                      'Tansiyon: ${_sonTansiyonlar.first['buyuk']}/${_sonTansiyonlar.first['kucuk']} mmHg',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text(
                      'Tarih: ${_tarihiBicimlendir(_sonTansiyonlar.first['tarih']?.toString())}',
                    ),
                  ),
                ),

              if (_sonSekerler.isEmpty && _sonTansiyonlar.isEmpty)
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
                  ),
                  child: const Center(
                    child: Text(
                      'Henüz kaydedilmiş bir ölçüm bulunmuyor.',
                      style: TextStyle(color: Colors.grey),
                    ),
                  ),
                ),
            ],
              ),
            ),
          ),
          // KARŞILAMA OVERLAY'İ — popup DEĞİL: ekranın ortasında belirir,
          // birkaç saniye sonra bulut gibi yavaşça büyüyüp solarak kaybolur.
          // IgnorePointer sayesinde altındaki içeriğe dokunmaya engel olmaz.
          if (_selamGorunur)
            Positioned.fill(
              child: IgnorePointer(
                child: Center(
                  child: AnimatedOpacity(
                    opacity: _selamSoluyor ? 0.0 : 1.0,
                    duration: const Duration(milliseconds: 1400),
                    curve: Curves.easeOut,
                    child: AnimatedScale(
                      scale: _selamSoluyor ? 1.25 : 1.0,
                      duration: const Duration(milliseconds: 1400),
                      curve: Curves.easeOut,
                      child: Container(
                        margin: const EdgeInsets.symmetric(horizontal: 32),
                        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
                        decoration: BoxDecoration(
                          color: AppRenkleri.aktif.shade50,
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.12), blurRadius: 16, offset: const Offset(0, 6))],
                        ),
                        child: Text(
                          '$_selamlama, $_kullaniciAdi $_hitap 🌤️',
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Color(0xFF006655)),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
      // NOT: Alt navigasyon menüsü artık sadece main.dart'taki
      // AnaEkranYonlendirici içinde tek bir yerden yönetiliyor.
      // Burada ikinci bir bottomNavigationBar OLMAMALI, aksi halde
      // eski (Ana Sayfa/Şeker/Tansiyon/Profil) menü ile yeni
      // (Özet/Analizler/İlaçlarım/Profil) menü çakışır.
    );
  }
}
