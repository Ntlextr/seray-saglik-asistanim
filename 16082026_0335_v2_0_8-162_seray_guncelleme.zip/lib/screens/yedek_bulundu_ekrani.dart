import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../theme/renkler.dart';
import '../theme/sablon.dart';
import 'profil_kayit_ekrani.dart';

// Android'in Otomatik Yedekleme'si (Auto Backup), uygulama silinip yeniden
// kurulunca kullanıcıya hiç sormadan eski verileri geri yüklüyor — bu ekran
// o sessizliği ortadan kaldırıyor: "bu senin verilerin mi, devam mı
// edelim" diye AÇIKÇA soruyor. main.dart, cihazda daha önce hiç
// çalışmamış (cache'teki iz dosyası yok) ama profil verisi VARSA
// (yedekten geldiği anlamına gelir) bu ekranı gösteriyor.
class YedekBulunduEkrani extends StatelessWidget {
  final String kullaniciAdi;
  final VoidCallback onDevamEt;

  const YedekBulunduEkrani({Key? key, required this.kullaniciAdi, required this.onDevamEt}) : super(key: key);

  Future<File> _iziDosyasi() async {
    final gecici = await getTemporaryDirectory();
    return File('${gecici.path}/cihaz_calisti.marker');
  }  // --- _iziDosyasi() sonu ---

  Future<void> _devamEt(BuildContext context) async {
    final dosya = await _iziDosyasi();
    await dosya.writeAsString('1');
    onDevamEt();
  }  // --- _devamEt() sonu ---

  Future<void> _sifirdanBasla(BuildContext context) async {
    final dosya = await _iziDosyasi();
    await dosya.writeAsString('1');
    // ÖNEMLİ DÜZELTME: "Bu Ben Değilim" dediğinde önceden SADECE profil
    // alanları (isim/yaş/foto) temizleniyor, ölçümler (şeker/tansiyon/ilaç)
    // BİLEREK korunuyordu — mantık şuydu: "kullanıcı belki ölçümleri de
    // istemiyordur, emin olamayız, geri dönüşü yok". Ama "Bu Ben Değilim"
    // AÇIKÇA "bu veri bana ait değil" demek — bu durumda ölçümler de o
    // kişiye ait olamaz. Şimdi GERÇEKTEN sıfırdan başlıyor: veritabanı +
    // yemek/ilaç/profil fotoğrafları da siliniyor, sadece tercihler değil.
    try {
      final dbYolu = join(await getDatabasesPath(), 'seray_saglik_asistanim.db');
      final dbDosyasi = File(dbYolu);
      if (await dbDosyasi.exists()) await dbDosyasi.delete();
    } catch (_) {}

    try {
      final belgeler = await getApplicationDocumentsDirectory();
      final yemekKlasoru = Directory('${belgeler.path}/yemek_fotograflari');
      if (await yemekKlasoru.exists()) await yemekKlasoru.delete(recursive: true);
      final ilacKlasoru = Directory('${belgeler.path}/ilac_fotograflari');
      if (await ilacKlasoru.exists()) await ilacKlasoru.delete(recursive: true);
      final profilFoto = File('${belgeler.path}/profil_foto.jpg');
      if (await profilFoto.exists()) await profilFoto.delete();
    } catch (_) {}

    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    await prefs.setBool('is_logged_in', false);
    if (context.mounted) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const ProfilKayitEkrani()),
      );
    }
  }  // --- _sifirdanBasla() sonu ---

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.cloud_download_outlined, size: 64, color: AppRenkleri.aktif),
              const SizedBox(height: 20),
              const Text('Önceki Verileriniz Bulundu', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
              const SizedBox(height: 12),
              Text(
                'Bu telefonda daha önce kayıtlı olan "$kullaniciAdi" adına ait veriler otomatik olarak geri yüklendi.',
                style: TextStyle(fontSize: 15, color: Colors.grey.shade700, height: 1.4),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 32),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppRenkleri.aktif,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
                  ),
                  onPressed: () => _devamEt(context),
                  child: const Text('Evet, Bu Benim — Devam Et', style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
                  ),
                  onPressed: () => _sifirdanBasla(context),
                  child: const Text('Hayır, Bu Ben Değilim — Profili Düzenle', style: TextStyle(fontSize: 14)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }  // --- build() sonu ---
}  // --- YedekBulunduEkrani sonu ---
