import 'dart:io';
import '../theme/renkler.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:path_provider/path_provider.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import 'package:printing/printing.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'veritabani_yardimcisi.dart';
import 'profil_yoneticisi.dart';
import 'adim_servisi.dart';

class PdfRaporServisi {
  // Uzun bir listeyi (örn. tablo satırları) verilen boyutta küçük parçalara
  // böler — büyük PDF tablolarının sayfaya sığmama hatasını önlemek için.
  static List<List<T>> _listeyiBol<T>(List<T> liste, int parcaBoyutu) {
    if (liste.isEmpty) return [liste];
    final sonuc = <List<T>>[];
    for (var i = 0; i < liste.length; i += parcaBoyutu) {
      sonuc.add(liste.sublist(i, i + parcaBoyutu > liste.length ? liste.length : i + parcaBoyutu));
    }
    return sonuc;
  }  // --- _listeyiBol() sonu ---

  // Tüm export dosya adlarında ortak kullanılan: kişi adı + tarih + saat
  // eki üretir (örn. "_Serdar_Cirak_03082026_1530"). Boşluk/özel karakterleri
  // dosya sisteminde sorun çıkarmasın diye alt çizgiye çevirir.
  static String _dosyaAdiEki(String kullaniciAdi) {
    final simdi = DateTime.now();
    String iki(int n) => n.toString().padLeft(2, '0');
    final tarihSaat = '${iki(simdi.day)}${iki(simdi.month)}${simdi.year}_${iki(simdi.hour)}${iki(simdi.minute)}';
    final temizAd = kullaniciAdi.trim().isEmpty
        ? ''
        : '_${kullaniciAdi.trim().replaceAll(RegExp(r'[^\w\sÇĞİÖŞÜçğıöşü]'), '').replaceAll(' ', '_')}';
    return '${temizAd}_$tarihSaat';
  }  // --- _dosyaAdiEki() sonu ---

  // ÖNEMLİ DÜZELTME: Kullanıcı istedi — dosya adları artık jenerik
  // "seray_analiz" değil, konuya özel (ör. "seray_kilo_gidisat_analizi_
  // 09082026_2104"). Başlığı (örn. "Kilo Gidişat Analizi") dosya sistemi
  // için güvenli, küçük harfli, alt çizgili bir "slug"a çevirir — Türkçe
  // karakterleri sadeleştirir, boşlukları alt çizgiye çevirir.
  static String _konuSlug(String baslik) {
    var s = baslik.trim().toLowerCase();
    const harfEslesme = {
      'ç': 'c', 'ğ': 'g', 'ı': 'i', 'ö': 'o', 'ş': 's', 'ü': 'u',
    };
    harfEslesme.forEach((tr, en) => s = s.replaceAll(tr, en));
    s = s.replaceAll(RegExp(r'[^a-z0-9\s_]'), ''); // parantez, nokta vb. temizlenir
    s = s.trim().replaceAll(RegExp(r'\s+'), '_');
    if (s.isEmpty) s = 'analiz';
    return s;
  }  // --- _konuSlug() sonu ---

  // Tarih/saat eki TEK BAŞINA (kişi adı olmadan) — konuya özel dosya
  // adlarında kullanılıyor, örn. "seray_kilo_gidisat_analizi_09082026_2104".
  static String _tarihSaatEki() {
    final simdi = DateTime.now();
    String iki(int n) => n.toString().padLeft(2, '0');
    return '${iki(simdi.day)}${iki(simdi.month)}${simdi.year}_${iki(simdi.hour)}${iki(simdi.minute)}';
  }  // --- _tarihSaatEki() sonu ---

  // yapay_zeka_ekrani.dart'taki _refDisinda ile aynı mantık (private
  // top-level fonksiyon farklı dosyada erişilemediği için burada tekrar
  // tanımlandı) — bir değerin referans aralığının dışında olup olmadığını
  // kontrol eder. Kullanıcı fark etti: e-Nabız Tahlil Matrisi'nde ref dışı
  // değerlerin arka planı hâlâ beyazdı, renklendirme bu tabloya hiç
  // uygulanmamıştı.
  static bool _degerRefDisinda(String deger, String ref) {
    if (ref.isEmpty || ref == '-') return false;
    final ilkSayiEslesme = RegExp(r'^-?[0-9]+([.,][0-9]+)?').firstMatch(deger.trim());
    if (ilkSayiEslesme == null) return false;
    final sayi = double.tryParse(ilkSayiEslesme.group(0)!.replaceAll(',', '.'));
    if (sayi == null) return false;
    final parcalar = ref.split(RegExp(r'[-–]'));
    if (parcalar.length < 2) return false;
    final min = double.tryParse(parcalar[0].trim().replaceAll(',', '.').replaceAll(RegExp(r'[^0-9.]'), ''));
    final maks = double.tryParse(parcalar[1].trim().replaceAll(',', '.').replaceAll(RegExp(r'[^0-9.]'), ''));
    if (min == null || maks == null) return false;
    return sayi < min || sayi > maks;
  }  // --- _degerRefDisinda() sonu ---

  // Tarihi GG.AA.YY (2 haneli yıl) biçimine çevirir — ekrandaki kısaltmayla tutarlı.
  static String _tarihiKisalt(String tarih) {
    final parcalar = tarih.split('.');
    if (parcalar.length != 3) return tarih;
    final yil = int.tryParse(parcalar[2]);
    if (yil == null) return tarih;
    return '${parcalar[0]}.${parcalar[1]}.${(yil % 100).toString().padLeft(2, '0')}';
  }  // --- _tarihiKisalt() sonu ---

  // Her PDF çıktısının altına, hangi paket sürümüyle üretildiğini belli belirsiz
  // (soluk/küçük) yazar — sorun bildirirken hangi sürümden geldiği anlaşılsın diye.
  static Future<pw.Widget> _versiyonEtiketi() async {
    try {
      final bilgi = await PackageInfo.fromPlatform();
      return pw.Text('Seray Sağlık Asistanım AI tarafından üretilmiştir — v${bilgi.version} (${bilgi.buildNumber})',
          style: const pw.TextStyle(fontSize: 7, color: PdfColors.grey500));
    } catch (_) {
      return pw.SizedBox();
    }
  }  // --- _versiyonEtiketi() sonu ---

  // Düz metin paylaşımları (PDF DEĞİL — Share.share ile WhatsApp/e-posta/
  // SMS'e giden ham metin) için AYNI marka ibaresini sona ekler. Kullanıcı
  // istedi: "her paylaşımda ve print'te Seray Sağlık Asistanım AI
  // tarafından üretilmiştir ibaresi olsun" — bu, PDF olmayan paylaşımları
  // kapsayan taraf.
  static Future<String> metneMarkaEkle(String metin) async {
    try {
      final bilgi = await PackageInfo.fromPlatform();
      return '$metin\n\n— Seray Sağlık Asistanım AI tarafından üretilmiştir (v${bilgi.version})';
    } catch (_) {
      return '$metin\n\n— Seray Sağlık Asistanım AI tarafından üretilmiştir';
    }
  }  // --- metneMarkaEkle() sonu ---

  // Tahlil isimlerini PDF sütunlarına sığması için Seray AI standartlarında kısaltır
  static String _tahlilAdiniKisalt(String ad) {
    String t = ad.trim();
    if (t.contains('Alanin Aminotransferaz')) return 'ALT';
    if (t.contains('Aspartat Transaminaz')) return 'AST';
    if (t.contains('Gama Glutamil')) return 'GGT';
    if (t.contains('Açlık Kan Şekeri') || t.contains('Glukoz')) return 'Glukoz (AKŞ)';
    if (t.contains('Hemogram') || t.contains('Tam Kan')) return 'Hemogram';
    if (t.contains('Kreatinin')) return 'Kreatinin';
    if (t.contains('Trigliserid')) return 'Trigliserid';
    if (t.contains('Kolesterol')) return 'Kolesterol';
    if (t.contains('Vitamin B12')) return 'B12 Vitamini';
    if (t.contains('25-Hidroksi')) return 'D Vitamini';
    return t.length > 22 ? '${t.substring(0, 20)}..' : t;
  }  // --- _tahlilAdiniKisalt() sonu ---

  // BÜYÜK YENİDEN TASARIM (kullanıcı isteği 3j): Günlük Şeker/Tansiyon/Su/
  // Kilo/Adım Ölçüm Raporu — artık tarihe göre gruplanmış TEK bir kompakt
  // tablo (6 eşit sütun: Tarih/Saat | Şeker | Tansiyon | Su | Kilo | Adım),
  // her hücrede değer + yön oku (↑ yüksek/hedef üstü, ↓ düşük/hedef altı,
  // → normal). Aynı günde birden fazla ölçüm varsa hücrede alt alta
  // (küçük yazı, tek hücre içinde çok satır) gösteriliyor. Satır yüksekliği
  // pw.Table'ın kendi doğası gereği her satırın içeriğine göre otomatik
  // ayarlanıyor (sabit değil) — kullanıcının istediği tam olarak bu.
  // NOT: Adım geçmişi cihazda sadece SON 7 GÜN olarak tutuluyor
  // (AdimServisi.sonYediGunGetir) — daha eski günlerde Adım hücresi "-"
  // görünür, bu bir kod eksikliği değil, veri kaynağının doğal sınırı.
  static Future<void> gunlukRaporuOlusturVePaylas({required String kullaniciAdi}) async {
    final sekerler = await VeritabaniYardimcisi().sekerleriGetir();
    final tansiyonlar = await VeritabaniYardimcisi().tansiyonlariGetir();
    final sular = await VeritabaniYardimcisi().suKayitlariniGetir(limit: 500);
    final kilolar = await VeritabaniYardimcisi().kiloKayitlariniGetir(limit: 500);
    final adimGecmisi = await AdimServisi.sonYediGunGetir(); // List<MapEntry<String tarih(yyyy-MM-dd), int>>

    final py = ProfilYoneticisi();
    final prefs = await SharedPreferences.getInstance();
    final hedefSuMl = await VeritabaniYardimcisi().suHedefiMlGetir();
    final hedefKilo = prefs.getDouble(await py.profilAnahtari('hedef_kilo'));
    final hedefAdim = prefs.getInt(await py.profilAnahtari('hedef_adim')) ?? 6000;

    String gunAnahtari(String? isoTarih) {
      final t = DateTime.tryParse(isoTarih ?? '');
      if (t == null) return '';
      return '${t.year.toString().padLeft(4, '0')}-${t.month.toString().padLeft(2, '0')}-${t.day.toString().padLeft(2, '0')}';
    }

    String saatBicimlendir(String? isoTarih) {
      final t = DateTime.tryParse(isoTarih ?? '');
      if (t == null) return '';
      String iki(int n) => n.toString().padLeft(2, '0');
      return '${iki(t.hour)}:${iki(t.minute)}';
    }

    // --- Her metriği "gün anahtarı" (yyyy-MM-dd) altında grupla ---
    final Map<String, List<Map<String, dynamic>>> sekerGunluk = {};
    for (final s in sekerler) {
      sekerGunluk.putIfAbsent(gunAnahtari(s['tarih']?.toString()), () => []).add(s);
    }
    final Map<String, List<Map<String, dynamic>>> tansiyonGunluk = {};
    for (final t in tansiyonlar) {
      tansiyonGunluk.putIfAbsent(gunAnahtari(t['tarih']?.toString()), () => []).add(t);
    }
    final Map<String, int> suGunluk = {};
    for (final s in sular) {
      final gun = gunAnahtari(s['tarih']?.toString());
      suGunluk[gun] = (suGunluk[gun] ?? 0) + ((s['miktar_ml'] as num?)?.toInt() ?? 0);
    }
    // Kilo: o günün EN SON ölçümü (kilolar zaten tarih DESC geliyor, ilk
    // rastladığımız o günün en yeni kaydı olur).
    final Map<String, double> kiloGunluk = {};
    for (final k in kilolar) {
      final gun = gunAnahtari(k['tarih']?.toString());
      kiloGunluk.putIfAbsent(gun, () => (k['kilo'] as num?)?.toDouble() ?? 0);
    }
    final Map<String, int> adimGunluk = {for (final e in adimGecmisi) e.key: e.value};

    String sekerOku(String durum) {
      if (durum.contains('Çok Yüksek') || durum.contains('Çok Düşük')) return '⚠';
      if (durum.contains('Yüksek')) return '↑';
      if (durum.contains('Düşük')) return '↓';
      return '→';
    }

    String tansiyonDurumu(int buyuk, int kucuk) {
      if (buyuk >= 180 || kucuk >= 120) return 'Çok Yüksek';
      if (buyuk < 90 || kucuk < 60) return 'Çok Düşük';
      if (buyuk >= 140 || kucuk >= 90) return 'Yüksek';
      return 'Normal';
    }

    String tansiyonOku(String durum) {
      if (durum.contains('Çok')) return '⚠';
      if (durum == 'Yüksek') return '↑';
      return '→';
    }

    // --- Son 30 günün listesi (bugünden geriye, en yeni üstte) ---
    final bugun = DateTime.now();
    final gunler = List.generate(30, (i) => bugun.subtract(Duration(days: i)));

    final satirlar = <List<String>>[];
    for (final gun in gunler) {
      final anahtar = '${gun.year.toString().padLeft(4, '0')}-${gun.month.toString().padLeft(2, '0')}-${gun.day.toString().padLeft(2, '0')}';
      String iki(int n) => n.toString().padLeft(2, '0');
      final tarihGosterim = '${iki(gun.day)}.${iki(gun.month)}.${gun.year}';

      final sekerSatirlari = (sekerGunluk[anahtar] ?? []).map((s) {
        final durum = (s['durum'] ?? '').toString();
        // ÖNEMLİ: Kullanıcı istedi — durum alanı "Açlık - Yüksek" gibi
        // saklanıyor, tipi (Açlık/Tokluk) ayırıp satıra ekliyoruz, yer
        // yeterli olduğu için sığıyor.
        final tip = durum.contains(' - ') ? durum.split(' - ').first : '';
        return '${s['deger']} ${sekerOku(durum)} ${saatBicimlendir(s['tarih']?.toString())}${tip.isNotEmpty ? ' ($tip)' : ''}';
      }).toList();

      final tansiyonSatirlari = (tansiyonGunluk[anahtar] ?? []).map((t) {
        final buyuk = (t['buyuk'] as num?)?.toInt() ?? 0;
        final kucuk = (t['kucuk'] as num?)?.toInt() ?? 0;
        final durum = tansiyonDurumu(buyuk, kucuk);
        return '$buyuk/$kucuk ${tansiyonOku(durum)} ${saatBicimlendir(t['tarih']?.toString())}';
      }).toList();

      String suHucresi = '-';
      if (suGunluk.containsKey(anahtar)) {
        final toplam = suGunluk[anahtar]!;
        final ok = toplam >= hedefSuMl ? '↑' : '↓';
        suHucresi = '$toplam ml $ok';
      }

      String kiloHucresi = '-';
      if (kiloGunluk.containsKey(anahtar)) {
        final deger = kiloGunluk[anahtar]!;
        String ok = '';
        if (hedefKilo != null && hedefKilo > 0) {
          ok = deger > hedefKilo ? ' ↑' : (deger < hedefKilo ? ' ↓' : ' →');
        }
        kiloHucresi = '${deger.toStringAsFixed(1)} kg$ok';
      }

      String adimHucresi = '-';
      if (adimGunluk.containsKey(anahtar)) {
        final adet = adimGunluk[anahtar]!;
        final ok = adet >= hedefAdim ? '↑' : '↓';
        adimHucresi = '$adet $ok';
      }

      satirlar.add([
        tarihGosterim,
        sekerSatirlari.isEmpty ? '-' : sekerSatirlari.join('\n'),
        tansiyonSatirlari.isEmpty ? '-' : tansiyonSatirlari.join('\n'),
        suHucresi,
        kiloHucresi,
        adimHucresi,
      ]);
    }

    final logoBaytlari = await rootBundle.load('assets/images/app_logo.png');
    final logo = pw.MemoryImage(logoBaytlari.buffer.asUint8List());

    final normalFontBaytlari = await rootBundle.load('assets/fonts/DejaVuSans.ttf');
    final kalinFontBaytlari = await rootBundle.load('assets/fonts/DejaVuSans-Bold.ttf');
    final normalFont = pw.Font.ttf(normalFontBaytlari);
    final kalinFont = pw.Font.ttf(kalinFontBaytlari);

    final belge = pw.Document(theme: pw.ThemeData.withFont(base: normalFont, bold: kalinFont));
    final versiyonEtiketi = await _versiyonEtiketi();

    final altiEsitSutun = {
      0: const pw.FlexColumnWidth(1),
      1: const pw.FlexColumnWidth(1),
      2: const pw.FlexColumnWidth(1),
      3: const pw.FlexColumnWidth(1),
      4: const pw.FlexColumnWidth(1),
      5: const pw.FlexColumnWidth(1),
    };

    belge.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        header: (context) => pw.Container(
          padding: const pw.EdgeInsets.only(bottom: 6),
          child: pw.Text('Seray Sağlık Asistanım — Ölçüm Raporu ($kullaniciAdi)',
              style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey600)),
        ),
        build: (context) => [
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.center,
            children: [
              pw.Image(logo, width: 44, height: 44),
              pw.SizedBox(width: 10),
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text('Seray Sağlık Asistanım', style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
                  pw.Text('Ölçüm Raporu (Son 30 Gün) - $kullaniciAdi', style: const pw.TextStyle(fontSize: 10)),
                  pw.SizedBox(height: 2),
                  versiyonEtiketi,
                ],
              ),
            ],
          ),
          pw.SizedBox(height: 4),
          pw.Text(
            'Oklar: ↑ yüksek/hedef üstü  ↓ düşük/hedef altı  → normal  ⚠ acil değer',
            style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey600),
          ),
          pw.SizedBox(height: 10),
          for (final grup in _listeyiBol(satirlar, 30))
            pw.Table(
              border: pw.TableBorder.all(color: PdfColors.grey400, width: 0.5),
              columnWidths: altiEsitSutun,
              children: [
                pw.TableRow(
                  decoration: const pw.BoxDecoration(color: PdfColors.grey300),
                  children: ['Tarih', 'Şeker', 'Tansiyon', 'Su', 'Kilo', 'Adım']
                      .map((baslik) => pw.Padding(
                            padding: const pw.EdgeInsets.all(4),
                            child: pw.Text(baslik, style: pw.TextStyle(fontSize: 8, fontWeight: pw.FontWeight.bold)),
                          ))
                      .toList(),
                ),
                for (final satir in grup)
                  pw.TableRow(
                    children: satir
                        .map((hucre) => pw.Padding(
                              padding: const pw.EdgeInsets.all(4),
                              child: pw.Text(hucre, style: const pw.TextStyle(fontSize: 7.5)),
                            ))
                        .toList(),
                  ),
              ],
            ),
        ],
      ),
    );

    final gecici = await getTemporaryDirectory();
    final dosyaYolu = '${gecici.path}/seray_olcum_raporu_${_tarihSaatEki()}.pdf';
    final dosyaAdi = 'seray_olcum_raporu_${_tarihSaatEki()}.pdf';
    final dosya = File(dosyaYolu);
    await dosya.writeAsBytes(await belge.save());

    await Share.shareXFiles([XFile(dosyaYolu, name: dosyaAdi)], text: 'Seray Sağlık Asistanım - Ölçüm Raporu');
  }  // --- gunlukRaporuOlusturVePaylas() sonu ---

  // İLAÇLARIM LİSTESİ (Doktora Götürmek İçin) — bazı doktorlar e-Nabız'dan
  // bakmak yerine hastadan "kullandığın ilaçları getir" diye istiyor; bu PDF
  // tam olarak o ihtiyaç için: sade, tek sayfalık, ilaç adı+doz+saat listesi.
  static Future<void> ilaclarListesiOlusturVePaylas({required String kullaniciAdi}) async {
    final ilaclar = await VeritabaniYardimcisi().ilaclariGetir();

    final logoBaytlari = await rootBundle.load('assets/images/app_logo.png');
    final logo = pw.MemoryImage(logoBaytlari.buffer.asUint8List());
    final normalFontBaytlari = await rootBundle.load('assets/fonts/DejaVuSans.ttf');
    final kalinFontBaytlari = await rootBundle.load('assets/fonts/DejaVuSans-Bold.ttf');
    final normalFont = pw.Font.ttf(normalFontBaytlari);
    final kalinFont = pw.Font.ttf(kalinFontBaytlari);

    final belge = pw.Document(theme: pw.ThemeData.withFont(base: normalFont, bold: kalinFont));
    final versiyonEtiketi = await _versiyonEtiketi();
    final simdi = DateTime.now();
    String iki(int n) => n.toString().padLeft(2, '0');

    belge.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        header: (context) => pw.Container(
          padding: const pw.EdgeInsets.only(bottom: 6),
          child: pw.Text('Seray Sağlık Asistanım — Kullandığım İlaçlar ($kullaniciAdi)',
              style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey600)),
        ),
        build: (context) => [
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.center,
            children: [
              pw.Image(logo, width: 50, height: 50),
              pw.SizedBox(width: 12),
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text('Seray Sağlık Asistanım', style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold)),
                  pw.Text('Kullandığım İlaçlar - $kullaniciAdi'),
                  pw.Text('Çıktı tarihi: ${iki(simdi.day)}.${iki(simdi.month)}.${simdi.year} ${iki(simdi.hour)}:${iki(simdi.minute)}', style: const pw.TextStyle(fontSize: 9)),
                  pw.SizedBox(height: 2),
                  versiyonEtiketi,
                ],
              ),
            ],
          ),
          pw.SizedBox(height: 20),
          for (final satirBlogu in _listeyiBol(
            ilaclar.map((i) => [
              '${i['ad'] ?? '-'}',
              '${i['dozaj'] ?? '-'} ${i['birim'] ?? ''}',
              '${i['tip'] ?? 'Hap'}',
              '${i['saat'] ?? '-'}',
            ]).toList(),
            25,
          ))
            pw.Table.fromTextArray(
              columnWidths: {0: const pw.FlexColumnWidth(1.6), 1: const pw.FlexColumnWidth(1), 2: const pw.FlexColumnWidth(0.8), 3: const pw.FlexColumnWidth(1)},
              headers: ['İlaç Adı', 'Dozaj', 'Tip', 'Kullanım Saati'],
              data: satirBlogu,
            ),
          pw.SizedBox(height: 16),
          pw.Text(
            'Bu liste Seray Sağlık Asistanım uygulamasında kayıtlı ilaçlardan otomatik oluşturulmuştur.',
            style: pw.TextStyle(fontSize: 9, color: PdfColor.fromInt(0xFF888888)),
          ),
        ],
      ),
    );

    final gecici = await getTemporaryDirectory();
    final dosyaYolu = '${gecici.path}/seray_ilaclarim${_dosyaAdiEki(kullaniciAdi)}.pdf';
    final dosya = File(dosyaYolu);
    await dosya.writeAsBytes(await belge.save());

    await Share.shareXFiles([XFile(dosyaYolu, name: 'seray_ilaclarim${_dosyaAdiEki(kullaniciAdi)}.pdf')], text: 'Seray Sağlık Asistanım - Kullandığım İlaçlar Listesi');
  }  // --- ilaclarListesiOlusturVePaylas() sonu ---
  // secilenYil verilirse (örn. 2025), sadece o yıla ait tarih sütunları basılır.
  // null ise tüm yıllar (mevcut davranış).
  static Future<void> enabizRaporuOlusturVePaylas({
    required Map<String, Map<String, String>> tabloVerisi,
    required List<String> tarihSutunlari,
    required String kullaniciAdi,
    int? secilenYil,
    String? filtreEtiketi, // "Ref Dışı Sonuçlar" / "Normal Sonuçlar" gibi — sadece filtreli çıktıda kullanılır
  }) async {
    // Yıl filtresi: tarih formatı GG.AA.YYYY, son parça yıl.
    final filtreliTarihler = secilenYil == null
        ? tarihSutunlari
        : tarihSutunlari.where((t) {
            final parcalar = t.split('.');
            if (parcalar.length != 3) return false;
            return int.tryParse(parcalar[2]) == secilenYil;
          }).toList();

    final logoBaytlari = await rootBundle.load('assets/images/app_logo.png');
    final logo = pw.MemoryImage(logoBaytlari.buffer.asUint8List());
    final normalFontBaytlari = await rootBundle.load('assets/fonts/DejaVuSans.ttf');
    final kalinFontBaytlari = await rootBundle.load('assets/fonts/DejaVuSans-Bold.ttf');
    final normalFont = pw.Font.ttf(normalFontBaytlari);
    final kalinFont = pw.Font.ttf(kalinFontBaytlari);
    final versiyonEtiketi = await _versiyonEtiketi();

    final belge = pw.Document(theme: pw.ThemeData.withFont(base: normalFont, bold: kalinFont));

    // ÖNEMLİ DEĞİŞİKLİK: önceden sayfa başına HER ZAMAN sabit 3 tarih sütunu
    // basılıyordu — tahlil adları kısa/uzun, değerler kısa/uzun olsun fark
    // etmiyordu. Artık sayfa başına kaç sütun sığacağı, GERÇEK verideki en
    // uzun tahlil adı ve en uzun değer metnine göre HESAPLANIYOR: isimler/
    // değerler kısaysa daha çok sütun (daha az sayfa), uzunsa daha az sütun
    // (okunaklılık için) sığdırılıyor.
    const double sayfaKullanilabilirGenislik = 515.0; // A4 dikey, kenar boşlukları düşülmüş (pt)
    const double harfBasinaPuan = 5.2; // ~9-10pt font için kaba ortalama karakter genişliği

    int enUzunAdKarakteri = 'Tahlil Adı / Referans'.length;
    int enUzunDegerKarakteri = 4;
    for (final entry in tabloVerisi.entries) {
      final kisaAd = _tahlilAdiniKisalt(entry.key);
      final ref = entry.value['_ref'] ?? '-';
      final adUzunlugu = kisaAd.length > (ref.length + 6) ? kisaAd.length : (ref.length + 6); // "(Ref: X)" payı
      if (adUzunlugu > enUzunAdKarakteri) enUzunAdKarakteri = adUzunlugu;
      entry.value.forEach((tarih, deger) {
        if (tarih == '_ref' || tarih == '_kategori') return;
        if (deger.length > enUzunDegerKarakteri) enUzunDegerKarakteri = deger.length;
      });
    }

    final ilkSutunGenislikPt = (enUzunAdKarakteri * harfBasinaPuan).clamp(110.0, 190.0);
    final degerSutunGenislikPt = (enUzunDegerKarakteri * harfBasinaPuan).clamp(55.0, 130.0);
    final hesaplananSutun = ((sayfaKullanilabilirGenislik - ilkSutunGenislikPt) / degerSutunGenislikPt).floor();
    final int sayfaBasiMaksSutun = hesaplananSutun.clamp(1, 8);

    if (filtreliTarihler.isEmpty) {
      belge.addPage(
        pw.Page(
          pageFormat: PdfPageFormat.a4,
          build: (context) => pw.Center(
            child: pw.Text(secilenYil == null
                ? 'Gösterilecek tahlil bulunamadı.'
                : '$secilenYil yılına ait tahlil bulunamadı.'),
          ),
        ),
      );
    }

    for (int i = 0; i < filtreliTarihler.length; i += sayfaBasiMaksSutun) {
      final altTarihler = filtreliTarihler.sublist(
        i,
        (i + sayfaBasiMaksSutun < filtreliTarihler.length) ? i + sayfaBasiMaksSutun : filtreliTarihler.length
      );

      // Sütun genişlikleri artık yukarıda hesaplanan gerçek karakter
      // uzunluklarına göre — ilk sütun (Tahlil Adı/Referans) ile değer
      // sütunları arasındaki oran veriye göre değişiyor, sabit değil.
      final sutunGenislikleri = <int, pw.TableColumnWidth>{
        0: pw.FlexColumnWidth(ilkSutunGenislikPt / degerSutunGenislikPt),
        for (int s = 0; s < altTarihler.length; s++) (s + 1): const pw.FlexColumnWidth(1),
      };

      final simdi = DateTime.now();
      String iki(int n) => n.toString().padLeft(2, '0');
      final olusturmaZamani = '${iki(simdi.day)}.${iki(simdi.month)}.${simdi.year} ${iki(simdi.hour)}:${iki(simdi.minute)}';

      belge.addPage(
        pw.MultiPage(
          pageFormat: PdfPageFormat.a4, // Dikey A4 — önceden yataydı, kullanıcı dikey istedi
          header: (context) => pw.Container(
            padding: const pw.EdgeInsets.only(bottom: 6),
            child: pw.Text('Seray Sağlık Asistanım — e-Nabız Tahlil Matrisi ($kullaniciAdi)',
                style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey600)),
          ),
          build: (context) => [
            pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
              children: [
                pw.Row(
                  children: [
                    pw.Image(logo, width: 40, height: 40),
                    pw.SizedBox(width: 10),
                    pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                      children: [
                        pw.Text('Seray Sağlık Asistanım - e-Nabız Tahlil Matrisi', style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
                        pw.Text('Hasta: $kullaniciAdi${secilenYil != null ? " — $secilenYil" : ""} ${filtreliTarihler.length > sayfaBasiMaksSutun ? "(Sayfa ${(i ~/ sayfaBasiMaksSutun) + 1})" : ""}'),
                        if (filtreEtiketi != null)
                          pw.Text(filtreEtiketi, style: pw.TextStyle(fontSize: 10, fontWeight: pw.FontWeight.bold, color: PdfColor.fromInt(AppRenkleri.aktif.value))),
                        pw.Text('Rapor çıktı tarihi: $olusturmaZamani', style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700)),
                        pw.SizedBox(height: 2),
                        versiyonEtiketi,
                      ],
                    ),
                  ],
                ),
              ],
            ),
            pw.SizedBox(height: 14),
            // ONEMLI DUZELTME: Tek bir dev pw.Table.fromTextArray, cok
            // satirli (ozellikle "Tum Sonuclar"/"Ref Disi" gibi genis
            // filtrelerde onlarca satir olabiliyor) verilerde "widget
            // sayfaya sigmiyor" hatasi veriyordu. Artik tablo, her biri
            // en fazla ~22 satirlik KUCUK parcalara bolunup ayri tablolar
            // olarak veriliyor.
            // ÖNEMLİ DÜZELTME: "Ref Dışı" gibi filtrelerde satır içeriği
            // (uzun tahlil adı + referans aralığı birlikte) normalden daha
            // fazla yer kaplayabiliyor — 22 satırlık blok bazı durumlarda
            // hâlâ sayfaya sığmıyordu ("widget sayfaya sığmıyor" hatası).
            // Güvenli payla 16'ya düşürüldü.
            for (final satirBlogu in _listeyiBol(
              tabloVerisi.entries.map((entry) {
                final kisaltilmisAd = _tahlilAdiniKisalt(entry.key);
                final ref = entry.value["_ref"] ?? "-";
                final adVeRef = '$kisaltilmisAd\n(Ref: $ref)';
                return [adVeRef, ...altTarihler.map((t) => entry.value[t] ?? "-")];
              }).toList(),
              16,
            ))
              pw.Table.fromTextArray(
                columnWidths: sutunGenislikleri,
                border: pw.TableBorder.all(color: PdfColors.grey300, width: 0.5),
                headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10, color: PdfColors.white),
                headerDecoration: pw.BoxDecoration(color: PdfColor.fromInt(AppRenkleri.aktif.value)),
                cellStyle: const pw.TextStyle(fontSize: 9),
                cellAlignment: pw.Alignment.center,
                headers: ['Tahlil Adı / Referans', ...altTarihler.map(_tarihiKisalt)],
                data: satirBlogu,
                // ÖNEMLİ: Kullanıcı fark etti — ref dışı değerlerin arka
                // planı hep beyazdı. Sütun 0 hariç (o isim/referans
                // sütunu), her hücrenin değerini o satırın referans
                // aralığıyla karşılaştırıp ref dışıysa açık kırmızı zemin
                // veriyoruz.
                cellDecoration: (columnIndex, data, rowNum) {
                  if (columnIndex == 0) return null;
                  final adVeRef = (data as List)[0].toString();
                  final refEslesme = RegExp(r'\(Ref: (.+)\)').firstMatch(adVeRef);
                  final ref = refEslesme?.group(1) ?? '-';
                  final hucreDegeri = data[columnIndex].toString();
                  if (hucreDegeri == '-' || hucreDegeri.trim().isEmpty) return null;
                  if (_degerRefDisinda(hucreDegeri, ref)) {
                    // ÖNEMLİ: Ekrandaki (yapay_zeka_ekrani.dart) ref dışı
                    // vurgusu shade300 (0xFFE57373) — kullanıcı "shade50/
                    // 100 belli olmuyor" demişti. PDF/print çıktısı da
                    // AYNI koyulukta olmalı, önceki çok açık renk (0xFFFFEBEE)
                    // ekranla tutarsızdı, düzeltildi.
                    return const pw.BoxDecoration(color: PdfColor.fromInt(0xFFE57373));
                  }
                  return null;
                },
              ),
          ],
        ),
      );
    }

    final gecici = await getTemporaryDirectory();
    final yilEki = secilenYil != null ? '_$secilenYil' : '';
    final filtreEki = filtreEtiketi != null ? (filtreEtiketi.contains('Ref') ? '_RefDisi' : '_Normal') : '';
    final dosyaYolu = '${gecici.path}/e-Nabiz_Tum_Tahliller_Raporu${_dosyaAdiEki(kullaniciAdi)}$yilEki$filtreEki.pdf';
    final dosya = File(dosyaYolu);
    await dosya.writeAsBytes(await belge.save());

    await Share.shareXFiles([XFile(dosyaYolu, name: 'e-Nabiz_Tum_Tahliller_Raporu${_dosyaAdiEki(kullaniciAdi)}$yilEki$filtreEki.pdf')], text: 'Seray Sağlık Asistanım - e-Nabız Tahlil Sonuçları${filtreEtiketi != null ? " ($filtreEtiketi)" : ""}');
  }

  // Tek bir AI analizini (genel ya da belirli bir tarihe ait) sade, "yazıcı
  // çıktısı" görünümlü bir PDF olarak paylaşır: üstte hasta adı + tarih,
  // altında analiz metni — başka hiçbir şey yok.
  static Future<void> analizRaporuOlusturVePaylas({
    required String kullaniciAdi,
    required String baslik,
    required String analizMetni,
  }) async {
    final normalFontBaytlari = await rootBundle.load('assets/fonts/DejaVuSans.ttf');
    final kalinFontBaytlari = await rootBundle.load('assets/fonts/DejaVuSans-Bold.ttf');
    final normalFont = pw.Font.ttf(normalFontBaytlari);
    final kalinFont = pw.Font.ttf(kalinFontBaytlari);
    final versiyonEtiketi = await _versiyonEtiketi();

    final simdi = DateTime.now();
    String iki(int n) => n.toString().padLeft(2, '0');
    final bugununTarihi = '${iki(simdi.day)}.${iki(simdi.month)}.${(simdi.year % 100).toString().padLeft(2, '0')}';

    final belge = pw.Document(theme: pw.ThemeData.withFont(base: normalFont, bold: kalinFont));
    // ÖNEMLİ DÜZELTME: Metin tek büyük bir pw.Text widget'ı olarak
    // verildiğinde, "Genel AI Analizi" gibi çok uzun analizlerde
    // (özellikle artık TÜM sonuçları kapsadığı için daha da uzun) pdf
    // paketi bunu tek bir bölünemez blok gibi ele alıp "widget sayfaya
    // sığmıyor" hatası veriyordu. Metni paragraf paragraf (boş satırlara
    // göre) AYRI Text widget'larına bölünce, MultiPage her paragrafı
    // ayrı ayrı sayfalar arasında bölebiliyor.
    final paragraflar = analizMetni.split(RegExp(r'\n\s*\n')).where((p) => p.trim().isNotEmpty).toList();
    belge.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        // ÖNEMLİ: TÜM PDF çıktılarında ortak — her sayfanın en üstünde
        // hangi rapora ait olduğu tekrar yazılıyor.
        header: (context) => pw.Container(
          padding: const pw.EdgeInsets.only(bottom: 6),
          child: pw.Text('Seray Sağlık Asistanım — $baslik ($kullaniciAdi)',
              style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey600)),
        ),
        build: (context) => [
          pw.Text(kullaniciAdi.trim().isNotEmpty ? kullaniciAdi : 'Hasta', style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
          pw.Text(bugununTarihi, style: const pw.TextStyle(fontSize: 11, color: PdfColors.grey700)),
          pw.SizedBox(height: 4),
          pw.Divider(),
          pw.SizedBox(height: 10),
          pw.Text(baslik, style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 8),
          for (final paragraf in (paragraflar.isEmpty ? [analizMetni] : paragraflar)) ...[
            pw.Text(paragraf.trim(), style: const pw.TextStyle(fontSize: 11, lineSpacing: 3)),
            pw.SizedBox(height: 8),
          ],
          pw.SizedBox(height: 16),
          versiyonEtiketi,
        ],
      ),
    );

    final gecici = await getTemporaryDirectory();
    final dosyaAdi = 'seray_${_konuSlug(baslik)}_${_tarihSaatEki()}.pdf';
    final dosyaYolu = '${gecici.path}/$dosyaAdi';
    final dosya = File(dosyaYolu);
    await dosya.writeAsBytes(await belge.save());

    await Share.shareXFiles([XFile(dosyaYolu, name: dosyaAdi)], text: 'Seray Sağlık Asistanım - $baslik');
  }  // --- analizRaporuOlusturVePaylas() sonu ---

  // ÖNEMLİ: Kullanıcı istedi — Yazdır butonu artık Paylaş penceresi üzerinden
  // dolaylı değil, DOĞRUDAN sistemin yazdırma ekranını açıyor (Printing
  // paketi ile). PDF oluşturma mantığı analizRaporuOlusturVePaylas ile
  // AYNI — sadece son adımda dosyaya yazıp paylaşmak yerine Printing.
  // layoutPdf() ile doğrudan yazıcı seçim ekranına gönderiliyor.
  static Future<void> analizRaporuYazdir({
    required String kullaniciAdi,
    required String baslik,
    required String analizMetni,
  }) async {
    final normalFontBaytlari = await rootBundle.load('assets/fonts/DejaVuSans.ttf');
    final kalinFontBaytlari = await rootBundle.load('assets/fonts/DejaVuSans-Bold.ttf');
    final normalFont = pw.Font.ttf(normalFontBaytlari);
    final kalinFont = pw.Font.ttf(kalinFontBaytlari);
    final versiyonEtiketi = await _versiyonEtiketi();

    final simdi = DateTime.now();
    String iki(int n) => n.toString().padLeft(2, '0');
    final bugununTarihi = '${iki(simdi.day)}.${iki(simdi.month)}.${(simdi.year % 100).toString().padLeft(2, '0')}';

    final belge = pw.Document(theme: pw.ThemeData.withFont(base: normalFont, bold: kalinFont));
    final paragraflar = analizMetni.split(RegExp(r'\n\s*\n')).where((p) => p.trim().isNotEmpty).toList();
    belge.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        header: (context) => pw.Container(
          padding: const pw.EdgeInsets.only(bottom: 6),
          child: pw.Text('Seray Sağlık Asistanım — $baslik ($kullaniciAdi)',
              style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey600)),
        ),
        build: (context) => [
          pw.Text(kullaniciAdi.trim().isNotEmpty ? kullaniciAdi : 'Hasta', style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
          pw.Text(bugununTarihi, style: const pw.TextStyle(fontSize: 11, color: PdfColors.grey700)),
          pw.SizedBox(height: 4),
          pw.Divider(),
          pw.SizedBox(height: 10),
          pw.Text(baslik, style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 8),
          for (final paragraf in (paragraflar.isEmpty ? [analizMetni] : paragraflar)) ...[
            pw.Text(paragraf.trim(), style: const pw.TextStyle(fontSize: 11, lineSpacing: 3)),
            pw.SizedBox(height: 8),
          ],
          pw.SizedBox(height: 16),
          versiyonEtiketi,
        ],
      ),
    );

    final dosyaAdi = 'seray_${_konuSlug(baslik)}_${_tarihSaatEki()}.pdf';
    await Printing.layoutPdf(
      onLayout: (format) async => belge.save(),
      name: dosyaAdi,
    );
  }  // --- analizRaporuYazdir() sonu ---
}
