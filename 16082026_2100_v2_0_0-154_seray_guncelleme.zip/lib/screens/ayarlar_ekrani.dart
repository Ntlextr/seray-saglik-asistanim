import 'dart:async';
import '../theme/renkler.dart';
import '../theme/sablon.dart';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:package_info_plus/package_info_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/bildirim_servisi.dart';
import '../services/saglik_baglantisi_servisi.dart';
import '../services/adim_servisi.dart';
import '../services/veritabani_yardimcisi.dart';
import '../services/profil_yoneticisi.dart';
import '../services/profil_sabitleri.dart';
import '../navigasyon_anahtari.dart';
import '../main.dart' show AnaEkranYonlendirici;
import 'profil_kayit_ekrani.dart';
import '../services/ses_servisi.dart';
import 'kritik_izinler_ekrani.dart';
import 'tanitim_turu_ekrani.dart';
import 'pin_kilit_ekrani.dart';
import 'package:local_auth/local_auth.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import '../services/crash_servisi.dart';

class AyarlarEkrani extends StatefulWidget {
  const AyarlarEkrani({Key? key}) : super(key: key);
  @override
  State<AyarlarEkrani> createState() => _AyarlarEkraniState();
}

class _AyarlarEkraniState extends State<AyarlarEkrani> {
  @override
  void dispose() {
    _acilKisiAdController.dispose();
    _acilKisiTelefonController.dispose();
    super.dispose();
  }  // --- dispose() sonu ---

  List<Map<String, String>> _sesler = [];
  String? _secilenSesAdi;
  double _hiz = SesServisi.varsayilanHiz;
  bool _seslerYukleniyor = true;
  String _nabizYontemi = 'fft'; // 'basit' | 'fft'

  // KVKK ve Hakkında metinleri artık Cloudflare'den çekiliyor — böylece
  // metni güncellemek için yeni bir APK yayınlamaya gerek kalmıyor.
  // İnternet yoksa uygulamanın içindeki yedek (fallback) metin gösterilir.
  String _kvkkMetni = _yerelKvkkYedek;
  String? _hakkindaAciklama;
  // YENİ: WhatsApp grup linki artık worker.js'den çekiliyor (link
  // sıfırlanırsa APK basmaya gerek kalmasın diye) — internet yoksa bu
  // sabit değer (en son bilinen link) yedek olarak kullanılır.
  String _whatsappGrupLinki = 'https://chat.whatsapp.com/GJpkqz6HC1c6w3kKM2QINE?s=cl&p=a&ilr=4';
  bool _pinAktif = false;
  bool _biyometriAktif = false;
  final _acilKisiAdController = TextEditingController();
  final _acilKisiTelefonController = TextEditingController();
  bool _haftalikOzetAktif = false;
  // AİLE TAKİBİ: profil listesi ve aktif profil.
  List<ProfilBilgisi> _profiller = [];
  String _aktifProfilId = ProfilSabitleri.varsayilanProfilId;

  @override
  void initState() {
    super.initState();
    _sesAyarlariniYukle();
    _icerigiCloudflaredanCek();
    _pinDurumunuYukle();
    _acilKisiyiYukle();
    _haftalikOzetDurumunuYukle();
    _profilleriYukle();
  }  // --- initState() sonu ---

  Future<void> _profilleriYukle() async {
    final liste = await ProfilYoneticisi().profilleriGetir();
    final aktif = await ProfilYoneticisi().aktifProfilId();
    if (mounted) {
      setState(() {
        _profiller = liste;
        _aktifProfilId = aktif;
      });
    }
  }  // --- _profilleriYukle() sonu ---

  // Yeni profil ekleme dialogu — isim sorulur, eklenince hemen o profile
  // geçmek isteyip istemediği sorulur.
  Future<void> _yeniProfilEkleDialogu() async {
    final controller = TextEditingController();
    final ad = await showDialog<String>(
      context: context,
      builder: (d) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Yeni Profil Ekle'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(labelText: 'Kişinin Adı (örn. Annem)'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d), child: const Text('Vazgeç')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppRenkleri.aktif),
            onPressed: () => Navigator.pop(d, controller.text.trim()),
            child: const Text('Ekle', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
    if (ad == null || ad.isEmpty) return;
    final yeni = await ProfilYoneticisi().profilEkle(ad);
    await _profilleriYukle();
    if (!mounted) return;
    final gecMi = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Profil Eklendi'),
        content: Text('"${yeni.ad}" profili eklendi. Şimdi bu profile geçmek ister misiniz?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Sonra')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppRenkleri.aktif),
            onPressed: () => Navigator.pop(d, true),
            child: const Text('Bu Profile Geç', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
    if (gecMi == true) await _profileGec(yeni.id);
  }  // --- _yeniProfilEkleDialogu() sonu ---

  // AİLE TAKİBİ: profil değiştirince veritabanı bağlantısı sıfırlanıyor —
  // ekranı en baştan tazelemek için TÜM navigasyon geçmişini temizleyip
  // yeniden başlıyoruz. Aksi hâlde eski profilin verileriyle açık kalan
  // ekranlar kafa karıştırırdı.
  //
  // ÖNEMLİ: Sadece profil YENİ OLUŞTURULDUĞUNDA değil, kullanıcı "Sonra"
  // deyip daha sonra listeden "Geç" ile geçtiğinde de aynı kontrol
  // uygulanır — geçilen profilin adı/yaşı/boyu HÂLÂ hiç girilmemişse
  // (yani ilk kez kullanılıyorsa), direkt Ana Sayfa yerine önce Profil
  // Kaydı ekranı açılır. Zaten bilgileri dolu bir profile geçerken bu
  // adım atlanır, direkt Ana Sayfa'ya gidilir.
  Future<void> _profileGec(String profilId) async {
    if (profilId == _aktifProfilId) return;
    await ProfilYoneticisi().aktifProfiliDegistir(profilId);
    if (!mounted) return;

    final prefs = await SharedPreferences.getInstance();
    final adAnahtari = await ProfilYoneticisi().profilAnahtari('kullanici_ad');
    final kimlikBosMu = (prefs.getString(adAnahtari) ?? '').trim().isEmpty;

    if (kimlikBosMu) {
      navigasyonAnahtari.currentState?.pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const ProfilKayitEkrani()),
        (route) => false,
      );
      return;
    }
    navigasyonAnahtari.currentState?.pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const AnaEkranYonlendirici()),
      (route) => false,
    );
  }  // --- _profileGec() sonu ---

  Future<void> _profilSilOnayi(ProfilBilgisi profil) async {
    final onay = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Profili Sil'),
        content: Text(
          '"${profil.ad}" profilini ve TÜM verilerini (ölçümler, ilaçlar, tahliller) '
          'kalıcı olarak silmek istediğinize emin misiniz? Bu işlem GERİ ALINAMAZ.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Vazgeç')),
          TextButton(
            onPressed: () => Navigator.pop(d, true),
            child: const Text('Sil', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
    if (onay != true) return;
    final oncekiAktif = _aktifProfilId;
    final basarili = await ProfilYoneticisi().profilSil(profil.id);
    if (!basarili && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('En az bir profil kalmalı, son profil silinemez.')),
      );
      return;
    }
    await _profilleriYukle();
    // Sadece silinen profil AKTİF olansa, ekranı en baştan tazelemek
    // gerekir (aktif veritabanı değişti demektir). Aktif olmayan bir
    // profil silindiyse sadece liste güncellenir, Ayarlar'da kalınır.
    if (oncekiAktif == profil.id && mounted) {
      navigasyonAnahtari.currentState?.pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const AnaEkranYonlendirici()),
        (route) => false,
      );
    }
  }  // --- _profilSilOnayi() sonu ---

  Future<void> _haftalikOzetDurumunuYukle() async {
    final prefs = await SharedPreferences.getInstance();
    if (mounted) setState(() => _haftalikOzetAktif = prefs.getBool('haftalik_ozet_aktif') ?? false);
  }  // --- _haftalikOzetDurumunuYukle() sonu ---

  Future<void> _haftalikOzetDegistir(bool acilsinMi) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('haftalik_ozet_aktif', acilsinMi);
    if (acilsinMi) {
      await BildirimServisi.haftalikOzetHatirlaticisiKur();
    } else {
      await BildirimServisi.haftalikOzetHatirlaticisiniIptalEt();
    }
    if (mounted) setState(() => _haftalikOzetAktif = acilsinMi);
  }  // --- _haftalikOzetDegistir() sonu ---

  // Basit, AI kullanmayan (anında, ücretsiz) istatistik özeti — bildirimin
  // yönlendirdiği yer burası. "Haftalık İçgörü" (Analizler'deki AI yorumu)
  // ile karıştırılmamalı, o ayrı ve daha derin bir analiz.
  Future<void> _haftalikOzetiGoster() async {
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Bu Haftaki Özetiniz'),
        content: FutureBuilder<String>(
          future: _haftalikOzetMetniHesapla(),
          builder: (context, snapshot) {
            if (!snapshot.hasData) {
              return const SizedBox(height: 60, child: Center(child: CircularProgressIndicator()));
            }
            return Text(snapshot.data!, style: const TextStyle(fontSize: 14, height: 1.5));
          },
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Kapat'))],
      ),
    );
  }  // --- _haftalikOzetiGoster() sonu ---

  Future<String> _haftalikOzetMetniHesapla() async {
    final yediGunOnce = DateTime.now().subtract(const Duration(days: 7));
    bool sonrasiMi(String? tarih) {
      if (tarih == null) return false;
      final t = DateTime.tryParse(tarih);
      return t != null && t.isAfter(yediGunOnce);
    }

    final sekerler = (await VeritabaniYardimcisi().sekerleriGetir())
        .where((s) => sonrasiMi(s['tarih']?.toString()))
        .toList();
    final suKayitlari = (await VeritabaniYardimcisi().suKayitlariniGetir())
        .where((s) => sonrasiMi(s['tarih']?.toString()))
        .toList();
    final kiloKayitlari = await VeritabaniYardimcisi().kiloKayitlariniGetir();
    final adimGecmisi = await AdimServisi.sonYediGunGetir();

    final sb = StringBuffer();
    if (sekerler.isNotEmpty) {
      final ortalama = sekerler.map((s) => (s['deger'] as num).toDouble()).reduce((a, b) => a + b) / sekerler.length;
      sb.writeln('🩸 Ortalama şeker: ${ortalama.toStringAsFixed(0)} mg/dL (${sekerler.length} ölçüm)');
    } else {
      sb.writeln('🩸 Bu hafta şeker ölçümü kaydedilmemiş.');
    }
    if (adimGecmisi.isNotEmpty) {
      final toplamAdim = adimGecmisi.fold<int>(0, (t, e) => t + e.value);
      sb.writeln('🚶 Toplam adım: $toplamAdim');
    }
    final suGunSayisi = suKayitlari.map((s) => (s['tarih'] ?? '').toString().split('T').first).toSet().length;
    sb.writeln('💧 Su kaydı girilen gün sayısı: $suGunSayisi / 7');
    if (kiloKayitlari.length >= 2) {
      final fark = (kiloKayitlari.first['kilo'] as num) - (kiloKayitlari.last['kilo'] as num);
      sb.writeln('⚖️ Kilo değişimi (kayıtlı ölçümler arası): ${fark.toStringAsFixed(1)} kg');
    }
    return sb.toString();
  }  // --- _haftalikOzetMetniHesapla() sonu ---

  Future<void> _acilKisiyiYukle() async {
    final prefs = await SharedPreferences.getInstance();
    final py = ProfilYoneticisi();
    _acilKisiAdController.text = prefs.getString(await py.profilAnahtari('acil_kisi_ad')) ?? '';
    _acilKisiTelefonController.text = prefs.getString(await py.profilAnahtari('acil_kisi_telefon')) ?? '';
  }  // --- _acilKisiyiYukle() sonu ---

  Future<void> _acilKisiyiKaydet() async {
    final prefs = await SharedPreferences.getInstance();
    final py = ProfilYoneticisi();
    await prefs.setString(await py.profilAnahtari('acil_kisi_ad'), _acilKisiAdController.text.trim());
    await prefs.setString(await py.profilAnahtari('acil_kisi_telefon'), _acilKisiTelefonController.text.trim());
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Acil durum kişisi kaydedildi.')),
      );
    }
  }  // --- _acilKisiyiKaydet() sonu ---

  Future<void> _pinDurumunuYukle() async {
    final prefs = await SharedPreferences.getInstance();
    if (mounted) {
      setState(() {
        _pinAktif = prefs.getBool('pin_kilit_aktif') ?? false;
        _biyometriAktif = prefs.getBool('biyometri_aktif') ?? false;
      });
    }
  }  // --- _pinDurumunuYukle() sonu ---

  Future<void> _biyometriDegistir(bool acilsinMi) async {
    if (acilsinMi) {
      // Açmadan önce gerçekten bir kez parmak izi doğrulatıyoruz — hem
      // cihazda parmak izi kayıtlı mı diye test etmiş oluyoruz hem de
      // kullanıcı "açtım ama çalışmıyor" şaşkınlığı yaşamıyor.
      try {
        final auth = LocalAuthentication();
        final destekleniyorMu = await auth.isDeviceSupported();
        final kayitliVarMi = await auth.canCheckBiometrics;
        if (!destekleniyorMu || !kayitliVarMi) {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Bu cihazda kayıtlı parmak izi/yüz tanıma bulunamadı. Önce telefon Ayarları\'ndan ekleyin.')),
            );
          }
          return;
        }
        final basarili = await auth.authenticate(
          localizedReason: 'Parmak izi kilidini açmak için doğrulayın',
          options: const AuthenticationOptions(biometricOnly: true),
        );
        if (!basarili) return;
      } catch (e) {
        if (mounted) {
          showDialog(
            context: context,
            builder: (dialogContext) => AlertDialog(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              title: const Text('Parmak İzi Hatası'),
              content: SelectableText(e.toString()),
              actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Kapat'))],
            ),
          );
        }
        return;
      }
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('biyometri_aktif', acilsinMi);
    if (mounted) setState(() => _biyometriAktif = acilsinMi);
  }  // --- _biyometriDegistir() sonu ---

  // Anahtar açılırken yeni PIN belirletir, kapatılırken önce mevcut PIN'i
  // doğrulatır (böylece kilidi telefonu ele geçiren biri sessizce kapatamaz).
  void _pinKilidiDegistir(bool acilsinMi) {
    if (acilsinMi) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => PinKilitEkrani(
            mod: PinKilitModu.belirle,
            onBasarili: () {
              if (mounted) setState(() => _pinAktif = true);
              Navigator.pop(context);
            },
            onVazgec: () => Navigator.pop(context),
          ),
        ),
      );
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => PinKilitEkrani(
            mod: PinKilitModu.dogrula,
            onBasarili: () async {
              final prefs = await SharedPreferences.getInstance();
              await prefs.setBool('pin_kilit_aktif', false);
              await prefs.setBool('biyometri_aktif', false);
              if (mounted) setState(() { _pinAktif = false; _biyometriAktif = false; });
              if (mounted) Navigator.pop(context);
            },
            onVazgec: () => Navigator.pop(context),
          ),
        ),
      );
    }
  }  // --- _pinKilidiDegistir() sonu ---

  Future<void> _icerigiCloudflaredanCek() async {
    try {
      final response = await http
          .get(Uri.parse('https://empty-union-ce11.serdarcirak.workers.dev/icerik'))
          .timeout(const Duration(seconds: 8));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (mounted) {
          setState(() {
            _kvkkMetni = data['kvkk'] ?? _yerelKvkkYedek;
            _hakkindaAciklama = data['hakkinda'];
            _whatsappGrupLinki = data['whatsapp_grup'] ?? _whatsappGrupLinki;
          });
        }
      }
    } catch (_) {
      // İnternet yoksa veya sunucuya ulaşılamazsa, uygulamanın içindeki
      // yedek metin zaten gösteriliyor — kullanıcı hiçbir hata görmez.
    }
  }  // --- _icerigiCloudflaredanCek() sonu ---

  Future<void> _sesAyarlariniYukle() async {
    final prefs = await SharedPreferences.getInstance();
    final sesler = await SesServisi.turkceSesleriGetir();
    if (mounted) {
      setState(() {
        _sesler = sesler;
        _secilenSesAdi = prefs.getString('tts_ses_adi');
        _hiz = prefs.getDouble('tts_hiz') ?? SesServisi.varsayilanHiz;
        _nabizYontemi = prefs.getString('nabiz_yontemi') ?? 'fft';
        _seslerYukleniyor = false;
      });
    }
  }  // --- _sesAyarlariniYukle() sonu ---

  Future<void> _nabizYontemiDegistir(String? yeniDeger) async {
    if (yeniDeger == null) return;
    setState(() => _nabizYontemi = yeniDeger);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('nabiz_yontemi', yeniDeger);
  }  // --- _nabizYontemiDegistir() sonu ---

  Future<void> _sesSec(Map<String, String> ses) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('tts_ses_adi', ses['name'] ?? '');
    await prefs.setString('tts_ses_locale', ses['locale'] ?? 'tr-TR');
    setState(() => _secilenSesAdi = ses['name']);
    SesServisi.konus('Merhaba, ben Seray. Bu sesle konuşacağım.');
  }  // --- _sesSec() sonu ---

  Future<void> _hiziGuncelle(double yeniHiz) async {
    setState(() => _hiz = yeniHiz);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('tts_hiz', yeniHiz);
  }  // --- _hiziGuncelle() sonu ---

  // Cihazdaki ses adları genelde uzun/teknik oluyor (örn. "tr-tr-x-abc-local");
  // burada kısa, sade "Ses 1", "Ses 2" gibi etiketler kullanıyoruz.
  Widget _sesButonu(int index, Map<String, String> ses) {
    final secili = _secilenSesAdi == ses['name'];
    return OutlinedButton(
      onPressed: () => _sesSec(ses),
      style: OutlinedButton.styleFrom(
        backgroundColor: secili ? AppRenkleri.aktif.shade50 : Colors.white,
        side: BorderSide(color: secili ? AppRenkleri.aktif : Colors.grey.shade300, width: secili ? 1.5 : 1),
        padding: const EdgeInsets.symmetric(horizontal: 4),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
      child: Text(
        'Ses ${index + 1}',
        style: TextStyle(fontSize: 12, color: secili ? AppRenkleri.aktif.shade800 : Colors.black87, fontWeight: secili ? FontWeight.bold : FontWeight.normal),
      ),
    );
  }  // --- _sesButonu() sonu ---
  Future<void> _temaSec(String temaAdi) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('tema_secimi', temaAdi);
    setState(() {
      AppRenkleri.temaAdi = temaAdi;
      AppRenkleri.cocukTemasiAktif = temaAdi == 'cocuk';
    });
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Yeni temanın tam olarak uygulanması için uygulamayı kapatıp yeniden açın.')),
      );
    }
  }  // --- _temaSec() sonu ---

  Widget _temaSecenegi(String anahtar, String etiket, MaterialColor renk) {
    final secili = AppRenkleri.temaAdi == anahtar;
    return InkWell(
      onTap: () => _temaSec(anahtar),
      borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: renk,
              shape: BoxShape.circle,
              border: Border.all(color: secili ? Colors.black87 : Colors.transparent, width: 2.5),
            ),
            child: secili ? const Icon(Icons.check, color: Colors.white) : null,
          ),
          const SizedBox(height: 4),
          Text(etiket, style: TextStyle(fontSize: 10, fontWeight: secili ? FontWeight.bold : FontWeight.normal)),
        ],
      ),
    );
  }  // --- _temaSecenegi() sonu ---

  // Renk temasından bağımsız, ayrı bir "görsel şablon" seçimi (bkz.
  // theme/sablon.dart). Şu an sadece köşe yuvarlaklığını değiştiriyor;
  // ileride yeni şablonlar eklenirse buraya sadece yeni bir seçenek
  // eklemek yeterli olacak.
  Future<void> _sablonSec(String sablonAdi) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('sablon_secimi', sablonAdi);
    setState(() {
      AppSablon.sablonAdi = sablonAdi;
    });
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Yeni şablonun tam olarak uygulanması için uygulamayı kapatıp yeniden açın.')),
      );
    }
  }  // --- _sablonSec() sonu ---

  Widget _sablonSecenegi(String anahtar, String etiket, String aciklama, IconData ikon) {
    final secili = AppSablon.sablonAdi == anahtar;
    return InkWell(
      onTap: () => _sablonSec(anahtar),
      borderRadius: BorderRadius.circular(AppSablon.kartYaricapi),
      child: Container(
        width: 140,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: secili ? AppRenkleri.aktif.shade50 : Colors.white,
          borderRadius: BorderRadius.circular(anahtar == 'modern_yuvarlak' ? 22 : 12),
          border: Border.all(color: secili ? AppRenkleri.aktif : Colors.grey.shade300, width: secili ? 1.5 : 1),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(ikon, color: secili ? AppRenkleri.aktif.shade700 : Colors.grey.shade600, size: 20),
                const Spacer(),
                if (secili) Icon(Icons.check_circle, color: AppRenkleri.aktif, size: 18),
              ],
            ),
            const SizedBox(height: 8),
            Text(etiket, style: TextStyle(fontSize: 13, fontWeight: secili ? FontWeight.bold : FontWeight.w500)),
            const SizedBox(height: 2),
            Text(aciklama, style: const TextStyle(fontSize: 10, color: Colors.grey)),
          ],
        ),
      ),
    );
  }  // --- _sablonSecenegi() sonu ---

  static const String _yerelKvkkYedek = '''
KİŞİSEL VERİLERİN KORUNMASI AYDINLATMA METNİ

0. Veri Sorumlusunun Kimliği
6698 sayılı Kişisel Verilerin Korunması Kanunu ("KVKK") uyarınca, aşağıda açıklanan kişisel verileriniz veri sorumlusu sıfatıyla Seray Teknoloji ("Uygulama", "biz") tarafından bu metinde açıklanan amaç ve kapsamda işlenmektedir. İletişim: seraysaglikasistanim@gmail.com

1. Toplanan Veriler
Ad-soyad, yaş, diyabet durumu gibi profil bilgileriniz; girdiğiniz tansiyon, kan şekeri, nabız, kilo, su, adım, ilaç/insülin, beslenme ve e-Nabız tahlil sonuçlarınızı içeren özel nitelikli sağlık verileriniz; onayınızla girdiğiniz acil durum kişisinin adı/telefonu; Seray AI sohbet geçmişiniz; cihaz ve hata (crash) kayıtları işlenir. Ayrıca, uygulamamızı kaç kişinin kullandığını görebilmemiz ve genel kullanım istatistiklerini takip edebilmemiz amacıyla ad-soyadınız ve yaşadığınız şehir, kayıt sırasında ayrıca alınır; bu bilgi şeker/tansiyon/ilaç gibi sağlık verilerinizden TAMAMEN AYRIDIR.

2. Verilerin Saklanma Yeri
Tüm ölçüm/sağlık verileriniz öncelikli olarak kendi cihazınızda (yerel SQLite veritabanında) saklanır. Ad-soyad ve şehir bilginiz ile uygulamayı ne sıklıkla kullandığınıza dair genel istatistikler ise (madde 1'de açıklandığı gibi) merkezi bir sistemde ayrıca tutulur — bu, sağlık verilerinizin cihazınızın dışına çıkması anlamına gelmez, sadece kimlik/kullanım bilgisi için geçerlidir. Kendi isteğinizle yapacağınız veri yedekleme/geri yükleme işlemleri için Firebase ve Google Drive güvenli bulut altyapıları kullanılır; bu yedekleme verileri şifreli tutulur ve üçüncü şahıslarla paylaşılmaz.

3. Yapay Zeka Analizi
e-Nabız tahlillerinizi, ilaçlarınızı veya beslenme kayıtlarınızı analiz ettirmek ya da Seray AI'a soru sormak istediğinizde, ilgili içerik veri güvenliğini ve API gizliliğini sağlamak amacıyla aracı bir Cloudflare Worker sunucusu üzerinden şifreli bağlantıyla (HTTPS) yapay zeka servis sağlayıcısına (OpenAI GPT-4o-mini) iletilir. Gönderilen verilerde gerçek kimlik bilgileriniz yer almaz, yalnızca ölçüm rakamları/sorunuz analiz edilir; bu içerik yapay zeka modellerini eğitmek amacıyla kullanılmaz veya sunucularda saklanmaz.

4. Kritik Ölçüm Bildirimi
Çok yüksek/çok düşük bir ölçüm kaydettiğinizde, sizin onayınızla ve sizin tetiklemenizle, Ayarlar'da belirlediğiniz acil durum kişisine cihazınızın kendi SMS uygulaması üzerinden bilgilendirme mesajı gönderme seçeneği sunulur; bu mesaj Uygulama sunucularından değil, doğrudan cihazınızdan gönderilir.

5. Cihaz İzinleri
Uygulama; kamera (nabız ölçümü ve ilaç kutusu fotoğrafı için), bildirimler (ilaç/su hatırlatmaları için), adım sayar/hareket sensörü ve isteğe bağlı Health Connect izinlerini yalnızca ilgili özellik kullanıldığında talep eder.

6. Yedekleme ve Paylaşım
"Yedekle" veya "Sonuçları Paylaş" özelliklerini kullandığınızda, oluşturulan dosya yalnızca sizin seçtiğiniz uygulama, kişi veya Firebase/Google Drive bulut hesabınızla paylaşılır. Bu paylaşımın sorumluluğu kullanıcıya aittir.

7. Hukuki Sebep
Genel kullanım verileri KVKK m.5/2 (meşru menfaat, sözleşmenin ifası) kapsamında; sağlık verisi gibi özel nitelikli verileriniz ise KVKK m.6 uyarınca yalnızca açık rızanızla işlenir (bkz. Açık Rıza Metni).

8. Haklarınız (KVKK m.11)
Verilerinizin işlenip işlenmediğini öğrenme; işlenmişse bilgi talep etme; işlenme amacına uygun kullanılıp kullanılmadığını öğrenme; yurt içinde/yurt dışında aktarıldığı kişileri bilme; eksik/yanlış işlenmişse düzeltilmesini isteme; KVKK'da öngörülen şartlarda silinmesini/yok edilmesini isteme; bu işlemlerin aktarılan taraflara bildirilmesini isteme; kanuna aykırı işlenme nedeniyle zarara uğramanız halinde zararın giderilmesini talep etme haklarına sahipsiniz. Uygulama içinden "Verileri Sıfırla" butonuna basmanız veya uygulamayı cihazınızdan silmeniz, yerel veritabanındaki tüm verilerinizi kalıcı olarak temizler. Sorularınız için seraysaglikasistanim@gmail.com adresinden bize ulaşabilirsiniz.

9. Sorumluluk Reddi
Uygulamanın kullanımından doğabilecek her türlü veri kaybı, cihaz arızası veya diğer teknik sorunlardan Seray Teknoloji sorumlu tutulamaz; uygulamanın kullanımı tamamen kullanıcının kendi sorumluluğundadır. Uygulama tıbbi teşhis veya tedavi amacı taşımaz, sağlıkla ilgili kararlarınız için mutlaka doktorunuza danışın.


AÇIK RIZA METNİ

Bu metin, yukarıdaki Aydınlatma Metni'nden ayrıdır. Sağlık verileriniz yalnızca onay verdiğiniz madde ölçüsünde işlenir; onaylamadığınız bir madde varsa yalnızca o özellik çalışmaz, uygulamanın temel ölçüm/kayıt kullanımı bu onaylara bağlı değildir.

☐ Şeker, tansiyon, nabız, kilo, su, adım, ilaç ve beslenme verilerim dahil sağlık verilerimin, uygulama içinde bana hizmet sunulması amacıyla işlenmesine,
☐ e-Nabız tahlillerimin, ilaçlarımın/beslenme kayıtlarımın ve Seray AI'a sorduğum soruların; anonimleştirilerek, aracı bir Cloudflare Worker sunucusu üzerinden yapay zeka servis sağlayıcısına (OpenAI GPT-4o-mini) iletilip analiz edilmesine,
☐ Verilerimin kendi isteğimle Firebase ve Google Drive altyapısında şifreli olarak yedeklenmesine (isteğe bağlı — onay vermezsem verilerim yalnızca cihazımda kalır),
☐ Kritik bir ölçüm kaydettiğimde, belirlediğim acil durum kişisine SMS ile bilgilendirme gönderme seçeneğinin bana sunulmasına,
☐ İlaç ve su hatırlatmalarımın zamanında iletilmesi için bildirim gönderilmesine
☐ Ad-soyadımın ve şehir bilgimin, uygulama istatistiklerini takip etme amacıyla merkezi bir sistemde saklanmasına (sağlık verilerimden ayrı olarak — bu onayı vermesem bile temel ölçüm/kayıt özelliklerini kullanabileceğimi biliyorum)

açık rıza gösteriyorum. Bu veriler yalnızca o anki analiz/seslendirme ve yedekleme işlemleri için kullanılır; yapay zeka modellerini eğitmek amacıyla üçüncü taraflarca saklanmaz veya işlenmez. Uygulamanın kesinlikle bir doktor teşhisi koymadığını, tıbbi tavsiye vermediğini ve acil klinik müdahale aracı olmadığını kabul ediyorum. Bu onayları dilediğim zaman Ayarlar ekranından geri çekebilirim; geri çekmem, öncesinde gerçekleştirilmiş işlemleri geçersiz kılmaz.
''';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Ayarlar'),
        backgroundColor: AppRenkleri.aktif,
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // ======== YAPI ETİKETİ — dosya adı/tarihiyle uğraşmadan, uygulamayı
          // açar açmaz BU KUTUYU görüp doğru sürümün kurulduğunu anla.
          // Her yeni paket verdiğimde bu metni değiştiriyorum.
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            margin: const EdgeInsets.only(bottom: 12),
            decoration: BoxDecoration(
              color: Colors.black87,
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Text(
              '🔖 YAPI ETİKETİ: "v2.0.0 — Görsel Şablon sistemi eklendi (Ayarlar > Şablon: Klasik / Modern Yuvarlak)" — bu yazıyı görüyorsan doğru sürüm kurulu.',
              style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
          ),
          // ======== UYGULAMA KİLİDİ (PIN) ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.lock_outline, color: AppRenkleri.aktif),
                      const SizedBox(width: 10),
                      const Expanded(
                        child: Text('Uygulama Kilidi (PIN)', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                      ),
                      Switch(value: _pinAktif, activeColor: AppRenkleri.aktif, onChanged: _pinKilidiDegistir),
                    ],
                  ),
                  const Text(
                    'Açıksa, uygulama her açıldığında 4 haneli PIN sorulur — sağlık verileriniz başkalarının eline geçen telefonda görünmez.',
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                  if (_pinAktif) ...[
                    const SizedBox(height: 4),
                    TextButton(
                      onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => PinKilitEkrani(
                            mod: PinKilitModu.belirle,
                            onBasarili: () {
                              if (mounted) Navigator.pop(context);
                            },
                            onVazgec: () => Navigator.pop(context),
                          ),
                        ),
                      ),
                      child: const Text('PIN\'i Değiştir'),
                    ),
                    const Divider(height: 1),
                    Row(
                      children: [
                        Icon(Icons.fingerprint, color: AppRenkleri.aktif, size: 22),
                        const SizedBox(width: 10),
                        const Expanded(child: Text('Parmak İziyle Aç', style: TextStyle(fontSize: 14))),
                        Switch(value: _biyometriAktif, activeColor: AppRenkleri.aktif, onChanged: _biyometriDegistir),
                      ],
                    ),
                    const Text(
                      'Açıksa, PIN yazmadan önce parmak izinizle hızlıca açabilirsiniz (cihazınız destekliyorsa).',
                      style: TextStyle(fontSize: 11, color: Colors.grey),
                    ),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),

          // ======== KRİTİK İZİNLER (İlaç hatırlatmaları için) ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            color: Colors.amber.shade50,
            child: ListTile(
              leading: const Icon(Icons.notifications_active, color: Colors.orange),
              title: const Text('İlaç Hatırlatma İzinlerini Kontrol Et', style: TextStyle(fontWeight: FontWeight.bold)),
              subtitle: const Text(
                'Alarmlar çalmıyorsa buraya dokunup pil, otomatik başlatma ve kilit ekranı izinlerini tekrar kontrol edin.',
                style: TextStyle(fontSize: 12),
              ),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => KritikIzinlerEkrani(onTamamlandi: () => Navigator.pop(context))),
              ),
            ),
          ),
          const SizedBox(height: 12),

          // ======== UYGULAMA TURU (madde 5 — görsel kimlik/tanıtım) ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: ListTile(
              leading: Icon(Icons.slideshow, color: AppRenkleri.aktif),
              title: const Text('Uygulama Turu', style: TextStyle(fontWeight: FontWeight.bold)),
              subtitle: const Text(
                'Seray Sağlık Asistanım\'ın ana özelliklerini kısaca tekrar gör.',
                style: TextStyle(fontSize: 12),
              ),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TanitimTuruEkrani())),
            ),
          ),
          const SizedBox(height: 12),

          // ======== PİL AYARI (tek tıkla, doğrudan) ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: ListTile(
              leading: Icon(Icons.battery_charging_full, color: AppRenkleri.aktif),
              title: const Text('Pil Optimizasyonunu Kapat'),
              subtitle: const Text(
                'Telefon uygulamayı arka planda kapatmasın diye açılması gerekir',
                style: TextStyle(fontSize: 12),
              ),
              onTap: () => BildirimServisi.pilOptimizasyonuGorMezdenGel(),
            ),
          ),
          const SizedBox(height: 12),

          // ======== HEALTH CONNECT (mevcut kullanıcılar için, ilk kurulum
          // ekranını bu özellik eklenmeden önce geçmiş olabilirler — o
          // ekranda hiç izin isteği tetiklenmemiş olabilir) ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: ListTile(
              leading: Icon(Icons.directions_walk, color: AppRenkleri.aktif),
              title: const Text('Health Connect\'e Bağlan'),
              subtitle: const Text(
                'Adım geçmişinizin uygulama kapalıyken de doğru görünmesi için (isteğe bağlı, Health Connect kuruluysa).',
                style: TextStyle(fontSize: 12),
              ),
              onTap: () async {
                final basarili = await SaglikBaglantisiServisi.izinIste();
                if (!mounted) return;
                final hata = SaglikBaglantisiServisi.sonHata;
                if (basarili) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Health Connect bağlantısı sağlandı.')),
                  );
                } else {
                  // Teşhis amaçlı: artık hatayı GİZLEMİYORUZ, ekranda gösteriyoruz —
                  // ekran görüntüsü alıp geliştiriciye iletilebilsin diye.
                  showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      title: const Text('Health Connect Bağlanamadı'),
                      content: SelectableText(hata ?? 'Bilinmeyen bir hata oluştu (detay yok).'),
                      actions: [
                        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Kapat')),
                      ],
                    ),
                  );
                }
              },
            ),
          ),
          const SizedBox(height: 12),

          // ======== ADIM SAYARI TEŞHİS/TEST ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: ListTile(
              leading: Icon(Icons.directions_run, color: AppRenkleri.aktif),
              title: const Text('Adım Sayarı Test Et'),
              subtitle: const Text(
                'Adım sayılmıyorsa, gerçek sebebi görmek için buraya dokunun.',
                style: TextStyle(fontSize: 12),
              ),
              onTap: () async {
                await AdimServisi.baslat();
                final bugunku = await AdimServisi.bugunkuAdimGetir();
                if (!mounted) return;
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    title: const Text('Adım Sayar Durumu'),
                    content: SelectableText(
                      'İzin verildi mi: ${AdimServisi.izinVerildiMi ? "Evet" : "Hayır"}\n'
                      'Sensör dinlemesi başladı mı: ${AdimServisi.akisBasladiMi ? "Evet" : "Hayır"}\n'
                      'Bugünkü adım (şu an): $bugunku\n\n'
                      '${AdimServisi.sonHata ?? "Bir hata yok — birkaç adım yürüyüp tekrar kontrol edin, sensörün ilk veriyi göndermesi biraz zaman alabilir."}',
                    ),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(context), child: const Text('Kapat')),
                    ],
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 12),

          // ======== SES AYARLARI (Bay/Bayan + Hız) ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.record_voice_over, color: AppRenkleri.aktif),
                      const SizedBox(width: 10),
                      const Text('Sesli Okuma Ayarları', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                    ],
                  ),
                  const SizedBox(height: 12),
                  if (_seslerYukleniyor)
                    const Center(child: Padding(padding: EdgeInsets.all(8), child: CircularProgressIndicator()))
                  else if (_sesler.isEmpty)
                    const Text('Bu cihazda birden fazla Türkçe ses bulunamadı.', style: TextStyle(fontSize: 12, color: Colors.grey))
                  else ...[
                    const Text('Ses', style: TextStyle(fontSize: 12, color: Colors.grey)),
                    const SizedBox(height: 6),
                    GridView.count(
                      crossAxisCount: 3,
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      crossAxisSpacing: 8,
                      mainAxisSpacing: 8,
                      childAspectRatio: 2.4,
                      children: [
                        for (int i = 0; i < _sesler.length; i++)
                          _sesButonu(i, _sesler[i]),
                      ],
                    ),
                    const SizedBox(height: 16),
                  ],
                  const Text('Konuşma Hızı', style: TextStyle(fontSize: 12, color: Colors.grey)),
                  Row(
                    children: [
                      const Icon(Icons.slow_motion_video, size: 18, color: Colors.grey),
                      Expanded(
                        child: Slider(
                          value: _hiz,
                          min: 0.3,
                          max: 0.8,
                          divisions: 10,
                          label: _hiz.toStringAsFixed(2),
                          activeColor: AppRenkleri.aktif,
                          onChanged: _hiziGuncelle,
                        ),
                      ),
                      const Icon(Icons.fast_forward, size: 18, color: Colors.grey),
                    ],
                  ),
                  Align(
                    alignment: Alignment.centerRight,
                    child: TextButton.icon(
                      onPressed: () => SesServisi.konus('Merhaba, ben Seray. Bu hızla konuşuyorum.'),
                      icon: const Icon(Icons.volume_up, size: 26),
                      label: const Text('Test Et'),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),

          // ======== GÖRÜNÜM / TEMA SEÇİMİ ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.palette, color: AppRenkleri.aktif),
                      const SizedBox(width: 10),
                      const Text('Görünüm', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                    ],
                  ),
                  const SizedBox(height: 4),
                  const Text('Uygulamanın renk temasını seçin', style: TextStyle(fontSize: 11, color: Colors.grey)),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 12,
                    runSpacing: 12,
                    children: [
                      _temaSecenegi('turkuaz', 'Turkuaz', AppRenkleri.turkuaz),
                      _temaSecenegi('mavi', 'Mavi', AppRenkleri.mavi),
                      _temaSecenegi('yesil', 'Yeşil', AppRenkleri.yesil),
                      _temaSecenegi('turuncu', 'Turuncu', AppRenkleri.turuncu),
                      _temaSecenegi('cocuk', 'Mor', AppRenkleri.cocukRenkli),
                      _temaSecenegi('kirmizi', 'Kırmızı', AppRenkleri.kirmizi),
                      _temaSecenegi('sari', 'Sarı', AppRenkleri.sari),
                      _temaSecenegi('lacivert', 'Lacivert', AppRenkleri.lacivert),
                      _temaSecenegi('bordo', 'Bordo/Kahve', AppRenkleri.bordo),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),

          // ======== GÖRSEL ŞABLON SEÇİMİ ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.dashboard_customize_outlined, color: AppRenkleri.aktif),
                      const SizedBox(width: 10),
                      const Text('Şablon', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                    ],
                  ),
                  const SizedBox(height: 4),
                  const Text('Uygulamanın genel görünüm hissini seçin', style: TextStyle(fontSize: 11, color: Colors.grey)),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 12,
                    runSpacing: 12,
                    children: [
                      _sablonSecenegi('klasik', 'Klasik', 'Mevcut, bilinen görünüm', Icons.crop_square),
                      _sablonSecenegi('modern_yuvarlak', 'Modern Yuvarlak', 'Daha yuvarlak, ferah köşeler', Icons.rounded_corner),
                    ],
                  ),
                ],
              ),
            ),
          ),

          // ======== NABIZ ÖLÇÜM YÖNTEMİ ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.favorite, color: AppRenkleri.aktif),
                      const SizedBox(width: 10),
                      const Text('Nabız Ölçüm Yöntemi', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  RadioListTile<String>(
                    contentPadding: EdgeInsets.zero,
                    dense: true,
                    activeColor: AppRenkleri.aktif,
                    value: 'basit',
                    groupValue: _nabizYontemi,
                    title: const Text('Basit (Hızlı)', style: TextStyle(fontSize: 14)),
                    subtitle: const Text('Tepe noktası sayma — 15 saniye', style: TextStyle(fontSize: 11)),
                    onChanged: _nabizYontemiDegistir,
                  ),
                  RadioListTile<String>(
                    contentPadding: EdgeInsets.zero,
                    dense: true,
                    activeColor: AppRenkleri.aktif,
                    value: 'fft',
                    groupValue: _nabizYontemi,
                    title: const Text('Gelişmiş (FFT)', style: TextStyle(fontSize: 14)),
                    subtitle: const Text('Frekans analizi — daha isabetli, 20 saniye sürer', style: TextStyle(fontSize: 11)),
                    onChanged: _nabizYontemiDegistir,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: ListTile(
              leading: Icon(Icons.info_outline, color: AppRenkleri.aktif),
              title: const Text('Uygulama Hakkında'),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  FutureBuilder<PackageInfo>(
                    future: PackageInfo.fromPlatform(),
                    builder: (context, snapshot) => Text(
                      snapshot.hasData
                          ? 'Seray Sağlık Asistanım v${snapshot.data!.version}'
                          : 'Seray Sağlık Asistanım',
                      style: const TextStyle(fontSize: 12),
                    ),
                  ),
                  if (_hakkindaAciklama != null) ...[
                    const SizedBox(height: 6),
                    Text(_hakkindaAciklama!, style: TextStyle(fontSize: 12, color: Colors.grey.shade700, height: 1.3)),
                  ],
                  const SizedBox(height: 6),
                  InkWell(
                    onTap: () => launchUrl(Uri.parse('mailto:seraysaglikasistanim@gmail.com')),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'İletişim: SERAY TEKNOLOJİ',
                          style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.grey.shade800),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          'Talep ve sorularınız için:',
                          style: TextStyle(fontSize: 12, color: Colors.grey.shade700),
                        ),
                        const SizedBox(height: 2),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.email_outlined, size: 14, color: Colors.blue.shade600),
                            const SizedBox(width: 4),
                            Text(
                              'seraysaglikasistanim@gmail.com',
                              style: TextStyle(fontSize: 12, color: Colors.blue.shade600, fontWeight: FontWeight.w500),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 6),
                  // YENİ: Kullanıcı grubu — WhatsApp topluluğuna katılım linki.
                  InkWell(
                    onTap: () => launchUrl(
                      Uri.parse(_whatsappGrupLinki),
                      mode: LaunchMode.externalApplication,
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.groups_outlined, size: 14, color: Colors.green),
                        const SizedBox(width: 4),
                        Text(
                          'Kullanıcı Grubuna Katıl (WhatsApp)',
                          style: TextStyle(fontSize: 12, color: Colors.green.shade700, fontWeight: FontWeight.w500),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),

          // ======== KVKK ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: ExpansionTile(
              leading: Icon(Icons.privacy_tip_outlined, color: AppRenkleri.aktif),
              title: const Text('KVKK Aydınlatma Metni'),
              children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(_kvkkMetni,
                      style: const TextStyle(fontSize: 13, height: 1.4, color: Colors.black87)),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),

          const SizedBox(height: 12),

          // ======== CRASHLYTICS TEST (sadece kurulumu doğrulamak için) ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: ListTile(
              leading: Icon(Icons.bug_report_outlined, color: crashlyticsAktifMi ? Colors.green : Colors.grey),
              title: const Text('Çökme Takibi (Crashlytics) Test Et'),
              subtitle: Text(
                crashlyticsAktifMi
                    ? 'Aktif — test için dokun (uygulama kapanır, tekrar aç, birkaç saat içinde Firebase panelinde görünür).'
                    : 'Henüz aktif değil (google-services.json bulunamadı).',
                style: const TextStyle(fontSize: 12),
              ),
              onTap: !crashlyticsAktifMi
                  ? null
                  : () => showDialog(
                        context: context,
                        builder: (context) => AlertDialog(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                          title: const Text('Test Çökmesi'),
                          content: const Text(
                            'Uygulama kasıtlı olarak kapanacak (gerçek bir hata değil, sadece Crashlytics\'in çalıştığını doğrulamak için). Devam edilsin mi?',
                          ),
                          actions: [
                            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Vazgeç')),
                            TextButton(
                              onPressed: () => FirebaseCrashlytics.instance.crash(),
                              child: const Text('Test Et', style: TextStyle(color: Colors.red)),
                            ),
                          ],
                        ),
                      ),
            ),
          ),

          const SizedBox(height: 12),

          const SizedBox(height: 12),

          // ======== AİLE TAKİBİ: PROFİL YÖNETİMİ ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.people_alt, color: AppRenkleri.aktif),
                      const SizedBox(width: 10),
                      const Expanded(
                        child: Text('Profiller (Aile Takibi)', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Kendi verilerinizin yanında, takip ettiğiniz bir yakınınızın (annenizin, babanızın) '
                    'verilerini de AYRI bir profilde tutabilirsiniz. Aktif profili değiştirdiğinizde tüm '
                    'ölçümler, ilaçlar ve tahliller o profile ait olanlarla değişir.',
                    style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                  ),
                  const SizedBox(height: 12),
                  for (final profil in _profiller)
                    Container(
                      margin: const EdgeInsets.only(bottom: 6),
                      decoration: BoxDecoration(
                        color: profil.id == _aktifProfilId ? AppRenkleri.aktif.shade50 : Colors.grey.shade50,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: profil.id == _aktifProfilId ? AppRenkleri.aktif : Colors.grey.shade300,
                          width: profil.id == _aktifProfilId ? 1.5 : 1,
                        ),
                      ),
                      child: ListTile(
                        dense: true,
                        leading: CircleAvatar(
                          backgroundColor: profil.id == _aktifProfilId ? AppRenkleri.aktif : Colors.grey.shade400,
                          child: Icon(Icons.person, color: Colors.white, size: 20),
                        ),
                        title: Text(profil.ad, style: const TextStyle(fontWeight: FontWeight.w600)),
                        subtitle: profil.id == _aktifProfilId ? const Text('Şu an aktif', style: TextStyle(fontSize: 11)) : null,
                        trailing: profil.id == _aktifProfilId
                            ? Icon(Icons.check_circle, color: AppRenkleri.aktif)
                            : Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  if (_profiller.length > 1)
                                    IconButton(
                                      icon: const Icon(Icons.delete_outline, color: Colors.red, size: 20),
                                      onPressed: () => _profilSilOnayi(profil),
                                    ),
                                  TextButton(
                                    onPressed: () => _profileGec(profil.id),
                                    child: const Text('Geç'),
                                  ),
                                ],
                              ),
                      ),
                    ),
                  const SizedBox(height: 4),
                  OutlinedButton.icon(
                    onPressed: _yeniProfilEkleDialogu,
                    icon: const Icon(Icons.person_add_alt_1, size: 18),
                    label: const Text('Yeni Profil Ekle'),
                    style: OutlinedButton.styleFrom(foregroundColor: AppRenkleri.aktif, side: BorderSide(color: AppRenkleri.aktif.shade300)),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 12),

          const SizedBox(height: 12),

          // ======== HAFTALIK ÖZET BİLDİRİMİ ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.calendar_view_week, color: AppRenkleri.aktif),
                      const SizedBox(width: 10),
                      const Expanded(child: Text('Haftalık Özet Bildirimi', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15))),
                      Switch(value: _haftalikOzetAktif, activeColor: AppRenkleri.aktif, onChanged: _haftalikOzetDegistir),
                    ],
                  ),
                  const Text(
                    'Açıksa, her pazar akşamı 20:00\'de o haftaki şeker/adım/su özetinizi hatırlatan bir bildirim gelir.',
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                  const SizedBox(height: 6),
                  TextButton(
                    onPressed: _haftalikOzetiGoster,
                    child: const Text('Bu Haftaki Özeti Şimdi Gör'),
                  ),
                ],
              ),
            ),
          ),

          // ======== ACİL DURUM KİŞİSİ ========
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.emergency_outlined, color: AppRenkleri.aktif),
                      const SizedBox(width: 10),
                      const Expanded(child: Text('Acil Durum Kişisi', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15))),
                    ],
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'Çok yüksek/düşük bir şeker ya da tansiyon ölçümü kaydettiğinizde, bu kişiye hazır bir mesaj göndermeniz önerilir.',
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _acilKisiAdController,
                    decoration: const InputDecoration(labelText: 'Ad (isteğe bağlı)', isDense: true, border: OutlineInputBorder()),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _acilKisiTelefonController,
                    keyboardType: TextInputType.phone,
                    decoration: const InputDecoration(labelText: 'Telefon Numarası', isDense: true, border: OutlineInputBorder()),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: AppRenkleri.aktif),
                      onPressed: _acilKisiyiKaydet,
                      child: const Text('Kaydet', style: TextStyle(color: Colors.white)),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // ======== GİZLİLİK POLİTİKASI (WEB) ========
          // Play Store, uygulama içi metnin YANI SIRA gerçek bir web
          // URL'sinde barındırılan bir gizlilik politikası ister.
          // GitHub Pages'te (Settings → Pages → main/docs) yayınlanan
          // docs/gizlilik.html'e bağlanır.
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSablon.kartYaricapi)),
            child: ListTile(
              leading: Icon(Icons.public, color: AppRenkleri.aktif),
              title: const Text('Gizlilik Politikası (Web)'),
              subtitle: const Text('Play Store için gerekli, tarayıcıda açılır', style: TextStyle(fontSize: 12)),
              trailing: const Icon(Icons.open_in_new, size: 18),
              onTap: () => launchUrl(
                Uri.parse('https://ntlextr.github.io/seray-saglik-asistanim/gizlilik.html'),
                mode: LaunchMode.externalApplication,
              ),
            ),
          ),
        ],
      ),
    );
  }  // --- build() sonu ---
}
