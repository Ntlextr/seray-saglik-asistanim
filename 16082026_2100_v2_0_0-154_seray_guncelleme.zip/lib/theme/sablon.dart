import 'package:flutter/material.dart';

// Uygulamanın görsel ŞABLON sistemi. Renk sisteminden (AppRenkleri, aynı
// klasördeki renkler.dart) TAMAMEN bağımsız — ikisi birlikte, üst üste
// çalışır: renk paleti "hangi ton", şablon ise "hangi his" (köşeler,
// yoğunluk) sorusuna cevap verir. main.dart, uygulama açılırken
// (runApp'tan ÖNCE) kayıtlı tercihi okuyup sablonAdi değerini ayarlar;
// Ayarlar ekranından değiştirilebilir.
//
// ÖNEMLİ TASARIM KARARI: "Klasik" şablonun tüm değerleri, mevcut kodda
// zaten sabit yazılı olan değerlerle (örn. BorderRadius.circular(12))
// BİREBİR AYNI. Yani bu sistem hiç eklenmemiş gibi davranır ta ki kullanıcı
// Ayarlar'dan bilinçli olarak "Modern Yuvarlak"ı seçene kadar — mevcut
// düzen hiçbir şekilde bozulmaz.
class AppSablon {
  static String sablonAdi = 'klasik'; // klasik | modern_yuvarlak

  static bool get modernMi => sablonAdi == 'modern_yuvarlak';

  // Kart / kutu / buton köşe yarıçapı. Klasik'te mevcut sabit değer (12)
  // ile birebir aynı — hiçbir görsel fark yaratmaz.
  static double get kartYaricapi => modernMi ? 22.0 : 12.0;

  static String get adi => modernMi ? 'Modern Yuvarlak' : 'Klasik';
  static String get aciklama => modernMi
      ? 'Daha yuvarlak köşeler, daha ferah bir görünüm'
      : 'Mevcut, bilinen görünüm';
}
