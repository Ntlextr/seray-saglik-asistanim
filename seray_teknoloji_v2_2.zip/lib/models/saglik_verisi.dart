class SaglikVerisi {
  final DateTime tarih;
  final double seker;
  final double tansiyonUst;
  final double tansiyonAlt;
  final double nabiz;

  SaglikVerisi({
    required this.tarih,
    required this.seker,
    required this.tansiyonUst,
    required this.tansiyonAlt,
    required this.nabiz,
  });

  /// Gelen JSON verisini tür uyuşmazlığı (int/double) olmadan güvenle Dart nesnesine dönüştürür
  factory SaglikVerisi.fromJson(Map<String, dynamic> json) {
    return SaglikVerisi(
      tarih: json['tarih'] != null ? DateTime.parse(json['tarih']) : DateTime.now(),
      seker: (json['seker'] as num?)?.toDouble() ?? 0.0,
      tansiyonUst: (json['tansiyonUst'] as num?)?.toDouble() ?? 0.0,
      tansiyonAlt: (json['tansiyonAlt'] as num?)?.toDouble() ?? 0.0,
      nabiz: (json['nabiz'] as num?)?.toDouble() ?? 0.0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'tarih': tarih.toIso8601String(),
      'seker': seker,
      'tansiyonUst': tansiyonUst,
      'tansiyonAlt': tansiyonAlt,
      'nabiz': nabiz,
    };
  }
}
