import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/saglik_verisi.dart';

class DatabaseServisi {
  static const String _key = 'saglik_kayitlari';

  static Future<void> veriKaydet(SaglikVerisi yeniVeri) async {
    final prefs = await SharedPreferences.getInstance();
    List<String> kayitlar = prefs.getStringList(_key) ?? [];
    kayitlar.add(jsonEncode(yeniVeri.toJson()));
    await prefs.setStringList(_key, kayitlar);
  }

  static Future<List<SaglikVerisi>> verileriGetir() async {
    final prefs = await SharedPreferences.getInstance();
    List<String> kayitlar = prefs.getStringList(_key) ?? [];
    return kayitlar.map((s) => SaglikVerisi.fromJson(jsonDecode(s))).toList();
  }

  /// Doktorun istediği formatta (Sabah/Öğlen/Akşam Ölçümleri) şık bir rapor dökümü hazırlar
  static Future<String> doktorRaporuHazirla() async {
    List<SaglikVerisi> liste = await verileriGetir();
    
    String rapor = "=========================================\n"
        "        SERAY TEKNOLOJİ SAĞLIK RAPORU      \n"
        "=========================================\n"
        "Sayın Doktorum, hastanızın günlük takip ölçüm dökümü:\n\n"
        "--------------------------------------------------\n"
        "Tarih / Saat       | Şeker    | Tansiyon | Nabız\n"
        "--------------------------------------------------\n";

    for (var v in liste) {
      String tarihTemiz = v.tarih.toString().substring(0, 16); // YYYY-MM-DD HH:mm formatı
      String sekerStr = "${v.seker.toStringAsFixed(0)} mg/dL";
      String tansiyonStr = "${v.tansiyonUst.toStringAsFixed(0)}/${v.tansiyonAlt.toStringAsFixed(0)}";
      String nabizStr = "${v.nabiz.toStringAsFixed(0)} bpm";

      rapor += "$tarihTemiz | $sekerStr | $tansiyonStr | $nabizStr\n";
    }

    rapor += "--------------------------------------------------\n"
        "Bu rapor Seray Sağlık Yönetim Paneli tarafından\n"
        "otomatik olarak üretilmiştir. Geçmiş olsun.";
        
    return rapor;
  }
}
