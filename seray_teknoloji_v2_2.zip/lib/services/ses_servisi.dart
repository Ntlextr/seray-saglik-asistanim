// lib/services/ses_servisi.dart
import 'package:flutter_tts/flutter_tts.dart';

class SesServisi {
  static final FlutterTts _tts = FlutterTts();

  static Future<void> tahlilOku({
    required double seker,
    required double tansiyonUst,
    required double tansiyonAlt,
    required double nabiz,
  }) async {
    // Ses ayarlarını sabitleyelim ki ses hep net çıksın
    await _tts.setLanguage("tr-TR");
    await _tts.setSpeechRate(0.5); // Yavaş ve net okuma
    await _tts.setVolume(1.0);     // Ses seviyesini %100 yap
    await _tts.setPitch(1.0);      // Ses tonunu normal seviyeye al
    
    // Mesajı netleştiriyoruz
    String mesaj = "Tahlil sonuçlarınız: Şekeriniz $seker, "
                   "tansiyonunuz ${tansiyonUst.toInt()}a ${tansiyonAlt.toInt()}, "
                   "nabzınız ise $nabiz olarak ölçülmüştür. Geçmiş olsun.";
                   
    // Seslendirmeyi başlat
    await _tts.speak(mesaj);
  }
}
