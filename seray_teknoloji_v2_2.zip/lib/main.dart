import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'screens/analizler.dart';
import 'screens/dosya_yonetim.dart';
import 'screens/ana_panel.dart';
import 'screens/profil_sayfasi.dart';
import 'screens/profil_kayit_ekrani.dart'; // Yeni ekranımızı ekledik

void main() => runApp(const MaterialApp(
  debugShowCheckedModeBanner: false,
  home: AnaEkran(),
));

class AnaEkran extends StatefulWidget {
  const AnaEkran({super.key});

  @override
  State<AnaEkran> createState() => _AnaEkranState();
}

class _AnaEkranState extends State<AnaEkran> {
  int _seciliSayfa = 0;
  final FlutterTts flutterTts = FlutterTts();

  @override
  void initState() {
    super.initState();
    flutterTts.setLanguage("tr-TR");
    // Uygulama açılır açılmaz profil kontrolü yapıyoruz
    _ilkKurulumKontrolu();
  }

  /// Eğer kullanıcı daha önce adını kaydetmediyse kayıt ekranına zorunlu yönlendirir
  Future<void> _ilkKurulumKontrolu() async {
    final prefs = await SharedPreferences.getInstance();
    String? ad = prefs.getString('user_ad');

    // Eğer isim yoksa, kullanıcıyı alt menüleri görmeden kayıt ekranına gönderiyoruz
    if (ad == null || ad.isEmpty) {
      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const ProfilKayitEkrani()),
        );
      }
    }
  }

  final List<Widget> _sayfalar = [
    const AnaSaglikPaneli(), 
    const AnalizlerSayfasi(), 
    const VeriYonetimiSekmeSayfasi(),
    const ProfilSayfasi(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _sayfalar[_seciliSayfa],
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        currentIndex: _seciliSayfa,
        selectedItemColor: Colors.teal,
        unselectedItemColor: Colors.grey,
        onTap: (index) => setState(() => _seciliSayfa = index),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Özet"),
          BottomNavigationBarItem(icon: Icon(Icons.bar_chart), label: "Analizler"),
          BottomNavigationBarItem(icon: Icon(Icons.upload_file), label: "PDF Yükle"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profil"),
        ],
      ),
    );
  }
}
