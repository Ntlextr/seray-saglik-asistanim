import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart';
import 'analiz_sonuc_ekrani.dart'; // Yeni gelişmiş ekran bağlandı

class VeriYonetimiSekmeSayfasi extends StatefulWidget {
  const VeriYonetimiSekmeSayfasi({Key? key}) : super(key: key);

  @override
  _VeriYonetimiSekmeSayfasiState createState() => _VeriYonetimiSekmeSayfasiState();
}

class _VeriYonetimiSekmeSayfasiState extends State<VeriYonetimiSekmeSayfasi> {
  bool _isLoading = false;
  String _durumMesaji = "PDF tahlilinizi seçin, asistanınız analiz etsin.";

  Future<void> tahlilYukleVeIsle() async {
    setState(() {
      _isLoading = true;
      _durumMesaji = "Dosya seçiliyor...";
    });

    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf'],
      );

      if (result != null && result.files.single.path != null) {
        setState(() {
          _durumMesaji = "PDF metni ayıklanıyor...";
        });

        File file = File(result.files.single.path!);
        final PdfDocument document = PdfDocument(inputBytes: await file.readAsBytes());
        String ayiklananMetin = PdfTextExtractor(document).extractText();
        document.dispose();

        setState(() {
          _durumMesaji = "Analiz başarıyla tamamlandı!";
        });

        if (mounted) {
          // Eski beyaz pop-up penceresi yerine yeni gelişmiş ekrana yönlendiriyoruz
          await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => AnalizSonucEkrani(hamPdfMetni: ayiklananMetin),
            ),
          );
        }
      } else {
        setState(() {
          _durumMesaji = "Dosya seçimi iptal edildi.";
        });
      }
    } catch (e) {
      setState(() {
        _durumMesaji = "Hata oluştu: $e";
      });
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("PDF Analiz & Asistan"),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                _durumMesaji,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
              ),
              const SizedBox(height: 30),
              _isLoading
                  ? const CircularProgressIndicator(color: Colors.teal)
                  : ElevatedButton.icon(
                      onPressed: tahlilYukleVeIsle,
                      icon: const Icon(Icons.picture_as_pdf),
                      label: const Text("Tahlil PDF'ini Analiz Et"),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.purple.shade700,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                        textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                    ),
            ],
          ),
        ),
      ),
    );
  }
}
