import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import '../services/api_service.dart';

class AnalizSonucEkrani extends StatefulWidget {
  final String hamPdfMetni;
  const AnalizSonucEkrani({Key? key, required this.hamPdfMetni}) : super(key: key);

  @override
  _AnalizSonucEkraniState createState() => _AnalizSonucEkraniState();
}

class _AnalizSonucEkraniState extends State<AnalizSonucEkrani> {
  bool _yukleniyor = true;
  String? _hataMesaji;
  List<Map<String, dynamic>> _tumGecmisTahliller = [];

  @override
  void initState() {
    super.initState();
    _analiziBaslat();
  }

  Future<void> _analiziBaslat() async {
    try {
      String jsonString = await ApiService.tahlilMetniniAnalizEt(widget.hamPdfMetni);
      
      // Web sitelerindeki gibi bozuk baytlar yok sayp kurtaran UTF-8 emniyet kilidi
      List<int> kodUnitleri = jsonString.codeUnits;
      String guvenliJsonString = utf8.decode(kodUnitleri, allowMalformed: true);

      final yeniTahlil = jsonDecode(guvenliJsonString);

      if (yeniTahlil.containsKey('hata')) {
        setState(() { _hataMesaji = yeniTahlil['hata']; _yukleniyor = false; });
      } else {
        final prefs = await SharedPreferences.getInstance();
        List<String> kayitlar = prefs.getStringList('saglik_kayitlari') ?? [];
        
        kayitlar.add(guvenliJsonString);
        await prefs.setStringList('saglik_kayitlari', kayitlar);

        List<Map<String, dynamic>> geciciListe = [];
        for (var k in kayitlar) {
          try { geciciListe.add(jsonDecode(k)); } catch (_) {}
        }

        setState(() {
          _tumGecmisTahliller = geciciListe;
          _yukleniyor = false;
        });
      }
    } catch (e) {
      setState(() { _hataMesaji = "Kodlama veya Veri Hatasi: $e"; _yukleniyor = false; });
    }
  }

  void _doktoraRaporGonder(String platform) async {
    if (_tumGecmisTahliller.isEmpty) return;

    String rapor = " SERAY TEKNOLOJ SALIK Y�NETM RAPORU\n"
        "Sayn Doktorum, hastanzn ge�miten g�n�m�ze t�m tahlil geliim d�k�m� aadadr:\n\n";

    for (var tahlil in _tumGecmisTahliller) {
      rapor += " Tahlil Tarihi: ${tahlil['tarih'] ?? '-'}\n"
          "� A�lk Kan ekeri: ${tahlil['seker']} mg/dL\n"
          "� Tansiyon: ${tahlil['tansiyonUst']}/${tahlil['tansiyonAlt']} mmHg\n"
          "� Nabz: ${tahlil['nabiz']} bpm\n"
          "� Toplam Kolesterol: ${tahlil['kolesterol']} mg/dL (LDL: ${tahlil['ldl']} / HDL: ${tahlil['hdl']})\n"
          "� Trigliserid: ${tahlil['trigliserid']} mg/dL\n"
          "� Karacier (AST/ALT): ${tahlil['ast']} / ${tahlil['alt']} U/L\n"
          "� B�brek (�re/Kreatinin): ${tahlil['ure']} / ${tahlil['kreatinin']}\n"
          "� Hemoglobin (Kan): ${tahlil['hemoglobin']} g/dL\n"
          "� Vitaminler (B12/D3): ${tahlil['b12']} / ${tahlil['d_vitamini']}\n"
          "� Tiroid (TSH): ${tahlil['tsh']} uIU/mL\n"
          "-----------------------------------------\n\n";
    }

    if (platform == "whatsapp") {
      await Share.share(rapor, subject: 'E-Nabz Tahlil Ge�miim');
    } else {
      final directory = await getTemporaryDirectory();
      final file = File('${directory.path}/tahlil_gecmis_raporu.txt');
      await file.writeAsString(rapor);
      await Share.shareXFiles([XFile(file.path)], text: 'Doktor Bey, kronolojik t�m tahlil d�k�m�m ektedir.');
    }
  }

  void _secimMenuGoster() {
    showModalBottomSheet(
      context: context,
      builder: (context) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(
            leading: const Icon(Icons.message, color: Colors.green),
            title: const Text("WhatsApp ile G�nder"),
            onTap: () { Navigator.pop(context); _doktoraRaporGonder("whatsapp"); },
          ),
          ListTile(
            leading: const Icon(Icons.email, color: Colors.blue),
            title: const Text("E-Posta / Dok�man Olarak G�nder"),
            onTap: () { Navigator.pop(context); _doktoraRaporGonder("email"); },
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('E-Nabz Zaman T�neli'), backgroundColor: Colors.teal),
      body: _yukleniyor
          ? const Center(child: CircularProgressIndicator(color: Colors.teal))
          : _hataMesaji != null
              ? Center(child: Text(_hataMesaji!))
              : Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: ElevatedButton.icon(
                        onPressed: _secimMenuGoster,
                        icon: const Icon(Icons.share),
                        label: const Text("T�M ZAMAN T�NELN DOKTORA G�NDER"),
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.teal, foregroundColor: Colors.white, minimumSize: const Size.fromHeight(50)),
                      ),
                    ),
                    Expanded(
                      child: SingleChildScrollView(
                        scrollDirection: Axis.vertical,
                        child: SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Padding(
                            padding: const EdgeInsets.all(12.0),
                            child: _dinamikTabloyuOlustur(),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
    );
  }

  Widget _dinamikTabloyuOlustur() {
    List<DataColumn> sutunlar = [
      const DataColumn(label: Text('Salk Kalemi', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.teal))),
    ];
    for (var tahlil in _tumGecmisTahliller) {
      sutunlar.add(DataColumn(label: Text(tahlil['tarih'] ?? 'Bilinmiyor', style: const TextStyle(fontWeight: FontWeight.bold))));
    }

    return DataTable(
      border: TableBorder.all(color: Colors.grey.shade300),
      columns: sutunlar,
      rows: [
        _dinamikSatirOlustur('A�lk Kan ekeri (mg/dL)', 'seker'),
        _dinamikSatirOlustur('B�y�k Tansiyon (�st)', 'tansiyonUst'),
        _dinamikSatirOlustur('K���k Tansiyon (Alt)', 'tansiyonAlt'),
        _dinamikSatirOlustur('Nabz (bpm)', 'nabiz'),
        _dinamikSatirOlustur('Toplam Kolesterol (mg/dL)', 'kolesterol'),
        _dinamikSatirOlustur('LDL Kolesterol', 'ldl'),
        _dinamikSatirOlustur('HDL Kolesterol', 'hdl'),
        _dinamikSatirOlustur('Trigliserid', 'trigliserid'),
        _dinamikSatirOlustur('Karacier AST (U/L)', 'ast'),
        _dinamikSatirOlustur('Karacier ALT (U/L)', 'alt'),
        _dinamikSatirOlustur('�re (mg/dL)', 'ure'),
        _dinamikSatirOlustur('Kreatinin (mg/dL)', 'kreatinin'),
        _dinamikSatirOlustur('Hemoglobin (Kan)', 'hemoglobin'),
        _dinamikSatirOlustur('Vitamin B12', 'b12'),
        _dinamikSatirOlustur('Vitamin D3', 'd_vitamini'),
        _dinamikSatirOlustur('Tiroid TSH (uIU/mL)', 'tsh'),
      ],
    );
  }

  DataRow _dinamikSatirOlustur(String satirBasligi, String jsonAnahtari) {
    List<DataCell> hucreler = [DataCell(Text(satirBasligi, style: const TextStyle(fontWeight: FontWeight.w500)))];
    for (var tahlil in _tumGecmisTahliller) {
      var deger = tahlil[jsonAnahtari];
      hucreler.add(DataCell(Text(deger != null && deger != 0 ? deger.toString() : '-')));
    }
    return DataRow(cells: hucreler);
  }
}
