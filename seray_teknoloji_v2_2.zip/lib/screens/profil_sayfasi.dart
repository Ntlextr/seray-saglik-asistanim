import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:share_plus/share_plus.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'profil_kayit_ekrani.dart';

class ProfilSayfasi extends StatefulWidget {
  const ProfilSayfasi({Key? key}) : super(key: key);

  @override
  _ProfilSayfasiState createState() => _ProfilSayfasiState();
}

class _ProfilSayfasiState extends State<ProfilSayfasi> {
  String _ad = "..."; String _soyad = "..."; int _yas = 0;

  @override
  void initState() { super.initState(); _verileriYukle(); }

  Future<void> _verileriYukle() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _ad = prefs.getString('user_ad') ?? "Bilinmiyor";
      _soyad = prefs.getString('user_soyad') ?? "Bilinmiyor";
      _yas = prefs.getInt('user_yas') ?? 0;
    });
  }

  Future<void> _cihazaVerileriYedekle() async {
    final prefs = await SharedPreferences.getInstance();
    Map<String, dynamic> tumVeriler = {
      'user_ad': prefs.getString('user_ad'),
      'user_soyad': prefs.getString('user_soyad'),
      'user_yas': prefs.getInt('user_yas'),
      'saglik_kayitlari': prefs.getStringList('saglik_kayitlari') ?? [],
      'ilaclar': prefs.getStringList('ilaclar') ?? [],
    };
    String jsonString = jsonEncode(tumVeriler);
    final directory = await getTemporaryDirectory();
    final file = File('${directory.path}/seray_saglik_yedek.data');
    await file.writeAsString(jsonString);
    await Share.shareXFiles([XFile(file.path)], text: 'Seray Salk Güvenli Yedek Dosyanz.');
  }
  Future<void> _cihazdanYedekGeriYukle() async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles();
      if (result != null && result.files.single.path != null) {
        File file = File(result.files.single.path!);
        String icerik = await file.readAsString();
        Map<String, dynamic> cozulen = jsonDecode(icerik);
        final prefs = await SharedPreferences.getInstance();
        if (cozulen.containsKey('user_ad')) {
          await prefs.setString('user_ad', cozulen['user_ad']);
          await prefs.setString('user_soyad', cozulen['user_soyad']);
          await prefs.setInt('user_yas', cozulen['user_yas']);
          await prefs.setStringList('saglik_kayitlari', List<String>.from(cozulen['saglik_kayitlari']));
          await prefs.setStringList('ilaclar', List<String>.from(cozulen['ilaclar']));
          _verileriYukle();
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Yedek dosyasndan tüm veriler baaryla geri yüklendi!'), backgroundColor: Colors.green));
          }
        }
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Hata: Geçersiz yedek dosyas seçildi!'), backgroundColor: Colors.red));
    }
  }

  Future<void> _cikisYapVeSifirla() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (mounted) {
      Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context) => const ProfilKayitEkrani()), (route) => false);
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Profil & Sistem Yönetimi'), backgroundColor: Colors.teal, foregroundColor: Colors.white),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          Card(
            color: Colors.teal.shade50,
            child: ListTile(
              leading: const Icon(Icons.account_box, size: 40, color: Colors.teal),
              title: Text("$_ad $_soyad", style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
              subtitle: Text("Kaytl Ya: $_yas"),
            ),
          ),
          const SizedBox(height: 20),
          const Text(" Cihaz / Bulut Yedekleme Sistemi", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          const Divider(),
          const SizedBox(height: 10),
          ElevatedButton.icon(
            onPressed: _cihazaVerileriYedekle, 
            icon: const Icon(Icons.cloud_upload), 
            label: const Text("TÜM VERLER YEDEKLE (DOSYA OLARAK KAYDET)"),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.teal.shade700, foregroundColor: Colors.white, padding: const EdgeInsets.all(14)),
          ),
          const SizedBox(height: 15),
          ElevatedButton.icon(
            onPressed: _cihazdanYedekGeriYukle,
            icon: const Icon(Icons.file_open),
            label: const Text("TELEFONDAN YEDEK DOSYASI SEÇ & YÜKLE"),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.orange.shade800, foregroundColor: Colors.white, padding: const EdgeInsets.all(14)),
          ),
          const SizedBox(height: 50),
          const Divider(),
          ElevatedButton.icon(
            onPressed: () {
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  title: const Text("Güvenli Çk & Profil Silme"),
                  content: const Text("Uygulamadaki tüm profil bilgileriniz..."),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context), child: const Text("ptal")),
                    TextButton(onPressed: _cikisYapVeSifirla, child: const Text("Evet, Tümünü Sil ve Çk", style: TextStyle(color: Colors.red))),
                  ],
                ),
              );
            },
            icon: const Icon(Icons.power_settings_new),
            label: const Text("HESABI SL & GÜVENL ÇIKI TUU"),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red.shade700, foregroundColor: Colors.white, padding: const EdgeInsets.all(14)),
          ),
        ],
      ),
    );
  }
}
