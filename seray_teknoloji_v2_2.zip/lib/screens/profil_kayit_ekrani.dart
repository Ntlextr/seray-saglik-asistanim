import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../main.dart'; // Alt menülerin (BottomNavigationBar) geri gelmesi için AnaEkran'a bağladık

class ProfilKayitEkrani extends StatefulWidget {
  const ProfilKayitEkrani({Key? key}) : super(key: key);

  @override
  _ProfilKayitEkraniState createState() => _ProfilKayitEkraniState();
}

class _ProfilKayitEkraniState extends State<ProfilKayitEkrani> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _adController = TextEditingController();
  final TextEditingController _soyadController = TextEditingController();
  final TextEditingController _yasController = TextEditingController();

  bool _isFirstTime = true;
  String _selamlamaMetni = "";
  String _kayitliAd = "";

  @override
  void initState() {
    super.initState();
    _profilKontrolEt();
  }

  /// Telefon hafızasını kontrol edip kullanıcının daha önce kayıt olup olmadığını anlar
  Future<void> _profilKontrolEt() async {
    final prefs = await SharedPreferences.getInstance();
    String? ad = prefs.getString('user_ad');
    
    if (ad != null && ad.isNotEmpty) {
      setState(() {
        _isFirstTime = false;
        _kayitliAd = ad;
        _selamlamaMetni = _getZamanAyarliSelamlama();
      });

      // Giriş animasyonu için 2 saniye bekleyip alt menülü ana yapıya aktarır
      Future.delayed(const Duration(seconds: 2), () {
        if (mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => const AnaEkran()),
          );
        }
      });
    } else {
      setState(() {
        _isFirstTime = true;
      });
    }
  }

  /// Sistem saatine göre dinamik Türkçe karşılama mesajı üretir
  String _getZamanAyarliSelamlama() {
    int saat = DateTime.now().hour;
    if (saat >= 5 && saat < 12) return "Günaydın";
    if (saat >= 12 && saat < 17) return "İyi Günler";
    if (saat >= 17 && saat < 22) return "İyi Akşamlar";
    return "İyi Geceler";
  }

  /// Profil bilgilerini kalıcı olarak telefona kaydeder
  Future<void> _profiliKaydet() async {
    if (_formKey.currentState!.validate()) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('user_ad', _adController.text.trim());
      await prefs.setString('user_soyad', _soyadController.text.trim());
      await prefs.setInt('user_yas', int.parse(_yasController.text.trim()));

      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const AnaEkran()),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    // DURUM A: Kullanıcı zaten kayıtlıysa açılan animasyonlu karşılama ekranı
    if (!_isFirstTime) {
      return Scaffold(
        backgroundColor: Colors.teal,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.health_and_safety, size: 80, color: Colors.white),
              const SizedBox(height: 24),
              Text(
                "$_selamlamaMetni, $_kayitliAd! ❤️",
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: Colors.white),
              ),
              const SizedBox(height: 10),
              const Text("Seray Sağlık Paneline Giriş Yapılıyor...", style: TextStyle(fontSize: 16, color: Colors.white70)),
              const SizedBox(height: 30),
              const CircularProgressIndicator(color: Colors.white),
            ],
          ),
        ),
      );
    }

    // DURUM B: İlk defa açıldığında gelen Profil Kayıt Ekranı
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profil Oluştur'), 
        backgroundColor: Colors.teal, 
        foregroundColor: Colors.white
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Icon(Icons.account_circle, size: 100, color: Colors.teal),
              const SizedBox(height: 16),
              const Text(
                'Hoş Geldiniz!\nSağlık panelinizi kişiselleştirmek için lütfen bilgilerinizi girin.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
              const SizedBox(height: 32),
              TextFormField(
                controller: _adController,
                decoration: const InputDecoration(labelText: 'Adınız', border: OutlineInputBorder()),
                validator: (v) => v == null || v.isEmpty ? 'Lütfen adınızı girin' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _soyadController,
                decoration: const InputDecoration(labelText: 'Soyadınız', border: OutlineInputBorder()),
                validator: (v) => v == null || v.isEmpty ? 'Lütfen soyadınızı girin' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _yasController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Yaşınız', border: OutlineInputBorder()),
                validator: (v) => v == null || int.tryParse(v) == null ? 'Lütfen geçerli bir yaş girin' : null,
              ),
              const SizedBox(height: 32),
              ElevatedButton(
                onPressed: _profiliKaydet,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.teal, 
                  foregroundColor: Colors.white, 
                  padding: const EdgeInsets.symmetric(vertical: 16)
                ),
                child: const Text('KAYDET VE BAŞLA', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
