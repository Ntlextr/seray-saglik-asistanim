import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart';
import 'analiz_sonuc_ekrani.dart';

class AnalizlerSayfasi extends StatefulWidget {
  const AnalizlerSayfasi({Key? key}) : super(key: key);

  @override
  _AnalizlerSayfasiState createState() => _AnalizlerSayfasiState();
}

class _AnalizlerSayfasiState extends State<AnalizlerSayfasi> {
  bool _isLoading = false;

  Future<void> pdfSecVeAnalizEt() async {
    setState(() {
      _isLoading = true;
    });

    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf'],
      );

      if (result != null && result.files.single.path != null) {
        File file = File(result.files.single.path!);
        
        final PdfDocument document = PdfDocument(inputBytes: await file.readAsBytes());
        String ayiklananMetin = PdfTextExtractor(document).extractText();
        document.dispose();

        if (mounted) {
          // Sayfa kapandığında ana panelin verileri yenilemesi için await kullanıyoruz
          await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => AnalizSonucEkrani(hamPdfMetni: ayiklananMetin),
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('PDF Okunurken Hata Oluştu: $e'), backgroundColor: Colors.red),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sağlık Raporu Analizi'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Center(
          child: _isLoading
              ? const Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircularProgressIndicator(color: Colors.teal),
                    SizedBox(height: 16),
                    Text('PDF Dosyası İşleniyor, Lütfen Bekleyin...'),
                  ],
                )
              : Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.picture_as_pdf, size: 100, color: Colors.teal),
                    const SizedBox(height: 24),
                    const Text(
                      'Tahlil veya Check-up PDF Raporunuzu Yükleyin',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Yapay zeka raporu inceleyerek tansiyon, şeker ve nabız değerlerinizi otomatik çıkartacaktır.',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 14, color: Colors.grey),
                    ),
                    const SizedBox(height: 40),
                    ElevatedButton.icon(
                      onPressed: pdfSecVeAnalizEt,
                      icon: const Icon(Icons.upload_file),
                      label: const Text('PDF YÜKLE & ANALİZ ET'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.teal,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                        textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}
