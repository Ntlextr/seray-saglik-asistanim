import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'screens/profil_kayit_ekrani.dart';
import 'screens/ana_sayfa.dart';
import 'screens/profil_sayfasi.dart';
import 'screens/ilac_ekrani.dart';
import 'screens/analizler_ekrani.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  final bool isLoggedIn = prefs.getBool('is_logged_in') ?? false;
  runApp(SeraySaglikUygulamasi(isLoggedIn: isLoggedIn));
}

class SeraySaglikUygulamasi extends StatelessWidget {
  final bool isLoggedIn;
  const SeraySaglikUygulamasi({Key? key, required this.isLoggedIn}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Seray Sağlık Asistanım',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.teal, scaffoldBackgroundColor: Colors.white),
      home: isLoggedIn ? const AnaEkranYonlendirici() : const ProfilKayitEkrani(),
    );
  }
}

class AnaEkranYonlendirici extends StatefulWidget {
  const AnaEkranYonlendirici({Key? key}) : super(key: key);
  @override
  _AnaEkranYonlendiriciState createState() => _AnaEkranYonlendiriciState();
}

class _AnaEkranYonlendiriciState extends State<AnaEkranYonlendirici> {
  int _seciliSekme = 0;
  // Sekme her seçildiğinde bu sayaç artar; sayfalara verilen key değiştiği için
  // Flutter o sayfayı sıfırdan kurar ve veriler (ölçümler, profil vb.) tazelenir.
  int _yenilemeSayaci = 0;

  @override
  Widget build(BuildContext context) {
    final List<Widget> sayfalar = [
      AnaSayfa(key: ValueKey('ana_$_yenilemeSayaci')),
      AnalizlerEkrani(key: ValueKey('analiz_$_yenilemeSayaci')),
      IlacEkrani(key: ValueKey('ilac_$_yenilemeSayaci')),
      ProfilSayfasi(key: ValueKey('profil_$_yenilemeSayaci')),
    ];
    return Scaffold(
      body: IndexedStack(index: _seciliSekme, children: sayfalar),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _seciliSekme,
        onDestinationSelected: (index) => setState(() {
          _seciliSekme = index;
          _yenilemeSayaci++;
        }),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Özet'),
          NavigationDestination(icon: Icon(Icons.analytics_outlined), selectedIcon: Icon(Icons.analytics), label: 'Analizler'),
          NavigationDestination(icon: Icon(Icons.medication_outlined), selectedIcon: Icon(Icons.medication), label: 'İlaçlarım'),
          NavigationDestination(icon: Icon(Icons.person_outlined), selectedIcon: Icon(Icons.person), label: 'Profil'),
        ],
      ),
    );
  }
}
