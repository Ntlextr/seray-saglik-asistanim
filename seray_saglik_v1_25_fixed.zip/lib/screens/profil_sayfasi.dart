import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import '../widgets/ust_menu.dart';

class ProfilSayfasi extends StatefulWidget {
  const ProfilSayfasi({Key? key}) : super(key: key);
  @override
  _ProfilSayfasiState createState() => _ProfilSayfasiState();
}

class _ProfilSayfasiState extends State<ProfilSayfasi> {
  String _ad = "..."; String _soyad = "...";
  int _yas = 0;
  String _diyabetTipi = "Yok";
  String? _fotoYolu;

  @override
  void initState() { super.initState(); _yukle(); }

  _yukle() async {
    final p = await SharedPreferences.getInstance();
    setState(() {
      _ad = p.getString('user_ad') ?? "";
      _soyad = p.getString('user_soyad') ?? "";
      _yas = p.getInt('user_yas') ?? 0;
      _diyabetTipi = p.getString('user_diyabet') ?? "Yok";
      _fotoYolu = p.getString('user_foto_yolu');
    });
  }

  Future<void> _fotoSec() async {
    final secim = await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(leading: const Icon(Icons.photo_camera), title: const Text('Fotoğraf Çek'), onTap: () => Navigator.pop(context, ImageSource.camera)),
            ListTile(leading: const Icon(Icons.photo_library), title: const Text('Galeriden Seç'), onTap: () => Navigator.pop(context, ImageSource.gallery)),
          ],
        ),
      ),
    );
    if (secim == null) return;

    try {
      final secilenDosya = await ImagePicker().pickImage(source: secim, maxWidth: 800, imageQuality: 80);
      if (secilenDosya == null) return;
      final p = await SharedPreferences.getInstance();
      await p.setString('user_foto_yolu', secilenDosya.path);
      setState(() => _fotoYolu = secilenDosya.path);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Fotoğraf alınamadı, izinleri kontrol edin.')));
    }
  }

  Future<void> _cikisYap() async {
    final onay = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Çıkış Yap'),
        content: const Text('Uygulamadan çıkmak istediğinize emin misiniz? Verileriniz cihazınızda saklı kalmaya devam edecek.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Vazgeç')),
          TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('ÇIKIŞ YAP')),
        ],
      ),
    );
    if (onay != true) return;
    // Gerçekten uygulamayı kapatır; profil bilgileri sonraki açılışta olduğu gibi kalır.
    SystemNavigator.pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Profil'), backgroundColor: Colors.teal, foregroundColor: Colors.white, actions: const [UstMenu()]),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(color: Colors.teal.shade50, borderRadius: BorderRadius.circular(16)),
                child: Column(
                  children: [
                    GestureDetector(
                      onTap: _fotoSec,
                      child: Stack(
                        children: [
                          CircleAvatar(
                            radius: 45,
                            backgroundColor: Colors.teal,
                            backgroundImage: _fotoYolu != null ? FileImage(File(_fotoYolu!)) : null,
                            child: _fotoYolu == null ? const Icon(Icons.person, size: 50, color: Colors.white) : null,
                          ),
                          Positioned(
                            bottom: 0,
                            right: 0,
                            child: Container(
                              padding: const EdgeInsets.all(4),
                              decoration: const BoxDecoration(color: Colors.orange, shape: BoxShape.circle),
                              child: const Icon(Icons.camera_alt, size: 16, color: Colors.white),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text('$_ad $_soyad', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
                    const Divider(height: 32),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Kayıtlı Yaş:', style: TextStyle(fontSize: 16)),
                        Text('$_yas', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.teal)),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Diyabet Durumu:', style: TextStyle(fontSize: 16)),
                        Text(_diyabetTipi, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.teal)),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              const Text('Yedekleme ve günlük sonuç paylaşımına artık sağ üstteki ☰ menüden ulaşabilirsiniz.', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.grey)),
              const SizedBox(height: 32),
              ElevatedButton.icon(
                onPressed: _cikisYap,
                icon: const Icon(Icons.logout),
                label: const Text('ÇIKIŞ YAP'),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.grey.shade700, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 14)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
