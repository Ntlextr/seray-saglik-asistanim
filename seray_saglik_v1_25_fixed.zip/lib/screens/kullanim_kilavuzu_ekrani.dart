import 'package:flutter/material.dart';

class KullanimKilavuzuEkrani extends StatelessWidget {
  const KullanimKilavuzuEkrani({Key? key}) : super(key: key);

  static const List<Map<String, String>> bolumler = [
    {
      'baslik': '🏠 Ana Sayfa',
      'metin': 'Ana sayfada en son girdiğiniz şeker ve tansiyon ölçümünüzü görürsünüz. "Şeker Ekle" ve "Tansiyon Ekle" butonlarıyla yeni ölçüm kaydedebilirsiniz.'
    },
    {
      'baslik': '📊 Analizler',
      'metin': 'Şeker ve tansiyon geçmişinizi burada tarih/saatiyle görürsünüz. Referans değerlerin dışındaki ölçümler kırmızı renkte gösterilir. Hoparlör ikonuna basarak ölçümü sesli dinleyebilirsiniz.'
    },
    {
      'baslik': '📄 e-Nabız Tahlil Okuma Merkezi',
      'metin': 'Analizler ekranındaki turuncu butondan e-Nabız\'dan indirdiğiniz PDF veya metin dosyasını yükleyin. Yapay zeka tahlilinizi okuyup tabloya işler ve size sade bir dille yorumlar; yorumu "Sesli Dinle" ile dinleyebilirsiniz.'
    },
    {
      'baslik': '💊 İlaçlarım',
      'metin': '"İlaç Ekle" ile ilacınızı, dozunu ve hatırlatma saatini girin. Belirlediğiniz saatte telefonunuz sesli olarak uyarır. Kalem ikonuyla düzenleyebilir, çöp kutusuyla silebilirsiniz.'
    },
    {
      'baslik': '👤 Profil',
      'metin': 'Adınızı, yaşınızı, diyabet durumunuzu ve fotoğrafınızı buradan güncelleyebilirsiniz. "Çıkış Yap" uygulamayı kapatır; verileriniz cihazınızda saklı kalır.'
    },
    {
      'baslik': '☰ Üst Menü',
      'metin': 'Her ekranın sağ üstündeki menüden: günlük ölçüm sonuçlarınızı PDF olarak paylaşabilir, verilerinizi yedekleyip geri yükleyebilir, ayarlara ve bu kılavuza her an ulaşabilirsiniz.'
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Kullanma Kılavuzu'), backgroundColor: Colors.teal, foregroundColor: Colors.white),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: bolumler.length,
        separatorBuilder: (context, index) => const SizedBox(height: 12),
        itemBuilder: (context, index) {
          final b = bolumler[index];
          return Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(b['baslik']!, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text(b['metin']!, style: const TextStyle(fontSize: 14, height: 1.4)),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
