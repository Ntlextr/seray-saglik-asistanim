import 'package:flutter/material.dart';
import '../services/veritabani_yardimcisi.dart';

class SekerEkleEkrani extends StatefulWidget {
  const SekerEkleEkrani({Key? key}) : super(key: key);
  @override
  _SekerEkleEkraniState createState() => _SekerEkleEkraniState();
}

class _SekerEkleEkraniState extends State<SekerEkleEkrani> {
  final _degerController = TextEditingController();
  String _durum = 'Açlık';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Şeker Ekle')),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            TextField(controller: _degerController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Değer (mg/dL)')),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: _durum,
              items: ['Açlık', 'Tokluk', 'Gece'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
              onChanged: (v) => setState(() => _durum = v!),
            ),
            const SizedBox(height: 32),
            ElevatedButton(
              onPressed: () async {
                await VeritabaniYardimcisi().sekerEkle({'deger': int.parse(_degerController.text), 'durum': _durum, 'tarih': DateTime.now().toIso8601String()});
                if (mounted) Navigator.pop(context, true);
              },
              child: const Text('KAYDET'),
            )
          ],
        ),
      ),
    );
  }
}
