import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../main.dart';

class ProfilKayitEkrani extends StatefulWidget {
  const ProfilKayitEkrani({Key? key}) : super(key: key);
  @override
  _ProfilKayitEkraniState createState() => _ProfilKayitEkraniState();
}

class _ProfilKayitEkraniState extends State<ProfilKayitEkrani> {
  final _formKey = GlobalKey<FormState>();
  final _adController = TextEditingController();
  final _soyadController = TextEditingController();
  final _yasController = TextEditingController();
  String _diyabetTipi = 'Yok';
  bool _kvkkOnay = false;

  @override
  void initState() {
    super.initState();
    _mevcutBilgileriYukle();
  }

  // Daha önce girilmiş profil varsa (örn. çıkış yapıp geri dönüldüğünde) alanları
  // önceden doldurur; kullanıcı her seferinde baştan yazmak zorunda kalmaz.
  Future<void> _mevcutBilgileriYukle() async {
    final prefs = await SharedPreferences.getInstance();
    final ad = prefs.getString('user_ad');
    if (ad == null) return; // ilk kurulum, dolduracak bir şey yok
    setState(() {
      _adController.text = ad;
      _soyadController.text = prefs.getString('user_soyad') ?? '';
      _yasController.text = (prefs.getInt('user_yas') ?? '').toString();
      _diyabetTipi = prefs.getString('user_diyabet') ?? 'Yok';
      _kvkkOnay = true; // KVKK metnini daha önce zaten onaylamıştı
    });
  }

  Future<void> _profiliKaydet() async {
    if (!_kvkkOnay) return;
    if (_formKey.currentState!.validate()) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('user_ad', _adController.text.trim());
      await prefs.setString('user_soyad', _soyadController.text.trim());
      await prefs.setInt('user_yas', int.parse(_yasController.text.trim()));
      await prefs.setString('user_diyabet', _diyabetTipi);
      await prefs.setBool('is_logged_in', true);
      if (mounted) {
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const AnaEkranYonlendirici()));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.teal.shade50,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Center(child: Image.asset('assets/images/app_logo.png', height: 120, width: 120)),
                const SizedBox(height: 16),
                const Text('Seray Sağlık Asistanım', textAlign: TextAlign.center, style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: Colors.teal)),
                const SizedBox(height: 24),
                TextFormField(controller: _adController, decoration: const InputDecoration(labelText: 'Adınız'), validator: (v) => v!.isEmpty ? 'Boş bırakılamaz' : null),
                const SizedBox(height: 16),
                TextFormField(controller: _soyadController, decoration: const InputDecoration(labelText: 'Soyadınız'), validator: (v) => v!.isEmpty ? 'Boş bırakılamaz' : null),
                const SizedBox(height: 16),
                TextFormField(controller: _yasController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Yaşınız'), validator: (v) => v!.isEmpty ? 'Boş bırakılamaz' : null),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  value: _diyabetTipi,
                  decoration: const InputDecoration(labelText: 'Diyabet Durumu'),
                  items: ['Yok', 'Tip 1 Diyabet', 'Tip 2 Diyabet', 'Gizli Şeker'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
                  onChanged: (v) => setState(() => _diyabetTipi = v!),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Checkbox(value: _kvkkOnay, onChanged: (v) => setState(() => _kvkkOnay = v!)),
                    const Expanded(child: Text('KVKK Aydınlatma Metnini okudum, onaylıyorum.', style: TextStyle(fontSize: 13))),
                  ],
                ),
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: _kvkkOnay ? _profiliKaydet : null,
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.teal, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 14)),
                  child: Text(_adController.text.isEmpty ? 'KAYDET VE BAŞLA' : 'BİLGİLERİ ONAYLA VE DEVAM ET', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
