import 'package:flutter/material.dart';
import '../services/veritabani_yardimcisi.dart';

class TansiyonEkleEkrani extends StatefulWidget {
  const TansiyonEkleEkrani({Key? key}) : super(key: key);
  @override
  _TansiyonEkleEkraniState createState() => _TansiyonEkleEkraniState();
}

class _TansiyonEkleEkraniState extends State<TansiyonEkleEkrani> {
  final _bController = TextEditingController();
  final _kController = TextEditingController();
  final _nController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Tansiyon Ekle')),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            TextField(controller: _bController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Büyük Tansiyon')),
            TextField(controller: _kController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Küçük Tansiyon')),
            TextField(controller: _nController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Nabız')),
            const SizedBox(height: 32),
            ElevatedButton(
              onPressed: () async {
                await VeritabaniYardimcisi().tansiyonEkle({'buyuk': int.parse(_bController.text), 'kucuk': int.parse(_kController.text), 'nabiz': int.parse(_nController.text), 'tarih': DateTime.now().toIso8601String()});
                if (mounted) Navigator.pop(context, true);
              },
              child: const Text('KAYDET'),
            )
          ],
        ),
      ),
    );
  }
}
