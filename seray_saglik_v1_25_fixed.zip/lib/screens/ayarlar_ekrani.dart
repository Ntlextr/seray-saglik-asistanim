import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';

class AyarlarEkrani extends StatelessWidget {
  const AyarlarEkrani({Key? key}) : super(key: key);

  static const String kvkkMetni = '''
KİŞİSEL VERİLERİN KORUNMASI AYDINLATMA METNİ

Seray Sağlık Asistanım ("Uygulama"), 6698 sayılı Kişisel Verilerin Korunması Kanunu ("KVKK") kapsamında kullanıcılarının kişisel verilerinin güvenliğine önem vermektedir.

1. Toplanan Veriler
Uygulama; ad-soyad, yaş, diyabet durumu gibi profil bilgilerinizi ile girdiğiniz tansiyon, kan şekeri, ilaç ve e-Nabız tahlil sonuçlarınızı içeren sağlık verilerinizi işler.

2. Verilerin Saklanma Yeri
Tüm verileriniz yalnızca kendi cihazınızda (yerel veritabanında) saklanır. Uygulama, verilerinizi hiçbir sunucuya otomatik olarak göndermez veya üçüncü kişilerle paylaşmaz.

3. Yapay Zeka Analizi
e-Nabız tahlillerinizi analiz ettirmek istediğinizde, yüklediğiniz belgenin metni yalnızca o anki yorumu oluşturmak amacıyla yapay zeka servis sağlayıcısına iletilir; bu içerik Uygulama tarafından ayrıca saklanmaz.

4. Yedekleme ve Paylaşım
"Yedekle" veya "Günlük Sonuçları Paylaş" özelliklerini kullandığınızda, oluşturulan dosya yalnızca sizin seçtiğiniz uygulama veya kişiyle (ör. WhatsApp, e-posta) paylaşılır. Bu paylaşımın sorumluluğu kullanıcıya aittir.

5. Haklarınız
KVKK'nın 11. maddesi uyarınca; verilerinizin işlenip işlenmediğini öğrenme, düzeltilmesini veya silinmesini isteme haklarına sahipsiniz. Uygulama içindeki "Çıkış Yap" ve profil düzenleme seçenekleriyle bilgilerinizi istediğiniz zaman güncelleyebilir veya kaldırabilirsiniz.

6. İletişim
Sorularınız için Seray Teknoloji ile iletişime geçebilirsiniz.
''';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ayarlar'), backgroundColor: Colors.teal, foregroundColor: Colors.white),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ExpansionTile(
              leading: const Icon(Icons.privacy_tip_outlined),
              title: const Text('KVKK Aydınlatma Metni'),
              children: [Padding(padding: const EdgeInsets.all(16), child: Text(kvkkMetni, style: const TextStyle(fontSize: 13, height: 1.4)))],
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.info_outline),
              title: const Text('Uygulama Hakkında'),
              subtitle: FutureBuilder<PackageInfo>(
                future: PackageInfo.fromPlatform(),
                builder: (context, snapshot) => Text(snapshot.hasData ? 'Sürüm ${snapshot.data!.version}' : 'Seray Sağlık Asistanım'),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
